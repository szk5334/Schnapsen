# v11 (Seth, Nov 28): ordering is automatic, shown as a delivery note; phone orders replace bouquets.
#   python3 v11_autoorder.py <index.html>      (edits in place; every edit must match exactly once)
import sys, re
P = sys.argv[1]
s = open(P, encoding='utf-8').read()

def rep(a, b, n=1):
    global s
    c = s.count(a)
    assert c == n, (c, a[:90])
    s = s.replace(a, b)

def cut(start, end, new):
    """replace from `start` up to (not including) `end`"""
    global s
    i = s.index(start); j = s.index(end, i)
    assert s.count(start) == 1
    s = s[:i] + new + s[j:]

# ---- save v7 -> v8 (bq gone; call and note added) ----
rep("function fresh(){G={v:7,", "function fresh(){G={v:8,")
rep("fx:0,fNew:0,hotD:null,bq:null}}", "fx:0,fNew:0,hotD:null,call:null,note:null}}")
rep("const KEY=CO?CO.key:'stockroom.v7';", "const KEY=CO?CO.key:'stockroom.v8';")
rep("if(!o||o.v!==7||", "if(!o||o.v!==8||")

# ---- styles ----
rep(".oc.bq{border-color:#ff8fcf;background:rgba(48,20,40,.94)}.oc.bq>b{background:#ffb3df}",
    ".oc.call{border-color:#5fd4c4;background:rgba(12,38,40,.94);flex-wrap:wrap;row-gap:4px;max-width:calc(100vw - 16px)}.oc.call>b{background:#9ff0e4}")
rep(".ohot img{width:26px;height:26px;vertical-align:middle;margin:0 2px}",
    ".ohot img{width:26px;height:26px;vertical-align:middle;margin:0 2px}\n"
    ".dnl{display:flex;flex-wrap:wrap;gap:6px;margin:6px 0 4px}.dnl span{display:inline-flex;align-items:center;gap:3px;background:#1b1e26;border:1px solid #333845;border-radius:9px;padding:3px 8px 3px 3px;font-weight:700;font-size:14px}.dnl img{width:34px;height:34px}.dnl.dim span{opacity:.6}")
rep("body.bigv .ohot img{width:36px;height:36px}",
    "body.bigv .ohot img{width:36px;height:36px}body.bigv .dnl img{width:48px;height:48px}body.bigv .dnl span{font-size:17px}")

# ---- genFlower: each line keeps its own materials (o.need), so a phone order can hold them line by line ----
rep("const order=[],need=[];const add=(p,n)=>{const o=order.find(o=>o.p===p);if(o)o.n+=n;else order.push({p,n,got:0})};",
    "const order=[],need=[];const add=(p,n,t)=>{let o=order.find(o=>o.p===p);if(o)o.n+=n;else order.push(o={p,n,got:0});if(t)o.need=(o.need||[]).concat(t);return o};")
rep("t.forEach(take);need.push(...t);add(compId(0,{b,g,r:0},{b:b2,g,r:0}),1);continue}",
    "t.forEach(take);need.push(...t);add(compId(0,{b,g,r:0},{b:b2,g,r:0}),1,t);continue}")
rep("const t=[blank,wholeId(b,NONE_G)];t.forEach(take);need.push(...t);add(r<0.5?invId(b,g,0):wholeId(b,g,0),1)}",
    "const t=[blank,wholeId(b,NONE_G)];t.forEach(take);need.push(...t);add(r<0.5?invId(b,g,0):wholeId(b,g,0),1,t)}")

# ---- bouquets -> phone orders ----
cut("// bouquet orders: a few coloured flowers due within a couple of rushes, handed in at any hatch\n",
    "// a custom thing's price grows",
    r"""// v11 phone orders (Seth, Nov 28; they replace v9's flower-only advance orders): someone calls ahead for a mix of plain catalogue things,
// custom things (once you have machines) and coloured flowers (once flowers arrive), due in 2-3 rushes.
// Everything is held from the call on (the plain things themselves, and the materials for what has to be made),
// so walk-in customers can't use it up. Handed in any time outside the order and summary, in any order.
function makeCall(){const av=stockCounts();const items=[];let val=0;const use=(p,n)=>{av[p]=(av[p]||0)-n};
 const np=1+(Math.random()<0.5?1:0);
 for(let i=0;i<np;i++){const p=wpick(knownProds().filter(q=>(av[q]||0)>=2&&!items.some(o=>o.p===q)));if(p==null)break;
  const n=Math.min(av[p],2+((Math.random()*2)|0));use(p,n);items.push({p,n,got:0});val+=n*PRICE}
 if(G.mach.length){const nc=G.mach.length>=3&&Math.random()<0.4?2:1;
  for(let i=0;i<nc;i++){const t=genCustom(av,null);if(t==null||items.some(o=>o.p===t))break;const st=genCustom.steps||1,u=(genCustom.use||[]).slice();
   u.forEach(p=>use(p,1));items.push({p:t,n:1,got:0,custom:true,steps:st,need:u});val+=customPrice(st)}}
 if(G.fx&&Math.random()<0.75){const c=genFlower(av,-1);if(c)for(const o of c.order){if(items.some(x=>x.p===o.p))continue;
  const it={p:o.p,n:o.n,got:0};if(o.need)it.need=o.need;items.push(it);val+=o.n*flowerPrice(o.p)}}
 if(items.length<2)return null;
 return{items,at:G.rounds,due:G.rounds+2+((Math.random()*2)|0),pay:Math.round(4+val*1.25)}}
// what the phone order holds: for each open line its materials (if it has to be made) and the thing itself
function callHold(){const m={},q=G.call;if(!q)return m;
 for(const o of q.items){if(o.got>=o.n)continue;m[o.p]=(m[o.p]||0)+o.n-o.got;if(o.need)for(const p of o.need)m[p]=(m[p]||0)+1}return m}
function serveCall(){const q=G.call;if(!q)return;let moved=0;
 for(;;){if(!G.hand.length)break;const o=q.items.find(o=>o.got<o.n&&o.p===G.hand[0]);if(!o)break;G.hand.shift();o.got++;moved++}
 ordersDirty=true;
 if(!q.items.some(o=>o.got<o.n)){G.stars+=q.pay;G.life+=q.pay;if(G.phase==='rush'&&RS)RS.stars+=q.pay;G.call=null;toast(`📞 Phone order done · +${q.pay}★`);sChime();save();return}
 if(moved){sGive(moved);if(G.hand.length)toast("Handed in. The next thing you're holding isn't on the phone order");save()}
 else{sErr();toast(G.hand.length?"That isn't on the phone order":'Your hands are empty')}}
""")
rep("if(!c){if(G.bq&&G.hand.length&&G.bq.items.some(o=>o.got<o.n&&o.p===G.hand[0])){serveBq();return}",
    "if(!c){if(G.call&&G.hand.length&&G.call.items.some(o=>o.got<o.n&&o.p===G.hand[0])){serveCall();return}")
rep("G.rounds++;if(G.bq&&G.rounds>=G.bq.due){RS.bqLost=1;G.bq=null}",
    "G.rounds++;if(G.call&&G.rounds>=G.call.due){RS.callLost=1;G.call=null}")

# customers never get promised what the phone order holds
rep("  if(hs.cust.need&&nextLine(hs.cust))for(const p of hs.cust.need)av[p]=(av[p]||0)-1}\n",
    "  if(hs.cust.need&&nextLine(hs.cust))for(const p of hs.cust.need)av[p]=(av[p]||0)-1}\n"
    " {const ch=callHold();for(const p in ch)av[p]=(av[p]||0)-ch[p]}\n")

# ---- the order phase: news, then the supplier's own order ----
rep(""" if(G.fx){for(const q of dyeLines())drift(q);if(!G.hotD&&Math.random()<0.5)G.hotD={p:rnd(dyeLines()),left:2};
  if(!G.bq&&G.rounds>=6&&Math.random()<0.6){G.bq=makeBouquet();ordersDirty=true}}
 G.newMach=checkUnlocks();rollSupply();G.phase='order';G.ord={};G.ordR={};save();showOrder()}""",
    """ if(G.fx){for(const q of dyeLines())drift(q);if(!G.hotD&&Math.random()<0.5)G.hotD={p:rnd(dyeLines()),left:2}}
 G.newMach=checkUnlocks();rollSupply();
 if(!G.call&&G.rounds>=3&&Math.random()<0.5){G.call=makeCall();ordersDirty=true}
 G.ordR={};autoOrder();G.phase='order';save();showOrder()}""")
rep("const flowerDemand=()=>custN()*FLOWER_SHARE*1.6+(G.bq?G.bq.items.reduce((a,o)=>a+o.n-o.got,0)/2:0);",
    "const flowerDemand=()=>custN()*FLOWER_SHARE*1.6;")

rep("function bestOrder(){const v=supplierView();G.ord={};for(const p in v)if(v[p].best)G.ord[p]=v[p].best}\n",
    r"""function bestOrder(){const v=supplierView();G.ord={};for(const p in v)if(v[p].best)G.ord[p]=v[p].best}
// v11 (Seth, Nov 28): ordering is automatic. The supplier buys every crate worth more than it costs (the same values
// as lineValues: sales over the next two rushes, crowds, trends, drift), best value per star first, and bills your stars.
// When stars run short the crates worth least per star are left out: sometimes you go without. It never orders more
// than the floor has room for. Stock the phone order holds doesn't count as yours to sell.
const FLOWER_VAL=2.5; // a flower sells for about 5★ and takes a blank flower and a dye tile
function autoOrder(){G.ord={};const st=stockCounts(),hold=callHold(),f=forecast(),cand=[],out=[];
 const have=p=>Math.max(0,(st[p]||0)-(hold[p]||0));
 for(const p of knownProds()){const v=lineValues(p,have(p),f),pr=priceAt(p),sp=supOf(p);
  if(!sp){if(v.ev.length>1&&v.ev[1]-v.ev[0]+CRATE_COST>pr)out.push(p);continue}
  for(let k=1;k<=sp&&k<v.ev.length;k++){const net=v.ev[k]-v.ev[k-1]+CRATE_COST-pr;if(net<=0)break;cand.push({p,k,net,pr})}}
 if(G.fx){const fd=flowerDemand(),sh=fShapes(),dl=dyeLines(),tw=dl.reduce((a,p)=>a+dyeW(dec(p).b),0)||1;
  for(const p of xLines()){const d=dec(p),m=1.5*(d.g===NONE_G?fd*dyeW(d.b)/tw:fd/sh.length),h0=have(p),pr=priceAt(p),sp=supOf(p);
   for(let k=1;k<=sp;k++){const net=FLOWER_VAL*(expSales(h0+CRATE*k,m)-expSales(h0+CRATE*(k-1),m))-pr;if(net<=0)break;cand.push({p,k,net,pr})}}}
 cand.sort((a,b)=>(b.net/b.pr-a.net/a.pr)||(a.k-b.k));
 let budget=G.stars,room=Math.floor(freeSpots()*2/CRATE);const broke={},full={},why={};
 for(;;){const i=cand.findIndex(c=>(G.ord[c.p]||0)===c.k-1&&!why[c.p]);if(i<0)break;const c=cand.splice(i,1)[0];
  if(room<=0)why[c.p]=full;else if(c.pr>budget)why[c.p]=broke;else{G.ord[c.p]=c.k;budget-=c.pr;room--;continue}
  why[c.p][c.p]=1}
 // a line's later crates go without with the one that didn't fit
 for(const c of cand)if(why[c.p])why[c.p][c.p]++;
 G.note={broke,full,out}}
""")
# ---- the delivery note replaces the order page ----
cut("// The supplier just reports the market, fashion-style: what's in, coming in, going out, out.\nconst MKT=",
    "function marketOf(p,avg)",
    "// The supplier reports the market, fashion-style (in, coming in, steady, going out, out); it sets supply and crate prices.\n")
cut("function showOrder(){", "\n\n// ---------- camera",
    r"""// v11: the delivery note. What the supplier picked, what it cost, what you went without, and the news.
function showOrder(){const n=G.note||{broke:{},full:{},out:[]},xl=new Set(xLines());
 const lines=Object.entries(G.ord).filter(([p,c])=>c>0).map(([p,c])=>[+p,c]).sort((a,b)=>(xl.has(a[0])-xl.has(b[0]))||(b[1]-a[1]));
 const chip=(p,x)=>`<span><img src="${iconURL(p)}" alt="">${x!=null?'×'+x:''}</span>`,imgs=l=>l.map(p=>`<img src="${iconURL(p)}" alt="">`).join('');
 const c=ordCrates(),cost=ordCost();
 let h=`<h2>Delivery note</h2><p class="olead">The supplier picked this delivery from what's selling and what you already have, and billed it to your stars. Crates hold ${CRATE}.</p>`;
 if(G.newMach.length)h+=`<p class="ohot" style="background:#22294a;border-color:#4a5aa0">🛠 New machine${G.newMach.length>1?'s':''} arriving: <b>${G.newMach.map(t=>MACH[t].name).join(' and ')}</b>. You'll place ${G.newMach.length>1?'them':'it'} after unloading. Customers will start asking for custom things.</p>`;
 if(G.fNew)h+=`<p class="ohot" style="background:#3a1d33;border-color:#a04a85">🌷 <b>Flowers have arrived.</b> From now on deliveries bring blank flowers and dye tiles too. In the dye swapper, a blank flower and a dye tile give the coloured flower <i>and</i> its inverse. Flower customers come to any hatch. This delivery brings a few free ones to start.</p>`;
 if(G.call){const q=G.call,l=q.due-G.rounds;h+=`<p class="ohot" style="background:#123033;border-color:#3f9e94">📞 <b>${q.at===G.rounds?'A phone order came in':'Phone order'}</b>: ${q.items.filter(o=>o.got<o.n).map(o=>`<img src="${iconURL(o.p)}" alt="">×${o.n-o.got}`).join(' ')} · due in ${l} rush${l===1?'':'es'} · pays <b>${q.pay}★</b>. What it needs is held for it. Hand it in any time, in any order: tap its card, or an empty hatch, with the things in hand.</p>`}
 if(G.hot&&G.hot.left>0)h+=`<p class="ohot">🔥 Trending: <img src="${iconURL(G.hot.p)}" alt=""> is wanted 2½× as much and sells for ${HOT_PRICE}★ each, for the next ${G.hot.left} rush${G.hot.left>1?'es':''}.</p>`;
 if(G.hotD&&G.hotD.left>0)h+=`<p class="ohot">🔥 Trending dye: <img src="${iconURL(G.hotD.p)}" alt=""> flowers in this colour pay ×1½ for the next ${G.hotD.left} rush${G.hotD.left>1?'es':''}.</p>`;
 if(G.newLines.length)h+=`<p class="ohot" style="background:#1d2a1f;border-color:#3f7a4a">🆕 New from the supplier: ${imgs(G.newLines)}</p>`;
 h+=`<div class="olist">`;
 if(lines.length)h+=`<div class="ohead"><b>Arriving</b> <span>${c} crate${c===1?'':'s'} · ${c*CRATE} things</span></div><div class="dnl">${lines.map(([p,k])=>chip(p,k*CRATE)).join('')}</div>`;
 else h+=`<p class="omuted">${Object.keys(n.broke).length?"Nothing this time: you're out of stars for it.":Object.keys(n.full).length?'Nothing this time: the floor is full.':'Nothing this time: you have enough of everything for now.'}</p>`;
 const br=Object.entries(n.broke),fu=Object.entries(n.full);
 if(br.length)h+=`<div class="ohead"><b>Went without</b> <span>not enough stars</span></div><div class="dnl dim">${br.map(([p,k])=>chip(+p,k*CRATE)).join('')}</div>`;
 if(fu.length)h+=`<div class="ohead"><b>Left on the truck</b> <span>no room on the floor</span></div><div class="dnl dim">${fu.map(([p,k])=>chip(+p,k*CRATE)).join('')}</div>`;
 if(n.out.length)h+=`<div class="ohead"><b>The supplier is out of</b> <span>${G.mach.length?'make them on your machines if you can':'none to be had this time'}</span></div><div class="dnl dim">${n.out.map(p=>chip(p)).join('')}</div>`;
 h+=`</div><div class="osum"><div>${cost?`Cost <b style="color:#ffd23f">${cost}★</b> · `:''}★ ${G.stars-cost} left after this</div>
  <div class="row" style="margin-top:8px"><button class="big" id="oGo">${c||G.fNew?'Unload':'Carry on'}</button></div></div>`;
 const card=$('#ovc');ov(h);card.classList.add('ord');card.scrollTop=0;
 $('#oGo').onclick=()=>{card.classList.remove('ord');placeOrder()}}""")

# ---- the 📞 card, the magnifier, taps ----
rep(""" if(G.bq&&G.phase!=='order'&&G.phase!=='sum'){const q=G.bq,nx=q.items.find(o=>o.got<o.n),l=q.due-G.rounds;
  h+=`<div class="oc bq" data-h="bq"><b>💐</b><span class="cut">${l} rush${l===1?'':'es'} · ${q.pay}★</span>`+q.items.map(o=>`<span class="it${o.got>=o.n?' done':''}${o===nx?' nx':''}"><img src="${iconURL(o.p)}" alt="">×${Math.max(0,o.n-o.got)}</span>`).join('<span class="ar">›</span>')+'</div>'}""",
    """ if(G.call&&G.phase!=='order'&&G.phase!=='sum'){const q=G.call,l=q.due-G.rounds;
  h+=`<div class="oc call" data-h="call"><b>📞</b><span class="cut">${l} rush${l===1?'':'es'} · ${q.pay}★</span>`+q.items.map(o=>`<span class="it${o.got>=o.n?' done':''}"><img src="${iconURL(o.p)}" alt="">×${Math.max(0,o.n-o.got)}</span>`).join('')+'</div>'}""")
rep(" if(h==='bq'){const q=G.bq;if(!q)return hideMag();const l=q.due-G.rounds;head=`<b>💐</b> Bouquet · ${l} rush${l===1?'':'es'} · ${q.pay}★`;lines=q.items;nx=q.items.find(o=>o.got<o.n);craft=true}",
    " if(h==='call'){const q=G.call;if(!q)return hideMag();const l=q.due-G.rounds;head=`<b>📞</b> Phone order · any order · ${l} rush${l===1?'':'es'} · ${q.pay}★`;lines=q.items;nx=null;craft=true}")
rep("if(oc.dataset.h==='bq'){serveBq();return}", "if(oc.dataset.h==='call'){serveCall();return}")
rep("if(ordersDirty||G.phase+(G.bq?'b':'')!==ordPh){ordPh=G.phase+(G.bq?'b':'');renderOrders()}",
    "if(ordersDirty||G.phase+(G.call?'c':'')!==ordPh){ordPh=G.phase+(G.call?'c':'');renderOrders()}")

# ---- help and summary ----
rep("<li>Between rushes you order stock from the supplier. Supply is limited (a few crates of each line, sometimes none) and prices follow the market. Each thing sold pays 2★ (trending things 5★); running out loses sales, unless you can make it on your machines. The order page shows everything you need: stock, the next-rush forecast, how long each line lasts, lost sales, and what's in, coming in, going out and out.</li>",
    "<li>Between rushes a delivery comes. The supplier picks it from what's selling and what you already have, and bills it to your stars, so when you're short you go without some things. Supply is limited, and sometimes a line runs out. Each thing sold pays 2★ (trending things 5★); running out loses sales, unless you can make it on your machines. The delivery note shows what's coming, what you went without, and what's trending.</li>")
rep("blank flowers and dye tiles on the order page.", "blank flowers and dye tiles start coming with deliveries.")
rep(" Now and then a <b>bouquet order</b> (💐) comes in: a few flowers due within a couple of rushes, handed in at any hatch or by tapping its card.", "")
rep("<li><b>Custom customers</b>",
    "<li><b>Phone orders</b> (📞) come in now and then: someone calls ahead for a mix of plain things, custom things and flowers, due within a couple of rushes. What they need is held for them, so other customers won't take it. Hand it in any time, in any order: tap the 📞 card, or an empty hatch, with the things in hand.</li>\n<li><b>Custom customers</b>")
rep("const nxt=G.rounds%3===0?'Day off':'Order stock';", "const nxt=G.rounds%3===0?'Day off':'Next delivery';")
rep("${r.bqLost?'<br>💐 The bouquet order lapsed':''}", "${r.callLost?'<br>📞 The phone order lapsed':''}")

rep("else if(G.phase==='down'){a.textContent='Order stock';a.disabled=false}", "else if(G.phase==='down'){a.textContent='Next delivery';a.disabled=false}")

rep("can be rising, steady or falling, and the drift shows on the order page", "can be rising, steady or falling; the supplier orders by it")

# free floor for a delivery: the same spots deliveries can land on (the cold case and closed storerooms don't count)
rep("function freeSpots(){let n=0;for(let k=0;k<N;k++)if(!SOLID[k]&&k!==BIN&&G.items[k]===-1)n++;return n}",
    "function freeSpots(){let n=0;for(let k=0;k<N;k++)if(free(k%W,(k/W)|0))n++;return n}")

# ---- test hooks ----
rep("genFlower,makeBouquet,serveBq,", "genFlower,makeCall,serveCall,callHold,autoOrder,showOrder,")

for w in ('G.bq', 'serveBq', 'makeBouquet', 'bqLost', "'bq'", 'Bouquet', 'bouquet', 'Order stock', 'order page', 'Interest #'):
    assert w not in s, w
open(P, 'w', encoding='utf-8').write(s)
print('v11 patched', P)
