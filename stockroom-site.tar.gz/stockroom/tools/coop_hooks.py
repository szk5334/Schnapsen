# Apply the co-op hooks to Stockroom's index.html (inert without window.SR_COOP).
import sys
p=sys.argv[1]; s=open(p,encoding='utf-8').read()
def rep(a,b,cnt=1):
    global s
    n=s.count(a)
    if n!=cnt: sys.exit(f"expected {cnt} of: {a[:80]!r}, found {n}")
    s=s.replace(a,b)
rep("const KEY='stockroom.v4';",
 "// Co-op: on the website a street adapter (stockroom/coop.js) sets window.SR_COOP before this script runs.\n"
 "// Without it (the artifact, or playing alone) every hook below is inert.\n"
 "const CO=window.SR_COOP||null;\n"
 "const KEY=CO?CO.key:'stockroom.v4';")
rep("hand:[],help:true,lastDel:0,lastNew:0,sheepIn:0,fc:0}}",
    "hand:[],help:true,lastDel:0,lastNew:0,sheepIn:0,fc:0,wait:false,pend:null,pendC:0,bd:-1}}")
rep("function closeOv(){$('#ov').classList.add('hidden');if(G&&G.phase==='order')setTimeout(showOrder,0)}",
    "function closeOv(){$('#ov').classList.add('hidden');if(G&&G.phase==='order'&&!G.wait)setTimeout(showOrder,0)}")
rep("function startRush(early){if(SH.on)giveUpSheep();botSettle();demoMode=false;const bonus=early&&isFinite(G.phaseT)?Math.floor(G.phaseT/15):0;",
    "function startRush(early,cb,cl){if(SH.on)giveUpSheep();botSettle();demoMode=false;G.wait=false;const bonus=cb!=null?(G.bd===G.rounds?0:cb):(early&&isFinite(G.phaseT)?Math.floor(G.phaseT/15):0);if(cb!=null)G.bd=G.rounds;")
rep("G.fc=fcMax();torchArmed=false;HS.forEach((h,i)=>{h.open=i<openN();h.cust=null;h.cd=0.6+i*2.2});ordersDirty=true;toast('Hatches open!');sBell()}",
    "G.fc=fcMax();torchArmed=false;HS.forEach((h,i)=>{h.open=i<openN();h.cust=null;h.cd=0.6+i*2.2});ordersDirty=true;save();toast('Hatches open!');sBell()}")
rep("G.phase='rush';G.phaseT=rushLen();RS={",
    "G.phase='rush';G.phaseT=cl||rushLen();RS={")
rep("if(G.rounds>=2){const L=rushLen(),",
    "if(G.rounds>=2){const L=G.phaseT,")
rep(" G.dn++;if(list.length){shuffle(list);place(list);",
    " if(CO){G.pend=list;G.pendC=cost;G.wait=true;G.ord={};G.newMach=[];closeOv();toast('Order in. Waiting for next door…');save();return}\n"
    " landDelivery(list,cost)}\n"
    "function landDelivery(list,cost){\n"
    " G.dn++;if(list.length){shuffle(list);place(list);")
rep(" G.sheepIn=(G.dn>=4&&Math.random()<0.06)?3:0;",
    " G.sheepIn=(!CO&&G.dn>=4&&Math.random()<0.06)?3:0;")
rep("function afterSummary(){if(G.rounds%3===0)",
    "function afterSummary(){if(CO){G.wait=true;save();toast('Waiting for next door…');return}if(G.rounds%3===0)")
rep("function startSheep(){if(SH.on||",
    "function startSheep(){if(CO||SH.on||")
rep("function actPress(){if(ovOpen())return;if(G.phase==='stock'){if(SH.on){toast('Shoo the sheep out first');sErr();return}startRush(true)}else if(G.phase==='down')openOrder()}",
    "function actPress(){if(ovOpen())return;if(G.phase==='stock'){if(SH.on){toast('Shoo the sheep out first');sErr();return}if(CO){CO.openHatches();return}startRush(true)}\n"
    " else if(G.phase==='down'){if(CO){G.wait=true;save();toast('Waiting for next door…');return}openOrder()}}")
rep(" if(G.phase==='stock')t=isFinite(G.phaseT)?`Delivery · ${fmt(G.phaseT)}`:'Delivery';",
    " if(G.wait)t='Waiting for next door…';\n"
    " else if(G.phase==='stock'){const lab=CO&&CO.opening()?'Opening the hatches…':'Delivery';t=isFinite(G.phaseT)?`${lab} · ${fmt(G.phaseT)}`:lab}")
rep("let ak;if(G.phase==='stock'){const b=isFinite(G.phaseT)?Math.floor(G.phaseT/15):0;ak='s'+b+(SH.on?'x':'')}else ak=G.phase;",
    "let ak;if(G.phase==='stock'){const b=isFinite(G.phaseT)?Math.floor(G.phaseT/15):0;ak='s'+b+(SH.on?'x':'')+(CO&&CO.opening()?'o':'')}else ak=G.phase;if(G.wait)ak+='w';")
rep("a.classList.toggle('hidden',!(G.phase==='stock'||G.phase==='down'));",
    "a.classList.toggle('hidden',!(G.phase==='stock'||G.phase==='down')||!!G.wait);")
rep("a.textContent='Open hatches'+(b?` · +${b}★`:'');a.disabled=SH.on}",
    "a.textContent='Open hatches'+(b?` · +${b}★`:'');a.disabled=SH.on||!!(CO&&CO.opening())}")
rep("$('#shopB').classList.toggle('hidden',G.phase!=='down')}}",
    "$('#shopB').classList.toggle('hidden',G.phase!=='down'||!!G.wait)}}")
rep(" if(ovOpen())return;\n if(G.phase==='stock'){if(!SH.on&&isFinite(G.phaseT)){G.phaseT-=dt;if(G.phaseT<=0)startRush(false)}",
    " if(ovOpen()&&!CO)return; // co-op never pauses: the street's clock keeps running\n"
    " if(CO&&(G.phase==='stock'||G.phase==='rush')){const e=CO.endAt(G.phase,G.rounds);if(e)G.phaseT=Math.max(0,(e-CO.now())/1000);else if(G.phase==='stock')G.phaseT=Infinity}\n"
    " if(G.phase==='stock'){if(!SH.on&&isFinite(G.phaseT)&&!CO){G.phaseT-=dt;if(G.phaseT<=0)startRush(false)}")
# menu: no "New stockroom" inside a street; a Street button instead
rep("<button id=\"mN\">New stockroom</button>",
    "${CO?'<button id=\"mT\">Street</button>':'<button id=\"mN\">New stockroom</button>'}")
rep("$('#mN').onclick=()=>{ov(`<h2>Start over?</h2>","if($('#mN'))$('#mN').onclick=()=>{ov(`<h2>Start over?</h2>")
s_menu_anchor="if($('#mU'))$('#mU').onclick=showShop;"
rep(s_menu_anchor, s_menu_anchor+"if($('#mT'))$('#mT').onclick=()=>CO.showStreet();")
rep("function newGame(){fresh();rebuildMap();",
    "function newGame(){fresh();if(CO)G.seed=CO.seed;rebuildMap();")
rep("if(G.help)showHelp();else if(G.phase==='sum')showSummary();else if(G.phase==='order')showOrder()}",
    "if(G.help)showHelp();else if(G.phase==='sum'&&!G.wait)showSummary();else if(G.phase==='order'&&!G.wait)showOrder()}")
rep("init();\n})();",
 "// What the street adapter may do to this warehouse: read where it is, and move it on when the street does.\n"
 "if(CO)CO.attach({\n"
 " info:()=>({ph:G.phase,d:G.rounds,w:!!G.wait,put:G.pend?Math.min(110,30+2*G.pend.length):0,rl:rushLen()}),\n"
 " land(){if(G.phase!=='order')return;const l=G.pend||[],c=G.pendC||0;G.pend=null;G.pendC=0;G.wait=false;G.ord={};landDelivery(l,c)},\n"
 " rush(b,L){if(G.phase==='stock')startRush(false,b,L)},\n"
 " end(){if(G.phase==='rush')endRush(false)},\n"
 " toDown(){G.wait=false;G.phase='down';G.phaseT=Infinity;actKey='';save();showShop()},\n"
 " toOrder(){G.wait=false;actKey='';openOrder()},\n"
 " ov,closeOv,ovOpen,toast,save:()=>save()});\n"
 "init();\n})();")
open(p,'w',encoding='utf-8').write(s)
print("hooks applied")
