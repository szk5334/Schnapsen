# Stockroom v8: the Display Case, the Cooler, freshness markers, hatch roles.
#   python3 v8_fresh_case.py <v74 index.html> <out index.html>
import sys
src, out = sys.argv[1:3]
s = open(src, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a)
    if n != cnt: sys.exit(f"expected {cnt} of: {a[:90]!r}, found {n}")
    s = s.replace(a, b)

# ---- zones ----
rep("const ix=(x,y)=>y*W+x, inF=(x,y)=>x>=0&&y>=0&&x<W&&y<H;",
"const ix=(x,y)=>y*W+x, inF=(x,y)=>x>=0&&y>=0&&x<W&&y<H;\n"
"// v8: the Display Case (bottom left, beside hatch 1) and the Cooler (top right).\n"
"// Case: one thing per spot. Fresh half x 3..5 (by the hatch), the rest x 0..2. Front row = y 14, the wall edge.\n"
"const CASE={x0:0,y0:13,x1:6,y1:15},COOL={x0:18,y0:0,x1:24,y1:4},CASE_H=0;\n"
"const CASEM=new Uint8Array(N),COOLM=new Uint8Array(N);\n"
"for(let y=CASE.y0;y<CASE.y1;y++)for(let x=CASE.x0;x<CASE.x1;x++)CASEM[y*W+x]=1;\n"
"for(let y=COOL.y0;y<COOL.y1;y++)for(let x=COOL.x0;x<COOL.x1;x++)COOLM[y*W+x]=1;\n"
"// spots in rank order: front row first, nearest the hatch first\n"
"const CSP_F=[],CSP_D=[];for(const y of[14,13]){for(let x=5;x>=3;x--)CSP_F.push(y*W+x);for(let x=2;x>=0;x--)CSP_D.push(y*W+x)}\n"
"const CSP=CSP_F.concat(CSP_D),FCOL=['','#ff6b6b','#ffd23f','#7bd88f'];")
rep("const free=(x,y)=>inF(x,y)&&!SOLID[ix(x,y)]&&G.items[ix(x,y)]===-1&&ix(x,y)!==BIN;",
    "const free=(x,y)=>inF(x,y)&&!SOLID[ix(x,y)]&&G.items[ix(x,y)]===-1&&ix(x,y)!==BIN&&!CASEM[ix(x,y)];")
rep("const capAt=k=>G.rack[k]?10:UV('stack');", "const capAt=k=>CASEM[k]?1:G.rack[k]?10:UV('stack');")

# ---- save v5 ----
rep("function fresh(){G={v:4,", "function fresh(){G={v:5,")
rep("wait:false,pend:null,pendC:0,bd:-1}}", "wait:false,pend:null,pendC:0,bd:-1,ct:null}}")
rep("const KEY=CO?CO.key:'stockroom.v4';", "const KEY=CO?CO.key:'stockroom.v5';")
rep("if(!o||o.v!==4||", "if(!o||o.v!==5||")

# ---- piles keep one freshness: runs and stacks only join with the same markers ----
rep("function runLen(){if(!G.hand.length)return 0;let n=1;while(n<G.hand.length&&G.hand[n]===G.hand[0])n++;return n}",
    "function runLen(){if(!G.hand.length)return 0;const fz=isFresh(G.hand[0]);let n=1;while(n<G.hand.length&&G.hand[n]===G.hand[0]&&(!fz||G.handF[n]===G.handF[0]))n++;return n}")
rep(" if(G.hand[0]!==v){toast('That stack is a different thing');sErr();return}\n",
    " if(G.hand[0]!==v){toast('That stack is a different thing');sErr();return}\n"
    " if(isFresh(v)&&G.fr[k]!==G.handF[0]){BLINK.set(k,performance.now());toast('Different freshness: give it its own pile');return}\n")
rep("if(G.items[c]===id&&G.cnt[c]<capAt(c)){G.cnt[c]++;",
    "if(G.items[c]===id&&!CASEM[c]&&G.cnt[c]<capAt(c)&&(!isFresh(id)||G.fr[c]===f)){G.cnt[c]++;")
rep("if(G.items[c]===-1&&c!==BIN&&!SOLID[c]&&!sheepOn(c%W,(c/W)|0)){G.items[c]=id;",
    "if(G.items[c]===-1&&c!==BIN&&!SOLID[c]&&!CASEM[c]&&!sheepOn(c%W,(c/W)|0)){G.items[c]=id;")
rep("if(!inF(x,y)||SOLID[k]||k===BIN||G.items[k]!==-1){toast('Machines need an empty spot');",
    "if(!inF(x,y)||SOLID[k]||k===BIN||CASEM[k]||G.items[k]!==-1){toast(CASEM[k]?'Machines can\\'t go in the Display Case':'Machines need an empty spot');")
rep("function placeRack(x,y){const k=ix(x,y);if(!inF(x,y)||SOLID[k]||k===BIN)return;",
    "function placeRack(x,y){const k=ix(x,y);if(!inF(x,y)||SOLID[k]||k===BIN)return;if(CASEM[k]){toast('Racks can\\'t go in the Display Case');return}")

# ---- Clunk: each freshness level is its own kind; he leaves the case alone ----
rep("function clusters(){const by=new Map();for(let k=0;k<N;k++){const v=G.items[k];if(v>=0&&!(POP.get(k)<0)){let a=by.get(v);if(!a)by.set(v,a=[]);a.push(k)}}\n const out=new Map();\n for(const[v,ks]of by){",
    "const kindK=(v,f)=>isFresh(v)?v+'/'+f:''+v;\n"
    "function clusters(){const by=new Map();for(let k=0;k<N;k++){const v=G.items[k];if(v>=0&&!CASEM[k]&&!(POP.get(k)<0)){const key=kindK(v,G.fr[k]);let a=by.get(key);if(!a)by.set(key,a={v,f:G.fr[k],ks:[]});a.ks.push(k)}}\n const out=new Map();\n for(const[key,{v,f,ks}]of by){")
rep("  out.set(v,{home,set,ks})}return out}", "  out.set(key,{v,f,home,set,ks})}return out}")
rep("if(G.items[c]===v&&G.cnt[c]<capAt(c)){const m=Math.min(n,capAt(c)-G.cnt[c]);",
    "if(G.items[c]===v&&!CASEM[c]&&G.cnt[c]<capAt(c)&&(!isFresh(v)||G.fr[c]===(f||3))){const m=Math.min(n,capAt(c)-G.cnt[c]);")
rep("else if(G.items[c]===-1&&c!==BIN&&!SOLID[c]){const m=Math.min(n,capAt(c));G.items[c]=v;",
    "else if(G.items[c]===-1&&c!==BIN&&!SOLID[c]&&!CASEM[c]){const m=Math.min(n,capAt(c));G.items[c]=v;")
rep("while(n<b.carry.length&&b.carry[n]===v){if(b.cf[n]>0)f=Math.min(f,b.cf[n]);n++}",
    "while(n<b.carry.length&&b.carry[n]===v&&(!isFresh(v)||b.cf[n]===b.cf[0])){if(b.cf[n]>0)f=Math.min(f,b.cf[n]);n++}")
rep(" for(const[v,c]of cl)for(const k of c.ks){if(c.set.has(k)||b.mine[k]===v)continue;",
    " for(const[,c]of cl){const v=c.v;for(const k of c.ks){if(c.set.has(k)||b.mine[k]===v)continue;")
rep("if(sc<bd){bd=sc;best={k,v}}}\n if(!best){", "if(sc<bd){bd=sc;best={k,v}}}}\n if(!best){")
rep("if(bf.d[k]>0&&bf.d[k]<pd&&G.items[k]===-1&&!inBayK(k)){", "if(bf.d[k]>0&&bf.d[k]<pd&&G.items[k]===-1&&!inBayK(k)&&!CASEM[k]){")
rep("let tgt=cl.get(v);B.mixed=false;", "let tgt=cl.get(kindK(v,b.cf[0]));B.mixed=false;")
rep("const alts=[...cl.keys()].filter(w=>w!==v&&pts(w).some(p=>pv.some(q=>p.b===q.b||p.g===q.g)));if(alts.length){tgt=cl.get(rnd(alts));B.mixed=true}",
    "const alts=[...cl.values()].filter(c=>c.v!==v&&pts(c.v).some(p=>pv.some(q=>p.b===q.b||p.g===q.g)));if(alts.length){tgt=rnd(alts);B.mixed=true}")

# ---- the Cooler: fresh things there lose a marker every other rush ----
rep("function spoil(){let n=0;for(let k=0;k<N;k++)if(G.fr[k]>0&&isFresh(G.items[k])){",
    "function spoil(){let n=0;for(let k=0;k<N;k++)if(G.fr[k]>0&&isFresh(G.items[k])&&!(COOLM[k]&&G.rounds%2===0)){")

# ---- prices: fresh things pay by their markers ----
rep("const priceOf=p=>hotOf(p)>1?HOT_PRICE:PRICE;",
    "const priceOf=p=>hotOf(p)>1?HOT_PRICE:PRICE;\n"
    "// fresh things pay by freshness: 3★, 2★ or 1★ (trending ×2½); everything else as before\n"
    "const priceItem=(p,f)=>isFresh(p)?Math.max(1,Math.min(3,f||3))*(hotOf(p)>1?2.5:1):priceOf(p);")
rep("RS.sold[o.p]=(RS.sold[o.p]||0)+1;G.hand.shift();",
    "RS.sold[o.p]=(RS.sold[o.p]||0)+1;o.val=(o.val||0)+priceItem(o.p,G.handF[0]);G.hand.shift();")
rep("sale+=o.n*priceOf(o.p);if(hotOf(o.p)>1)hot+=o.n}", "sale+=o.val!=null?o.val:o.n*priceOf(o.p);if(hotOf(o.p)>1)hot+=o.n}")

# ---- hatches: hatch 1 is the case hatch ----
rep("function newCust(){const av=stockCounts();", "function newCust(h){const av=stockCounts();")
rep("if(G.mach.length&&Math.random()<customShare()){const t=genCustom(av);",
    "if(G.mach.length&&Math.random()<customShare()){const t=genCustom(av,h===CASE_H?caseShown():null);")
rep("t3:(36+8*G.mach.length)*UV('patience')", "t3:1.5*(36+8*G.mach.length)*UV('patience')")
rep("for(let i=0;i<want;i++){let p=wpick(kn.filter(q=>!used.has(q)));",
    "for(let i=0;i<want;i++){let p=pickLine(kn.filter(q=>!used.has(q)),h);")
rep("if(!order.length){const p=wpick(kn.filter(q=>av[q]>0));", "if(!order.length){const p=pickLine(kn.filter(q=>av[q]>0),h);")
rep("function genCustom(av){const have=G.mach.map(m=>m.type);",
    "// what's in the case: catalogue line -> interest (front row 2, back row 1)\n"
    "function caseShown(){const m=new Map();for(const k of CSP){const v=G.items[k];if(v>=0&&isCat(v)){const f=((k/W)|0)===H-1?2:1;m.set(v,Math.max(m.get(v)||0,f))}}return m}\n"
    "// customers at the case hatch mostly want what's on display; elsewhere the case still draws a little interest\n"
    "function pickLine(list,h){const sh=caseShown();\n"
    " if(h===CASE_H&&sh.size&&Math.random()<0.8){const l=list.filter(p=>sh.has(p));if(l.length){let t=0;for(const p of l)t+=weightOf(p)*sh.get(p);let r=Math.random()*t;for(const p of l){r-=weightOf(p)*sh.get(p);if(r<=0)return p}return l[l.length-1]}}\n"
    " const w=p=>weightOf(p)*(sh.has(p)?1.3:1);let t=0;for(const p of list)t+=w(p);if(!list.length||t<=0)return null;let r=Math.random()*t;for(const p of list){r-=w(p);if(r<=0)return p}return list[list.length-1]}\n"
    "function genCustom(av,pref){const have=G.mach.map(m=>m.type);")
rep(" const kinds=[];if(have.includes('dye')&&wholes.length>=2)kinds.push('dye');",
    " let WH=wholes;if(pref&&Math.random()<0.75){const pw=wholes.filter(p=>pref.has(p));if(pw.length>=2)WH=pw}\n"
    " const kinds=[];if(have.includes('dye')&&wholes.length>=2)kinds.push('dye');")
rep("const A=rnd(wholes),B=rnd(wholes.filter(p=>p!==A));", "const A=rnd(WH),B=rnd(WH.filter(p=>p!==A));")
rep("HS.forEach(hs=>{if(!hs.open)return;if(hs.cust){hs.cust.t+=dt}else if(G.phaseT>6&&RS.total<custN()){hs.cd-=dt;if(hs.cd<=0){const c=newCust();",
    "HS.forEach((hs,hi)=>{if(!hs.open)return;if(hs.cust){hs.cust.t+=dt}else if(G.phaseT>6&&RS.total<custN()){hs.cd-=dt;if(hs.cd<=0){const c=newCust(hi);")

# ---- the case's targets: the best layout for what you have, worked out when a delivery lands ----
rep("function nextDelivery(){openOrder()}",
"function nextDelivery(){openOrder()}\n"
"// targets: fresh lines you hold (incl. extra) by interest into the fresh half, the rest into the other half\n"
"function caseTargets(extra){const have=stockCounts();if(extra)for(const p of extra)have[p]=(have[p]||0)+1;\n"
" const kn=knownProds().filter(p=>have[p]>0).sort((a,b)=>weightOf(b)-weightOf(a));const fz=kn.filter(isFresh),dr=kn.filter(p=>!isFresh(p));\n"
" return CSP_F.map((k,i)=>fz[i]??-1).concat(CSP_D.map((k,i)=>dr[i]??-1))}\n"
"const caseWrong=t=>t?CSP.reduce((n,k,i)=>n+(t[i]>=0&&G.items[k]!==t[i]?1:0),0):0;\n"
"const ctAt=k=>{const i=CSP.indexOf(k);return i<0||!G.ct?-1:G.ct[i]};\n"
"let caseSel=-1;const REDF=new Map(),BLINK=new Map();\n"
"function caseMark(k){const t=ctAt(k);if(t>=0&&G.items[k]!==t&&G.phase!=='rush')REDF.set(k,performance.now());else REDF.delete(k)}\n"
"function setCase(k,v,f){G.items[k]=v;G.cnt[k]=1;G.fr[k]=isFresh(v)?(f>0?f:3):0;POP.set(k,0);sDrop();caseMark(k)}\n"
"// The Display Case: one thing per spot. Between rushes: tap one thing, then another, to swap them; tap a thing\n"
"// twice to pick it up; with things in hand, tap a spot to put the first one in (a thing already there comes back\n"
"// to your hand). In the rush, a tap takes one, like anywhere else.\n"
"function caseTap(x,y){const k=ix(x,y),v=G.items[k],arr=G.phase!=='rush';\n"
" if(v===-2){tossRotten(x,y);return}\n"
" if(caseSel>=0&&(!arr||G.items[caseSel]<0))caseSel=-1;\n"
" if(v>=0){if(!arr){pickAt(x,y);return}\n"
"  if(G.hand.length){const hv=G.hand.shift(),hf=G.handF.shift();G.hand.push(v);G.handF.push(G.fr[k]);setCase(k,hv,hf);return}\n"
"  if(caseSel===k){caseSel=-1;pickAt(x,y);return}\n"
"  if(caseSel>=0){const a=caseSel,av=G.items[a],af=G.fr[a];setCase(a,v,G.fr[k]);setCase(k,av,af);caseSel=-1;return}\n"
"  caseSel=k;beep(600,0.04,'triangle',0.05,1.2);return}\n"
" if(caseSel>=0){const a=caseSel,av=G.items[a],af=G.fr[a];G.items[a]=-1;G.cnt[a]=0;G.fr[a]=0;REDF.delete(a);setCase(k,av,af);caseSel=-1;return}\n"
" if(G.hand.length){const hv=G.hand.shift(),hf=G.handF.shift();setCase(k,hv,hf);return}\n"
" toast('The Display Case: one thing per spot. Faded pictures show the best layout.')}")
rep(" G.lastDel=list.length;G.ord={};G.phase='stock';G.phaseT=Math.min(110,30+2*list.length);",
    " G.lastDel=list.length;G.ord={};G.phase='stock';G.ct=caseTargets();REDF.clear();caseSel=-1;\n"
    " G.phaseT=Math.min(110,30+2*list.length)+3*caseWrong(G.ct); // arranging the case gets its own time: 3 s a spot")
rep("demoMode=false;deliver();G.phase='stock';", "demoMode=false;deliver();G.ct=caseTargets();G.phase='stock';")
rep(" if(load()){makeCat(G.seed);rebuildMap();makeHS();", " if(load()){makeCat(G.seed);rebuildMap();makeHS();if(!G.ct)G.ct=caseTargets();")
rep(" info:()=>({ph:G.phase,d:G.rounds,w:!!G.wait,put:G.pend?Math.min(110,30+2*G.pend.length):0,rl:rushLen()}),",
    " info:()=>({ph:G.phase,d:G.rounds,w:!!G.wait,put:G.pend?Math.min(110,30+2*G.pend.length)+3*caseWrong(caseTargets(G.pend)):0,rl:rushLen()}),")

# ---- taps ----
rep(" if(machMode){placeMachine(cx,cy);return}\n if(ix(cx,cy)===BIN){binTap();return}",
    " if(machMode){placeMachine(cx,cy);return}\n if(CASEM[ix(cx,cy)]){caseTap(cx,cy);return}\n if(ix(cx,cy)===BIN){binTap();return}")
rep("if(demoMode||rackMode||machMode||!inF(cx,cy)||SOLID[ix(cx,cy)]||ix(cx,cy)===BIN||G.items[ix(cx,cy)]===-1){tap(wx,wy);return}",
    "if(demoMode||rackMode||machMode||!inF(cx,cy)||SOLID[ix(cx,cy)]||ix(cx,cy)===BIN||CASEM[ix(cx,cy)]||G.items[ix(cx,cy)]===-1){tap(wx,wy);return}")

# ---- drawing ----
rep(" fr(BAY.x0,BAY.y0,BAY.x1-BAY.x0,BAY.y1-BAY.y0,'rgba(255,210,63,.07)');",
" drawZones();\n fr(BAY.x0,BAY.y0,BAY.x1-BAY.x0,BAY.y1-BAY.y0,'rgba(255,210,63,.07)');")
rep("function draw(){",
"// the Cooler (frost blue) and the Display Case (glass front on the wall edge, fresh half green, the rest brown),\n"
"// with faded pictures of the best layout on its empty spots\n"
"function drawZones(){const px=S*DPR;\n"
" fr(COOL.x0,COOL.y0,COOL.x1-COOL.x0,COOL.y1-COOL.y0,'rgba(120,190,255,.10)');\n"
" {const r=wr(COOL.x0+0.06,COOL.y0+0.06,COOL.x1-COOL.x0-0.12,COOL.y1-COOL.y0-0.12);ctx.strokeStyle='rgba(140,200,255,.7)';ctx.lineWidth=Math.max(2,S*0.06);ctx.setLineDash([S*0.18,S*0.18]);ctx.strokeRect(r[0],r[1],r[2],r[3]);ctx.setLineDash([]);\n"
"  const[sx,sy]=w2s(COOL.x1-0.5,COOL.y1-0.5);ctx.fillStyle='rgba(170,215,255,.55)';ctx.font=`${Math.round(S*0.55)}px system-ui`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('❄',sx,sy)}\n"
" fr(3,13,3,2,'rgba(123,216,143,.11)');fr(0,13,3,2,'rgba(197,154,98,.11)');\n"
" {const r=wr(CASE.x0+0.04,CASE.y0+0.04,CASE.x1-CASE.x0-0.08,CASE.y1-CASE.y0-0.08);ctx.strokeStyle='rgba(150,230,240,.75)';ctx.lineWidth=Math.max(2,S*0.07);ctx.strokeRect(r[0],r[1],r[2],r[3]);\n"
"  const a=w2s(3,13.1),b=w2s(3,14.9);ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.stroke();\n"
"  const m=w2s(0.1,14),n=w2s(5.9,14);ctx.strokeStyle='rgba(150,230,240,.25)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(m[0],m[1]);ctx.lineTo(n[0],n[1]);ctx.stroke();\n"
"  const g1=w2s(0,H-0.03),g2=w2s(6,H-0.03);ctx.strokeStyle='rgba(190,245,255,.9)';ctx.lineWidth=Math.max(3,S*0.1);ctx.beginPath();ctx.moveTo(g1[0],g1[1]);ctx.lineTo(g2[0],g2[1]);ctx.stroke()}\n"
" if(G.ct)CSP.forEach((k,i)=>{const t=G.ct[i];if(t<0||G.items[k]!==-1)return;const r=wr(k%W+0.12,((k/W)|0)+0.12,0.76,0.76);ctx.globalAlpha=0.24;ctx.drawImage(tileImg(t,px),r[0],r[1],r[2],r[3]);ctx.globalAlpha=1})}\n"
"// a target picture tinted red, for a spot holding the wrong thing\n"
"const REDT=new Map();function redTile(id,px){const key=id+'@'+Math.round(px);let c=REDT.get(key);if(c)return c;c=document.createElement('canvas');c.width=c.height=Math.max(8,Math.round(px));const g=c.getContext('2d');\n"
" g.drawImage(tileImg(id,px),0,0,c.width,c.height);g.globalCompositeOperation='source-atop';g.fillStyle='rgba(255,45,45,.72)';g.fillRect(0,0,c.width,c.height);if(REDT.size>200)REDT.clear();REDT.set(key,c);return c}\n"
"function drawCaseMarks(){if(!G.ct)return;const now=performance.now(),px=S*DPR;\n"
" CSP.forEach((k,i)=>{const t=G.ct[i],v=G.items[k];if(t<0||v===-1||v===t){REDF.delete(k);return}const ft=REDF.get(k),fl=ft!=null&&now-ft<900;\n"
"  const r=wr(k%W+0.22,((k/W)|0)+0.22,0.56,0.56);ctx.globalAlpha=fl?(Math.floor((now-ft)/150)%2?1:0.65):0.6;ctx.drawImage(redTile(t,px),r[0],r[1],r[2],r[3]);ctx.globalAlpha=1;\n"
"  const o=wr(k%W+0.04,((k/W)|0)+0.04,0.92,0.92);ctx.strokeStyle=fl?'#ff3b3b':'rgba(255,90,90,.8)';ctx.lineWidth=Math.max(2,S*(fl?0.09:0.05));ctx.strokeRect(o[0],o[1],o[2],o[3])});\n"
" if(caseSel>=0){const o=wr(caseSel%W-0.04,((caseSel/W)|0)-0.04,1.08,1.08);ctx.strokeStyle='#ffd23f';ctx.lineWidth=3;ctx.strokeRect(o[0],o[1],o[2],o[3])}}\n"
"// freshness markers: 3, 2 or 1 dots (green, yellow, red); they blink when a pile refuses a different freshness\n"
"function drawMarks(r,f,k){const bt=BLINK.get(k),now=performance.now(),bl=bt!=null&&now-bt<700;if(bt!=null&&!bl)BLINK.delete(k);\n"
" const n=Math.min(3,f),d=Math.max(3.2,S*0.085),col=FCOL[n];\n"
" for(let i=0;i<n;i++){const fx=r[0]+r[2]*0.13+i*d*2.3,fy=r[1]+r[3]*0.14;ctx.fillStyle=bl&&Math.floor((now-bt)/120)%2===0?'#fff':col;ctx.strokeStyle='#14161c';ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(fx,fy,d*(bl?1.35:1),0,7);ctx.fill();ctx.stroke()}}\n"
"function draw(){")
rep("if(G.fr[k]>0&&isFresh(v)){const fx=r[0]+r[2]*0.16,fy=r[1]+r[3]*0.16,fr2=Math.max(4,S*0.11);ctx.fillStyle=['','#ff6b6b','#ffd23f','#7bd88f'][G.fr[k]]||'#7bd88f';ctx.strokeStyle='#14161c';ctx.lineWidth=2;ctx.beginPath();ctx.arc(fx,fy,fr2,0,7);ctx.fill();ctx.stroke()}}",
    "if(G.fr[k]>0&&isFresh(v))drawMarks(r,G.fr[k],k)}\n drawCaseMarks();")
rep("  fr(x+0.06,H+0.06,0.88,0.88,hs.open?'#56627d':'#2e333f');",
    "  fr(x+0.06,H+0.06,0.88,0.88,hs.open?'#56627d':'#2e333f');\n"
    "  if(i===CASE_H){const r=wr(x+0.03,H+0.03,0.94,0.94);ctx.strokeStyle='rgba(150,230,240,.9)';ctx.lineWidth=Math.max(2,S*0.07);ctx.strokeRect(r[0],r[1],r[2],r[3])}")

# ---- HUD: case-hatch cards, freshness on things in hand ----
rep("h+=`<div class=\"oc${c.farmer?' farm':''}${c.custom?' cu':''}\" data-h=\"${i}\">",
    "h+=`<div class=\"oc${c.farmer?' farm':''}${c.custom?' cu':''}${i===CASE_H?' ch':''}\" data-h=\"${i}\">")
rep(".oc.farm{border-color:#7bd88f}", ".oc.farm{border-color:#7bd88f}\n.oc.ch>b{background:#8fe6f0}\n#hand .hw{position:relative;display:block}#hand .fm{position:absolute;left:3px;top:2px;display:flex;gap:2px;pointer-events:none}#hand .fm b{width:6px;height:6px;border-radius:50%;border:1px solid #14161c}")
rep(" const hk=G.hand.join(',')+'/'+cap();", " const hk=G.hand.join(',')+'|'+G.handF.join(',')+'/'+cap();")
rep("G.hand.map((p,i)=>`<img src=\"${iconURL(p)}\" alt=\"\"${i===0?' class=\"first\"':''}>`).join('')",
    "G.hand.map((p,i)=>{const im=`<img src=\"${iconURL(p)}\" alt=\"\"${i===0?' class=\"first\"':''}>`,f=Math.min(3,G.handF[i]|0);return f>0&&isFresh(p)?`<span class=\"hw\">${im}<span class=\"fm\">${`<b style=\"background:${FCOL[f]}\"></b>`.repeat(f)}</span></span>`:im}).join('')")

# ---- order page: interest rank and fresh prices ----
rep("Everything sells for ${PRICE}★ (trending ${HOT_PRICE}★), and running out loses the sale.",
    "Things sell for ${PRICE}★ (trending ${HOT_PRICE}★); fresh things pay by freshness, 3★, 2★ or 1★ (trending ×2½). Running out loses the sale. <b>#</b> is a line's interest rank, which sets the Display Case's layout.")
rep(" const MI=Object.fromEntries(MKT.map((m,i)=>[m.k,i]));",
    " const RK=new Map(kn.slice().sort((a,b)=>weightOf(b)-weightOf(a)).map((p,i)=>[p,i+1]));\n const MI=Object.fromEntries(MKT.map((m,i)=>[m.k,i]));")
rep("tags.push(`<span class=\"tg\">Sells for ${r.hot?HOT_PRICE:PRICE}★ each</span>`);",
    "tags.push(`<span class=\"tg\">Interest #${RK.get(r.p)} of ${kn.length}</span>`);tags.push(r.fresh?`<span class=\"tg\">Sells for ${r.hot?'7½/5/2½':'3/2/1'}★ by freshness</span>`:`<span class=\"tg\">Sells for ${r.hot?HOT_PRICE:PRICE}★ each</span>`);")
rep("if(r.fresh)tags.push('<span class=\"tg fr\">Fresh: spoils after 3 rushes</span>');",
    "if(r.fresh)tags.push('<span class=\"tg fr\">Fresh: 3 rushes, 6 in the Cooler</span>');")

# ---- help ----
rep("<li>Some pictures are fresh (every colour of them, and halves too): they get a coloured dot, green, then yellow, then red. Sell them within three rushes or they spoil. Tap a rotten stack to throw it out (or tap your hands to dump any rotten things you're holding).</li>",
    "<li>Some pictures are fresh (every colour of them, and halves too). Fresh piles carry <b>freshness markers</b>: three, then two, then one, then they spoil. Fresher things sell for more (3★, 2★, 1★), so you choose which pile to sell from. Only piles with the same number of markers stack. The <b>Cooler</b> (top right, ❄) keeps fresh things twice as long. Tap a rotten stack to throw it out (or tap your hands to dump any rotten things you're holding).</li>\n"
    "<li><b>The Display Case</b> (bottom left, beside hatch 1) holds one thing per spot: fresh things on the half by the hatch, everything else on the other half. Faded pictures show the best layout, the most wanted at the front by the wall; red means the wrong thing is in a spot. Between rushes, tap one thing and then another to swap them (tap a thing twice to pick it up). Customers at hatch 1 mostly want what's on display, custom orders too.</li>")
rep("rebuildMap,setDemo:v=>{demoMode=v}};","rebuildMap,setDemo:v=>{demoMode=v},\n caseTap,caseTargets,caseWrong,caseShown,newCust,priceItem,landDelivery,runLen,putAt,pickAt,CSP,CASEM,COOLM,get caseSel(){return caseSel}};")
open(out, 'w', encoding='utf-8').write(s)
print("v8 applied")
