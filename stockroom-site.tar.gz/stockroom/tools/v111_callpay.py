# v11.1 (Seth, Nov 28): phone orders pay only as well as custom orders: each thing at its walk-in price
# (plain 2★, custom 10★ + 2★ a step, flowers 5-8★) plus the 3★ a quick customer adds. No premium.
#   python3 v111_callpay.py <index.html>
import sys
P=sys.argv[1];s=open(P,encoding='utf-8').read()
a="return{items,at:G.rounds,due:G.rounds+2+((Math.random()*2)|0),pay:Math.round(4+val*1.25)}}"
b="return{items,at:G.rounds,due:G.rounds+2+((Math.random()*2)|0),pay:Math.round(val)+3}}"
assert s.count(a)==1;s=s.replace(a,b)
a="// Everything is held from the call on"
b="// Pay (v11.1, Seth: \"only just as lucrative as custom orders\"): each thing at its walk-in price + the 3★ a quick customer adds.\n// Everything is held from the call on"
assert s.count(a)==1;s=s.replace(a,b)
open(P,'w',encoding='utf-8').write(s);print('v11.1 patched',P)
