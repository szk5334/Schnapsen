# Stockroom v8.2: a custom customer's recipe reserves its materials, so later customers can't ask for the
# same whole thing (Seth, Nov 27: "one guy wanted a whole moon and I only had half a moon").
import sys
src, out = sys.argv[1:3]
s = open(src, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a)
    if n != cnt: sys.exit(f"expected {cnt} of: {a[:90]!r}, found {n}")
    s = s.replace(a, b)
rep(" for(let tries=0;tries<12;tries++){const A=rnd(WH),B=rnd(WH.filter(p=>p!==A));if(B==null)return null;const a=dec(A),c=dec(B);let t;",
    " for(let tries=0;tries<12;tries++){const A=rnd(WH),B=rnd(WH.filter(p=>p!==A));if(B==null)return null;const a=dec(A),c=dec(B);let t,use=[A,B];")
rep("  if(kind==='rot'){t=wholeId(a.b,a.g,a.r+1+((Math.random()*3)|0))}",
    "  if(kind==='rot'){t=wholeId(a.b,a.g,a.r+1+((Math.random()*3)|0));use=[A]}")
rep("if(hs.length&&Math.random()<0.6){const h=dec(rnd(hs));const first=",
    "if(hs.length&&Math.random()<0.6){const hid=rnd(hs),h=dec(hid);use=[hid,B];const first=")
rep("  if(dec(t).t==='w'&&isCat(t))continue;if(av[t]>0)continue;return t}return null}",
    "  if(dec(t).t==='w'&&isCat(t))continue;if(av[t]>0)continue;genCustom.use=use;return t}return null}")
rep("for(const hs of HS)if(hs.cust&&!hs.cust.farmer)for(const o of hs.cust.order)av[o.p]=(av[o.p]||0)-(o.n-o.got);",
    "for(const hs of HS)if(hs.cust&&!hs.cust.farmer){for(const o of hs.cust.order)av[o.p]=(av[o.p]||0)-(o.n-o.got);\n"
    "  // a custom customer's recipe holds its materials, so nobody else is promised the same things\n"
    "  if(hs.cust.need&&nextLine(hs.cust))for(const p of hs.cust.need)av[p]=(av[p]||0)-1}")
rep("return{order:[{p:t,n:1,got:0,custom:true}],t:0,t3:1.5*(36+8*G.mach.length)*UV('patience'),face:rnd(FACES),shirt:rnd(SHIRTS),custom:true}",
    "return{order:[{p:t,n:1,got:0,custom:true}],need:genCustom.use||[],t:0,t3:1.5*(36+8*G.mach.length)*UV('patience'),face:rnd(FACES),shirt:rnd(SHIRTS),custom:true}")
open(out, 'w', encoding='utf-8').write(s)
print("v8.2 applied")
