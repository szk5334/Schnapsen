# Stockroom v9: flowers, dyes (with a trend), the colour stripper, inverse things, bouquet orders, a 3-section Display Case.
#   python3 v9_flowers.py <v8.2 index.html> <out>
import sys
src, out = sys.argv[1:3]
s = open(src, encoding='utf-8').read()
FLOWER_GL = open(__import__('os').path.join(__import__('os').path.dirname(__file__),'flowerglyphs.js')).read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a)
    if n != cnt: sys.exit(f"expected {cnt} of: {a[:100]!r}, found {n}")
    s = s.replace(a, b)

# ---------- pictures: 37 catalogue pictures, 37 = none, 38–42 flowers ----------
rep(" {p:'M24 14h52v8L56 50L76 78v8H24v-8L44 50L24 22Z'},\n];",
    " {p:'M24 14h52v8L56 50L76 78v8H24v-8L44 50L24 22Z'},\n {}, // 37: no picture (dye tiles)\n // 38–42: flowers (tulip, rose, bells, daisy on a stem, lily); only ever flowers, always fresh\n " + FLOWER_GL + "\n];")
rep("const FRESH_G=new Set([9,10,17,20,21,26]);",
    "const FRESH_G=new Set([9,10,17,20,21,26,38,39,40,41,42]);\n"
    "const FLOWERS=[38,39,40,41,42],FLOWER_G=new Set(FLOWERS);")
rep("const SYM=[4,4,4,4,1,1,1,1,4,1,1,1,4,4,1,2,1,1,1,1,1,4,1,1,1,2,1,1,2,1,1,1,2,2,4,1,2];",
    "const SYM=[4,4,4,4,1,1,1,1,4,1,1,1,4,4,1,2,1,1,1,1,1,4,1,1,1,2,1,1,2,1,1,1,2,2,4,1,2, 1, 1,1,1,1,1];")
rep(" const nb=BG.length,ng=GL.length;const first=[];", " const nb=BG.length,ng=37;const first=[];")

# ---------- inverse things: 14096 + pkey (wholes only) ----------
rep("function dec(id){if(id==null||id<0)return null;",
    "// inverse things: the picture coloured, the tile left plain. Wholes only (14096..19999).\n"
    "const INV0=14096;const invId=(b,g,r=0)=>INV0+pkey(b,g,r);\n"
    "function dec(id){if(id==null||id<0)return null;")
rep(" if(id<20000)return{t:'w',...unk(id-10000)};",
    " if(id<INV0)return{t:'w',...unk(id-10000)};\n if(id<20000)return{t:'w',...unk(id-INV0),inv:true};")
rep(" if(d.t==='w')return wholeId(d.b,d.g,d.r+1);", " if(d.t==='w')return d.inv?invId(d.b,d.g,d.r+1):wholeId(d.b,d.g,d.r+1);")
rep("const isBlankWhole=d=>d&&d.t==='w'&&(d.b===BLANK_B||d.g===NONE_G);",
    "const isBlankWhole=d=>d&&d.t==='w'&&!d.inv&&(d.b===BLANK_B||d.g===NONE_G);\n"
    "const isFlowerD=d=>!!d&&(d.t==='c'?FLOWER_G.has(d.a.g)||FLOWER_G.has(d.c.g):FLOWER_G.has(d.g));\n"
    "const isFlower=v=>isFlowerD(dec(v));\n"
    "const isBlankShape=d=>!!d&&d.t==='w'&&!d.inv&&d.b===BLANK_B&&d.g!==NONE_G;\n"
    "const isDyeD=d=>!!d&&d.t==='w'&&!d.inv&&d.g===NONE_G&&d.b!==BLANK_B;\n"
    "const colouredFlower=v=>{const d=dec(v);return isFlowerD(d)&&(d.t==='c'?d.a.b!==BLANK_B&&d.c.b!==BLANK_B:d.t==='w'&&d.b!==BLANK_B)};")
rep("function paintItem(g,id,px){if(id===-2)return paintSpoiled(g,px);const d=dec(id);if(!d)return;\n if(d.t==='w')return paintParts(g,px,[{b:d.b,g:d.g,r:d.r}]);",
    "// an inverse: a plain tile with a coloured rim, the picture in the colour\n"
    "function paintInv(g,px,d){const m=px*0.06,s=px-2*m,r=s*0.2,col=COLS[d.b],pale='#f6f2e8';\n"
    " g.fillStyle='#cfc8b8';rr(g,m,m+px*0.05,s,s-px*0.05,r);g.fill();g.fillStyle=pale;rr(g,m,m,s,s-px*0.06,r);g.fill();\n"
    " g.strokeStyle=col;g.lineWidth=Math.max(1.5,px*0.06);rr(g,m+px*0.04,m+px*0.04,s-px*0.08,s-px*0.14,r*0.8);g.stroke();\n"
    " const gx=px/2,gy=px/2-px*0.03,sz=s*0.64;g.save();if(d.r){g.translate(gx,gy);g.rotate(d.r*Math.PI/2);g.translate(-gx,-gy)}\n"
    " drawGlyph(g,d.g,col,pale,gx,gy,sz);if(CAPPED.has(d.g)){g.fillStyle=col;rr(g,gx-sz*0.3,gy-sz*0.64,sz*0.6,sz*0.1,sz*0.05);g.fill()}g.restore()}\n"
    "function paintItem(g,id,px){if(id===-2)return paintSpoiled(g,px);const d=dec(id);if(!d)return;\n"
    " if(d.t==='w')return d.inv?paintInv(g,px,d):paintParts(g,px,[{b:d.b,g:d.g,r:d.r}]);")

# ---------- the colour stripper; the swapper's inverse rule; flowers join only with flowers ----------
rep("const UNLOCKS=[{r:2,t:['dye']},{r:4,t:['vsplit','comb','recyc']},{r:6,t:['hsplit']},{r:8,t:['rot']},{r:10,t:['dback','dfwd']}];",
    "MACH.strip={name:'Colour stripper',ins:1,desc:'Takes one whole coloured thing apart: out come its blank picture and a dye tile of its colour.',col:'#6b4a2f'};\n"
    "const UNLOCKS=[{r:2,t:['dye']},{r:4,t:['vsplit','comb','recyc']},{r:6,t:['hsplit']},{r:7,t:['strip']},{r:8,t:['rot']},{r:10,t:['dback','dfwd']}];")
rep(" if(m.type in SPLIT)return d.t==='w'||(d.t==='c'&&d.axis===SPLIT[m.type]);",
    " if(m.type in SPLIT)return (d.t==='w'&&!d.inv)||(d.t==='c'&&d.axis===SPLIT[m.type]);\n"
    " if(m.type==='strip')return d.t==='w'&&d.b!==BLANK_B&&d.g!==NONE_G;")
rep("dye:'The dye swapper takes whole things only, not halves.'",
    "dye:'The dye swapper takes whole things only, not halves.',strip:'The colour stripper takes one whole coloured thing (not a blank, a dye tile or a half).'")
rep("function recolour(id,b){const d=dec(id);return d.t==='w'?wholeId(b,d.g,d.r):halfId(d.side,b,d.g,d.r)}",
    "function recolour(id,b){const d=dec(id);return d.t==='w'?(d.inv&&b!==BLANK_B?invId(b,d.g,d.r):wholeId(b,d.g,d.r)):halfId(d.side,b,d.g,d.r)}")
rep("\n  if(pair(a,c))out.push(compId(SIDE_AX[a.side],a,c));",
    "\n  if(FLOWER_G.has(a.g)!==FLOWER_G.has(c.g)){out.push(m.inp[0],m.inp[1]);toast('Flowers only join with other flowers')}\n  else if(pair(a,c))out.push(compId(SIDE_AX[a.side],a,c));")
rep(" else{const a=dec(m.inp[0]),c=dec(m.inp[1]);out.push(recolour(m.inp[0],c.b),recolour(m.inp[1],a.b))}",
    " else if(m.type==='strip'){const d=dec(m.inp[0]);out.push(wholeId(BLANK_B,d.g,d.r),wholeId(d.b,NONE_G))}\n"
    " // the dye swapper: two things swap colours; an uncoloured thing + a dye tile gives the coloured thing AND its inverse\n"
    " else{const a=dec(m.inp[0]),c=dec(m.inp[1]);\n"
    "  if(isBlankShape(a)&&isDyeD(c))out.push(wholeId(c.b,a.g,a.r),invId(c.b,a.g,a.r));\n"
    "  else if(isBlankShape(c)&&isDyeD(a))out.push(wholeId(a.b,c.g,c.r),invId(a.b,c.g,c.r));\n"
    "  else out.push(recolour(m.inp[0],c.b),recolour(m.inp[1],a.b))}")
rep("  else{ctx.fillStyle='#ff6b6b';ctx.beginPath();ctx.arc(cx-u*0.45,cy,u*0.55,0,7);ctx.fill();",
    "  else if(m.type==='strip'){ctx.strokeRect(cx-u,cy-u,2*u,2*u);ctx.fillRect(cx-u,cy-u,u,2*u);ctx.beginPath();ctx.moveTo(cx+u*0.3,cy+u*1.25);ctx.lineTo(cx+u*1.1,cy+u*1.25);ctx.stroke()}\n"
    "  else{ctx.fillStyle='#ff6b6b';ctx.beginPath();ctx.arc(cx-u*0.45,cy,u*0.55,0,7);ctx.fill();")
rep("function recycleCredit(id){const d=dec(id);if(!d)return 0;", "function recycleCredit(id){const d=dec(id);if(!d||d.inv)return 0;")
rep(" const wholes=keys.filter(p=>{const d=dec(p);return d&&d.t==='w'&&!isBlankWhole(d)}),halves=keys.filter(p=>{const d=dec(p);return d&&d.t==='h'&&d.b!==BLANK_B&&d.g!==NONE_G});",
    " const wholes=keys.filter(p=>{const d=dec(p);return d&&d.t==='w'&&!d.inv&&!isBlankWhole(d)&&!FLOWER_G.has(d.g)}),halves=keys.filter(p=>{const d=dec(p);return d&&d.t==='h'&&d.b!==BLANK_B&&d.g!==NONE_G&&!FLOWER_G.has(d.g)});")

# ---------- flowers and dyes on the order page, with their own market and a trending dye ----------
rep("const PMULT={in:1.25,coming:1.1,steady:1,going:0.75,out:0.5};",
    "const PMULT={in:1.25,coming:1.1,steady:1,going:0.75,out:0.5};\n"
    "// v9 flowers: blank flowers (3 shapes, all 5 from rush 9) and dye tiles, from rush 5\n"
    "const fShapes=()=>G.fx?FLOWERS.slice(0,G.rounds>=9?5:3):[];\n"
    "const fBlanks=()=>fShapes().map(g=>wholeId(BLANK_B,g)),dyeLines=()=>G.fx?BG.map((c,b)=>wholeId(b,NONE_G)):[],xLines=()=>fBlanks().concat(dyeLines());\n"
    "const hotDOf=p=>G.hotD&&G.hotD.p===p&&G.hotD.left>0?2.5:1;\n"
    "const dyeW=b=>{const p=wholeId(b,NONE_G);return popOf(p)*dmOf(p)*hotDOf(p)};\n"
    "const hotCol=b=>hotDOf(wholeId(b,NONE_G))>1;\n"
    "function wdye(cols){let t=0;for(const b of cols)t+=dyeW(b);let r=Math.random()*t;for(const b of cols){r-=dyeW(b);if(r<=0)return b}return cols[cols.length-1]}\n"
    "const flowerW=p=>{const d=dec(p);return popOf(p)*(d.t==='c'?(dyeW(d.a.b)+dyeW(d.c.b))/2:dyeW(d.b))};\n"
    "const FLOWER_SHARE=0.2;\n"
    "const flowerDemand=()=>custN()*FLOWER_SHARE*1.6+(G.bq?G.bq.items.reduce((a,o)=>a+o.n-o.got,0)/2:0);\n"
    "function drift(q){if(G.dd[q]==null||Math.random()<0.3)G.dd[q]=[-1,0,0,1][(Math.random()*4)|0];\n"
    " const m=(G.dm[q]||1)*(1+0.22*G.dd[q]);G.dm[q]=Math.max(0.35,Math.min(2.6,m));if(G.dm[q]<=0.35&&G.dd[q]<0)G.dd[q]=0;if(G.dm[q]>=2.6&&G.dd[q]>0)G.dd[q]=0}")
rep(" G.newMach=checkUnlocks();rollSupply();G.phase='order';",
    " if(!CO&&!G.fx&&G.rounds>=5){G.fx=1;G.fNew=1} // co-op gets its own flower shop later\n"
    " if(G.fx){for(const q of dyeLines())drift(q);if(!G.hotD&&Math.random()<0.5)G.hotD={p:rnd(dyeLines()),left:2};\n"
    "  if(!G.bq&&G.rounds>=6&&Math.random()<0.6){G.bq=makeBouquet();ordersDirty=true}}\n"
    " G.newMach=checkUnlocks();rollSupply();G.phase='order';")
rep("  G.sup[p]=n;G.price[p]=Math.max(1,Math.round(CRATE_COST*PMULT[mk]*(hotOf(p)>1?1.4:1)*UV('deal')))}}",
    "  G.sup[p]=n;G.price[p]=Math.max(1,Math.round(CRATE_COST*PMULT[mk]*(hotOf(p)>1?1.4:1)*UV('deal')))}\n"
    " if(G.fx){const fd=flowerDemand(),sh=fShapes(),dl=dyeLines(),tw=dl.reduce((a,p)=>a+dyeW(dec(p).b),0)||1;\n"
    "  for(const p of xLines()){const d=dec(p),dye=d.g===NONE_G;const fc=dye?fd*dyeW(d.b)/tw*1.3:fd/sh.length;const k=G.fNew?1.5:(Math.random()<0.15?0:0.6+Math.random()*1.2);\n"
    "   G.sup[p]=Math.max(G.fNew?1:0,Math.round(fc*k*2/CRATE+Math.random()*0.6));\n"
    "   G.price[p]=Math.max(1,Math.round(CRATE_COST*(dye?Math.min(1.4,Math.max(0.6,dmOf(p))):1)*(hotDOf(p)>1?1.4:1)*UV('deal')))}}}")
# placing an order: the free starter flowers and dyes when flowers arrive
rep(" for(const p in G.ord)for(let i=0;i<G.ord[p]*CRATE;i++)list.push(+p);",
    " for(const p in G.ord)for(let i=0;i<G.ord[p]*CRATE;i++)list.push(+p);\n"
    " if(G.fNew){for(const p of fBlanks().slice(0,2))list.push(p,p);for(const p of dyeLines().slice().sort((a,b)=>dyeW(dec(b).b)-dyeW(dec(a).b)).slice(0,3))list.push(p);G.fNew=0}")
# order page: banners and the two new sections
rep(" if(G.hot&&G.hot.left>0)h+=`<p class=\"ohot\">",
    " if(G.fNew)h+=`<p class=\"ohot\" style=\"background:#3a1d33;border-color:#a04a85\">🌷 <b>Flowers have arrived.</b> Order blank flowers and dye tiles below. In the dye swapper, a blank flower and a dye tile give the coloured flower <i>and</i> its inverse. Flower customers come to any hatch. This delivery brings a few free ones to start.</p>`;\n"
    " if(G.bq){const q=G.bq,l=q.due-G.rounds;h+=`<p class=\"ohot\" style=\"background:#3a1d33;border-color:#a04a85\">💐 <b>Bouquet order</b>: ${q.items.map(o=>`<img src=\"${iconURL(o.p)}\" alt=\"\">×${o.n-o.got}`).join(' ')} · due in ${l} rush${l===1?'':'es'} · pays <b>${q.pay}★</b>. Hand it in at any hatch, or tap its card, whenever it's ready.</p>`}\n"
    " if(G.hot&&G.hot.left>0)h+=`<p class=\"ohot\">")
rep(" h+=`</div>`;\n const c=ordCrates()",
    " if(G.fx){const st2=stockCounts();\n"
    "  const row=(p,title,tags)=>{const n=G.ord[p]||0,sp=supOf(p);return `<div class=\"orow\"><img src=\"${iconURL(p)}\" alt=\"\"><div class=\"om\"><div class=\"o1\"><b>Have ${st2[p]||0}</b> · ${title}</div><div class=\"o2\">${tags.join('')}</div></div><div class=\"step\"><button data-om=\"${p}\"${n?'':' disabled'}>−</button><span>${n}</span><button data-op=\"${p}\"${n>=sp?' disabled':''}>+</button></div></div>`};\n"
    "  const sup=p=>supOf(p)?`<span class=\"tg sup\">Supplier has ${supOf(p)} · ${priceAt(p)}★ a crate</span>`:'<span class=\"tg miss\">Out at the supplier</span>';\n"
    "  h+=`<div class=\"ohead mk-flower\"><b>🌷 Flowers</b> <span>blank flowers to colour · fresh</span></div>`;\n"
    "  for(const p of fBlanks())h+=row(p,'blank flower',[sup(p),'<span class=\"tg fr\">Fresh: 3 rushes, 6 in the Cooler</span>']);\n"
    "  const dl=dyeLines().slice().sort((a,b)=>dyeW(dec(b).b)-dyeW(dec(a).b));\n"
    "  h+=`<div class=\"ohead mk-dye\"><b>🎨 Dyes</b> <span>colour tiles · the colours flower customers want most come first</span></div>`;\n"
    "  dl.forEach((p,i)=>{const b=dec(p).b,dir=dirOf(p);h+=row(p,`${COLNAME[b]} dye`,[sup(p),`<span class=\"tg\">Interest #${i+1} of ${dl.length}</span>`,hotDOf(p)>1?'<span class=\"tg hot\">🔥 Trending: flowers in this colour pay ×1½</span>':'',dir>0?'<span class=\"tg\">Rising ↑</span>':dir<0?'<span class=\"tg\">Falling ↓</span>':''])})}\n"
    " h+=`</div>`;\n const c=ordCrates()")
rep(".mk-refurb{background:#1d3a2c}", ".mk-refurb{background:#1d3a2c}.mk-flower{background:#3a1d33}.mk-flower b{color:#ffb3df}.mk-dye{background:#2a2440}.mk-dye b{color:#c9b6ff}")

# ---------- flower customers and prices ----------
rep("const priceItem=(p,f)=>isFresh(p)?",
    "// flowers: 5★ (inverse 6★, two-tone 8★) when fresh, 1★ less per lost marker; ×1½ in a trending colour\n"
    "function flowerPrice(p,f){const d=dec(p);let v=(d.t==='c'?8:d.inv?6:5)-(3-Math.max(1,Math.min(3,f||3)));const hc=d.t==='c'?hotCol(d.a.b)||hotCol(d.c.b):hotCol(d.b);return Math.max(2,v)*(hc?1.5:1)}\n"
    "const priceItem=(p,f)=>isFlower(p)?flowerPrice(p,f):isFresh(p)?")
rep("  if(hs.cust.need&&nextLine(hs.cust))for(const p of hs.cust.need)av[p]=(av[p]||0)-1}",
    "  if(hs.cust.need&&nextLine(hs.cust))for(const p of hs.cust.need)av[p]=(av[p]||0)-1}\n"
    " if(G.fx&&Math.random()<(h===CASE_H&&shownFlowers().length?0.35:FLOWER_SHARE)){const c=genFlower(av,h);if(c){RS.flowers=(RS.flowers||0)+1;return c}}")
rep("function genCustom(av,pref){",
    "// flower customers want coloured flowers: ready ones, or ones you can make from a blank flower and a dye\n"
    "const shownFlowers=()=>CSP_L.map(k=>G.items[k]).filter(v=>v>=0&&colouredFlower(v));\n"
    "function genFlower(av,h){const sh=fShapes();if(!sh.length)return null;const keys=Object.keys(av).map(Number).filter(p=>av[p]>0);\n"
    " const left={...av},take=p=>(left[p]||0)>0?(left[p]--,true):false;\n"
    " const ready=keys.filter(p=>colouredFlower(p)),dyes=[...new Set(keys.filter(p=>isDyeD(dec(p))).map(p=>dec(p).b))];\n"
    " const have=t=>t.every(p=>(left[p]||0)>=t.filter(q=>q===p).length);\n"
    " const order=[],need=[];const add=(p,n)=>{const o=order.find(o=>o.p===p);if(o)o.n+=n;else order.push({p,n,got:0})};\n"
    " if(h===CASE_H){const sf=shownFlowers().filter(p=>av[p]>0);if(sf.length&&Math.random()<0.8){const p=rnd(sf);take(p);add(p,1)}}\n"
    " const want=1+(Math.random()<0.4?1:0)-order.length;const two=G.mach.some(m=>m.type==='vsplit')&&G.mach.some(m=>m.type==='comb');\n"
    " for(let i=0;i<want;i++){\n"
    "  const rd=ready.filter(p=>(left[p]||0)>0);if(rd.length&&Math.random()<0.3){const p=rnd(rd);take(p);add(p,1);continue}\n"
    "  const g=rnd(sh),blank=wholeId(BLANK_B,g),dl=dyes.filter(b=>(left[wholeId(b,NONE_G)]||0)>0);if(!dl.length||!((left[blank]||0)>0))continue;\n"
    "  const b=wdye(dl),r=Math.random();\n"
    "  if(two&&r<0.15){const b2=wdye(dl.filter(x=>x!==b));const t=[blank,blank,wholeId(b,NONE_G),wholeId(b2,NONE_G)];if(b2==null||b2===b||!have(t))continue;t.forEach(take);need.push(...t);add(compId(0,{b,g,r:0},{b:b2,g,r:0}),1);continue}\n"
    "  const t=[blank,wholeId(b,NONE_G)];t.forEach(take);need.push(...t);add(r<0.5?invId(b,g,0):wholeId(b,g,0),1)}\n"
    " if(!order.length)return null;const items=order.reduce((a,o)=>a+o.n,0);\n"
    " return{order,need,flower:true,t:0,t3:1.5*(30+12*items)*UV('patience'),face:rnd(FACES),shirt:rnd(SHIRTS)}}\n"
    "// bouquet orders: a few coloured flowers due within a couple of rushes, handed in at any hatch\n"
    "function makeBouquet(){const sh=fShapes(),dl=dyeLines();if(!sh.length)return null;const items=[];let pay=6;const nl=2+(Math.random()<0.5?1:0);\n"
    " for(let t=0;items.length<nl&&t<30;t++){const g=rnd(sh),b=wdye(dl.map(p=>dec(p).b)),inv=Math.random()<0.35;const p=inv?invId(b,g,0):wholeId(b,g,0);if(items.some(o=>o.p===p))continue;const n=1+((Math.random()*2)|0);items.push({p,n,got:0});pay+=n*(inv?6:5)}\n"
    " return{items,due:G.rounds+2+((Math.random()*2)|0),pay:Math.round(pay*1.4)}}\n"
    "function serveBq(){const q=G.bq;if(!q)return;let moved=0;\n"
    " for(;;){const o=q.items.find(o=>o.got<o.n);if(!o||!G.hand.length||G.hand[0]!==o.p)break;G.hand.shift();G.handF.shift();o.got++;moved++}\n"
    " ordersDirty=true;\n"
    " if(!q.items.some(o=>o.got<o.n)){G.stars+=q.pay;G.life+=q.pay;if(G.phase==='rush'&&RS)RS.stars+=q.pay;G.bq=null;toast(`💐 Bouquet delivered · +${q.pay}★`);sChime();save();return}\n"
    " if(moved){sGive(moved);save()}else{sErr();toast(G.hand.length?'Not for the bouquet: it wants the highlighted flower next':'Your hands are empty')}}\n"
    "function genCustom(av,pref){")
rep("if(!c){toast(G.phase==='rush'?'Nobody at that hatch yet':'The hatches are closed');return}",
    "if(!c){if(G.bq&&G.hand.length&&G.bq.items.some(o=>o.got<o.n&&o.p===G.hand[0])){serveBq();return}toast(G.phase==='rush'?'Nobody at that hatch yet':'The hatches are closed');return}")
rep("if(G.hot){G.hot.left--;if(G.hot.left<=0)G.hot=null}",
    "if(G.hot){G.hot.left--;if(G.hot.left<=0)G.hot=null}\n if(G.hotD){G.hotD.left--;if(G.hotD.left<=0)G.hotD=null}")
rep(" G.rounds++;G.served+=RS.served;", " G.rounds++;if(G.bq&&G.rounds>=G.bq.due){RS.bqLost=1;G.bq=null}G.served+=RS.served;")
rep("${r.made?`<br>Custom things made: ${r.made}`:''}",
    "${r.made?`<br>Custom things made: ${r.made}`:''}${r.flowers?`<br>Flower customers: ${r.flowers}`:''}${r.bqLost?'<br>💐 The bouquet order lapsed':''}")
# order cards: flower customers, the bouquet card
rep("h+=`<div class=\"oc${c.farmer?' farm':''}${c.custom?' cu':''}${i===CASE_H?' ch':''}\" data-h=\"${i}\"><b>${i+1}</b>${c.custom?'<span class=\"cut\">✨ Custom · '+CUSTOM_PRICE+'★</span>':''}`",
    "h+=`<div class=\"oc${c.farmer?' farm':''}${c.custom?' cu':''}${c.flower?' fl':''}${i===CASE_H?' ch':''}\" data-h=\"${i}\"><b>${i+1}</b>${c.custom?'<span class=\"cut\">✨ Custom · '+CUSTOM_PRICE+'★</span>':''}${c.flower?'<span class=\"cut\">🌷</span>':''}`")
rep(" const show=G.phase==='rush'||SH.on;",
    " const show=G.phase==='rush'||SH.on;\n"
    " if(G.bq&&G.phase!=='order'&&G.phase!=='sum'){const q=G.bq,nx=q.items.find(o=>o.got<o.n),l=q.due-G.rounds;\n"
    "  h+=`<div class=\"oc bq\" data-h=\"bq\"><b>💐</b><span class=\"cut\">${l} rush${l===1?'':'es'} · ${q.pay}★</span>`+q.items.map(o=>`<span class=\"it${o.got>=o.n?' done':''}${o===nx?' nx':''}\"><img src=\"${iconURL(o.p)}\" alt=\"\">×${Math.max(0,o.n-o.got)}</span>`).join('<span class=\"ar\">›</span>')+'</div>'}")
rep("barRefs=[...el.querySelectorAll('.oc')].map(n=>({h:+n.dataset.h,st:n.querySelector('.st'),bar:n.querySelector('.bar')}))",
    "barRefs=[...el.querySelectorAll('.oc')].map(n=>({h:+n.dataset.h,st:n.querySelector('.st'),bar:n.querySelector('.bar')})).filter(r=>r.h>=0)")
rep("addEventListener('click',e=>{const oc=e.target.closest('.oc');if(!oc)return;ensureAudio();const h=+oc.dataset.h;",
    "addEventListener('click',e=>{const oc=e.target.closest('.oc');if(!oc)return;ensureAudio();if(oc.dataset.h==='bq'){serveBq();return}const h=+oc.dataset.h;")
rep(".oc.ch>b{background:#8fe6f0}", ".oc.ch>b{background:#8fe6f0}\n.oc.fl{border-color:#ff8fcf;background:rgba(58,22,46,.92)}.oc.bq{border-color:#ff8fcf;background:rgba(48,20,40,.94)}.oc.bq>b{background:#ffb3df}")

# ---------- the Display Case gets a flower section (9 × 2: other | fresh | flowers) ----------
rep("const CASE={x0:0,y0:13,x1:6,y1:15},", "const CASE={x0:0,y0:13,x1:9,y1:15},")
rep("const CSP_F=[],CSP_D=[];for(const y of[14,13]){for(let x=5;x>=3;x--)CSP_F.push(y*W+x);for(let x=2;x>=0;x--)CSP_D.push(y*W+x)}\nconst CSP=CSP_F.concat(CSP_D),",
    "const CSP_F=[],CSP_D=[],CSP_L=[];for(const y of[14,13]){for(let x=5;x>=3;x--)CSP_F.push(y*W+x);for(let x=2;x>=0;x--)CSP_D.push(y*W+x);for(let x=6;x<=8;x++)CSP_L.push(y*W+x)}\nconst CSP=CSP_F.concat(CSP_D,CSP_L),")
rep(" return CSP_F.map((k,i)=>fz[i]??-1).concat(CSP_D.map((k,i)=>dr[i]??-1))}",
    " const fl=Object.keys(have).map(Number).filter(p=>have[p]>0&&colouredFlower(p)).sort((a,b)=>flowerW(b)-flowerW(a));\n"
    " return CSP_F.map((k,i)=>fz[i]??-1).concat(CSP_D.map((k,i)=>dr[i]??-1),CSP_L.map((k,i)=>fl[i]??-1))}")
rep(" fr(3,13,3,2,'rgba(123,216,143,.11)');fr(0,13,3,2,'rgba(197,154,98,.11)');",
    " fr(3,13,3,2,'rgba(123,216,143,.11)');fr(0,13,3,2,'rgba(197,154,98,.11)');fr(6,13,3,2,'rgba(255,143,207,.12)');")
rep("  const a=w2s(3,13.1),b=w2s(3,14.9);ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.stroke();",
    "  for(const dx of[3,6]){const a=w2s(dx,13.1),b=w2s(dx,14.9);ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);ctx.stroke()}")
rep("const m=w2s(0.1,14),n=w2s(5.9,14);", "const m=w2s(0.1,14),n=w2s(CASE.x1-0.1,14);")
rep("const g1=w2s(0,H-0.03),g2=w2s(6,H-0.03);", "const g1=w2s(0,H-0.03),g2=w2s(CASE.x1,H-0.03);")

# ---------- save v6 ----------
rep("function fresh(){G={v:5,", "function fresh(){G={v:6,")
rep("wait:false,pend:null,pendC:0,bd:-1,ct:null}}", "wait:false,pend:null,pendC:0,bd:-1,ct:null,fx:0,fNew:0,hotD:null,bq:null}}")
rep("const KEY=CO?CO.key:'stockroom.v5';", "const KEY=CO?CO.key:'stockroom.v6';")
rep("if(!o||o.v!==5||", "if(!o||o.v!==6||")

# ---------- help ----------
rep("<li><b>The Display Case</b> (bottom left, beside hatch 1) holds one thing per spot: fresh things on the half by the hatch, everything else on the other half.",
    "<li><b>The Display Case</b> (bottom left, around hatch 1) holds one thing per spot in three sections: other things, fresh things, and (once you have them) flowers.")
rep("<li><b>Custom customers</b>",
    "<li><b>Flowers</b> arrive after a few rushes: blank flowers and dye tiles on the order page. Put a blank flower and a dye tile in the dye swapper: out comes the coloured flower <b>and its inverse</b> (the flower coloured, the tile left plain). Flowers are fresh, keep best in the Cooler, and only join with other flowers. Flower customers (🌷) want coloured flowers; the dye that's trending pays ×1½. Now and then a <b>bouquet order</b> (💐) comes in: a few flowers due within a couple of rushes, handed in at any hatch or by tapping its card. The <b>colour stripper</b> takes a coloured thing apart into its blank picture and a dye tile.</li>\n<li><b>Custom customers</b>")
rep("rebuildMap,setDemo:v=>{demoMode=v},", "rebuildMap,setDemo:v=>{demoMode=v},iconURL,genFlower,makeBouquet,serveBq,invId,isFlower,colouredFlower,flowerPrice,fBlanks,dyeLines,dyeW,rollSupply,CSP_L,FLOWERS,")
rep(" if(ordersDirty)renderOrders();", " if(ordersDirty||G.phase+(G.bq?'b':'')!==ordPh){ordPh=G.phase+(G.bq?'b':'');renderOrders()}")
rep("let ordersDirty=true,handKey='',actKey='',barRefs=[];", "let ordersDirty=true,handKey='',actKey='',barRefs=[],ordPh='';")
open(out, 'w', encoding='utf-8').write(s)
print("v9 applied")
