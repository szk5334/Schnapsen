# Build the Stockroom website files from the artifact's index.html (the single source) + pages/coop.js.
#   python3 build_pages.py <index.html> <coop.js> <outdir>
# Writes <outdir>/stockroom.html, <outdir>/stockroom/game.js, <outdir>/stockroom/coop.js.
import sys, os, re
src, coop, out = sys.argv[1:4]
h = open(src, encoding='utf-8').read()
m = re.search(r'<script>\n?(.*)</script>', h, re.S)
assert m and h.count('<script') == 1
game = m.group(1)
page = h[:m.start()] + ('<!-- Optional site settings (relays). Lives in the repo root, outside the tarballs. -->\n'
  '<script src="config.js" onerror="void 0"></script>\n'
  '<script type="module" src="stockroom/coop.js"></script>\n') + h[m.end():]
ICON = ("data:image/svg+xml,%3Csvg%20xmlns=%27http://www.w3.org/2000/svg%27%20viewBox=%270%200%2032%2032%27%3E"
        "%3Crect%20width=%2732%27%20height=%2732%27%20rx=%276%27%20fill=%27%2314161c%27/%3E"
        "%3Crect%20x=%276%27%20y=%2710%27%20width=%2720%27%20height=%2716%27%20rx=%272%27%20fill=%27%23c59a62%27/%3E"
        "%3Cpath%20d=%27M6%2015h20M16%2010v5%27%20stroke=%27%2314161c%27%20stroke-width=%271.6%27/%3E"
        "%3Ccircle%20cx=%2724%27%20cy=%278%27%20r=%274%27%20fill=%27%23ffd23f%27/%3E%3C/svg%3E")
page = page.replace('<title>Stockroom</title>', '<meta name="theme-color" content="#14161c">\n'
  '<meta name="description" content="Stockroom: sort a warehouse, serve the hatches, and run a shop next door to a friend.">\n'
  '<link rel="icon" href="' + ICON + '">\n<title>Stockroom</title>')
page = page.replace('<div id="ov" class="hidden"><div class="card" id="ovc"></div></div>',
                    '<div id="ov"><div class="card" id="ovc"><p>Unlocking the shop…</p></div></div>')
assert page.count('<body>') == 1 and page.count('</style>') == 1
page = page.replace('<body>', '<body class="lobby">')
page = page.replace('</style>', '/* the street door: no warehouse controls until a warehouse is open */\nbody.lobby #hud,body.lobby #bot{display:none}\n</style>')
os.makedirs(os.path.join(out, 'stockroom'), exist_ok=True)
open(os.path.join(out, 'stockroom.html'), 'w', encoding='utf-8').write(page)
open(os.path.join(out, 'stockroom', 'game.js'), 'w', encoding='utf-8').write('/* Stockroom: the game, built from the claude.ai artifact\'s index.html (do not edit here). */\n' + game)
open(os.path.join(out, 'stockroom', 'coop.js'), 'w', encoding='utf-8').write(open(coop, encoding='utf-8').read())
print('built', out)
