# Stockroom v10: the cold case. No spoilage, no freshness markers, no rotten goods, no Cooler, no case targets.
# Fresh things (some pictures in every colour, their halves, flowers) only stack in the cold case (bottom left,
# 9 x 3, around hatch 1); anywhere else they sit one to a spot. The case is a plain shelf: tap takes one, tap puts.
# Seth, Nov 28: "I don't think I like spoilage ... I do like needing to store some things in a special area ...
# I also don't like the way the display case tells you something is wrong, and it takes two taps to pick up one thing"
# -> "Option 2 with the soft rule".   python3 v10_coldcase.py <v9.4 index.html> <out>
import sys, re
src, out = sys.argv[1:3]
s = open(src, encoding='utf-8').read()
def rep(a, b='', cnt=1):
    global s
    n = s.count(a)
    if n != cnt: sys.exit(f"expected {cnt} of: {a[:110]!r}, found {n}")
    s = s.replace(a, b)
def cut(start, end, new=''):
    global s
    i = s.index(start); j = s.index(end, i) + len(end); s = s[:i] + new + s[j:]

# ---------- zones ----------
rep("// The Display Case (bottom left, around hatch 1) and the Cooler (top right).\n", "// The cold case (bottom left, 9 x 3, around hatch 1): the one place fresh things stack.\n")
rep("// Case: one thing per spot, three sections: other x 0..2, fresh x 3..5, flowers x 6..8. Front row = y 14, the wall edge.\n",
    "// It stacks like the floor; its front row (y 14, the wall edge) draws the most interest at hatch 1.\n")
rep("const CASE={x0:0,y0:13,x1:9,y1:15},COOL={x0:18,y0:0,x1:24,y1:4},CASE_H=0;", "const CASE={x0:0,y0:12,x1:9,y1:15},CASE_H=0;")
rep("const CASEM=new Uint8Array(N),COOLM=new Uint8Array(N);", "const CASEM=new Uint8Array(N);")
rep("for(let y=COOL.y0;y<COOL.y1;y++)for(let x=COOL.x0;x<COOL.x1;x++)COOLM[y*W+x]=1;\n")
cut("// spots in rank order: front row first", "FCOL=['','#ff6b6b','#ffd23f','#7bd88f'];\n")
rep("// Freshness belongs to the picture: every colour of these pictures spoils (drop, leaf, fish, mushroom, flower, apple).",
    "// Fresh pictures (every colour of them): drop, leaf, fish, mushroom, flower, apple, and the five flowers. Fresh things only stack in the cold case.")
cut("function paintSpoiled(g,px){", "g.stroke()}}\n")
rep("function paintItem(g,id,px){if(id===-2)return paintSpoiled(g,px);const d=dec(id);", "function paintItem(g,id,px){const d=dec(id);")
rep("const capAt=k=>CASEM[k]?1:G.rack[k]?10:UV('stack');",
    "// how many fit on a spot: fresh things stack only in the cold case (one to a spot anywhere else)\n"
    "const capAt=(k,v=G.items[k])=>v>=0&&isFresh(v)&&!CASEM[k]?1:G.rack[k]?10:UV('stack');")
rep("const canPlace=(x,y)=>free(x,y);", "const canPlace=(x,y)=>inF(x,y)&&!SOLID[ix(x,y)]&&G.items[ix(x,y)]===-1&&ix(x,y)!==BIN;")

# ---------- save ----------
rep("function fresh(){G={v:6,", "function fresh(){G={v:7,")
rep("cnt:new Array(N).fill(0),fr:new Array(N).fill(0),", "cnt:new Array(N).fill(0),")
rep("rack:new Array(N).fill(0),handF:[],", "rack:new Array(N).fill(0),")
rep(",bd:-1,ct:null,fx:0,", ",bd:-1,fx:0,")
rep("const KEY=CO?CO.key:'stockroom.v6';", "const KEY=CO?CO.key:'stockroom.v7';")
rep("if(!o||o.v!==6||", "if(!o||o.v!==7||")

# ---------- hands and piles ----------
rep("G.cnt[k]=m;G.fr[k]=isFresh(p)?3:0;POP.set(k,-0.02*j)};", "G.cnt[k]=m;POP.set(k,-0.02*j)};")
rep(" G.hand.push(v);G.handF.push(G.fr[k]);if(--G.cnt[k]<=0){G.items[k]=-1;G.cnt[k]=0;G.fr[k]=0}", " G.hand.push(v);if(--G.cnt[k]<=0){G.items[k]=-1;G.cnt[k]=0}")
rep("function runLen(){if(!G.hand.length)return 0;const fz=isFresh(G.hand[0]);let n=1;while(n<G.hand.length&&G.hand[n]===G.hand[0]&&(!fz||G.handF[n]===G.handF[0]))n++;return n}\nfunction takeRun(n){let f=99;for(let i=0;i<n;i++)if(G.handF[i]>0)f=Math.min(f,G.handF[i]);G.hand.splice(0,n);G.handF.splice(0,n);return f}",
    "function runLen(){if(!G.hand.length)return 0;let n=1;while(n<G.hand.length&&G.hand[n]===G.hand[0])n++;return n}\nfunction takeRun(n){G.hand.splice(0,n)}")
rep(" const k=ix(x,y),v=G.hand[0],n=Math.min(runLen(),capAt(k));const f=takeRun(n);\n G.items[k]=v;G.cnt[k]=n;G.fr[k]=isFresh(v)?(f===99?3:f):0;POP.set(k,0);sDrop()}",
    " const k=ix(x,y),v=G.hand[0],n=Math.min(runLen(),capAt(k,v));takeRun(n);\n G.items[k]=v;G.cnt[k]=n;POP.set(k,0);sDrop()}")
rep(" if(isFresh(v)&&G.fr[k]!==G.handF[0]){BLINK.set(k,performance.now());toast('Different freshness: give it its own pile');return}\n const room=capAt(k)-G.cnt[k];if(room<=0){toast(`That stack is full (${capAt(k)})`);sErr();return}\n const n=Math.min(room,runLen());const f=takeRun(n);if(G.fr[k]>0&&f!==99)G.fr[k]=Math.min(G.fr[k],f);G.cnt[k]+=n;",
    " const room=capAt(k)-G.cnt[k];if(room<=0){toast(isFresh(v)&&!CASEM[k]?'Fresh things only stack in the cold case ❄':`That stack is full (${capAt(k)})`);sErr();return}\n const n=Math.min(room,runLen());takeRun(n);G.cnt[k]+=n;")
rep("toast('The bin: throw spoiled things out here')", "toast('The bin: throw things out here')")
rep("toast(v===-2?`Threw out ${n} spoiled`:`Threw out ${n}`);", "toast(`Threw out ${n}`);")
rep("if(!got)break;G.hand.shift();G.handF.shift();n++;", "if(!got)break;G.hand.shift();n++;")
rep("const id=refurbId(k);G.hand.push(id);G.handF.push(isFresh(id)?3:0);", "const id=refurbId(k);G.hand.push(id);")
rep("{m.inp.push(G.hand.shift());m.inf.push(G.handF.shift());took++}", "{m.inp.push(G.hand.shift());took++}")
rep("function runMachine(m){const out=[];const fs=m.inf.filter(f=>f>0);m.of=fs.length?Math.min(...fs):3;", "function runMachine(m){const out=[];")
rep(" m.inp=[];m.inf=[];m.out=out.filter(", " m.inp=[];m.out=out.filter(")
rep("function dropNear(k0,id,f){", "function dropNear(k0,id){")
rep("if(G.items[c]===id&&!CASEM[c]&&G.cnt[c]<capAt(c)&&(!isFresh(id)||G.fr[c]===f)){G.cnt[c]++;if(G.fr[c]>0&&f>0)G.fr[c]=Math.min(G.fr[c],f);POP.set(c,0.12);return true}",
    "if(G.items[c]===id&&!CASEM[c]&&G.cnt[c]<capAt(c)){G.cnt[c]++;POP.set(c,0.12);return true}")
rep("if(G.items[c]===-1&&c!==BIN&&!SOLID[c]&&!CASEM[c]){G.items[c]=id;G.cnt[c]=1;G.fr[c]=isFresh(id)?f:0;POP.set(c,0);return true}}",
    "if(G.items[c]===-1&&c!==BIN&&!SOLID[c]&&!CASEM[c]){G.items[c]=id;G.cnt[c]=1;POP.set(c,0);return true}}")
rep("dropNear(m.k,m.out[0],m.of)", "dropNear(m.k,m.out[0])")
rep("G.mach.push({type,k,inp:[],inf:[],t:0,out:[],of:3});", "G.mach.push({type,k,inp:[],t:0,out:[]});")
# leftover stock behind the walls: no rotten pile
rep("G.items[k]=p;G.cnt[k]=m;G.fr[k]=isFresh(p)?2:0;POP.set(k,-0.05*j);n-=m;found+=m}}", "G.items[k]=p;G.cnt[k]=m;POP.set(k,-0.05*j);n-=m;found+=m}}")
rep("\n  if(j<cells.length){const k=cells[j++];G.items[k]=-2;G.cnt[k]=1+((Math.random()*2)|0);G.fr[k]=0;POP.set(k,-0.05*j)}}", "}")

# ---------- Clunk: leaves fresh things to you (they belong in the cold case, which he never touches) ----------
rep("const kindK=(v,f)=>isFresh(v)?v+'/'+f:''+v;", "const kindK=v=>''+v;")
rep("if(v>=0&&!CASEM[k]&&!(POP.get(k)<0)){const key=kindK(v,G.fr[k]);let a=by.get(key);if(!a)by.set(key,a={v,f:G.fr[k],ks:[]});",
    "if(v>=0&&!CASEM[k]&&!isFresh(v)&&!(POP.get(k)<0)){const key=kindK(v);let a=by.get(key);if(!a)by.set(key,a={v,ks:[]});")
rep("function putNear(k0,v,n,f,avoidBay,maxD,touched){", "function putNear(k0,v,n,avoidBay,maxD,touched){")
rep("if(G.items[c]===v&&!CASEM[c]&&G.cnt[c]<capAt(c)&&(!isFresh(v)||G.fr[c]===(f||3))){const m=Math.min(n,capAt(c)-G.cnt[c]);G.cnt[c]+=m;n-=m;if(G.fr[c]>0&&f>0)G.fr[c]=Math.min(G.fr[c],f);POP.set(c,0.12);",
    "if(G.items[c]===v&&!CASEM[c]&&G.cnt[c]<capAt(c)){const m=Math.min(n,capAt(c)-G.cnt[c]);G.cnt[c]+=m;n-=m;POP.set(c,0.12);")
rep("const m=Math.min(n,capAt(c));G.items[c]=v;G.cnt[c]=m;G.fr[c]=isFresh(v)?(f||3):0;n-=m;", "const m=Math.min(n,capAt(c,v));G.items[c]=v;G.cnt[c]=m;n-=m;")
rep("while(b.carry.length){const v=b.carry[0];let n=0,f=99;while(n<b.carry.length&&b.carry[n]===v&&(!isFresh(v)||b.cf[n]===b.cf[0])){if(b.cf[n]>0)f=Math.min(f,b.cf[n]);n++}\n  const left=putNear(k0,v,n,f===99?0:f,avoidBay,maxD,touched),done=n-left;b.carry.splice(0,done);b.cf.splice(0,done);",
    "while(b.carry.length){const v=b.carry[0];let n=0;while(n<b.carry.length&&b.carry[n]===v)n++;\n  const left=putNear(k0,v,n,avoidBay,maxD,touched),done=n-left;b.carry.splice(0,done);")
rep("for(let i=0;i<n;i++){b.carry.push(B.v);b.cf.push(G.fr[k])}\n G.cnt[k]-=n;if(G.cnt[k]<=0){G.items[k]=-1;G.cnt[k]=0;G.fr[k]=0}", "for(let i=0;i<n;i++)b.carry.push(B.v);\n G.cnt[k]-=n;if(G.cnt[k]<=0){G.items[k]=-1;G.cnt[k]=0}")
rep("let tgt=cl.get(kindK(v,b.cf[0]));", "let tgt=cl.get(kindK(v));")
rep("G.bot={x:k%W+0.5,y:((k/W)|0)+0.5,carry:[],cf:[],mine:{},on:true};", "G.bot={x:k%W+0.5,y:((k/W)|0)+0.5,carry:[],mine:{},on:true};")

# ---------- the case at hatch 1 ----------
rep("function caseShown(){const m=new Map();for(const k of CSP){", "const CASEK=[];for(let k=0;k<N;k++)if(CASEM[k])CASEK.push(k);\nfunction caseShown(){const m=new Map();for(const k of CASEK){")
rep("const shownFlowers=()=>CSP_L.map(k=>G.items[k])", "const shownFlowers=()=>CASEK.map(k=>G.items[k])")

# ---------- selling: fresh things sell like anything else ----------
rep("G.hand.shift();G.handF.shift();o.got++;moved++}\n ordersDirty=true;\n if(!q.items", "G.hand.shift();o.got++;moved++}\n ordersDirty=true;\n if(!q.items")
rep("o.val=(o.val||0)+priceItem(o.p,G.handF[0]);G.hand.shift();G.handF.shift();o.got++;moved++}", "o.val=(o.val||0)+priceItem(o.p);G.hand.shift();o.got++;moved++}")
rep("// flowers: 5★ (inverse 6★, two-tone 8★) when fresh, 1★ less per lost marker; ×1½ in a trending colour\nfunction flowerPrice(p,f){const d=dec(p);let v=(d.t==='c'?8:d.inv?6:5)-(3-Math.max(1,Math.min(3,f||3)));",
    "// flowers: 5★ (inverse 6★, two-tone 8★); ×1½ in a trending colour\nfunction flowerPrice(p){const d=dec(p);let v=d.t==='c'?8:d.inv?6:5;")
rep("const priceItem=(p,f)=>isFlower(p)?flowerPrice(p,f):isFresh(p)?Math.max(1,Math.min(3,f||3))*(hotOf(p)>1?2.5:1):priceOf(p);", "const priceItem=p=>isFlower(p)?flowerPrice(p):priceOf(p);")
rep("clean:false,spoiled:0,loss:0,drops:0,", "clean:false,drops:0,")
cut("function spoil(){", "}return n}\n")
rep(" {const n=spoil();if(n){const loss=Math.min(G.stars,n);G.stars-=loss;RS.spoiled=n;RS.loss=loss}}", " ")
rep("${r.spoiled?`<br>${r.spoiled} thing${r.spoiled>1?'s':''} spoiled${r.loss?` −${r.loss}★`:''}. Tap them to throw them out.`:''}", "")
rep("(crowds growing, trends and their price, rising/falling demand, spoilage)", "(crowds growing, trends and their price, rising/falling demand)")
rep("const pr1=hot?HOT_PRICE:PRICE,pr2=hot2?HOT_PRICE:PRICE;const fresh=isFresh(p);", "const pr1=hot?HOT_PRICE:PRICE,pr2=hot2?HOT_PRICE:PRICE;")
rep("ev.push(pr1*s1+pr2*(s12-s1)+(fresh?-0.7:0.6)*left-CRATE_COST*k);", "ev.push(pr1*s1+pr2*(s12-s1)+0.6*left-CRATE_COST*k);")
rep("const colOf=r=>{const c=r.cov2;if(r.fresh&&c>3.5)return['#ff9f43','may spoil'];", "const colOf=r=>{const c=r.cov2;")
rep("if(r.fresh)tags.push('<span class=\"tg fr\">Fresh: 3 rushes, 6 in the Cooler</span>');", "if(r.fresh)tags.push('<span class=\"tg fr\">❄ Stacks only in the cold case</span>');")
rep("[sup(p),'<span class=\"tg fr\">Fresh: 3 rushes, 6 in the Cooler</span>']", "[sup(p),'<span class=\"tg fr\">❄ Stacks only in the cold case</span>']")

# ---------- delivery: no targets, no arranging time ----------
rep("G.ord={};G.phase='stock';G.ct=caseTargets();REDF.clear();caseSel=-1;", "G.ord={};G.phase='stock';")
rep("G.phaseT=Math.min(110,30+2*list.length)+3*caseWrong(G.ct); // arranging the case gets its own time: 3 s a spot", "G.phaseT=Math.min(110,30+2*list.length);")
cut("function caseTargets(extra){", "function caseTap(x,y){","function caseTap(x,y){")
cut("function caseTap(x,y){", "Faded pictures show the best layout.')}\n")
rep(" if(CASEM[ix(cx,cy)]){caseTap(cx,cy);return}\n", "")
rep(" if(G.items[ix(cx,cy)]===-2){tossRotten(cx,cy);return}\n", "")
cut("// rotten goods: one tap throws the whole rotten stack out where it stands\n", "toast(`Threw out ${n} rotten`)}\n")
rep("const rot=G.hand.filter(v=>v===-2).length;if(rot){for(let i=G.hand.length-1;i>=0;i--)if(G.hand[i]===-2){G.hand.splice(i,1);G.handF.splice(i,1)}beep(200,0.14,'sawtooth',0.04,0.5);toast(`Threw out ${rot} rotten from your hands`);return}", "")
rep("const hk=G.hand.join(',')+'|'+G.handF.join(',')+'/'+cap();", "const hk=G.hand.join(',')+'/'+cap();")

# ---------- part 2: leftover comments, drawing, help, exports ----------
rep("// targets: fresh lines you hold (incl. extra) by interest into the fresh half, the rest into the other half\n")
cut("// the Cooler (frost blue) and the Display Case", "ctx.arc(fx,fy,d*(bl?1.35:1),0,7);ctx.fill();ctx.stroke()}}\n",
 "// the cold case: frosted glass, a faint line behind its front row, a glass front on the wall, ❄ in the corner\n"
 "function drawZones(){\n"
 " fr(CASE.x0,CASE.y0,CASE.x1-CASE.x0,CASE.y1-CASE.y0,'rgba(120,190,255,.13)');\n"
 " const r=wr(CASE.x0+0.04,CASE.y0+0.04,CASE.x1-CASE.x0-0.08,CASE.y1-CASE.y0-0.08);ctx.strokeStyle='rgba(150,220,255,.8)';ctx.lineWidth=Math.max(2,S*0.07);ctx.strokeRect(r[0],r[1],r[2],r[3]);\n"
 " const m=w2s(0.1,H-1),n=w2s(CASE.x1-0.1,H-1);ctx.strokeStyle='rgba(150,220,255,.25)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(m[0],m[1]);ctx.lineTo(n[0],n[1]);ctx.stroke();\n"
 " const g1=w2s(0,H-0.03),g2=w2s(CASE.x1,H-0.03);ctx.strokeStyle='rgba(190,245,255,.9)';ctx.lineWidth=Math.max(3,S*0.1);ctx.beginPath();ctx.moveTo(g1[0],g1[1]);ctx.lineTo(g2[0],g2[1]);ctx.stroke();\n"
 " const[sx,sy]=w2s(CASE.x1-0.2,CASE.y0+0.22);ctx.fillStyle='rgba(190,230,255,.85)';ctx.font=`${Math.round(S*0.34)}px system-ui`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('❄',sx,sy)}\n"
 "// a small ❄ on fresh things outside the cold case: they belong in it\n"
 "function drawCold(r){const z=Math.max(9,S*0.3);ctx.fillStyle='rgba(20,22,28,.75)';ctx.beginPath();ctx.arc(r[0]+r[2]*0.16,r[1]+r[3]*0.17,z*0.62,0,7);ctx.fill();\n"
 " ctx.fillStyle='#bfe6ff';ctx.font=`${Math.round(z)}px system-ui`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('❄',r[0]+r[2]*0.16,r[1]+r[3]*0.17+0.5)}\n")
rep("  if(G.fr[k]>0&&isFresh(v))drawMarks(r,G.fr[k],k)}\n drawCaseMarks();\n", "  if(v>=0&&!CASEM[k]&&isFresh(v))drawCold(r)}\n")
rep(",f=Math.min(3,G.handF[i]|0);return f>0&&isFresh(p)?`<span class=\"hw\">${im}<span class=\"fm\">${`<b style=\"background:${FCOL[f]}\"></b>`.repeat(f)}</span></span>`:im})", ";return im})")
rep("deliver();G.ct=caseTargets();G.phase='stock';", "deliver();G.phase='stock';")
rep(" if(load()){makeCat(G.seed);rebuildMap();makeHS();if(!G.ct)G.ct=caseTargets();", " if(load()){makeCat(G.seed);rebuildMap();makeHS();")
rep("surprise,spoil,hold,", "surprise,hold,")
rep("flowerPrice,fBlanks,dyeLines,dyeW,rollSupply,CSP_L,FLOWERS,", "flowerPrice,fBlanks,dyeLines,dyeW,rollSupply,FLOWERS,")
rep(" caseTap,caseTargets,caseWrong,caseShown,newCust,priceItem,landDelivery,runLen,putAt,pickAt,CSP,CASEM,COOLM,get caseSel(){return caseSel}};",
    " caseShown,newCust,priceItem,landDelivery,runLen,putAt,pickAt,CASE,CASEM,CASEK,capAt,knownProds};")
rep("put:G.pend?Math.min(110,30+2*G.pend.length)+3*caseWrong(caseTargets(G.pend)):0,", "put:G.pend?Math.min(110,30+2*G.pend.length):0,")
rep("<li>Some pictures are fresh (every colour of them, and halves too). Fresh piles carry <b>freshness markers</b>: three, then two, then one, then they spoil. Fresher things sell for more (3★, 2★, 1★), so you choose which pile to sell from. Only piles with the same number of markers stack. The <b>Cooler</b> (top right, ❄) keeps fresh things twice as long. Tap a rotten stack to throw it out (or tap your hands to dump any rotten things you're holding).</li>\n<li><b>The Display Case</b> (bottom left, around hatch 1) holds one thing per spot in three sections: other things, fresh things, and (once you have them) flowers. Faded pictures show the best layout, the most wanted at the front by the wall; red means the wrong thing is in a spot. Between rushes, tap one thing and then another to swap them (tap a thing twice to pick it up). Customers at hatch 1 mostly want what's on display, custom orders too.</li>",
    "<li>Some pictures are <b>fresh</b> (every colour of them, their halves too, and flowers). Fresh things only stack in <b>the cold case</b> (bottom left, around hatch 1, ❄). Anywhere else they sit one to a spot, with a little ❄ to say where they belong. Nothing spoils.</li>\n<li>The cold case works like the floor (tap to take one, tap to put down). Anything can go in it. Customers at hatch 1 mostly ask for what's in the cold case, the front row by the wall most of all, custom orders too.</li>")
rep("Flowers are fresh, keep best in the Cooler, and only join with other flowers.", "Flowers are fresh (they stack only in the cold case) and only join with other flowers.")
rep("He's clumsy, so check his work.", "He leaves fresh things to you. He's clumsy, so check his work.")

left=[w for w in ["G.fr","handF","COOL","CSP","caseSel","REDF","BLINK","caseTargets","caseWrong","G.ct","spoil(","tossRotten","paintSpoiled","drawMarks","FCOL","Cooler","rotten","=-2","===-2","m.inf","m.of","b.cf"] if w in s]
if left: sys.exit(f"left over: {left}")
open(out, 'w', encoding='utf-8').write(s)
print("v10 applied")
