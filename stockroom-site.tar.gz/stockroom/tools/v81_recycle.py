# Stockroom v8.1: recycled stock menu on the recycler, dye swapper takes whole things only, stronger case targets.
#   python3 v81_recycle.py <v8 index.html> <out>
import sys
src, out = sys.argv[1:3]
s = open(src, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a)
    if n != cnt: sys.exit(f"expected {cnt} of: {a[:90]!r}, found {n}")
    s = s.replace(a, b)

# 6) the case's faded pictures were too faint
rep("ctx.globalAlpha=0.24;ctx.drawImage(tileImg(t,px),r[0],r[1],r[2],r[3]);ctx.globalAlpha=1})}",
    "ctx.globalAlpha=0.5;ctx.drawImage(tileImg(t,px),r[0],r[1],r[2],r[3]);ctx.globalAlpha=1})}")

# 7) the dye swapper takes whole things only
rep(" if(m.type==='rot')return true;\n return d.t==='w'||d.t==='h'}",
    " if(m.type==='rot')return true;\n if(m.type==='dye')return d.t==='w';\n return d.t==='w'||d.t==='h'}")
rep("dye:{name:'Dye swapper',ins:2,desc:'Put in two things (whole or halves) and their colours swap.'",
    "dye:{name:'Dye swapper',ins:2,desc:'Put in two whole things and their colours swap.'")
rep("dye:'The dye swapper takes whole things or halves.'", "dye:'The dye swapper takes whole things only, not halves.'")

# 5) recycled stock is a menu on the recycler: tap it with empty hands, any time, and take blanks into your hands
rep("function recycleFeed(){if(!G.hand.length){const c=Object.entries(G.rc.c).filter(([b,n])=>n>0).map(([b,n])=>`${COLNAME[b]} ${n}`),sh=Object.values(G.rc.s).reduce((a,n)=>a+n,0);\n  toast(`Recycler: ${c.length?'colours '+c.join(', '):'no colour parts yet'} · ${sh} picture part${sh===1?'':'s'}. Two parts make a blank you can order.`);return}",
    "function recycleFeed(){if(!G.hand.length){showRecycle();return}")
rep("function feed(m){if(m.type==='recyc')return recycleFeed();",
    "// the recycled stock: every 2 parts of a colour or a picture make a blank you can take straight into your hands\n"
    "function showRecycle(){const keys=[...Object.keys(G.rc.c).map(b=>'c'+b),...Object.keys(G.rc.s).map(g=>'s'+g)].filter(k=>refurbAvail(k)>0);\n"
    " let h=`<h2>♻ Recycled stock</h2><p class=\"olead\">Two recycled parts make a blank: a plain colour tile or an unpainted picture. Tap one to take it. A blank picture and a colour tile in the dye swapper make the real thing.</p>`;\n"
    " h+=keys.length?`<div class=\"rgrid\">`+keys.map(k=>`<button class=\"rb\" data-rk=\"${k}\"><img src=\"${iconURL(refurbId(k))}\" alt=\"\"><span>×${refurbAvail(k)}</span></button>`).join('')+`</div>`:`<p class=\"omuted\">Nothing yet. Feed the recycler spare halves, two-part things or blanks.</p>`;\n"
    " h+=`<p class=\"omuted\">Hands: ${G.hand.length}/${cap()}</p><div class=\"row\"><button class=\"big\" id=\"rX\">Done</button></div>`;ov(h);\n"
    " $('#ovc').querySelectorAll('[data-rk]').forEach(b=>b.onclick=()=>takeRecycled(b.dataset.rk));$('#rX').onclick=closeOv}\n"
    "function takeRecycled(k){if(refurbAvail(k)<1)return;if(G.hand.length>=cap()){toast(`Hands full (${cap()})`);sErr();return}\n"
    " const t=k[0],v=+k.slice(1);if(t==='c')G.rc.c[v]-=2;else G.rc.s[v]-=2;const id=refurbId(k);G.hand.push(id);G.handF.push(isFresh(id)?3:0);sPick();save();showRecycle()}\n"
    "function feed(m){if(m.type==='recyc')return recycleFeed();")
rep(".oc.ch>b{background:#8fe6f0}",
    ".oc.ch>b{background:#8fe6f0}\n.rgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(64px,1fr));gap:8px;margin:8px 0}.rb{display:flex;flex-direction:column;align-items:center;gap:2px;padding:6px 4px}.rb img{width:40px;height:40px}")
rep("every 2 parts of a colour or a picture lets you order a refurbished blank (1★) on the order page.'",
    "tap it with empty hands to take blanks from your recycled stock (every 2 parts of a colour or a picture make one).'")
# the order page no longer sells refurbished blanks
a = s.index(" const rk=[...Object.keys(G.rc.c).map(b=>'c'+b)")
b = s.index(" h+=`</div>`;\n const c=ordCrates()", a)
s = s[:a] + s[b:]
rep("<li><b>Recycler:</b> feed it spare halves (or two-part things). It saves each part's colour and picture. Every 2 parts of a colour or picture lets you order a refurbished <b>blank</b> for 1★: a plain colour tile, or an unpainted picture. Put a blank picture and a blank colour into the dye swapper to make the real thing, even when the supplier is out.</li>",
    "<li><b>Recycler:</b> feed it spare halves, two-part things or blanks. It saves each part's colour and picture. <b>Tap it with empty hands</b> (any time, even in a rush) to open your recycled stock: every 2 parts of a colour or picture make a <b>blank</b> you can take straight into your hands, a plain colour tile or an unpainted picture. Put a blank picture and a colour tile into the dye swapper (it takes whole things only) to make the real thing, even when the supplier is out.</li>")
rep("rebuildMap,setDemo:v=>{demoMode=v},", "rebuildMap,setDemo:v=>{demoMode=v},showRecycle,takeRecycled,accepts,")
open(out, 'w', encoding='utf-8').write(s)
print("v8.1 applied")
