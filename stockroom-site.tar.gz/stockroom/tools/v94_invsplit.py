# Stockroom v9.4: inverse things split, turn and join like normal ones; custom things pay by the steps they take.
#   python3 v94_invsplit.py <v9.3 index.html> <out>
import sys
src, out = sys.argv[1:3]
s = open(src, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a)
    if n != cnt: sys.exit(f"expected {cnt} of: {a[:100]!r}, found {n}")
    s = s.replace(a, b)

# ---------- encoding: inverse halves 60000 + side·4096 + pkey; two-part code = axis | 4 (first part inverse) | 8 (second part inverse) ----------
rep("function halfId(side,b,g,r=0){return 20000+side*4096+pkey(b,g,r)}\nfunction compId(axis,a,c){const ka=pkey(a.b,a.g,a.r),kc=pkey(c.b,c.g,c.r);if(ka===kc)return wholeId(a.b,a.g,a.r||0);return 100000+axis*16777216+ka*4096+kc}",
    "const HINV0=60000; // inverse halves (v9.4): 60000 + side·4096 + pkey\n"
    "function halfId(side,b,g,r=0,inv=false){return (inv&&b!==BLANK_B?HINV0:20000)+side*4096+pkey(b,g,r)}\n"
    "// two-part things: 100000 + code·16777216 + pkey(a)·4096 + pkey(c), code = axis | 4 if the first part is inverse | 8 if the second is\n"
    "function compId(axis,a,c){const ka=pkey(a.b,a.g,a.r),kc=pkey(c.b,c.g,c.r),ia=!!a.inv&&a.b!==BLANK_B,ic=!!c.inv&&c.b!==BLANK_B;\n"
    " if(ka===kc&&ia===ic)return ia?invId(a.b,a.g,a.r||0):wholeId(a.b,a.g,a.r||0);return 100000+(axis|(ia?4:0)|(ic?8:0))*16777216+ka*4096+kc}")
rep(" if(id<100000){const q=id-20000;return{t:'h',side:(q/4096)|0,...unk(q%4096)}}\n const q=id-100000,ax=(q/16777216)|0,z=q%16777216;return{t:'c',axis:ax,a:unk((z/4096)|0),c:unk(z%4096)}}",
    " if(id<HINV0){const q=id-20000;return{t:'h',side:(q/4096)|0,...unk(q%4096)}}\n"
    " if(id<100000){const q=id-HINV0;return{t:'h',side:(q/4096)|0,...unk(q%4096),inv:true}}\n"
    " const q=id-100000,cd=(q/16777216)|0,z=q%16777216,a=unk((z/4096)|0),c=unk(z%4096);if(cd&4)a.inv=true;if(cd&8)c.inv=true;return{t:'c',axis:cd&3,a,c}}")
rep("// inverse things: the picture coloured, the tile left plain. Wholes only (14096..19999).",
    "// inverse things: the picture coloured, the tile left plain. Wholes 14096..19999; halves and parts of two-part things too (v9.4).")
rep(" if(d.t==='h')return halfId([2,3,1,0,5,6,7,4][d.side],d.b,d.g,d.r+1);", " if(d.t==='h')return halfId([2,3,1,0,5,6,7,4][d.side],d.b,d.g,d.r+1,d.inv);")
rep("halfId(d.side,b,d.g,d.r)}", "halfId(d.side,b,d.g,d.r,d.inv&&b!==BLANK_B)}")
# splitting
rep(" if(m.type in SPLIT)return (d.t==='w'&&!d.inv)||(d.t==='c'&&d.axis===SPLIT[m.type]);", " if(m.type in SPLIT)return d.t==='w'||(d.t==='c'&&d.axis===SPLIT[m.type]);")
rep("  if(d.t==='w')out.push(halfId(sd[0],d.b,d.g,d.r),halfId(sd[1],d.b,d.g,d.r));else out.push(halfId(sd[0],d.a.b,d.a.g,d.a.r),halfId(sd[1],d.c.b,d.c.g,d.c.r))}",
    "  if(d.t==='w')out.push(halfId(sd[0],d.b,d.g,d.r,d.inv),halfId(sd[1],d.b,d.g,d.r,d.inv));else out.push(halfId(sd[0],d.a.b,d.a.g,d.a.r,d.a.inv),halfId(sd[1],d.c.b,d.c.g,d.c.r,d.c.inv))}")
# recycling: inverse things give their colour and picture like any other
rep("function recycleCredit(id){const d=dec(id);if(!d||d.inv)return 0;", "function recycleCredit(id){const d=dec(id);if(!d)return 0;")
# drawing inverse parts (halves and two-part things)
rep(" for(const pt of parts){const bg=COLS[pt.b];g.save();", " for(const pt of parts){const bg=pt.inv?'#f6f2e8':COLS[pt.b],fg=pt.inv?COLS[pt.b]:FG(pt.b);g.save();")
rep("  g.fillStyle='rgba(255,255,255,.14)';rr(g,m+s*0.08,m+s*0.06,s*0.84,s*0.16,s*0.08);g.fill();\n  if(pt.b===BLANK_B)",
    "  g.fillStyle='rgba(255,255,255,.14)';rr(g,m+s*0.08,m+s*0.06,s*0.84,s*0.16,s*0.08);g.fill();\n"
    "  if(pt.inv){g.strokeStyle=COLS[pt.b];g.lineWidth=Math.max(1.5,px*0.06);rr(g,m+px*0.04,m+px*0.04,s-px*0.08,s-px*0.14,r*0.8);g.stroke()}\n  if(pt.b===BLANK_B)")
rep("if(pt.g!==NONE_G)drawGlyph(g,pt.g,FG(pt.b),bg,gx,gy,sz);", "if(pt.g!==NONE_G)drawGlyph(g,pt.g,fg,bg,gx,gy,sz);")
rep("  if(CAPPED.has(pt.g)){g.fillStyle=FG(pt.b);", "  if(CAPPED.has(pt.g)){g.fillStyle=fg;")
rep(" if(d.t==='h')return paintParts(g,px,[{b:d.b,g:d.g,r:d.r,clip:SIDES[d.side]}],true);", " if(d.t==='h')return paintParts(g,px,[{b:d.b,g:d.g,r:d.r,inv:d.inv,clip:SIDES[d.side]}],true);")
# the magnifier shows inverse halves and parts
rep("${iconURL(halfId(sd[k],q.b,q.g,q.r),216)}", "${iconURL(halfId(sd[k],q.b,q.g,q.r,q.inv),216)}")
rep("if(d.t==='h')parts='<span class=\"mb\">half</span>'+", "if(d.t==='h')parts='<span class=\"mb\">half</span>'+(d.inv?'<span class=\"mb\">inverse</span>':'')+")

# ---------- custom things pay by steps: 10★ for one machine step, +3★ for each more ----------
rep("function genCustom(av,pref){",
    "// a custom thing's price grows with the machine steps its recipe takes (Seth, Nov 28): 1 step 10★, then +2★ a step (kept small: stars are meant to stay scarce)\n"
    "const customPrice=n=>CUSTOM_PRICE+2*Math.max(0,(n||1)-1);\n"
    "function genCustom(av,pref){")
rep("halves=keys.filter(p=>{const d=dec(p);return d&&d.t==='h'&&d.b!==BLANK_B&&d.g!==NONE_G&&!FLOWER_G.has(d.g)});",
    "halves=keys.filter(p=>{const d=dec(p);return d&&d.t==='h'&&!d.inv&&d.b!==BLANK_B&&d.g!==NONE_G&&!FLOWER_G.has(d.g)});")
rep(""" for(let tries=0;tries<12;tries++){const A=rnd(WH),B=rnd(WH.filter(p=>p!==A));if(B==null)return null;const a=dec(A),c=dec(B);let t,use=[A,B];
  const tw=()=>rot&&Math.random()<0.25?1+((Math.random()*3)|0):0;
  if(kind==='rot'){t=wholeId(a.b,a.g,a.r+1+((Math.random()*3)|0));use=[A]}
  else if(kind==='dye'){if(a.b===c.b||a.g===c.g)continue;t=wholeId(c.b,a.g,tw())}
  else{const ax=kind;const hs=halves.filter(h=>SIDE_AX[dec(h).side]===ax);
   const c2={...c,r:c.r+tw()};if(hs.length&&Math.random()<0.6){const hid=rnd(hs),h=dec(hid);use=[hid,B];const first=h.side===AX_SIDES[ax][0];t=first?compId(ax,h,c2):compId(ax,c2,h)}else t=compId(ax,{...a,r:a.r+tw()},c2)}
  if(dec(t).t==='w'&&isCat(t))continue;if(av[t]>0)continue;genCustom.use=use;return t}return null}""",
""" // turns(d, k): rotator passes to turn whole d by k quarter turns (0 when the turn doesn't show)
 const turns=(d,k)=>{let id=wholeId(d.b,d.g,d.r),to=wholeId(d.b,d.g,d.r+k);for(let j=0;j<4;j++){if(id===to)return j;id=rotateId(id)}return 0};
 for(let tries=0;tries<12;tries++){const A=rnd(WH),B=rnd(WH.filter(p=>p!==A));if(B==null)return null;const a=dec(A),c=dec(B);let t,use=[A,B],steps;
  const tw=()=>rot&&Math.random()<0.25?1+((Math.random()*3)|0):0;
  if(kind==='rot'){const k=1+((Math.random()*3)|0);t=wholeId(a.b,a.g,a.r+k);use=[A];steps=turns(a,k)}
  else if(kind==='dye'){if(a.b===c.b||a.g===c.g)continue;const k=tw();t=wholeId(c.b,a.g,k);steps=1+turns({b:c.b,g:a.g,r:a.r},k-a.r)}
  else{const ax=kind;const hs=halves.filter(h=>SIDE_AX[dec(h).side]===ax);
   const kc=tw(),c2={...c,r:c.r+kc};if(hs.length&&Math.random()<0.6){const hid=rnd(hs),h=dec(hid);use=[hid,B];const first=h.side===AX_SIDES[ax][0];t=first?compId(ax,h,c2):compId(ax,c2,h);steps=2+turns(c,kc)}
   else{const ka=tw();t=compId(ax,{...a,r:a.r+ka},c2);steps=3+turns(a,ka)+turns(c,kc)}}
  if(!(steps>=1))continue;if(dec(t).t==='w'&&isCat(t))continue;if(av[t]>0)continue;genCustom.use=use;genCustom.steps=steps;return t}return null}""")
rep("  return{order:[{p:t,n:1,got:0,custom:true}],need:genCustom.use||[],t:0,t3:1.5*(36+8*G.mach.length)*UV('patience'),face:rnd(FACES),shirt:rnd(SHIRTS),custom:true}}}",
    "  const n=genCustom.steps||1;return{order:[{p:t,n:1,got:0,custom:true}],need:genCustom.use||[],steps:n,price:customPrice(n),t:0,t3:1.5*(36+8*G.mach.length+10*(n-1))*UV('patience'),face:rnd(FACES),shirt:rnd(SHIRTS),custom:true}}}")
rep("for(const o of c.order){if(o.custom){sale+=CUSTOM_PRICE;", "for(const o of c.order){if(o.custom){sale+=c.price||CUSTOM_PRICE;")
rep("'<span class=\"cut\">✨<span class=\"cl\"> Custom ·</span> '+CUSTOM_PRICE+'★</span>'", "'<span class=\"cut\">✨<span class=\"cl\"> Custom ·</span> '+(c.price||CUSTOM_PRICE)+'★</span>'")
rep("c.custom?'✨ Custom · '+CUSTOM_PRICE+'★'", "c.custom?'✨ Custom · '+(c.price||CUSTOM_PRICE)+'★ · '+(c.steps||1)+' step'+((c.steps||1)>1?'s':'')")
rep("they pay 10★. Spare halves", "they pay 10★ for a one-step recipe and 2★ more for each extra step (the card shows the price; hold it to see the steps). Inverse things cut, turn and join like any other. Spare halves")
rep("rebuildMap,setDemo:v=>{demoMode=v},", "rebuildMap,setDemo:v=>{demoMode=v},customPrice,newCust,recycleCredit,")
open(out, 'w', encoding='utf-8').write(s)
print("v9.4 applied")
