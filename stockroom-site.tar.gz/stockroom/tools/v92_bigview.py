# Stockroom v9.2: Big view (per phone) and the press-and-hold order magnifier (for everyone).
#   python3 v92_bigview.py <v9.1 index.html> <out>
import sys
src, out = sys.argv[1:3]
s = open(src, encoding='utf-8').read()
def rep(a, b, cnt=1):
    global s
    n = s.count(a)
    if n != cnt: sys.exit(f"expected {cnt} of: {a[:100]!r}, found {n}")
    s = s.replace(a, b)

# sharper icons: 144 px by default (crisp at 56 css px on 3x phones), any size on request
rep("function iconURL(p){let u=ICON.get(p);if(!u){const c=document.createElement('canvas');c.width=c.height=72;\n if(p===-1){const g=c.getContext('2d');sheepSprite(g,36,40,20,1,0,0)}else paintItem(c.getContext('2d'),p,72);u=c.toDataURL();ICON.set(p,u)}return u}",
    "function iconURL(p,px=144){const key=p+'@'+px;let u=ICON.get(key);if(!u){const c=document.createElement('canvas');c.width=c.height=px;const g=c.getContext('2d');\n if(p===-1){g.scale(px/72,px/72);sheepSprite(g,36,40,20,1,0,0)}else paintItem(g,p,px);u=c.toDataURL();ICON.set(key,u)}return u}")

# the setting: per phone, like sound
rep("let AC=null,SND=true;try{SND=localStorage.getItem('stockroom.snd')!=='0'}catch(e){}",
    "let AC=null,SND=true;try{SND=localStorage.getItem('stockroom.snd')!=='0'}catch(e){}\n"
    "// Big view (v9.2): bigger orders, hand and floor, stronger contrast. Saved per phone, not per game.\n"
    "let BIGV=false;try{BIGV=localStorage.getItem('stockroom.big')==='1'}catch(e){}\n"
    "function applyBig(){document.body.classList.toggle('bigv',BIGV);ordersDirty=true;handKey=''}")
rep("<button id=\"mS\">Sound: ${SND?'on':'off'}</button>",
    "<button id=\"mS\">Sound: ${SND?'on':'off'}</button><button id=\"mB\">Big view: ${BIGV?'on':'off'}</button>")
rep(" $('#mS').onclick=()=>{SND=!SND;try{localStorage.setItem('stockroom.snd',SND?'1':'0')}catch(e){}showMenu()};",
    " $('#mS').onclick=()=>{SND=!SND;try{localStorage.setItem('stockroom.snd',SND?'1':'0')}catch(e){}showMenu()};\n"
    " $('#mB').onclick=()=>{BIGV=!BIGV;try{localStorage.setItem('stockroom.big',BIGV?'1':'0')}catch(e){}applyBig();toast(BIGV?'Big view on. Press and hold an order to see it up close':'Big view off');showMenu()};")
rep("const minS=TOUCH?30:22;", "const minS=TOUCH?(BIGV?46:30):(BIGV?34:22);")

# CSS
rep("#hand{gap:4px}#hand img{width:34px;height:34px}",
    "#hand{gap:4px}#hand img{width:34px;height:34px}\n"
    "#orders img,#hand img{-webkit-touch-callout:none;-webkit-user-drag:none}#orders .it img{pointer-events:none}\n"
    "body.bigv .it img{width:52px;height:52px;border-radius:10px;box-shadow:0 0 0 2px rgba(255,255,255,.55)}\n"
    "body.bigv .it{font-size:20px;color:#fff;gap:3px}body.bigv .it.nx{outline:3px solid #ffe066;outline-offset:3px;border-radius:12px}body.bigv .it.done{opacity:.18}\n"
    "body.bigv .oc{background:rgba(6,7,10,.97);border-width:2px;padding:6px 10px 12px 6px;gap:8px;flex-wrap:wrap;max-width:calc(100vw - 16px)}\n"
    "body.bigv .oc>b{min-width:32px;height:32px;font-size:18px}body.bigv .oc .st{display:none}body.bigv .oc .bar{height:8px}\n"
    "body.bigv .cut{font-size:15px}body.bigv .cut .cl{display:none}body.bigv .ar{display:none}body.bigv .oc.idle{font-size:17px}\n"
    "body.bigv #hand{max-width:86vw;border-width:2px;background:rgba(6,7,10,.95);min-height:62px}body.bigv #hand img{width:50px;height:50px}\n"
    "body.bigv #hand img.first{outline:3px solid #ffe066}body.bigv #hand .fm b{width:9px;height:9px}body.bigv #hand .cap{font-size:15px;color:#fff}\n"
    "body.bigv .orow>img{width:56px;height:56px}body.bigv .o1{font-size:15.5px}body.bigv .tg{font-size:13px}body.bigv .ohot img{width:36px;height:36px}\n"
    "body.bigv .pill{font-size:16px;border-width:2px}body.bigv #toast{font-size:18px}\n"
    "#mag{position:fixed;left:8px;right:8px;bottom:max(10px,env(safe-area-inset-bottom));z-index:4;background:#0b0c10;border:2px solid #ffd23f;border-radius:18px;padding:12px 14px;max-height:66vh;overflow:hidden;pointer-events:none;box-shadow:0 10px 40px rgba(0,0,0,.7)}\n"
    "#mag.hidden{display:none}#mag h3{margin:0 0 6px;font-size:18px;display:flex;gap:10px;align-items:center;flex-wrap:wrap}#mag h3 b{display:inline-grid;place-items:center;min-width:32px;height:32px;border-radius:50%;background:#ffd23f;color:#222}\n"
    ".mrow{display:flex;align-items:center;gap:10px;padding:7px 0;border-top:1px solid #2a2e38}.mrow.done{opacity:.22}.mrow.nx .mbig{outline:3px solid #ffe066;outline-offset:3px;border-radius:14px}\n"
    ".mbig{width:min(27vw,112px);height:min(27vw,112px);flex:none}#mag.many .mbig{width:min(20vw,80px);height:min(20vw,80px)}\n"
    ".mcol{display:flex;flex-direction:column;gap:6px;min-width:0}.mn{font-size:28px;font-weight:900;color:#fff}.mparts{display:flex;align-items:center;gap:6px;flex-wrap:wrap}\n"
    ".mp{position:relative;display:inline-block}.mparts img{width:min(16vw,62px);height:min(16vw,62px);display:block}#mag.many .mparts img{width:min(12vw,48px);height:min(12vw,48px)}\n"
    ".eq{font-size:24px;color:#8a90a0;font-weight:900}.mb{font-size:14px;font-weight:800;background:#2d323e;border-radius:7px;padding:3px 8px;color:#fff;white-space:nowrap}\n"
    ".mt{position:absolute;right:-4px;top:-6px;background:#ffe066;color:#1d1f24;border-radius:9px;font-size:13px;font-weight:900;padding:1px 5px}")

# the magnifier
rep("$('#orders').addEventListener('click',e=>{const oc=e.target.closest('.oc');if(!oc)return;ensureAudio();",
    "// ---------- the magnifier (v9.2): press and hold an order card to see it up close; let go to close ----------\n"
    "document.body.insertAdjacentHTML('beforeend','<div id=\"mag\" class=\"hidden\"></div>');\n"
    "let magT=0,magH=null,magUsed=false,magP=null;\n"
    "const turnVis=(g,r)=>r%4&&((r*SYM[g])%4)!==0,TURN=['','¼','½','¾'];\n"
    "function magLine(o,nx,craft){const d=dec(o.p);let parts='';const tb=(g,r)=>turnVis(g,r)?`<span class=\"mt\">↻${TURN[r%4]}</span>`:'';\n"
    " if(d.t==='c'){const sd=AX_SIDES[d.axis];parts='<span class=\"eq\">=</span>'+[d.a,d.c].map((q,k)=>`<span class=\"mp\"><img src=\"${iconURL(halfId(sd[k],q.b,q.g,q.r),216)}\" alt=\"\">${tb(q.g,q.r)}</span>`).join('<span class=\"eq\">+</span>');\n"
    "  if(isFlowerD(d))parts+='<span class=\"mb\">two-tone</span>'}\n"
    " else if(d.t==='h')parts='<span class=\"mb\">half</span>'+(craft&&turnVis(d.g,d.r)?`<span class=\"mb\">↻${TURN[d.r%4]}</span>`:'');\n"
    " else{if(d.inv)parts+='<span class=\"mb\">inverse</span>';if(craft&&turnVis(d.g,d.r))parts+=`<span class=\"mb\">↻${TURN[d.r%4]}</span>`}\n"
    " return `<div class=\"mrow${o.got>=o.n?' done':''}${o===nx?' nx':''}\"><img class=\"mbig\" src=\"${iconURL(o.p,288)}\" alt=\"\"><span class=\"mcol\"><span class=\"mn\">×${Math.max(0,o.n-o.got)}</span><span class=\"mparts\">${parts}</span></span></div>`}\n"
    "function showMag(h){const m=$('#mag');let head,lines,nx,craft;\n"
    " if(h==='bq'){const q=G.bq;if(!q)return hideMag();const l=q.due-G.rounds;head=`<b>💐</b> Bouquet · ${l} rush${l===1?'':'es'} · ${q.pay}★`;lines=q.items;nx=q.items.find(o=>o.got<o.n);craft=true}\n"
    " else{const c=HS[+h]&&HS[+h].cust;if(!c||c.farmer)return hideMag();head=`<b>${+h+1}</b>${c.custom?'✨ Custom · '+CUSTOM_PRICE+'★':c.flower?'🌷 Flowers':+h===CASE_H?'Case hatch':'Hatch '+(+h+1)}`;lines=c.order;nx=nextLine(c);craft=!!(c.custom||c.flower)}\n"
    " magH=h;m.classList.toggle('many',lines.length>3);m.innerHTML=`<h3>${head}</h3>`+lines.map(o=>magLine(o,nx,craft)).join('');m.classList.remove('hidden')}\n"
    "function hideMag(){magH=null;$('#mag').classList.add('hidden')}\n"
    "{const O=$('#orders');O.addEventListener('contextmenu',e=>e.preventDefault());\n"
    " O.addEventListener('pointerdown',e=>{const oc=e.target.closest('.oc');magUsed=false;if(!oc)return;magP=[e.clientX,e.clientY];clearTimeout(magT);const h=oc.dataset.h;magT=setTimeout(()=>{magUsed=true;magP=null;showMag(h)},HOLD)});\n"
    " O.addEventListener('pointermove',e=>{if(magP&&Math.hypot(e.clientX-magP[0],e.clientY-magP[1])>14){clearTimeout(magT);magP=null}});\n"
    " const end=()=>{clearTimeout(magT);magP=null;if(magH!=null)hideMag()};addEventListener('pointerup',end);addEventListener('pointercancel',end)}\n"
    "$('#orders').addEventListener('click',e=>{if(magUsed){magUsed=false;return}const oc=e.target.closest('.oc');if(!oc)return;ensureAudio();")
# keep the magnifier current when the cards change (a served line, a customer leaving)
rep(" el.innerHTML=h;barRefs=", " el.innerHTML=h;if(magH!=null)showMag(magH);barRefs=")

# turn it on at start, and in help
rep("rebuildMap,setDemo:v=>{demoMode=v},", "rebuildMap,setDemo:v=>{demoMode=v},showMag,hideMag,setBig:v=>{BIGV=!!v;applyBig()},")
rep("<li><b>Flowers</b>", "<li><b>Hard to see?</b> Press and hold any order to see it up close, with custom things shown as their parts. ☰ → <b>Big view</b> makes the orders, your hands and the floor bigger, with stronger contrast (saved on this phone).</li>\n<li><b>Flowers</b>")
rep(" else newGame();\n camX=(BAY.x0+BAY.x1)/2;", " else newGame();\n applyBig();camX=(BAY.x0+BAY.x1)/2;")
rep("${c.custom?'<span class=\"cut\">✨ Custom · '+CUSTOM_PRICE+'★</span>':''}", "${c.custom?'<span class=\"cut\">✨<span class=\"cl\"> Custom ·</span> '+CUSTOM_PRICE+'★</span>':''}")
open(out, 'w', encoding='utf-8').write(s)
print("v9.2 applied")
