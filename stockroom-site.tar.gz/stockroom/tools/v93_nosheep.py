# Stockroom v9.3: the sheep Easter egg removed entirely (Seth, Nov 28: "Please remove the sheep Easter egg entirely"),
# and no talk of moving about the floor (Seth: "given all of this is tap driven ... remove all reference of movement", Clunk excepted).
#   python3 v93_nosheep.py <v9.2 index.html> <out>
import sys, re
src, out = sys.argv[1:3]
s = open(src, encoding='utf-8').read()
def rep(a, b='', cnt=1):
    global s
    n = s.count(a)
    if n != cnt: sys.exit(f"expected {cnt} of: {a[:100]!r}, found {n}")
    s = s.replace(a, b)
def cut(start, end):  # remove from start up to and including end
    global s
    i = s.index(start); j = s.index(end, i) + len(end)
    s = s[:i] + s[j:]

rep(".oc.farm{border-color:#7bd88f}\n")
rep("if(p===-1){g.scale(px/72,px/72);sheepSprite(g,36,40,20,1,0,0)}else paintItem(g,p,px);", "paintItem(g,p,px);")
rep("doorTaps=[],giveUpT=0,")
rep("const SH={on:false,list:[],h:0,need:0,got:0};\n")
rep("lastNew:0,sheepIn:0,fc:0,", "lastNew:0,fc:0,")
cut("function baa(){", "l.stop(t+0.6)}\n")
cut("function sheepOn(x,y){", "return true;return false}\n")
rep("const canPlace=(x,y)=>free(x,y)&&!sheepOn(x,y);", "const canPlace=(x,y)=>free(x,y);")
rep("&&!sheepOn(c%W,(c/W)|0)", "", 2)
rep("(G.phase==='stock'||G.phase==='down')&&!SH.on;", "(G.phase==='stock'||G.phase==='down');")
rep(" for(const hs of HS)if(hs.cust&&!hs.cust.farmer){", " for(const hs of HS)if(hs.cust){")
rep("\n if(c.farmer){toast('The farmer wants his sheep. Shoo them over with your finger.');return}")
rep("function startRush(early,cb,cl){if(SH.on)giveUpSheep();", "function startRush(early,cb,cl){")
rep("!HS.some(h=>h.cust&&!h.cust.farmer)", "!HS.some(h=>h.cust)")
rep("function endRush(clean){for(const h of HS)if(h.cust&&!h.cust.farmer){", "function endRush(clean){for(const h of HS)if(h.cust){")
rep(" G.sheepIn=(!CO&&G.dn>=4&&Math.random()<0.06)?3:0;", " ")
cut("// ---------- the farmer's flock (shh) ----------\n", "toast('The farmer’s flock is home · +3★');sChime();save()}}\n")
rep("m:[(a.x+b.x)/2,(a.y+b.y)/2]};finger=null;return}", "m:[(a.x+b.x)/2,(a.y+b.y)/2]};return}")
rep(" const[wx,wy]=s2w(e.clientX,e.clientY);\n gest={type:'maybe'", " gest={type:'maybe'")
rep("\n if(SH.on)finger={x:wx,y:wy}});", "});")
rep(" const[wx,wy]=s2w(e.clientX,e.clientY);\n if(gest.type==='maybe'", " if(gest.type==='maybe'")
rep("gest.type=SH.on?'herd':'pan';", "gest.type='pan';")
rep(" if(SH.on)finger={x:wx,y:wy};gest.lx=e.clientX;", " gest.lx=e.clientX;")
rep("if(ptrs.size===0){gest=null;finger=null}", "if(ptrs.size===0){gest=null}")
rep("\n if(cy===-1&&cx>=DOOR[0]&&cx<DOOR[1]){doorTaps=doorTaps.filter(t=>now-t<2500);doorTaps.push(now);beep(170,0.05,'square',0.04);if(doorTaps.length>=5){doorTaps=[];startSheep()}return}")
rep(" const show=G.phase==='rush'||SH.on;", " const show=G.phase==='rush';")
rep("${c.farmer?' farm':''}")
rep("${o===nx&&!c.farmer?' nx':''}", "${o===nx?' nx':''}")
rep("+(c.farmer?'':`<span class=\"st\"></span><i class=\"bar\"></i>`)+", "+'<span class=\"st\"></span><i class=\"bar\"></i>'+")
rep("if(!c||c.farmer)return hideMag();", "if(!c)return hideMag();")
rep("\n if(c&&c.farmer){const now=performance.now();if(now-giveUpT<2500){giveUpSheep()}else{giveUpT=now;toast('Tap again to let the flock go home by itself')}return}")
rep("if(G.phase==='stock'){if(SH.on){toast('Shoo the sheep out first');sErr();return}if(CO)", "if(G.phase==='stock'){if(CO)")
rep("if(!c||c.farmer||!r.bar)continue;", "if(!c||!r.bar)continue;")
rep("+(SH.on?'x':'')")
rep("a.disabled=SH.on||!!(CO&&CO.opening())", "a.disabled=!!(CO&&CO.opening())")
cut("function sheepSprite(g,sx,sy,r,ph,hx,hy){", "r*0.07,0,7);g.fill()}\n")
rep("function drawPerson(x,y,c,farmer,shake){", "function drawPerson(x,y,c,shake){")
rep("\n if(farmer){ctx.fillStyle='#8a5a2b';ctx.beginPath();ctx.ellipse(sx,sy-r*0.7,r*1.35,r*0.32,0,0,7);ctx.fill();ctx.fillRect(sx-r*0.7,sy-r*1.3,r*1.4,r*0.65)}")
rep("if(shake>0||(!farmer&&G.phase==='rush'&&c.t>c.t3*2))", "if(shake>0||(G.phase==='rush'&&c.t>c.t3*2))")
rep("drawPerson(x+0.5,H+0.55,hs.cust,hs.cust.farmer,hs.shake);", "drawPerson(x+0.5,H+0.55,hs.cust,hs.shake);")
rep("if(hs.cust&&!hs.cust.farmer){const rt=rating(hs.cust);", "if(hs.cust){const rt=rating(hs.cust);")
rep("\n if(SH.on)for(const s of SH.list){if(s.gone)continue;const[sx,sy]=w2s(s.x,s.y);const[hx,hy]=sdir(s.hx,s.hy);sheepSprite(ctx,sx,sy,S*0.42,s.ph,hx,hy)}")
rep("\n if(SH.on&&finger){const[fx,fy]=w2s(finger.x,finger.y);ctx.strokeStyle='rgba(255,255,255,.28)';ctx.lineWidth=2;ctx.beginPath();ctx.arc(fx,fy,FR*S,0,7);ctx.stroke()}")
rep(" if(G.phase==='stock'){if(!SH.on&&isFinite(G.phaseT)&&!CO){G.phaseT-=dt;if(G.phaseT<=0)startRush(false)}\n  if(G.sheepIn>0){G.sheepIn-=dt;if(G.sheepIn<=0){G.sheepIn=0;startSheep()}}}",
    " if(G.phase==='stock'){if(isFinite(G.phaseT)&&!CO){G.phaseT-=dt;if(G.phaseT<=0)startRush(false)}}")
rep(" stepSheep(dt);stepMachines(dt);", " stepMachines(dt);")
rep("G.phaseT=Infinity;SH.on=false;SH.list=[];ordersDirty=true;", "G.phaseT=Infinity;ordersDirty=true;")
rep("startRush,endRush,startSheep,", "startRush,endRush,")
rep("get HS(){return HS},SH,tap,", "get HS(){return HS},tap,")
rep("setFinger:f=>{finger=f},")
rep("// v8: the Display Case (bottom left, beside hatch 1) and the Cooler (top right).\n// Case: one thing per spot. Fresh half x 3..5 (by the hatch), the rest x 0..2. Front row = y 14, the wall edge.",
    "// The Display Case (bottom left, around hatch 1) and the Cooler (top right).\n// Case: one thing per spot, three sections: other x 0..2, fresh x 3..5, flowers x 6..8. Front row = y 14, the wall edge.")
rep("// spots in rank order: front row first, nearest the hatch first", "// spots in rank order: front row first (it draws the most interest), then a fixed order along each row")
left = [m.group(0) for m in re.finditer(r'SH\.|\bSH\b|sheep|Sheep|farmer|doorTaps|giveUp|flock|herd|\bbaa\b|finger', s)]
if left: sys.exit(f"left over: {sorted(set(left))}")
open(out, 'w', encoding='utf-8').write(s)
print("v9.3 applied")
