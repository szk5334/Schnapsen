/* STOCKROOM ON THE STREET — the co-op adapter (co-op build step 1).
 *
 * The page opens on the street door: open a new street (you get a 4-letter code), join one by its code, or play
 * alone. A street is a room on the site's own transport (the same relays as Schnapsen and Scroll & Stone; rooms
 * are prefixed "stock-"), so nothing here talks to anything the other games don't.
 *
 * Every warehouse runs its own floor, stock and save. What the street shares (step 1) is the clock:
 *   order → delivery → rush → summary (→ day off every 3rd rush), with
 *   - ordering, summaries and days off as barriers: the street moves on when every shop present is ready;
 *   - one put-away timer (the longest anyone needs) and one rush clock (the longest anyone has);
 *   - shared hatches: whoever opens them opens them for everyone, and the early bonus is the street's.
 *
 * The street's state {d, ph, end, bonus, n} rides in the presence of every seated phone; the newest copy (n)
 * wins. The first seated person who is here (the opener, else the next) moves it on. Each phone reports where
 * its own warehouse is (sr: pos, waiting, opening, put-away, rush length) in its presence, and brings its own
 * warehouse up to the street's position. Presence changes only at phase changes: a handful per rush, far
 * under the relay budget (a burst of 30, then 1 a second per phone). Clunk, hands and animations stay local.
 *
 * Positions: pos = d*10 + {sum 0, down 1, order 2, stock 3, rush 4}, where d = rushes finished (G.rounds).
 * Deadlines are wall-clock ms (phones keep their clocks within a second of each other).
 *
 * No player-facing text mentions devices, servers or the like (site rule). */
import { relayP2P } from "../app/net/relay.js";
import { localP2P } from "../app/net/local.js";
import { openMesh } from "../app/net/mesh.js";
import { LS, makeCode, cleanCode } from "../app/util.js";
import { me, setName } from "../app/ident.js";

export const BUILD = "2026-11-28.6 (Stockroom v11.1: automatic ordering; phone orders at walk-in prices)";
const SEATS = 2;
const IDX = { sum: 0, down: 1, order: 2, stock: 3, rush: 4 };
const posOf = (ph, d) => d * 10 + (IDX[ph] ?? 0);
/* The street's clock. __srdt is a test-only offset (tests/sr16_street.py runs a rush out without waiting 90 s). */
const clock = () => Date.now() + (window.__srdt || 0);
const TICK_MS = 250, GRACE_MS = 4000, LOST_MS = 25000;
/* Someone who drops out of the room (a reload, a phone switching networks) still holds the street's barriers this
 * long, with what they last reported, so a reload never costs them their order or their rush. */
const GONE_MS = 60000;
const q = new URLSearchParams(location.search);
const NS = q.get("as") ? "as." + q.get("as") + "." : "";   // matches app/util.js, so ?as= tabs keep separate saves

const $ = s => document.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const card = html => { $("#ovc").classList.remove("ord"); $("#ovc").innerHTML = html; $("#ov").classList.remove("hidden"); };

const cfg = window.SX_CONFIG || {};
let p2p = null;
const transport = () => {
  if (!p2p) {
    const base = q.has("local") ? localP2P() : relayP2P(cfg);
    p2p = Object.create(base);
    p2p.join = (roomId, opts) => base.join("stock-" + roomId, opts);
  }
  return p2p;
};

/* ------------------------------------------------------------------ the street door */
function home(note) {
  LS.del("sr.session");
  const name = me.get().name;
  card(`<h2>Stockroom</h2>
    <p style="margin:0 0 10px">Run a shop next door to a friend. Open a street and share its code, or join theirs.</p>
    <label style="display:block;font-weight:700;margin:6px 0 4px">Your name</label>
    <input id="nm" maxlength="16" autocomplete="off" value="${esc(name)}" placeholder="Name"
      style="width:100%;font:inherit;padding:10px 12px;border-radius:12px;border:1px solid #4a5060;background:#14161c;color:inherit;user-select:text;-webkit-user-select:text">
    ${note ? `<p style="color:#ffc2c2;margin:10px 0 0">${esc(note)}</p>` : ""}
    <div class="up" style="margin-top:12px"><div class="t"><b>Open a new street</b><small>You get a code to send next door.</small></div><button class="big" id="hOpen">Open</button></div>
    <div class="up"><div class="t"><b>Join a street</b>
      <input id="cd" maxlength="4" autocomplete="off" placeholder="CODE" style="margin-top:6px;width:7.5em;font:inherit;font-weight:800;letter-spacing:4px;text-transform:uppercase;padding:8px 10px;border-radius:10px;border:1px solid #4a5060;background:#14161c;color:inherit;user-select:text;-webkit-user-select:text"></div>
      <button id="hJoin">Join</button></div>
    <div class="row"><button id="hSolo">Play alone</button></div>`);
  const named = () => { const n = $("#nm").value.trim(); if (!n) { $("#nm").focus(); $("#nm").style.borderColor = "#ff9f43"; return false; } setName(n); return true; };
  $("#hOpen").onclick = () => {
    if (!named()) return;
    const code = makeCode();
    const w = me.get();
    const st = { code, owner: w.cid, seed: (Math.random() * 2147483647) | 0, seats: [{ cid: w.cid, name: w.name, color: w.color }],
      status: "open", d: 0, ph: "stock", end: 0, bonus: 0, n: 1 };
    LS.set("sr.st." + code, st);
    street(code);
  };
  const join = () => { const c = cleanCode($("#cd").value); if (c.length !== 4) { $("#cd").focus(); return; } if (named()) street(c); };
  $("#hJoin").onclick = join;
  $("#cd").onkeydown = e => { if (e.key === "Enter") join(); };
  $("#hSolo").onclick = () => { $("#ov").classList.add("hidden"); loadGame(); };
}

/* ------------------------------------------------------------------ one street */
function street(code) {
  LS.set("sr.session", { code, at: Date.now() });
  const self = () => me.get();
  let st = LS.get("sr.st." + code);
  let sr = null;                         // what this warehouse reports, once the game runs
  let api = null;                        // the game's hooks (stockroom/game.js), once it runs
  let openReq = -1;                      // the position at which this phone asked to open the hatches
  let started = false, lostT = 0, ticker = 0;
  const openedAt = Date.now();

  const seated = cid => !!(st && st.seats.some(x => x.cid === cid));
  const presence = () => { const w = self(); return { cid: w.cid, name: w.name, color: w.color, ...(st && seated(w.cid) ? { st } : {}), ...(sr ? { sr } : {}) }; };
  const mesh = openMesh(transport(), "street-" + code, { presence: presence() });
  const publish = () => mesh.setPresence(presence());
  me.sub(publish);

  const better = (a, b) => !b || a.n > b.n || (a.n === b.n && posOf(a.ph, a.d) > posOf(b.ph, b.d));
  const keep = next => { st = next; LS.set("sr.st." + code, st); publish(); };
  const change = patch => keep({ ...st, ...patch, n: st.n + 1 });
  const here = () => mesh.people.get();
  const present = cid => here().some(p => p.cid === cid);
  const lastSeen = new Map();             // cid -> { at, sr }: the last time a seated person was here, and their report
  const seen = () => { for (const x of (st ? st.seats : [])) { const p = x.cid !== self().cid && latest(x.cid); if (p) lastSeen.set(x.cid, { at: Date.now(), sr: p.sr }); } };
  const counted = cid => present(cid) || (lastSeen.has(cid) && Date.now() - lastSeen.get(cid).at < GONE_MS);
  /* A person's newest presence (a reload leaves the old one behind for a while). */
  const latest = cid => { const id = mesh.peerOf(cid); return here().find(y => y.peerId === id) || here().find(y => y.cid === cid && !y.self); };
  const name = cid => { const p = here().find(x => x.cid === cid); return (p && p.name) || ((st && st.seats.find(x => x.cid === cid)) || {}).name || "Next door"; };

  /* The first seated person who is here moves the street on; a phone that has just arrived first listens a moment. */
  const acting = () => {
    if (!st || st.status !== "on") return false;
    const first = st.seats.find(x => present(x.cid));
    if (!first || first.cid !== self().cid) return false;
    const others = st.seats.filter(x => x.cid !== self().cid);
    const heardAll = others.every(x => here().some(p => p.cid === x.cid && p.sr));
    return Date.now() - openedAt > (heardAll ? GRACE_MS : 2 * GRACE_MS);
  };
  /* The shops taking part right now: seated and here (or only just gone). Their reports (this phone's own included). */
  const players = () => st.seats.filter(x => counted(x.cid)).map(x => {
    if (x.cid === self().cid) return { cid: x.cid, sr };
    const p = latest(x.cid);
    return { cid: x.cid, sr: p ? p.sr : (lastSeen.get(x.cid) || {}).sr };
  });

  function advance() {
    const S = posOf(st.ph, st.d), ps = players(), now = clock();
    if (!ps.length || !ps.some(p => p.cid === self().cid && p.sr)) return;
    const ready = ps.every(p => p.sr && (p.sr.p > S || (p.sr.p === S && p.sr.w)));
    const atS = ps.filter(p => p.sr && p.sr.p === S);
    switch (st.ph) {
      case "order":
        if (ready) change({ ph: "stock", end: now + Math.max(30, ...atS.map(p => p.sr.put || 0)) * 1000, bonus: 0 });
        break;
      case "stock":
        if (atS.some(p => p.sr.o) || (st.end && now >= st.end)) {
          const left = st.end ? Math.max(0, st.end - now) : 0;
          const L = Math.max(30, ...atS.map(p => p.sr.rl || 0));
          change({ ph: "rush", bonus: Math.floor(left / 15000), end: now + L * 1000 });
        }
        break;
      case "rush":
        if (now >= st.end || ps.every(p => p.sr && p.sr.p > S)) change({ ph: "sum", d: st.d + 1, end: 0, bonus: 0 });
        break;
      case "sum":
        if (ready) change({ ph: st.d % 3 === 0 ? "down" : "order" });
        break;
      case "down":
        if (ready) change({ ph: "order" });
        break;
    }
  }

  /* Bring this warehouse up to where the street is: one step per tick. */
  function reconcile(info) {
    const L = posOf(info.ph, info.d), S = posOf(st.ph, st.d);
    if (L >= S) return;
    if (info.ph === "rush") api.end();
    else if (info.ph === "sum") { if (info.d % 3 === 0 && S === info.d * 10 + 1) api.toDown(); else api.toOrder(); }
    else if (info.ph === "down") api.toOrder();
    else if (info.ph === "order") api.land();
    else if (info.ph === "stock") {
      if (S === L + 1) api.rush(st.bonus || 0, Math.max(1, (st.end - clock()) / 1000));
      else api.rush(0, 0.05);           // the street is further on: this rush is already over
    }
  }

  function tick() {
    if (!api) return;
    const info = api.info();
    const L = posOf(info.ph, info.d);
    const mine = { p: L, w: info.w ? 1 : 0, o: openReq === L ? 1 : 0, put: info.put, rl: info.rl };
    if (!sr || JSON.stringify(mine) !== JSON.stringify(sr)) { sr = mine; publish(); }
    seen();
    if (acting()) advance();
    reconcile(info);
    pill();
  }

  /* ---- the street pill and card */
  function others() {
    return st.seats.filter(x => x.cid !== self().cid).map(x => {
      const p = latest(x.cid);
      const S = posOf(st.ph, st.d);
      const state = !p ? (counted(x.cid) ? "gone" : "away") : !p.sr ? "…" : (p.sr.p > S || (p.sr.p === S && p.sr.w)) ? "ready" : "busy";
      return { name: name(x.cid), state };
    });
  }
  let pillHTML = "";
  function pill() {
    let el = $("#streetB");
    if (!el) {
      el = document.createElement("div");
      el.id = "streetB"; el.className = "pill"; el.style.pointerEvents = "auto"; el.style.cursor = "pointer";
      $("#bar").insertBefore(el, $("#bar .sp"));
      el.onclick = () => api && !api.ovOpen() && showStreet();
    }
    const os = others();
    const h = "🏪 " + (os.length ? os.map(o => esc(o.name) + " " + ({ ready: "✓", busy: "…", away: "💤", gone: "…", "…": "…" }[o.state])).join(" · ") : esc(code));
    if (h !== pillHTML) { pillHTML = h; el.innerHTML = h; }
  }
  function showStreet() {
    const os = others();
    api.ov(`<h2>Street ${esc(code)}</h2>
      <p style="margin:0 0 6px">Send this code next door: <b style="letter-spacing:3px;color:#ffd23f">${esc(code)}</b></p>
      ${os.length ? os.map(o => `<div class="up"><div class="t"><b>${esc(o.name)}</b><small>${{ ready: "Ready and waiting for you", busy: "Busy in their shop", away: "Not here right now. The street carries on without them.", gone: "Stepped out a moment. The street waits a little.", "…": "On their way in" }[o.state]}</small></div></div>`).join("")
        : `<div class="up"><div class="t"><b>Nobody next door yet</b></div></div>`}
      <p class="omuted">Ordering, summaries and days off wait until every shop is ready. Either of you can open the hatches for both.</p>
      <div class="row"><button id="stLeave">Leave street</button><button class="big" id="stX">Back</button></div>`);
    $("#stX").onclick = () => api.closeOv();
    $("#stLeave").onclick = () => { api.save(); LS.del("sr.session"); location.reload(); };
  }

  /* ---- before the shops open */
  function setupCard() {
    if (started) return;
    const w = self();
    if (!st) {
      card(`<h2>Street ${esc(code)}</h2><p>${lostT ? "Nobody is on this street right now. Check the code, or ask next door to open it." : "Looking for the street…"}</p>
        <div class="row"><button id="sLeave">Back</button></div>`);
    } else if (st.status === "open") {
      const owner = st.owner === w.cid, mine = seated(w.cid);
      const ownerHere = owner || present(st.owner);
      card(`<h2>Street ${esc(code)}</h2>
        <p style="margin:0 0 6px">${owner ? "Send this code next door:" : "You're on the street."}</p>
        <div class="bigstars" style="letter-spacing:8px">${esc(code)}</div>
        ${st.seats.map(x => `<div class="up"><div class="t"><b style="color:${esc(x.color)}">${esc(present(x.cid) || x.cid === w.cid ? name(x.cid) : x.name)}</b><small>${x.cid === st.owner ? "Opened the street" : "Next door"}${present(x.cid) || x.cid === w.cid ? "" : " · not here"}</small></div></div>`).join("")}
        ${st.seats.length < SEATS ? `<div class="up"><div class="t"><small>Waiting for next door to join…</small></div></div>` : ""}
        ${!mine && st.seats.length >= SEATS ? `<p>This street is full.</p>` : ""}
        ${!owner && mine ? `<p class="omuted">${ownerHere ? `Waiting for ${esc(name(st.owner))} to open the shops.` : `${esc(st.seats[0].name)} isn't here right now.`}</p>` : ""}
        <div class="row"><button id="sLeave">Leave</button>${owner ? `<button class="big" id="sGo">${st.seats.length > 1 ? "Open the shops" : "Open my shop alone"}</button>` : ""}</div>`);
      if ($("#sGo")) $("#sGo").onclick = () => change({ status: "on", d: 0, ph: "stock", end: 0, bonus: 0 });
    } else if (!seated(w.cid)) {
      card(`<h2>Street ${esc(code)}</h2><p>The shops on this street are already open.</p><div class="row"><button id="sLeave">Back</button></div>`);
    }
    if ($("#sLeave")) $("#sLeave").onclick = () => { mesh.leave(); if (st && st.owner === w.cid && st.status === "open") LS.del("sr.st." + code); home(); };
  }

  function maybeStart() {
    if (started || !st || st.status !== "on" || !seated(self().cid)) return;
    started = true;
    $("#ov").classList.add("hidden");
    window.SR_COOP = {
      key: "stockroom.v8." + NS + "street." + code + "." + st.seed,
      seed: st.seed,
      attach(a) { api = a; ticker = setInterval(tick, TICK_MS); setTimeout(tick, 0); },
      openHatches() {
        if (!api) return;
        const i = api.info(); openReq = posOf(i.ph, i.d);
        api.toast(others().some(o => o.state !== "away") ? "Opening the hatches for the whole street…" : "Opening the hatches…");
        tick();
      },
      opening() { if (!api) return false; const i = api.info(); return openReq === posOf(i.ph, i.d); },
      /* The street's deadline for this warehouse's current phase, if the street is in that phase too. */
      endAt(ph, d) { return st && posOf(st.ph, st.d) === posOf(ph, d) ? st.end || 0 : 0; },
      now: clock,
      showStreet,
    };
    loadGame();
  }

  mesh.people.sub(list => {
    for (const p of list) if (!p.self && p.st && p.st.code === code && better(p.st, st)) { st = p.st; LS.set("sr.st." + code, st); publish(); }
    seen();
    if (st && st.status === "open" && st.owner === self().cid) {
      /* The opener seats whoever comes in with the code, up to two shops; a seat empties if they leave before the start. */
      let seats = st.seats.filter(x => x.cid === st.owner || present(x.cid));
      for (const p of list) if (!p.self && p.cid && seats.length < SEATS && !seats.some(x => x.cid === p.cid)) seats.push({ cid: p.cid, name: p.name, color: p.color });
      seats = seats.map(x => { const p = list.find(y => y.cid === x.cid); return p ? { cid: x.cid, name: p.name, color: p.color } : x; });
      if (JSON.stringify(seats) !== JSON.stringify(st.seats)) change({ seats });
    }
    maybeStart();
    setupCard();
    if (api) pill();
  });
  setTimeout(() => { if (!st) { lostT = 1; setupCard(); } }, LOST_MS);
  setupCard();
  maybeStart();
  window.__street = { get st() { return st; }, get sr() { return sr; }, mesh, tick, acting };
}

/* ------------------------------------------------------------------ the warehouse itself */
function loadGame() {
  document.body.classList.remove("lobby");
  const s = document.createElement("script");
  s.src = "stockroom/game.js?b=" + encodeURIComponent(BUILD.split(" ")[0]);
  document.body.appendChild(s);
}

try {
  console.info("Stockroom build", BUILD);
  const ses = LS.get("sr.session");
  if (ses && ses.code) street(ses.code); else home();
} catch (e) {
  console.error(e);
  card(`<h2>Something went wrong</h2><pre style="white-space:pre-wrap">${esc(e && e.message || e)}</pre><div class="row"><button class="big" onclick="location.reload()">Reload</button></div>`);
}
