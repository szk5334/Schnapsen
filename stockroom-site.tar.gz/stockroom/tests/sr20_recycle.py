# Stockroom v8.1: recycled stock menu, dye swapper whole-only, case target visibility (screenshot).
import asyncio, sys, os
from playwright.async_api import async_playwright
SRC = sys.argv[1] if len(sys.argv) > 1 else "/home/claude/stockroom/index.html"
ok, bad = [], []
def check(c, m): (ok if c else bad).append(m); print(("  ok  " if c else "FAIL  ") + m, flush=True)
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path="/usr/bin/google-chrome",args=["--no-sandbox"])
        pg=await (await b.new_context(viewport={"width":420,"height":860},device_scale_factor=2,is_mobile=True,has_touch=True)).new_page();errs=[]
        pg.on("pageerror",lambda e:errs.append(str(e)))
        await pg.goto("file://"+SRC);await pg.wait_for_function("!!window.__wh");await pg.click("#hX")
        g=lambda js:pg.evaluate(js)
        await g("""(()=>{const w=__wh,G=w.G;G.mach.push({type:'recyc',k:9*32+12,inp:[],inf:[],t:0,out:[],of:3},{type:'dye',k:9*32+14,inp:[],inf:[],t:0,out:[],of:3});G.items[9*32+12]=-3;G.items[9*32+14]=-3;
          G.rc.c[3]=5;G.rc.s[10]=2;G.hand=[];G.handF=[]})()""")
        await g("__wh.tap(12.5,9.5)")
        check(await g("__wh.ovOpen()&&!!document.querySelector('.rgrid')"), "tapping the recycler with empty hands opens the recycled stock")
        n=await g("document.querySelectorAll('.rb').length")
        check(n==2, f"two kinds of blank on offer ({n})")
        await pg.screenshot(path="/tmp/sr-shots/v81_recycle.png")
        await g("document.querySelector('[data-rk=\"c3\"]').click()")
        await g("document.querySelector('[data-rk=\"c3\"]').click()")
        check(await g("__wh.G.hand.length===2&&__wh.G.rc.c[3]===1&&!document.querySelector('[data-rk=\"c3\"]')"), "taking two green tiles uses 4 parts; the last part isn't enough for a third")
        await g("document.querySelector('[data-rk=\"s10\"]').click()")
        check(await g("__wh.G.hand.length===3&&__wh.G.rc.s[10]===0"), "a blank picture comes into the hands")
        await g("document.querySelector('#rX').click()")
        check(await g("!__wh.ovOpen()"), "Done closes it")
        check(await g("!document.querySelector('.mk-refurb')"), "no refurbished section on the order page any more")
        # dye: whole things only
        dyeok=await g("(()=>{const w=__wh,m=w.G.mach[1];const h=w.halfId(0,2,5,0),wh=w.wholeId(2,5,0);return[w.accepts(m,h),w.accepts(m,wh)]})()")
        check(dyeok==[False,True], f"dye swapper refuses halves, takes wholes {dyeok}")
        # a blank picture + a colour tile make the real thing
        res=await g("""(()=>{const w=__wh,G=w.G,m=G.mach[1];m.inp=[w.wholeId(12,10,0),w.wholeId(3,37,0)];m.inf=[0,0];w.runMachine(m);return m.out.map(x=>{const d=w.dec(x);return[d.t,d.b,d.g,!!d.inv]})})()""")
        check(res==[["w",3,10,False],["w",3,10,True]], f"blank picture + dye tile → the real thing and its inverse {res}")
        # in a rush, the recycler still opens
        await g("__wh.G.hand=[];__wh.G.handF=[];__wh.startRush(true);__wh.closeOv()")
        await g("__wh.tap(12.5,9.5)")
        check(await g("__wh.ovOpen()&&!!document.querySelector('#rX')"), "the recycled stock opens in a rush too")
        await g("document.querySelector('#rX').click()")
        await g("__wh.endRush(false)")
        # case targets visible
        await g("""(()=>{const w=__wh,G=w.G;G.batch=8;G.ct=w.caseTargets();w.closeOv()})()""")
        check(not errs, "no page errors"+(": "+"; ".join(errs[:3]) if errs else ""))
        await b.close()
    print(f"\n{len(ok)} ok, {len(bad)} failed"); sys.exit(1 if bad else 0)
asyncio.run(main())
