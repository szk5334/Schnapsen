# v8.2: a custom order's materials are held, so later customers aren't promised the same whole thing.
import asyncio, sys
from playwright.async_api import async_playwright
SRC = sys.argv[1] if len(sys.argv) > 1 else "/home/claude/stockroom/index.html"
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path="/usr/bin/google-chrome",args=["--no-sandbox"])
        pg=await (await b.new_context()).new_page();errs=[]
        pg.on("pageerror",lambda e:errs.append(str(e)))
        await pg.goto("file://"+SRC);await pg.wait_for_function("!!window.__wh");await pg.click("#hX")
        r=await pg.evaluate("""(()=>{const w=__wh,G=w.G;G.rounds=6;
          G.mach=[{type:'rot',k:1,inp:[],inf:[],t:0,out:[],of:3},{type:'dye',k:2,inp:[],inf:[],t:0,out:[],of:3}];
          // exactly one of each line in stock
          const lines=[...new Set(G.items.filter(v=>v>=0&&v<10000))];for(let k=0;k<G.items.length;k++)if(G.items[k]>=0)G.items[k]=-1;
          lines.forEach((p,i)=>{const k=8*32+2+i;G.items[k]=p;G.cnt[k]=1});
          w.startRush(true);w.closeOv();for(const h of w.HS)h.cust=null;
          let c=null;for(let i=0;i<500&&!c;i++){const x=w.newCust(1);if(x&&x.custom&&x.need&&x.need.length)c=x}
          if(!c)return{err:'no custom'};w.HS[1].cust=c;w.HS[1].open=true;
          let hits=0,n=0;for(let i=0;i<600;i++){const x=w.newCust(0);if(!x||x.custom)continue;n++;for(const o of x.order)if(c.need.includes(o.p))hits++}
          return{need:c.need,n,hits}})()""")
        print(r, errs[:2]); await b.close()
        ok = r.get("hits") == 0 and r.get("n", 0) > 50 and not errs
        print("ok" if ok else "FAIL"); sys.exit(0 if ok else 1)
asyncio.run(main())
