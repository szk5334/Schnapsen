# Stockroom v9: flowers, dyes and their trend, the colour stripper, inverses, flower customers, bouquets, the case's flower section.
import asyncio, sys, os
from playwright.async_api import async_playwright
SRC = sys.argv[1] if len(sys.argv) > 1 else "/home/claude/stockroom/index.html"
OUT="/tmp/sr-shots";os.makedirs(OUT,exist_ok=True)
ok, bad = [], []
def check(c, m): (ok if c else bad).append(m); print(("  ok  " if c else "FAIL  ") + m, flush=True)
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path="/usr/bin/google-chrome",args=["--no-sandbox"])
        pg=await (await b.new_context(viewport={"width":900,"height":700},device_scale_factor=2)).new_page();errs=[]
        pg.on("pageerror",lambda e:errs.append(str(e)))
        await pg.goto("file://"+SRC);await pg.wait_for_function("!!window.__wh");await pg.click("#hX")
        g=lambda js:pg.evaluate(js)
        check(await g("!__wh.G.fx&&__wh.dyeLines().length===0"), "no flowers before rush 5")
        # flowers arrive with the order page after rush 5
        await g("__wh.G.rounds=5;__wh.G.stars=200;__wh.openOrder()")
        check(await g("__wh.G.fx===1&&__wh.G.fNew===1"), "flowers arrive at rush 5")
        check(await g("!!document.querySelector('.mk-flower')&&!!document.querySelector('.mk-dye')"), "order page has Flowers and Dyes sections")
        nfl,ndy=await g("[__wh.fBlanks().length,__wh.dyeLines().length]")
        check(nfl==3 and ndy==12, f"3 blank flower lines, 12 dye lines ({nfl}, {ndy})")
        check(await g("__wh.fBlanks().every(p=>__wh.G.sup[p]>=1)"), "every blank flower is in supply the first time")
        await pg.screenshot(path=f"{OUT}/v9_order.png")
        # trend: one dye can be trending; dyes list sorted by interest
        await g("__wh.G.hotD={p:__wh.dyeLines()[4],left:2};__wh.closeOv();__wh.openOrder()")
        first=await g("document.querySelector('.mk-dye').nextElementSibling.querySelector('img').src===document.querySelector('.mk-dye').nextElementSibling.querySelector('img').src")
        check(await g("!!document.querySelector('.mk-dye ~ .orow .tg.hot')"), "the trending dye is flagged in the Dyes section")
        # order a crate of each blank flower and two dyes; the free starter comes with it
        await g("(()=>{const w=__wh,G=w.G;for(const p of w.fBlanks())if(G.sup[p])G.ord[p]=1;const d=w.dyeLines();G.ord[d[0]]=Math.min(1,G.sup[d[0]]||0);document.querySelector('#oGo').click()})()")
        st=await g("(()=>{const w=__wh,c=w.stockCounts();return[w.fBlanks().reduce((a,p)=>a+(c[p]||0),0),w.dyeLines().reduce((a,p)=>a+(c[p]||0),0)]})()")
        check(st[0]>=4 and st[1]>=3, f"flowers and dyes delivered, with the free starter ({st[0]} blanks, {st[1]} dyes)")
        check(await g("__wh.G.fNew===0"), "the starter only comes once")
        # the swapper: blank flower + dye → flower + inverse
        res=await g("""(()=>{const w=__wh,G=w.G;const m={type:'dye',k:1,inp:[w.wholeId(12,38,0),w.wholeId(0,37,0)],inf:[3,0],t:0,out:[],of:3};w.runMachine(m);return m.out.map(x=>{const d=w.dec(x);return[d.b,d.g,!!d.inv,w.isFlower(x),w.isFresh(x)]})})()""")
        check(res==[[0,38,False,True,True],[0,38,True,True,True]], f"blank flower + red dye → red flower + inverse red flower {res}")
        res=await g("""(()=>{const w=__wh;const m={type:'dye',k:1,inp:[w.wholeId(0,7,0),w.wholeId(5,37,0)],inf:[0,0],t:0,out:[],of:3};w.runMachine(m);return m.out.map(x=>{const d=w.dec(x);return[d.b,d.g,!!d.inv]})})()""")
        check(res==[[5,7,False],[0,37,False]], f"red moon + blue dye → blue moon + red dye (colours swap) {res}")
        res=await g("""(()=>{const w=__wh;const m={type:'dye',k:1,inp:[w.wholeId(12,7,0),w.wholeId(0,5,0)],inf:[0,0],t:0,out:[],of:3};w.runMachine(m);return m.out.map(x=>{const d=w.dec(x);return[d.b,d.g,!!d.inv]})})()""")
        check(res==[[0,7,False],[12,5,False]], f"blank moon + red star → red moon + blank star {res}")
        # the stripper
        check(await g("__wh.checkUnlocks.toString().length>0&&(()=>{const G=__wh.G;G.rounds=7;G.unl=G.unl.filter(t=>t!=='strip');return __wh.checkUnlocks().includes('strip')})()"), "the colour stripper unlocks at rush 7")
        res=await g("""(()=>{const w=__wh;const m={type:'strip',k:1,inp:[w.wholeId(3,5,0)],inf:[0],t:0,out:[],of:3};w.runMachine(m);return m.out.map(x=>{const d=w.dec(x);return[d.b,d.g]})})()""")
        check(res==[[12,5],[3,37]], f"stripper: green star → blank star + green dye {res}")
        acc=await g("(()=>{const w=__wh,m={type:'strip'};return[w.accepts(m,w.wholeId(3,5,0)),w.accepts(m,w.wholeId(12,5,0)),w.accepts(m,w.wholeId(3,37,0)),w.accepts(m,w.halfId(0,3,5,0)),w.accepts(m,w.invId(3,38,0))]})()")
        check(acc==[True,False,False,False,True], f"stripper takes coloured wholes (and inverses), not blanks, dyes or halves {acc}")
        # inverses stay whole: splitters and the recycler refuse them; the rotator keeps them inverse
        r=await g("(()=>{const w=__wh,iv=w.invId(2,38,0);return[w.accepts({type:'vsplit'},iv),w.dec(w.rotateId(iv)).inv===true]})()")
        check(r==[True,True], f"inverses can be cut (v9.4); turning keeps them inverse {r}")
        # flowers only join with flowers
        res=await g("""(()=>{const w=__wh;const m={type:'comb',k:1,inp:[w.halfId(0,0,38,0),w.halfId(1,3,5,0)],inf:[0,0],t:0,out:[],of:3};w.runMachine(m);const a=m.out.length;
             const m2={type:'comb',k:1,inp:[w.halfId(0,0,38,0),w.halfId(1,3,38,0)],inf:[0,0],t:0,out:[],of:3};w.runMachine(m2);return[a,m2.out.length,w.dec(m2.out[0]).t]})()""")
        check(res==[2,1,'c'], f"a flower half won't join a non-flower half; two flower halves make a two-tone flower {res}")
        # prices
        pr=await g("(()=>{const w=__wh;w.G.hotD=null;return[w.flowerPrice(w.wholeId(0,38,0),3),w.flowerPrice(w.invId(0,38,0),3),w.flowerPrice(w.wholeId(0,38,0),1),w.flowerPrice(w.compId(0,{b:0,g:38,r:0},{b:3,g:38,r:0}),3)]})()")
        check(pr==[5,6,3,8], f"flower prices: 5★, inverse 6★, last day 3★, two-tone 8★ {pr}")
        hp=await g("(()=>{const w=__wh;w.G.hotD={p:w.wholeId(0,37,0),left:2};return w.flowerPrice(w.wholeId(0,38,0),3)})()")
        check(hp==7.5, f"a trending colour pays ×1½ ({hp})")
        # flower customers
        await g("""(()=>{const w=__wh,G=w.G;G.rounds=6;let k=10*32+2;const put=(p,n,f)=>{while(G.items[k]!==-1||w.SOLID[k]||w.CASEM[k])k++;G.items[k]=p;G.cnt[k]=n;G.fr[k]=f;k++};
            for(const p of w.fBlanks())put(p,4,3);for(const p of w.dyeLines().slice(0,6))put(p,3,0);w.closeOv();w.startRush(true);w.closeOv()})()""")
        fc=await g("""(()=>{const w=__wh;let n=0,fl=0,ok=0,inv=0;for(let i=0;i<400;i++){const c=w.newCust(1);if(!c)continue;n++;if(c.flower){fl++;if(c.order.every(o=>w.colouredFlower(o.p))&&c.need.length>=0)ok++;if(c.order.some(o=>w.dec(o.p).inv))inv++}}return[n,fl,ok,inv]})()""")
        check(fc[1]>0.1*fc[0] and fc[1]<0.35*fc[0] and fc[2]==fc[1] and fc[3]>0, f"about 1 in 5 customers want coloured flowers, some inverse ({fc})")
        need=await g("""(()=>{const w=__wh;for(let i=0;i<200;i++){const c=w.genFlower(w.stockCounts(),1);if(c&&c.need.length)return c.need.map(p=>w.dec(p).g)}return null})()""")
        check(need is not None and 37 in need and any(x>=38 for x in need), f"a flower customer holds a blank flower and a dye ({need})")
        # serve a flower customer
        got=await g("""(()=>{const w=__wh,G=w.G,h=w.HS[1];w.G.hotD=null;const p=w.wholeId(3,39,0);h.open=true;h.cust={order:[{p,n:1,got:0}],t:0,t3:100,face:'#fff',shirt:'#000',flower:true};G.hand=[p];G.handF=[3];const s0=G.stars;w.serveAt(1);return G.stars-s0})()""")
        check(got==3+5, f"a quick flower sale pays 3★ service + 5★ ({got})")
        await g("__wh.endRush(false)")
        # bouquets
        bq=await g("(()=>{const w=__wh,G=w.G;G.bq=w.makeBouquet();return G.bq})()")
        check(bq and 2<=len(bq["items"])<=3 and bq["due"]>=8, f"a bouquet: {len(bq['items'])} lines, due after rush {bq['due']}, pays {bq['pay']}★")
        await g("document.querySelector('#nx')&&document.querySelector('#nx').click();__wh.closeOv()")
        await g("__wh.G.phase='stock';__wh.G.phaseT=60")
        await pg.wait_for_timeout(200)
        check(await g("!!document.querySelector('#orders .oc.bq')"), "the bouquet card shows between rushes")
        pay=await g("""(()=>{const w=__wh,G=w.G,q=G.bq;const s0=G.stars;const first=q.items[0];G.hand=[first.p];G.handF=[3];w.serveBq();const part=first.got===1&&G.bq===q;
             G.hand=[];G.handF=[];for(const o of q.items)for(let i=o.got;i<o.n;i++){G.hand.push(o.p);G.handF.push(3)}w.serveBq();return[part,G.bq===null,G.stars-s0,q.pay]})()""")
        check(pay[0] and pay[1] and pay[2]==pay[3], f"bouquet handed in bit by bit, then paid in full {pay}")
        lapse=await g("""(()=>{const w=__wh,G=w.G;G.bq=w.makeBouquet();G.bq.due=G.rounds+1;w.startRush(true);w.closeOv();w.endRush(false);return[G.bq===null,!!G.lastRS.bqLost]})()""")
        check(lapse==[True,True], f"an unfinished bouquet lapses when it's due {lapse}")
        await g("__wh.closeOv()")
        # the case's flower section
        await g("""(()=>{const w=__wh,G=w.G;let k=11*32+10;for(const p of [w.wholeId(0,38,0),w.invId(3,39,0),w.wholeId(5,40,0),w.wholeId(12,41,0)]){while(G.items[k]!==-1||w.SOLID[k])k++;G.items[k]=p;G.cnt[k]=2;G.fr[k]=3;k++}G.ct=w.caseTargets()})()""")
        ft=await g("__wh.G.ct.slice(12).filter(t=>t>=0).map(t=>[__wh.dec(t).g,!!__wh.dec(t).inv,__wh.dec(t).b])")
        check(len(ft)>=3 and all(x[2]!=12 for x in ft), f"the flower section targets coloured flowers, not blanks {ft}")
        await g("""(()=>{const w=__wh,G=w.G;w.CSP.forEach((k,i)=>{const t=G.ct[i];if(t>=0){G.items[k]=t;G.cnt[k]=1;G.fr[k]=w.isFresh(t)?3:0}})})()""")
        await g("__wh.startRush(true);__wh.closeOv()")
        sf=await g("""(()=>{const w=__wh;const sh=new Set(w.CSP_L.map(k=>w.G.items[k]).filter(v=>v>=0));let n=0,d=0;for(let i=0;i<500;i++){const c=w.genFlower(w.stockCounts(),0);if(!c)continue;n++;if(c.order.some(o=>sh.has(o.p)))d++}return d/Math.max(1,n)})()""")
        check(sf>0.6, f"flower customers at the case hatch mostly want displayed flowers ({sf:.2f})")
        await g("__wh.endRush(false);__wh.closeOv()")
        await pg.wait_for_timeout(200)
        await pg.screenshot(path=f"{OUT}/v9_case.png")
        # save and reload keeps inverses and flowers
        await g("__wh.save()")
        await pg.reload();await pg.wait_for_function("!!window.__wh")
        check(await g("__wh.G.v===6&&__wh.G.fx===1&&__wh.G.items.some(v=>v>=14096&&v<20000)"), "save v6 keeps flowers and inverses")
        check(not errs, "no page errors"+(": "+"; ".join(errs[:3]) if errs else ""))
        await b.close()
    print(f"\n{len(ok)} ok, {len(bad)} failed"); sys.exit(1 if bad else 0)
asyncio.run(main())
