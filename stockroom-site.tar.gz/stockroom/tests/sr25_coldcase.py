# Stockroom v10: the cold case (fresh things stack only there; no spoilage; plain taps).
import asyncio, sys, os
from playwright.async_api import async_playwright
SRC = sys.argv[1] if len(sys.argv) > 1 else "/home/claude/stockroom/index.html"
OUT="/tmp/sr-shots";os.makedirs(OUT,exist_ok=True)
ok, bad = [], []
def check(c, m): (ok if c else bad).append(m); print(("  ok  " if c else "FAIL  ") + m, flush=True)
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path="/usr/bin/google-chrome",args=["--no-sandbox"])
        pg=await (await b.new_context(viewport={"width":900,"height":700},device_scale_factor=2)).new_page();errs=[]
        pg.on("pageerror",lambda e:errs.append(str(e)))
        await pg.goto("file://"+SRC);await pg.wait_for_function("!!window.__wh");await pg.click("#hX")
        g=lambda js:pg.evaluate(js)
        check(await g("__wh.G.v===7&&!('fr' in __wh.G)&&!('handF' in __wh.G)&&!('ct' in __wh.G)"), "save v7, no freshness or case-target fields")
        check(await g("__wh.CASEK.length===27&&__wh.CASE.x0===0&&__wh.CASE.x1===9&&__wh.CASE.y0===12"), "the cold case is 9 × 3 at the bottom left")
        check(await g("__wh.CASEK.every(k=>__wh.G.items[k]===-1)"), "the first delivery doesn't land in the cold case")
        # pick a fresh and a plain line from the catalogue
        await g("""(()=>{const w=__wh,c=w.cat();window.FZ=c.findIndex((x,i)=>w.isFresh(i));window.PL=c.findIndex((x,i)=>!w.isFresh(i))})()""")
        check(await g("FZ>=0&&PL>=0"), "the catalogue has fresh and plain lines")
        # outside the case: fresh things sit one to a spot
        r=await g("""(()=>{const w=__wh,G=w.G;G.hand=[FZ,FZ,FZ];w.putAt(10,8);return[G.items[w.ix?0:0]===undefined,G.cnt[8*32+10],G.hand.length]})()""")
        check(r[1]==1 and r[2]==2, f"a fresh thing goes down one to a spot outside the cold case (put 1, 2 left in hand) {r}")
        r=await g("""(()=>{const w=__wh,G=w.G;w.addAt(10,8);return[G.cnt[8*32+10],G.hand.length,document.querySelector('#toast')?document.querySelector('#toast').textContent:'']})()""")
        check(r[0]==1 and r[1]==2 and "cold case" in r[2], f"adding to it is refused with a pointer to the cold case {r}")
        r=await g("""(()=>{const w=__wh,G=w.G;G.hand=[PL,PL,PL];w.putAt(12,8);return[G.cnt[8*32+12],G.hand.length]})()""")
        check(r==[3,0], f"plain things still stack anywhere {r}")
        # in the case: fresh things stack; one tap takes one; a tap on an empty case spot puts the run down
        await g("__wh.G.hand=[FZ,FZ]")
        k=await g("__wh.CASEK[0]")
        x,y=k%32,k//32
        await g(f"__wh.tap({x}+0.5,{y}+0.5)")
        r=await g(f"[__wh.G.items[{k}]===FZ,__wh.G.cnt[{k}],__wh.G.hand.length]")
        check(r==[True,2,0], f"tapping an empty cold-case spot puts down the whole run, stacked {r}")
        await g("__wh.G.hand=[FZ,FZ,FZ]");await g(f"__wh.addAt({x},{y})")
        r=await g(f"[__wh.G.cnt[{k}],__wh.G.hand.length,__wh.capAt({k})]")
        check(r[0]==min(r[2],5) and r[0]>2, f"holding adds to a fresh stack in the cold case {r}")
        n0=await g(f"__wh.G.cnt[{k}]")
        await g("__wh.G.hand=[]");await g(f"__wh.tap({x}+0.5,{y}+0.5)")
        r=await g(f"[__wh.G.cnt[{k}],__wh.G.hand.length,__wh.G.hand[0]===FZ]")
        check(r==[n0-1,1,True], f"one tap in the cold case takes one {r}")
        # nothing spoils
        await g("""(()=>{const w=__wh;for(let i=0;i<5;i++){w.closeOv();w.startRush(true);w.closeOv();w.endRush(false);w.closeOv()}})()""")
        r=await g(f"[__wh.G.items[{k}]===FZ,__wh.G.items[8*32+10]===FZ,__wh.G.items.includes(-2)]")
        check(r==[True,True,False], f"after five rushes fresh things are still there, nothing rotten {r}")
        # prices: fresh things sell like anything else
        r=await g("[__wh.priceItem(FZ),__wh.priceItem(PL)]")
        check(r[0]==r[1], f"fresh and plain things sell for the same {r}")
        # Clunk leaves fresh things alone
        r=await g("(()=>{const w=__wh;return [...w.clusters().values()].some(c=>w.isFresh(c.v))})()")
        check(r is False, "Clunk's sorting ignores fresh things")
        # put-away time: no arranging bonus
        r=await g("(()=>{const w=__wh,G=w.G;w.landDelivery([0,0,0,1,1]);return G.phaseT})()")
        check(r==40, f"put-away time is 30 s + 2 s an item ({r})")
        # hatch 1 asks for what's in the cold case
        await g("""(()=>{const w=__wh,G=w.G;for(const kk of w.CASEK){G.items[kk]=-1;G.cnt[kk]=0}const kn=w.knownProds();window.SH=kn.slice(0,3);SH.forEach((p,i)=>{const kk=w.CASEK[18+i];G.items[kk]=p;G.cnt[kk]=3});
          let j=0;for(const p of kn){let kk=6*32+2+j;while(G.items[kk]!==-1||w.SOLID[kk]||w.CASEM[kk])kk++;G.items[kk]=p;G.cnt[kk]=4;j++}w.closeOv();w.startRush(true);w.closeOv()})()""")
        fr=await g("""(()=>{const w=__wh;const sh=new Set(SH);const f=h=>{let n=0,d=0;for(let i=0;i<400;i++){w.HS.forEach(x=>x.cust=null);const c=w.newCust(h);if(!c||c.custom||c.flower)continue;for(const o of c.order){n++;if(sh.has(o.p))d++}}return d/Math.max(1,n)};return[f(0),f(1)]})()""")
        check(fr[0]>0.8 and fr[0]>fr[1], f"hatch 1 mostly asks for what's in the cold case ({fr[0]:.2f} vs {fr[1]:.2f} elsewhere)")
        await g("__wh.endRush(false);__wh.closeOv()")
        await pg.wait_for_timeout(250);await pg.screenshot(path=f"{OUT}/v10_case.png")
        await g("__wh.save()");await pg.reload();await pg.wait_for_function("!!window.__wh")
        check(await g("__wh.G.v===7&&__wh.CASEK.some(k=>__wh.G.items[k]>=0)"), "the game saves and reloads")
        check(not errs, "no page errors"+(": "+"; ".join(errs[:3]) if errs else ""))
        await b.close()
    print(f"\n{len(ok)} ok, {len(bad)} failed"); sys.exit(1 if bad else 0)
asyncio.run(main())
