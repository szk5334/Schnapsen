# Single player on the artifact (index.html with the co-op hooks, no SR_COOP): the loop is unchanged.
#   python3 sr17_solo.py [path/to/index.html]
import asyncio, os, sys
from playwright.async_api import async_playwright
SRC = sys.argv[1] if len(sys.argv) > 1 else "/home/claude/stockroom/index.html"
ok, bad = [], []
def check(c, m): (ok if c else bad).append(m); print(("  ok  " if c else "FAIL  ") + m, flush=True)

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path="/usr/bin/google-chrome", args=["--no-sandbox"])
        ctx = await b.new_context(viewport={"width": 390, "height": 844}, is_mobile=True, has_touch=True)
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("file://" + SRC)
        await pg.wait_for_function("!!window.__wh")
        check(await pg.evaluate("localStorage.getItem('stockroom.v5')!==null"), "saves under stockroom.v5")
        await pg.click("#hX")
        g = lambda js: pg.evaluate(js)
        check(await g("__wh.G.wait===false&&__wh.G.pend===null"), "fresh() makes the new fields")
        await pg.click("#act")
        check(await g("__wh.G.phase==='rush'"), "Open hatches starts the rush at once")
        L0 = await g("__wh.G.phaseT")
        check(70 < L0 <= 75, f"rush length from rushLen ({L0:.1f})")
        await g("__wh.tick(120,1/30)")
        check(await g("__wh.G.phaseT") < L0 - 3, "rush clock runs on dt")
        await g("__wh.endRush(false)")
        check(await g("__wh.G.phase==='sum'"), "summary")
        await pg.click("#nx")
        check(await g("__wh.G.phase==='order'&&__wh.ovOpen()"), "summary → order page (no waiting)")
        await g("__wh.G.stars+=40;__wh.suggestOrder()")
        await pg.evaluate("document.querySelector('#oGo').click()")
        check(await g("__wh.G.phase==='stock'&&isFinite(__wh.G.phaseT)&&__wh.G.phaseT>=30"), "order lands at once with a put-away timer")
        T = await g("__wh.G.phaseT")
        await g(f"__wh.tick({int(T*30)+40},1/30)")
        check(await g("__wh.G.phase==='rush'"), "put-away runs out: hatches open themselves")
        for _ in range(2):
            await g("__wh.endRush(false)"); await pg.click("#nx")
            if await g("__wh.G.phase==='order'"):
                await pg.evaluate("document.querySelector('#oGo').click()"); await g("__wh.startRush(true)")
        check(await g("__wh.G.phase==='down'&&__wh.G.rounds===3"), "day off after rush 3")
        await pg.click("#shX"); await pg.click("#act")
        check(await g("__wh.G.phase==='order'"), "day off → Order stock")
        await g("__wh.closeOv()"); await asyncio.sleep(0.1)
        check(await g("__wh.ovOpen()"), "order page comes back if closed (unchanged)")
        await g("document.querySelector('#oGo').click()")
        await pg.click("#menuB")
        check(await pg.locator("#mN").count() == 1 and await pg.locator("#mT").count() == 0, "menu: New stockroom, no Street")
        await pg.click("#mX")
        await pg.reload(); await pg.wait_for_function("!!window.__wh")
        check(await g("__wh.G.rounds===3"), "reload keeps the game")
        check(not errs, "no page errors" + (": " + "; ".join(errs[:3]) if errs else ""))
        await b.close()
    print(f"\n{len(ok)} ok, {len(bad)} failed"); sys.exit(1 if bad else 0)
asyncio.run(main())
