# Stockroom v9.4: inverse things split/turn/join like normal ones; custom things pay by steps.
import asyncio, sys, os
from playwright.async_api import async_playwright
SRC = sys.argv[1] if len(sys.argv) > 1 else "/home/claude/stockroom/index.html"
OUT="/tmp/sr-shots";os.makedirs(OUT,exist_ok=True)
ok, bad = [], []
def check(c, m): (ok if c else bad).append(m); print(("  ok  " if c else "FAIL  ") + m, flush=True)
RUN = """(type,inp)=>{const w=__wh;const m={type,k:1,inp,inf:inp.map(()=>0),t:0,out:[],of:3};w.runMachine(m);return m.out}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path="/usr/bin/google-chrome",args=["--no-sandbox"])
        pg=await (await b.new_context(viewport={"width":900,"height":700},device_scale_factor=2)).new_page();errs=[]
        pg.on("pageerror",lambda e:errs.append(str(e)))
        await pg.goto("file://"+SRC);await pg.wait_for_function("!!window.__wh");await pg.click("#hX")
        g=lambda js:pg.evaluate(js)
        await g("void (window.RUN="+RUN+")")
        D="(x=>{const d=__wh.dec(x);return d.t==='c'?['c',d.axis,!!d.a.inv,!!d.c.inv,d.a.b,d.c.b]:[d.t,d.side??-1,!!d.inv,d.b,d.g,d.r]})"
        check(await g("__wh.accepts({type:'vsplit'},__wh.invId(3,5,0))"), "the splitter takes an inverse thing")
        hv=await g(f"RUN('vsplit',[__wh.invId(3,5,0)]).map({D})")
        check(hv==[["h",0,True,3,5,0],["h",1,True,3,5,0]], f"an inverse green star splits into two inverse halves {hv}")
        back=await g(f"(()=>{{const w=__wh,h=RUN('vsplit',[w.invId(3,5,0)]);return {D}(RUN('comb',h)[0])}})()")
        check(back==["w",-1,True,3,5,0], f"the two inverse halves rejoin into the inverse whole {back}")
        mix=await g(f"(()=>{{const w=__wh,L=w.halfId(0,3,5,0,true),R=w.halfId(1,3,5,0,false);const o=RUN('comb',[L,R]);return [o.length,{D}(o[0])]}})()")
        check(mix[0]==1 and mix[1][:4]==["c",0,True,False], f"an inverse left half + a normal right half make a two-part thing, left side inverse {mix}")
        sp=await g(f"(()=>{{const w=__wh,c=w.compId(0,{{b:3,g:5,r:0,inv:true}},{{b:0,g:7,r:0}});return RUN('vsplit',[c]).map({D})}})()")
        check(sp==[["h",0,True,3,5,0],["h",1,False,0,7,0]], f"cutting it again gives back the inverse and the normal half {sp}")
        rt=await g(f"{D}(__wh.rotateId(__wh.halfId(0,3,5,0,true)))")
        check(rt[0]=="h" and rt[1]==2 and rt[2] is True, f"turning an inverse left half makes an inverse top half {rt}")
        rc=await g(f"(()=>{{const w=__wh,c=w.compId(0,{{b:3,g:5,r:0,inv:true}},{{b:0,g:7,r:0}});return {D}(w.rotateId(c))}})()")
        check(rc[0]=="c" and rc[1]==1 and rc[2] is True and rc[3] is False, f"turning a mixed two-part thing keeps which part is inverse {rc}")
        dg=await g(f"RUN('dback',[__wh.invId(2,9,0)]).map({D})")
        check(len(dg)==2 and all(x[0]=="h" and x[2] for x in dg) and {x[1] for x in dg}=={5,7}, f"the diagonal cutter makes inverse triangles {dg}")
        fl=await g(f"(()=>{{const w=__wh,h=RUN('vsplit',[w.invId(0,38,0)]),k=RUN('vsplit',[w.wholeId(4,38,0)]);return {D}(RUN('comb',[h[0],k[1]])[0])}})()")
        check(fl[0]=="c" and fl[2] is True, f"inverse flower halves make two-tone flowers too {fl}")
        cr=await g("(()=>{const w=__wh,G=w.G;G.rc={c:{},s:{}};return [w.recycleCredit(w.halfId(0,3,5,0,true)),G.rc.c[3],G.rc.s[5]]})()")
        check(cr==[1,1,1], f"an inverse half recycles into its colour and picture {cr}")
        ids=await g("(()=>{const w=__wh;const a=[w.halfId(7,11,20,3,true),w.compId(3,{b:11,g:20,r:3,inv:true},{b:2,g:1,r:1,inv:true}),w.compId(2,{b:1,g:2,r:0},{b:5,g:9,r:2,inv:true})];return a.map(x=>{const d=w.dec(x);return d.t==='c'?w.compId(d.axis,d.a,d.c)===x:w.halfId(d.side,d.b,d.g,d.r,d.inv)===x})})()")
        check(ids==[True,True,True], f"ids round-trip through dec {ids}")
        # draw a sheet
        await g("""(()=>{const w=__wh;const L=[w.invId(3,5,0),w.halfId(0,3,5,0,true),w.halfId(1,3,5,0,true),w.compId(0,{b:3,g:5,r:0,inv:true},{b:0,g:7,r:0}),w.compId(1,{b:5,g:30,r:1,inv:true},{b:9,g:30,r:1}),w.halfId(5,2,9,0,true),w.compId(0,{b:0,g:38,r:0,inv:true},{b:4,g:38,r:0})];
          document.body.insertAdjacentHTML('beforeend','<div id=sheet style="position:fixed;inset:0;z-index:999;background:#1b1d24;padding:20px">'+L.map(p=>`<img src="${w.iconURL(p,216)}" width=100>`).join('')+'</div>')})()""")
        await pg.screenshot(path=f"{OUT}/v94_inv.png");await g("document.querySelector('#sheet').remove()")
        # custom pricing by steps
        res=await g("""(()=>{const w=__wh,G=w.G;G.rounds=12;for(const t of ['dye','vsplit','hsplit','comb','rot','dback','dfwd'])if(!G.mach.some(m=>m.type===t))G.mach.push({type:t,k:-1,inp:[],inf:[],t:0,out:[],of:3});
          let k=10*32+2;const put=(p,n)=>{while(G.items[k]!==-1||w.SOLID[k]||w.CASEM[k])k++;G.items[k]=p;G.cnt[k]=n;G.fr[k]=0;k++};
          for(const p of w.cat().slice(0,40).map((_,i)=>i))put(p,3);
          w.closeOv();w.startRush(true);w.closeOv();
          const seen={};let bad=0,n=0;for(let i=0;i<3000&&n<300;i++){w.HS.forEach(h=>h.cust=null);const c=w.newCust(1);if(!c||!c.custom)continue;n++;const s=c.steps;seen[s]=(seen[s]||0)+1;if(c.price!==10+2*(s-1)||!(s>=1))bad++;
            const d=w.dec(c.order[0].p);if(d.t==='c'&&c.need.length===2&&w.dec(c.need[0]).t==='w'&&s<3)bad++}
          return{n,bad,seen}})()""")
        check(res["n"]>50 and res["bad"]==0, f"custom prices are 10★ + 2★ per extra step, two-part things from two wholes take 3+ steps ({res})")
        check(len(res["seen"])>=3, f"custom orders come in several step counts {res['seen']}")
        pay=await g("""(()=>{const w=__wh,G=w.G,h=w.HS[1];const p=w.compId(0,{b:0,g:7,r:0},{b:5,g:30,r:0});h.open=true;h.cust={order:[{p,n:1,got:0,custom:true}],need:[],steps:4,price:w.customPrice(4),custom:true,t:0,t3:300,face:'#fff',shirt:'#000'};G.hand=[p];G.handF=[0];const s0=G.stars;w.serveAt(1);return [G.stars-s0,w.customPrice(4)]})()""")
        check(pay[1]==16 and pay[0]>=16, f"a 4-step custom thing pays 16★ plus service {pay}")
        await g("""(()=>{const w=__wh,h=w.HS[1];h.cust={order:[{p:w.compId(0,{b:0,g:7,r:0},{b:5,g:30,r:0}),n:1,got:0,custom:true}],need:[],steps:3,price:14,custom:true,t:0,t3:300,face:'#fff',shirt:'#000'};w.setBig(false)})()""")
        await pg.wait_for_timeout(300)
        lbl=await g("[...document.querySelectorAll('#orders .oc.cu .cut')].map(x=>x.textContent).join('|')")
        check("14★" in lbl, f"the custom card shows its price ({lbl})")
        await g("__wh.showMag(1)")
        hd=await g("document.querySelector('#mag h3').textContent")
        check("14★" in hd and "3 steps" in hd, f"holding it shows the price and the steps ({hd})")
        check(not errs, "no page errors"+(": "+"; ".join(errs[:3]) if errs else ""))
        await b.close()
    print(f"\n{len(ok)} ok, {len(bad)} failed"); sys.exit(1 if bad else 0)
asyncio.run(main())
