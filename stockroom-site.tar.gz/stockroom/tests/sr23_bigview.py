# Stockroom v9.2: Big view and the hold-to-magnify order cards.
import asyncio, sys
from playwright.async_api import async_playwright
SRC = sys.argv[1] if len(sys.argv) > 1 else "/home/claude/stockroom/index.html"
ok, bad = [], []
def check(c, m): (ok if c else bad).append(m); print(("  ok  " if c else "FAIL  ") + m, flush=True)
SETUP = """(()=>{const w=__wh,G=w.G;G.rounds=8;w.closeOv();w.startRush(true);w.closeOv();const H=w.HS;H.forEach(h=>h.open=true);
 H[0].cust={order:[{p:w.compId(0,{b:0,g:7,r:0},{b:5,g:30,r:1}),n:1,got:0},{p:w.wholeId(3,30,1),n:1,got:0}],t:0,t3:300,face:'#f0c',shirt:'#333',custom:true,need:[]};
 H[1].cust={order:[{p:w.wholeId(2,14,0),n:2,got:0}],t:0,t3:300,face:'#fc0',shirt:'#333'};
 if(H[2])H[2].cust={order:[{p:w.invId(4,39,0),n:1,got:0}],t:0,t3:300,face:'#0cf',shirt:'#333',flower:true,need:[]};
 G.hand=[w.wholeId(2,14,0)];G.handF=[0];})()"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path="/usr/bin/google-chrome",args=["--no-sandbox"])
        ctx=await b.new_context(viewport={"width":360,"height":740},device_scale_factor=3,is_mobile=True,has_touch=True)
        pg=await ctx.new_page();errs=[];pg.on("pageerror",lambda e:errs.append(str(e)))
        await pg.goto("file://"+SRC);await pg.wait_for_function("!!window.__wh");await pg.click("#hX")
        g=lambda js:pg.evaluate(js)
        check(not await g("document.body.classList.contains('bigv')"), "Big view is off by default")
        await g(SETUP);await pg.wait_for_timeout(300)
        w0=await g("document.querySelector('#orders .it img').getBoundingClientRect().width")
        s0=await g("__wh.S||0")
        # the menu switch
        await pg.click("#menuB");await pg.click("#mB")
        check(await g("document.body.classList.contains('bigv')&&localStorage.getItem('stockroom.big')==='1'"), "☰ → Big view turns it on and saves it on this phone")
        check("Big view: on" in await pg.inner_text("#ovc"), "the menu shows Big view: on")
        await pg.click("#mX");await pg.wait_for_timeout(400)
        w1=await g("document.querySelector('#orders .it img').getBoundingClientRect().width")
        hw=await g("document.querySelector('#hand img').getBoundingClientRect().width")
        check(w1>=50 and w0<=36, f"order pictures grow ({w0:.0f} → {w1:.0f} px)")
        check(hw>=48, f"hand pictures grow ({hw:.0f} px)")
        wide=await g("Math.max(...[...document.querySelectorAll('#orders .oc')].map(n=>n.getBoundingClientRect().right))")
        check(wide<=360, f"cards stay on screen ({wide:.0f} ≤ 360)")
        sp=await g("(()=>{const a=__wh.w2s(0,0),b=__wh.w2s(1,0);return Math.hypot(b[0]-a[0],b[1]-a[1])})()")
        check(sp>=45, f"floor tiles at least ~46 px ({sp:.0f})")
        # hold to magnify: opens, shows parts, doesn't serve
        box=await pg.locator('#orders .oc').nth(0).bounding_box()
        await pg.mouse.move(box['x']+20,box['y']+20);await pg.mouse.down();await pg.wait_for_timeout(550)
        m=await g("(()=>{const m=document.querySelector('#mag');return{open:!m.classList.contains('hidden'),rows:m.querySelectorAll('.mrow').length,parts:m.querySelectorAll('.mparts img').length,turn:[...m.querySelectorAll('.mt,.mb')].map(x=>x.textContent)}})()")
        check(m["open"] and m["rows"]==2, f"holding a card opens the magnifier with its lines {m}")
        check(m["parts"]==2 and "↻¼" in m["turn"], f"a custom two-part thing shows its two halves, the turned one marked ↻¼ {m['turn']}")
        await pg.mouse.up();await pg.wait_for_timeout(150)
        check(await g("document.querySelector('#mag').classList.contains('hidden')"), "letting go closes it")
        check(await g("__wh.HS[0].cust.order[0].got===0&&__wh.G.hand.length===1"), "holding doesn't serve")
        # hold the flower card: inverse badge
        box=await pg.locator('#orders .oc').nth(2).bounding_box()
        await pg.mouse.move(box['x']+20,box['y']+20);await pg.mouse.down();await pg.wait_for_timeout(550)
        t=await g("[...document.querySelectorAll('#mag .mb')].map(x=>x.textContent)")
        check("inverse" in t, f"an inverse flower is marked inverse {t}")
        await pg.mouse.up();await pg.wait_for_timeout(150)
        # a quick tap still serves
        box=await pg.locator('#orders .oc').nth(1).bounding_box()
        await pg.mouse.click(box['x']+20,box['y']+20);await pg.wait_for_timeout(150)
        check(await g("__wh.G.hand.length===0"), "a quick tap still serves")
        # a drag on a card doesn't open it
        box=await pg.locator('#orders .oc').nth(0).bounding_box()
        await pg.mouse.move(box['x']+20,box['y']+20);await pg.mouse.down();await pg.mouse.move(box['x']+80,box['y']+20,steps=4);await pg.wait_for_timeout(550)
        check(await g("document.querySelector('#mag').classList.contains('hidden')"), "sliding off a card doesn't open the magnifier")
        await pg.mouse.up()
        # bouquet card
        await g("__wh.G.bq=__wh.makeBouquet()||{items:[{p:__wh.invId(2,38,0),n:1,got:0}],due:__wh.G.rounds+2,pay:20};__wh.G.fx=1;__wh.renderOrders&&0")
        await g("__wh.G.phase='stock';__wh.G.phaseT=60");await pg.wait_for_timeout(300)
        if await pg.locator('#orders .oc.bq').count():
            box=await pg.locator('#orders .oc.bq').bounding_box()
            await pg.mouse.move(box['x']+15,box['y']+15);await pg.mouse.down();await pg.wait_for_timeout(550)
            check(await g("document.querySelector('#mag h3').textContent.includes('Bouquet')"), "the bouquet card magnifies too")
            await pg.mouse.up()
        else: check(False, "bouquet card present")
        # persists across reload; off again
        await pg.reload();await pg.wait_for_function("!!window.__wh")
        check(await g("document.body.classList.contains('bigv')"), "Big view stays on after a reload")
        await g("__wh.setBig(false)")
        check(not await g("document.body.classList.contains('bigv')"), "and turns off")
        check(not errs, "no page errors"+(": "+"; ".join(errs[:3]) if errs else ""))
        await b.close()
    print(f"\n{len(ok)} ok, {len(bad)} failed"); sys.exit(1 if bad else 0)
asyncio.run(main())
