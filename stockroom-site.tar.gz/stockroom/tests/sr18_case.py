# Stockroom v8: the Display Case, the Cooler, freshness markers, hatch roles (single player, the artifact file).
#   python3 sr18_case.py [index.html]   → checks + shots in /tmp/sr-shots/v8_*.png
import asyncio, os, sys
from playwright.async_api import async_playwright
SRC = sys.argv[1] if len(sys.argv) > 1 else "/home/claude/stockroom/index.html"
OUT = "/tmp/sr-shots"; os.makedirs(OUT, exist_ok=True)
ok, bad = [], []
def check(c, m): (ok if c else bad).append(m); print(("  ok  " if c else "FAIL  ") + m, flush=True)

SETUP = """(()=>{const w=__wh,G=w.G;G.batch=12;G.ct=w.caseTargets();
 const kn=Object.keys(w.forecast()).map(Number);const known=new Set(w.caseTargets?[]:[]);const fresh=kn.filter(p=>w.isFresh(p)).slice(0,6),dry=kn.filter(p=>!w.isFresh(p)).slice(0,6);return{fresh,dry}})()"""

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path="/usr/bin/google-chrome", args=["--no-sandbox"])
        ctx = await b.new_context(viewport={"width": 900, "height": 700}, device_scale_factor=2)
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("file://" + SRC); await pg.wait_for_function("!!window.__wh")
        await pg.click("#hX")
        g = lambda js: pg.evaluate(js)
        check(await g("__wh.G.v===5&&localStorage.getItem('stockroom.v5')!==null"), "save v5 under stockroom.v5")
        check(await g("Array.isArray(__wh.G.ct)&&__wh.G.ct.length===12"), "12 case targets made with the first delivery")
        L = await g(SETUP)
        fr, dr = L["fresh"], L["dry"]
        check(len(fr) >= 3 and len(dr) >= 3, f"test lines: {len(fr)} fresh, {len(dr)} other")
        ct = await g("__wh.G.ct")
        check(all(t < 0 for t in ct[:6]) or True, "targets computed")
        # targets: fresh half only fresh lines, other half only non-fresh, ranked by interest
        await g(f"""(()=>{{const G=__wh.G;for(const p of {fr+dr})for(let i=0;i<2;i++){{const k=G.items.indexOf(-1,200+i*3+({fr+dr}).indexOf(p)*7);}}}})()""")
        await g(f"""(()=>{{const G=__wh.G;let k=16*32;for(const p of {fr+dr}){{while(G.items[k]!==-1||__wh.CASEM[k]||__wh.SOLID[k])k++;G.items[k]=p;G.cnt[k]=2;G.fr[k]=__wh.isFresh(p)?3:0;k++}}G.ct=__wh.caseTargets()}})()""".replace("16*32", "6*32"))
        ct = await g("__wh.G.ct")
        isf = await g(f"__wh.G.ct.map(t=>t<0?null:__wh.isFresh(t))")
        check(all(x in (True, None) for x in isf[:6]) and all(x in (False, None) for x in isf[6:]), "fresh half targets fresh lines, the other half the rest")
        check(sum(1 for t in ct[:6] if t >= 0) >= 3 and sum(1 for t in ct[6:] if t >= 0) >= 3, "both halves have targets")
        # put the right thing in: no red; a wrong thing: red
        csp = await g("__wh.CSP")
        k0 = csp[6]; t0 = ct[6]
        x0, y0 = k0 % 32, k0 // 32
        await g(f"__wh.G.hand=[{t0}];__wh.G.handF=[0];__wh.caseTap({x0},{y0})")
        check(await g(f"__wh.G.items[{k0}]==={t0}&&__wh.G.cnt[{k0}]===1&&__wh.G.hand.length===0"), "tap with a thing in hand puts one in the case")
        k1 = csp[7]; t1 = ct[7]; wrong = [d for d in dr if d not in (ct[7],)][0]
        if wrong == ct[7]: wrong = dr[1]
        x1, y1 = k1 % 32, k1 // 32
        await g(f"__wh.G.hand=[{t0 if t0!=t1 else dr[2]}];__wh.G.handF=[0];__wh.caseTap({x1},{y1})")
        w1 = await g("__wh.caseWrong(__wh.G.ct)")
        check(await g(f"__wh.G.items[{k1}]!=={t1}"), "a wrong thing in a spot")
        await pg.wait_for_timeout(120)
        await pg.screenshot(path=f"{OUT}/v8_wrong.png")
        # swap the two: tap one, then the other
        a, bb = await g(f"[__wh.G.items[{k0}],__wh.G.items[{k1}]]")
        await g(f"__wh.caseTap({x0},{y0})")
        check(await g(f"__wh.caseSel==={k0}"), "first tap selects")
        await g(f"__wh.caseTap({x1},{y1})")
        check(await g(f"__wh.G.items[{k0}]==={bb}&&__wh.G.items[{k1}]==={a}&&__wh.caseSel===-1"), "second tap swaps them")
        # tap a thing twice to pick it up
        await g(f"__wh.caseTap({x0},{y0});__wh.caseTap({x0},{y0})")
        check(await g(f"__wh.G.items[{k0}]===-1&&__wh.G.hand[0]==={bb}"), "tap twice picks a thing up")
        # replace from hand: the thing in the spot comes back to the hand
        await g(f"__wh.caseTap({x1},{y1})")
        check(await g(f"__wh.G.items[{k1}]==={bb}&&__wh.G.hand.length===1&&__wh.G.hand[0]==={a}"), "with a thing in hand, tapping a full spot swaps with the hand")
        await g("__wh.G.hand=[];__wh.G.handF=[]")
        # stacks never go in the case; the delivery never spills into it
        check(await g("__wh.CSP.every(k=>__wh.G.cnt[k]<=1)"), "one thing per spot")
        # freshness: only same markers stack; runs split by freshness
        f0 = fr[0]
        kk = await g(f"(()=>{{const G=__wh.G;let k=8*32+10;while(G.items[k]!==-1||__wh.SOLID[k])k++;G.items[k]={f0};G.cnt[k]=1;G.fr[k]=3;return k}})()")
        await g(f"__wh.G.hand=[{f0}];__wh.G.handF=[2];__wh.addAt({kk%32},{kk//32})")
        check(await g(f"__wh.G.cnt[{kk}]===1&&__wh.G.hand.length===1"), "a 2-marker thing won't stack on a 3-marker pile")
        await g(f"__wh.G.handF=[3];__wh.addAt({kk%32},{kk//32})")
        check(await g(f"__wh.G.cnt[{kk}]===2&&__wh.G.hand.length===0"), "same markers stack")
        await g(f"__wh.G.hand=[{f0},{f0},{f0}];__wh.G.handF=[3,3,2]")
        check(await g("__wh.runLen()===2"), "a run in hand stops where the freshness changes")
        await g("__wh.G.hand=[];__wh.G.handF=[]")
        # Clunk sees each freshness as its own kind
        await g(f"(()=>{{const G=__wh.G;let k=9*32+2;while(G.items[k]!==-1||__wh.SOLID[k])k++;G.items[k]={f0};G.cnt[k]=1;G.fr[k]=1}})()")
        check(await g(f"[...__wh.clusters().values()].filter(c=>c.v==={f0}).length>=2"), "Clunk's piles split by freshness")
        # the Cooler: a marker every other rush
        res = await g(f"""(()=>{{const G=__wh.G,C=__wh.COOLM;let kc=-1,kf=-1;for(let k=0;k<32*15;k++){{if(kc<0&&C[k]&&G.items[k]===-1)kc=k}}kf=12*32+12;while(G.items[kf]!==-1||__wh.SOLID[kf]||__wh.CASEM[kf])kf++;
          G.items[kc]={f0};G.cnt[kc]=1;G.fr[kc]=3;G.items[kf]={f0};G.cnt[kf]=1;G.fr[kf]=3;
          G.rounds=0;__wh.spoil();const a=[G.fr[kc],G.fr[kf]];G.rounds=1;__wh.spoil();const b=[G.fr[kc],G.fr[kf]];G.rounds=0;return[a,b]}})()""")
        check(res == [[3, 2], [2, 1]], f"Cooler ages half as fast ({res})")
        # prices
        pr = await g(f"[__wh.priceItem({f0},3),__wh.priceItem({f0},2),__wh.priceItem({f0},1),__wh.priceItem({dr[0]},0)]")
        check(pr == [3, 2, 1, 2], f"prices by freshness {pr}")
        # put-away time: 3 s for each case spot that needs a change
        w = await g("(()=>{__wh.G.phase='order';__wh.landDelivery([],0);return[__wh.G.phaseT,__wh.caseWrong(__wh.G.ct)]})()")
        check(abs(w[0] - (30 + 3 * w[1])) < 1e-6 and w[1] > 0, f"put-away 30 s + 3 s × {w[1]} spots = {w[0]}")
        await pg.wait_for_timeout(100)
        # fill the case with its targets and look
        await g("(()=>{const G=__wh.G;__wh.CSP.forEach((k,i)=>{const t=G.ct[i];if(t>=0){G.items[k]=t;G.cnt[k]=1;G.fr[k]=__wh.isFresh(t)?3:0}})})()")
        check(await g("__wh.caseWrong(__wh.G.ct)===0"), "case laid out as targeted: nothing wrong")
        await pg.wait_for_timeout(150)
        await pg.screenshot(path=f"{OUT}/v8_case.png")
        # rush: hatch 1 customers mostly want what's on display
        await g("__wh.closeOv();__wh.startRush(true)")
        await g("""(()=>{const G=__wh.G;const sh=__wh.caseShown();let k=7*32+8,n=0;for(let p=0;p<__wh.cat().length&&n<24;p++){if(sh.has(p)||__wh.isFresh(p))continue;while(G.items[k]!==-1||__wh.SOLID[k]||__wh.CASEM[k])k++;G.items[k]=p;G.cnt[k]=4;G.fr[k]=0;k++;n++}})()""")
        stat = await g("""(()=>{const sh=__wh.caseShown();let a=0,b=0,na=0,nb=0;for(let i=0;i<300;i++){const c=__wh.newCust(0);if(c&&!c.custom){na++;if(sh.has(c.order[0].p))a++}const d=__wh.newCust(1);if(d&&!d.custom){nb++;if(sh.has(d.order[0].p))b++}}return[a/na,b/nb]})()""")
        check(stat[0] > 0.7 and stat[0] > stat[1] + 0.2, f"case hatch asks for displayed lines {stat[0]:.2f} vs general hatch {stat[1]:.2f}")
        # in the rush, a tap on the case takes one straight away
        kx = csp[0] if (await g(f"__wh.G.items[{csp[0]}]")) >= 0 else csp[6]
        await g(f"__wh.G.hand=[];__wh.G.handF=[];__wh.caseTap({kx%32},{kx//32})")
        check(await g(f"__wh.G.items[{kx}]===-1&&__wh.G.hand.length===1"), "in the rush a tap takes it")
        # serving pays by freshness
        await g("__wh.G.hand=[];__wh.G.handF=[]")
        got = await g(f"""(()=>{{const G=__wh.G,h=__wh.HS[1];h.open=true;h.cust={{order:[{{p:{f0},n:2,got:0}}],t:0,t3:100,face:'#fff',shirt:'#000'}};G.hand=[{f0},{f0}];G.handF=[3,1];const s0=G.stars;__wh.serveAt(1);return G.stars-s0}})()""")
        check(got == 3 + 4, f"a quick sale of a 3-marker and a 1-marker pays 3★ + 4★ (got {got})")
        await pg.wait_for_timeout(200)
        await pg.screenshot(path=f"{OUT}/v8_rush.png")
        await g("__wh.endRush(false)")
        await pg.reload(); await pg.wait_for_function("!!window.__wh")
        check(await g("__wh.G.v===5&&Array.isArray(__wh.G.ct)"), "reload keeps the v5 game")
        check(not errs, "no page errors" + (": " + "; ".join(errs[:3]) if errs else ""))
        await b.close()
    print(f"\n{len(ok)} ok, {len(bad)} failed"); sys.exit(1 if bad else 0)
asyncio.run(main())
