# Stockroom on the street (co-op step 1): two tabs over ?local, separate people via ?as=.
#   python3 sr16_street.py   (site served at :8765 with stockroom.html)
# Covers: open a street, join by code, open the shops, same catalogue, shared hatches + early bonus,
# shared rush clock (by shifting both clocks), summary barrier, order barrier + shared put-away timer,
# a reload mid-rush, the day off after rush 3, a partner away (street carries on) and catching up.
import asyncio, os, sys, json
from playwright.async_api import async_playwright
BASE = "http://localhost:8765/stockroom.html"
RELAY = os.environ.get("SR_RELAY") == "1"   # through the real relay transport (local relays; config.js written by the caller)
SLOW = 4 if RELAY else 1
OUT = os.environ.get("SHOTS", "/tmp/sr-shots")
ok, bad = [], []
def check(c, m): (ok if c else bad).append(m); print(("  ok  " if c else "FAIL  ") + m, flush=True)

SHIFT = ""

async def until(pg, js, t=15, step=0.1):
    for _ in range(int(t * SLOW / step)):
        try:
            if await pg.evaluate(js): return True
        except Exception: pass
        await asyncio.sleep(step)
    return False

G = lambda pg: pg.evaluate("window.__wh&&{ph:__wh.G.phase,d:__wh.G.rounds,w:!!__wh.G.wait,stars:__wh.G.stars,dn:__wh.G.dn,seed:__wh.G.seed,T:__wh.G.phaseT}")
ST = lambda pg: pg.evaluate("window.__street&&__street.st")

async def shift(pages, ms):
    for p in pages: await p.evaluate(f"window.__srdt=(window.__srdt||0)+{ms}")

async def dismiss(pg):
    if await pg.locator("#hX").count(): await pg.click("#hX")

async def main():
    os.makedirs(OUT, exist_ok=True)
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path=os.environ.get("CHROME") or "/usr/bin/google-chrome", args=["--no-sandbox"])
        ctxs = {}
        async def context(tag):
            if RELAY:   # separate phones: separate browser storage
                if tag not in ctxs: ctxs[tag] = await b.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, is_mobile=True, has_touch=True)
                return ctxs[tag]
            if "one" not in ctxs: ctxs["one"] = await b.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, is_mobile=True, has_touch=True)
            return ctxs["one"]
        errs = []
        async def newp(tag):
            pg = await (await context(tag)).new_page()
            pg.on("pageerror", lambda e: errs.append(f"{tag}: {e}"))
            pg.on("console", lambda m: m.type == "error" and not m.text.startswith("Failed to load resource") and errs.append(f"{tag} console: {m.text}"))
            pg.on("response", lambda r: r.status >= 400 and not r.url.endswith("/config.js") and not r.url.startswith("http://localhost:78") and errs.append(f"{tag} {r.status} {r.url}"))
            await pg.goto(f"{BASE}?as={tag}" if RELAY else f"{BASE}?local&as={tag}")
            return pg
        A = await newp("A")
        await until(A, "!!document.querySelector('#hOpen')")
        await A.screenshot(path=f"{OUT}/a_home.png")
        await A.fill("#nm", "Seth"); await A.click("#hOpen")
        await until(A, "!!document.querySelector('.bigstars')")
        code = (await A.inner_text(".bigstars")).strip()
        check(len(code) == 4, f"street opened with code {code}")
        await A.screenshot(path=f"{OUT}/a_street.png")
        Bp = await newp("B")
        await Bp.fill("#nm", "Jamie"); await Bp.fill("#cd", code.lower()); await Bp.click("#hJoin")
        check(await until(A, "document.querySelector('#ovc').innerText.includes('Jamie')"), "Jamie shows up on Seth's street card")
        check(await until(Bp, "document.querySelector('#ovc').innerText.includes('Waiting for Seth')"), "Jamie waits for Seth to open the shops")
        await Bp.screenshot(path=f"{OUT}/b_wait.png")
        await A.click("#sGo")
        check(await until(A, "!!window.__wh") and await until(Bp, "!!window.__wh"), "both warehouses load")
        await asyncio.sleep(0.5)
        await dismiss(A); await dismiss(Bp)
        ga, gb = await G(A), await G(Bp)
        check(ga["seed"] == gb["seed"], "same street seed")
        ca = await A.evaluate("JSON.stringify(__wh.cat())"); cb = await Bp.evaluate("JSON.stringify(__wh.cat())")
        check(ca == cb, "same catalogue on both shops")
        check(ga["ph"] == "stock" and gb["ph"] == "stock", "both start on the free starter delivery")
        check(await until(A, "!!document.querySelector('#streetB')&&document.querySelector('#streetB').innerText.includes('Jamie')"), "street pill names next door")
        await A.screenshot(path=f"{OUT}/a_start.png")

        # shared hatches: Jamie opens, both rush
        await Bp.click("#act")
        check(await until(A, "__wh.G.phase==='rush'", 12) and await until(Bp, "__wh.G.phase==='rush'", 12), "Jamie opens the hatches: both shops open")
        ea, eb = (await ST(A))["end"], (await ST(Bp))["end"]
        check(ea == eb and ea > 0, "one rush clock")
        ta, tb = (await G(A))["T"], (await G(Bp))["T"]
        check(abs(ta - tb) < 1.5, f"rush timers agree ({ta:.1f} / {tb:.1f})")
        await A.screenshot(path=f"{OUT}/a_rush.png")

        # reload Jamie mid-rush: comes back into the same rush
        await Bp.reload()
        check(await until(Bp, "window.__wh&&__wh.G.phase==='rush'", 20), "Jamie reloads mid-rush and is back in the rush")
        await dismiss(Bp)
        tb = (await G(Bp))["T"]; ta = (await G(A))["T"]
        check(abs(ta - tb) < 1.5, f"same clock after the reload ({ta:.1f} / {tb:.1f})")

        # the clock runs out for both
        await shift([A, Bp], 200000)
        check(await until(A, "__wh.G.phase==='sum'", 12) and await until(Bp, "__wh.G.phase==='sum'", 12), "rush ends on both when the street clock runs out")
        await until(A, "__street.st.ph==='sum'", 5)
        check((await ST(A))["ph"] == "sum" and (await ST(A))["d"] == 1, "street at summary, 1 rush done")

        # summary barrier
        await A.click("#nx")
        await asyncio.sleep(1.5)
        check((await G(A))["w"] and (await G(A))["ph"] == "sum", "Seth waits after the summary")
        check((await ST(A))["ph"] == "sum", "the street waits for Jamie")
        check(await A.locator("#phase").inner_text() == "Waiting for next door…", "phase pill says waiting")
        check(await until(Bp, "document.querySelector('#streetB').innerText.includes('✓')"), "Jamie's pill shows Seth ready")
        await Bp.click("#nx")
        check(await until(A, "__wh.G.phase==='order'&&!__wh.G.wait", 12) and await until(Bp, "__wh.G.phase==='order'", 12), "both move to ordering together")

        # order barrier and the shared put-away timer
        await A.click("#oGo")
        await asyncio.sleep(1.5)
        check((await G(A))["ph"] == "order" and (await G(A))["w"], "Seth's order is in; no delivery yet")
        check(not await A.evaluate("window.__wh.ovOpen()"), "Seth is back on the floor while waiting")
        await Bp.evaluate("__wh.G.stars+=60;__wh.autoOrder()")
        await Bp.evaluate("document.querySelector('#oGo').click()")
        check(await until(A, "__wh.G.phase==='stock'", 12) and await until(Bp, "__wh.G.phase==='stock'", 12), "both deliveries land once both have ordered")
        sa = await ST(A)
        # each phone switches to the street's deadline on its next frame (a background tab's frames can lag)
        for _ in range(40):
            ta, tb = (await G(A))["T"], (await G(Bp))["T"]
            if abs(ta - tb) < 1.5: break
            await asyncio.sleep(0.1)
        check(abs(ta - tb) < 1.5 and ta > 25, f"one put-away timer ({ta:.0f} s / {tb:.0f} s)")
        await A.screenshot(path=f"{OUT}/a_delivery.png")

        # early open: the bonus is the street's
        before_a, before_b = (await G(A))["stars"], (await G(Bp))["stars"]
        await A.click("#act")
        check(await until(A, "__wh.G.phase==='rush'", 12) and await until(Bp, "__wh.G.phase==='rush'", 12), "Seth opens early: both rush")
        ba = await A.evaluate("__wh.G.stars") - before_a; bb = await Bp.evaluate("__wh.G.stars") - before_b
        check(ba == bb and ba >= 1, f"same early bonus on both (+{ba} / +{bb})")

        # reload mid-rush: the street's early bonus isn't paid twice
        sb = await Bp.evaluate("__wh.G.stars")
        await Bp.reload()
        check(await until(Bp, "window.__wh&&__wh.G.phase==='rush'", 20), "Jamie reloads in the early-opened rush")
        await dismiss(Bp)
        check(await Bp.evaluate("__wh.G.stars") == sb, "no second early bonus after the reload")

        # both serve out early → the street's rush ends early (clean end path)
        await A.evaluate("__wh.endRush(true)"); await asyncio.sleep(1)
        check((await ST(A))["ph"] == "rush", "one shop done early: the street's rush goes on")
        await Bp.evaluate("__wh.endRush(true)")
        check(await until(A, "__street.st.ph==='sum'", 12), "both done: the street closes the rush early")

        # rushes 2 and 3 done → day off together
        async def round_trip():
            for pg in (A, Bp):
                await until(pg, "!!document.querySelector('#nx')", 5); await pg.click("#nx")
            for pg in (A, Bp): await until(pg, "__wh.G.phase==='order'&&!!document.querySelector('#oGo')", 12)
        await round_trip()
        # Jamie orders, then reloads; Seth orders during the gap: Jamie's order still arrives
        await Bp.evaluate("(()=>{const w=__wh;w.G.stars+=60;w.autoOrder();if(!Object.keys(w.G.ord).length){const v=w.supplierView();for(const p in v)if(v[p].best){w.G.ord[p]=1;break}}document.querySelector('#oGo').click()})()")
        await asyncio.sleep(0.6)
        check(await Bp.evaluate("__wh.G.wait&&__wh.G.pend.length>0"), "Jamie's order is in")
        await Bp.reload()
        await A.evaluate("document.querySelector('#oGo').click()")
        check(await until(Bp, "window.__wh&&__wh.G.phase==='stock'", 20), "after her reload Jamie's delivery lands")
        await dismiss(Bp)
        check(await Bp.evaluate("__wh.G.lastDel") > 0, f"with what she ordered ({await Bp.evaluate('__wh.G.lastDel')} things)")
        await until(A, "__wh.G.phase==='stock'", 12); await until(Bp, "__wh.G.phase==='stock'", 12)
        await shift([A, Bp], 200000)  # put-away runs out: hatches open by themselves
        check(await until(A, "__wh.G.phase==='rush'", 12) and await until(Bp, "__wh.G.phase==='rush'", 12), "put-away runs out: both rush")
        await shift([A, Bp], 300000)
        check(await until(A, "__wh.G.phase==='sum'&&__wh.G.rounds===3", 12) and await until(Bp, "__wh.G.phase==='sum'&&__wh.G.rounds===3", 12), "rush 3 over on both")
        for pg in (A, Bp): await pg.click("#nx")
        check(await until(A, "__wh.G.phase==='down'", 12) and await until(Bp, "__wh.G.phase==='down'", 12), "day off together after rush 3")
        for pg in (A, Bp):
            if await pg.locator("#shX").count(): await pg.click("#shX")
        await A.click("#act"); await asyncio.sleep(1.2)
        check((await G(A))["ph"] == "down" and (await G(A))["w"], "Seth is ready to order; the day off waits for Jamie")
        await Bp.click("#act")
        check(await until(A, "__wh.G.phase==='order'", 12) and await until(Bp, "__wh.G.phase==='order'", 12), "both order after the day off")

        # Jamie goes away: the street carries on with Seth alone
        await Bp.close()
        check(await until(A, "document.querySelector('#streetB').innerText.includes('💤')", 100 if not RELAY else 60), "Seth sees Jamie away")
        await A.evaluate("document.querySelector('#oGo').click()")
        check(await until(A, "__wh.G.phase==='stock'", 15), "the street carries on without Jamie")
        await A.click("#act")
        await until(A, "__wh.G.phase==='rush'", 12)
        await shift([A], 300000)
        check(await until(A, "__wh.G.phase==='sum'&&__wh.G.rounds===4", 12), "Seth finishes rush 4 alone")

        # Jamie comes back and catches up
        Bp = await newp("B")
        await Bp.evaluate("window.__srdt=" + str(await A.evaluate("window.__srdt")))
        check(await until(Bp, "window.__wh&&__wh.G.rounds===4&&__wh.G.phase==='sum'", 25), "Jamie returns and catches up to rush 4's summary")
        sa, sb = await ST(A), await ST(Bp)
        check(sa["n"] == sb["n"] and sa["d"] == sb["d"] == 4, "one street state again")
        for pg in (A, Bp):
            await dismiss(pg)
            if await pg.locator("#nx").count(): await pg.click("#nx")
        check(await until(A, "__wh.G.phase==='order'", 12) and await until(Bp, "__wh.G.phase==='order'", 12), "both order rush 5 together")
        await Bp.screenshot(path=f"{OUT}/b_back.png")

        # rush 5, then flowers arrive on both shops' order pages, and the starter lands through the street
        for pg in (A, Bp): await pg.evaluate("document.querySelector('#oGo').click()")
        await until(A, "__wh.G.phase==='stock'", 15); await until(Bp, "__wh.G.phase==='stock'", 15)
        for pg in (A, Bp): await dismiss(pg)
        await A.click("#act")
        await until(A, "__wh.G.phase==='rush'", 12); await until(Bp, "__wh.G.phase==='rush'", 12)
        await shift([A, Bp], 300000)
        check(await until(A, "__wh.G.phase==='sum'&&__wh.G.rounds===5", 12) and await until(Bp, "__wh.G.phase==='sum'&&__wh.G.rounds===5", 12), "rush 5 over on both")
        for pg in (A, Bp):
            await dismiss(pg)
            if await pg.locator("#nx").count(): await pg.click("#nx")
        await until(A, "__wh.G.phase==='order'&&!!document.querySelector('#oGo')", 12); await until(Bp, "__wh.G.phase==='order'&&!!document.querySelector('#oGo')", 12)
        fl = [await pg.evaluate("[__wh.G.fx,__wh.G.fNew,document.querySelector('#ovc').textContent.includes('Flowers have arrived'),__wh.dyeLines().length===12]") for pg in (A, Bp)]
        check(all(x == [1, 1, True, True] for x in fl), f"flowers arrive in both shops on the street {fl}")
        await A.screenshot(path=f"{OUT}/a_flowers.png")
        for pg in (A, Bp): await pg.evaluate("(()=>{const w=__wh;w.G.stars+=40;for(const p of w.fBlanks())if(w.G.sup[p])w.G.ord[p]=1;document.querySelector('#oGo').click()})()")
        check(await until(A, "__wh.G.phase==='stock'", 15) and await until(Bp, "__wh.G.phase==='stock'", 15), "both flower orders land together")
        st = [await pg.evaluate("(()=>{const w=__wh,c=w.stockCounts();return[w.fBlanks().reduce((a,p)=>a+(c[p]||0),0),w.dyeLines().reduce((a,p)=>a+(c[p]||0),0),w.G.fNew]})()") for pg in (A, Bp)]
        check(all(x[0] >= 4 and x[1] >= 3 and x[2] == 0 for x in st), f"blank flowers, dyes and the free starter in both shops {st}")
        for pg in (A, Bp): await dismiss(pg)

        # menu: no New stockroom inside a street; the Street card
        await Bp.evaluate("document.querySelector('#oGo')&&document.querySelector('#oGo').click()"); await asyncio.sleep(0.4)
        await Bp.click("#menuB")
        check(await Bp.locator("#mN").count() == 0 and await Bp.locator("#mT").count() == 1, "menu: Street, no New stockroom")
        await Bp.click("#mT")
        check("Street " + code in await Bp.inner_text("#ovc"), "street card shows the code")
        await Bp.screenshot(path=f"{OUT}/b_card.png")

        # a third person can't take a seat
        C = await newp("C")
        await C.fill("#nm", "Pat"); await C.fill("#cd", code); await C.click("#hJoin")
        check(await until(C, "document.querySelector('#ovc').innerText.includes('already open')", 15), "a third person is told the shops are open")
        # playing alone from the street door
        D = await newp("D")
        await D.click("#hSolo")
        check(await until(D, "!!window.__wh&&!window.SR_COOP"), "Play alone loads the single-player game")
        await dismiss(D)
        await D.click("#act")
        check(await until(D, "__wh.G.phase==='rush'", 5), "alone: hatches open at once")
        check(await D.locator("#streetB").count() == 0, "alone: no street pill")
        check(not errs, "no page errors" + ("" if not errs else ": " + "; ".join(errs[:5])))
        await b.close()
    print(f"\n{len(ok)} ok, {len(bad)} failed")
    sys.exit(1 if bad else 0)

asyncio.run(main())
