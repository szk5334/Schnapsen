# Soak: 12 rounds with Clunk working, deliveries, rushes and spoiling, watching for page errors (v8).
import asyncio, sys
from playwright.async_api import async_playwright
SRC = sys.argv[1] if len(sys.argv) > 1 else "/home/claude/stockroom/index.html"
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path="/usr/bin/google-chrome",args=["--no-sandbox"])
        pg=await (await b.new_context(viewport={"width":800,"height":700})).new_page();errs=[]
        pg.on("pageerror",lambda e:errs.append(str(e)))
        await pg.goto("file://"+SRC);await pg.wait_for_function("!!window.__wh");await pg.click("#hX")
        g=lambda js:pg.evaluate(js)
        await g("__wh.G.up.bot=3;__wh.hireBot();__wh.G.stars=500")
        for r in range(12):
            await g("__wh.tick(900,1/30)")            # delivery: Clunk sorts
            await g("__wh.closeOv();__wh.startRush(true)")
            # serve whatever we can: hand the right things over from stock
            await g("""(()=>{const w=__wh,G=w.G;for(let s=0;s<400;s++){w.tick(6,1/30);for(let h=0;h<3;h++){const c=w.HS[h].cust;if(!c||c.farmer)continue;const o=c.order.find(o=>o.got<o.n);if(!o)continue;
               const k=G.items.findIndex(v=>v===o.p);if(k<0)continue;G.hand=[];G.handF=[];w.pickAt(k%32,(k/32)|0);w.serveAt(h)}if(G.phase!=='rush')break}})()""")
            if await g("__wh.G.phase==='rush'"): await g("__wh.endRush(false)")
            await g("document.querySelector('#nx')&&document.querySelector('#nx').click()")
            if await g("__wh.G.phase==='down'"):
                await g("__wh.closeOv();document.querySelector('#act').click()")
            if await g("__wh.G.phase==='order'"):
                await g("document.querySelector('#oGo')&&document.querySelector('#oGo').click()")
            await g("__wh.G.machSpare=[];__wh.closeOv()")
        st=await g("({r:__wh.G.rounds,stars:__wh.G.stars,served:__wh.G.served,mix:(()=>{const G=__wh.G;let bad=0;return bad})(),case:__wh.CASEK.filter(k=>__wh.G.items[k]>=0).length})")
        print("soak:",st,"errors:",errs[:3])
        await b.close();sys.exit(1 if errs else 0)
asyncio.run(main())
