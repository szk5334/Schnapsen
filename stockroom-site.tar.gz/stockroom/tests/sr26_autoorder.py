# v11: automatic ordering (the delivery note) and phone orders.
#   python3 sr26_autoorder.py [path/to/index.html]
import asyncio, sys, json
from playwright.async_api import async_playwright
SRC = sys.argv[1] if len(sys.argv) > 1 else "/home/claude/stockroom/index.html"
OUT = "/home/claude/tools/shots"
ok, bad = [], []
def check(c, m): (ok if c else bad).append(m); print(("  ok  " if c else "FAIL  ") + m, flush=True)

# a bot that serves every customer it can from stock (machines aside), to see what the economy does
SERVE = """(()=>{const w=__wh,G=w.G;for(let s=0;s<500;s++){w.tick(6,1/30);for(let h=0;h<3;h++){const c=w.HS[h].cust;if(!c)continue;const o=c.order.find(o=>o.got<o.n);if(!o)continue;
  const k=G.items.findIndex(v=>v===o.p);if(k<0)continue;G.hand=[];w.pickAt(k%32,(k/32)|0);w.serveAt(h)}if(G.phase!=='rush')break}})()"""

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path="/usr/bin/google-chrome", args=["--no-sandbox"])
        ctx = await b.new_context(viewport={"width": 390, "height": 844}, is_mobile=True, has_touch=True, device_scale_factor=2)
        pg = await ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto("file://" + SRC); await pg.wait_for_function("!!window.__wh"); await pg.click("#hX")
        g = lambda js: pg.evaluate(js)

        # ---- the delivery note ----
        await g("__wh.startRush(true);__wh.closeOv();__wh.endRush(false)")
        await pg.click("#nx")
        check(await g("__wh.G.phase==='order'&&document.querySelector('#ovc h2').textContent==='Delivery note'"), "summary → the delivery note")
        check(await g("!document.querySelector('[data-op]')&&!document.querySelector('.mk-in,.mk-steady,.mk-out')&&!document.querySelector('#ovc').textContent.includes('Interest')"), "no steppers, market rows or interest ranks")
        r = await g("(()=>{const G=__wh.G;return{n:Object.keys(G.ord).length,sup:Object.entries(G.ord).every(([p,n])=>n<=(G.sup[p]||0)),stars:G.stars,cost:Object.entries(G.ord).reduce((a,[p,n])=>a+n*G.price[p],0)}})()")
        check(r["sup"] and r["cost"] <= r["stars"], f"the order stays within supply and stars ({r})")
        await pg.screenshot(path=f"{OUT}/v11_note.png")
        s0 = await g("__wh.G.stars"); cost = r["cost"]
        await pg.click("#oGo")
        check(await g("__wh.G.phase==='stock'") and await g("__wh.G.stars") == s0 - cost, f"Unload lands it and bills {cost}★")

        # ---- going without ----
        r = await g("""(()=>{const w=__wh,G=w.G;G.rounds=4;G.stars=0;w.openOrder();return{n:Object.keys(G.ord).length,broke:Object.keys(G.note.broke).length,txt:document.querySelector('#ovc').textContent,btn:document.querySelector('#oGo').textContent}})()""")
        check(r["n"] == 0 and r["broke"] > 0 and "out of stars" in r["txt"] and "Went without" in r["txt"] and r["btn"] == "Carry on", f"no stars: nothing comes, the note lists what you went without ({r['broke']} lines)")
        await pg.click("#oGo")
        r = await g("""(()=>{const w=__wh,G=w.G;G.stars=1000;w.openOrder();const full=Object.entries(G.ord).reduce((a,[p,n])=>a+n*G.price[p],0);
          G.stars=Math.floor(full/3);w.autoOrder();const part=Object.entries(G.ord).reduce((a,[p,n])=>a+n*G.price[p],0);return{full,part,budget:G.stars,broke:Object.values(G.note.broke).reduce((a,b)=>a+b,0)}})()""")
        check(r["part"] <= r["budget"] and r["part"] > 0 and r["broke"] > 0, f"a third of the stars: it buys what it can and goes without the rest {r}")
        # the crates it keeps are the ones worth most per star: every crate bought beats every crate gone without, line by line
        r = await g("""(()=>{const w=__wh,G=w.G;G.stars=1000;w.autoOrder();const a={...G.ord};G.stars=8;w.autoOrder();const b={...G.ord};return{a,b,ok:Object.entries(b).every(([p,n])=>n<=(a[p]||0))}})()""")
        check(r["ok"], "a smaller budget buys a subset of the full order")
        # no room on the floor
        r = await g("""(()=>{const w=__wh,G=w.G;G.stars=1000;const saved=G.items.slice(),sc=G.cnt.slice();let fill=0;for(let k=0;k<G.items.length;k++){const x=k%32,y=(k/32)|0;if(G.items[k]===-1&&!w.SOLID[k]&&!w.CASEM[k]&&fill<10000){G.items[k]=w.cat()[0].p!=null?w.cat()[0].p:0;G.cnt[k]=1;fill++}}
          let left=0;for(let k=0;k<G.items.length;k++)if(G.items[k]===-1&&!w.SOLID[k])left++;
          // free four spots again
          let f=0;for(let k=0;k<G.items.length&&f<4;k++){const x=k%32,y=(k/32)|0;if(y===8&&x>2&&x<20&&G.items[k]>=0){G.items[k]=-1;G.cnt[k]=0;f++}}
          w.autoOrder();const n=Object.values(G.ord).reduce((a,b)=>a+b,0),full=Object.keys(G.note.full).length;G.items=saved;G.cnt=sc;return{n,full}})()""")
        check(r["n"] <= 2 and r["full"] > 0, f"a nearly full floor: at most 2 crates, the rest left on the truck {r}")
        # out at the supplier
        r = await g("""(()=>{const w=__wh,G=w.G;G.stars=1000;const p=w.knownProds()[0];for(let k=0;k<G.items.length;k++)if(G.items[k]===p){G.items[k]=-1;G.cnt[k]=0}G.sup[p]=0;w.autoOrder();return{out:G.note.out.includes(p),none:!G.ord[p]}})()""")
        check(r["out"] and r["none"], "a wanted line the supplier is out of is listed as out")
        await g("__wh.showOrder()")
        check(await g("document.querySelector('#ovc').textContent.includes('The supplier is out of')"), "the note shows it")
        await pg.click("#oGo"); await g("__wh.closeOv()")

        # ---- phone orders ----
        await g("""(()=>{const w=__wh,G=w.G;G.rounds=6;G.fx=1;G.stars=0;
          G.mach=[{type:'rot',k:1,inp:[],t:0,out:[]},{type:'dye',k:2,inp:[],t:0,out:[]},{type:'vsplit',k:3,inp:[],t:0,out:[]},{type:'comb',k:4,inp:[],t:0,out:[]}];
          // stock: 4 of each catalogue line, blank flowers and dyes
          const lines=w.knownProds();for(let k=0;k<G.items.length;k++)if(G.items[k]>=0){G.items[k]=-1;G.cnt[k]=0}
          let k=6*32+1;const put=(p,n)=>{while(w.SOLID[k]||w.CASEM[k])k++;G.items[k]=p;G.cnt[k]=n;k++};
          for(const p of lines)put(p,4);for(const p of w.fBlanks())put(p,3);for(const p of w.dyeLines().slice(0,6))put(p,3)})()""")
        r = await g("""(()=>{const w=__wh;let n=0,mix=0,cu=0,fl=0,pl=0,pays=[],dues=[],sizes=[];for(let i=0;i<300;i++){const c=w.makeCall();if(!c)continue;n++;
          const P=c.items.some(o=>!o.custom&&!o.need),C=c.items.some(o=>o.custom),F=c.items.some(o=>w.isFlower(o.p));pl+=P;cu+=C;fl+=F;if(P&&(C||F))mix++;pays.push(c.pay);dues.push(c.due-w.G.rounds);sizes.push(c.items.length)}
          return{n,mix,pl,cu,fl,minPay:Math.min(...pays),maxPay:Math.max(...pays),avgPay:pays.reduce((a,b)=>a+b,0)/pays.length,dues:[Math.min(...dues),Math.max(...dues)],sizes:[Math.min(...sizes),Math.max(...sizes)]}})()""")
        print("   calls:", r)
        check(r["n"] >= 250 and r["mix"] >= 0.8 * r["n"] and r["cu"] > 0.5 * r["n"] and r["fl"] > 0.3 * r["n"], "calls mix plain things with custom things and flowers")
        check(r["dues"] == [2, 3] and 2 <= r["sizes"][0] and r["sizes"][1] <= 6, f"due in 2-3 rushes, 2-6 lines ({r['dues']}, {r['sizes']})")
        # what a call holds is never promised to walk-in customers
        r = await g("""(()=>{const w=__wh,G=w.G;let c=null;for(let i=0;i<200&&!c;i++){const x=w.makeCall();if(x&&x.items.some(o=>o.custom))c=x}G.call=c;
          let hold=w.callHold();
          // leave exactly what the call holds of each held line, in one pile
          for(const p in hold){let first=true;for(let k=0;k<G.items.length;k++)if(G.items[k]===+p){if(first){G.cnt[k]=hold[p];first=false}else{G.items[k]=-1;G.cnt[k]=0}}}
          const st=w.stockCounts();const fully=Object.keys(hold).map(Number).filter(p=>hold[p]>=(st[p]||0)&&(st[p]||0)>0);
          w.startRush(true);w.closeOv();for(const h of w.HS)h.cust=null;let n=0,hits=0;
          for(let i=0;i<600;i++){const x=w.newCust(1);if(!x)continue;n++;for(const o of x.order)if(fully.includes(o.p))hits++;if(x.need)for(const p of x.need)if(fully.includes(p))hits++}
          w.endRush(false);w.closeOv();return{fully:fully.length,n,hits}})()""")
        check(r["fully"] > 0 and r["n"] > 200 and r["hits"] == 0, f"walk-ins never ask for what the call holds {r}")
        # the automatic order counts held stock as gone
        r = await g("""(()=>{const w=__wh,G=w.G;G.stars=1000;const q=G.call;w.rollSupply();for(const p in G.sup)G.sup[p]=Math.max(G.sup[p],6);
          G.call=null;w.autoOrder();const a={...G.ord};G.call=q;w.autoOrder();const b={...G.ord};const h=w.callHold();
          const held=Object.keys(h).filter(p=>w.knownProds().includes(+p));return{more:held.filter(p=>(b[p]||0)>(a[p]||0)).length,held:held.length,less:held.filter(p=>(b[p]||0)<(a[p]||0)).length}})()""")
        check(r["held"] == 0 or (r["less"] == 0 and r["more"] > 0), f"held stock makes the supplier send more of those lines {r}")
        # the card shows between rushes, not on the note or the summary
        await g("__wh.G.phase='stock';__wh.G.phaseT=60;__wh.closeOv()"); await pg.wait_for_timeout(250)
        check(await g("!!document.querySelector('#orders .oc.call')"), "the 📞 card shows between rushes")
        await pg.screenshot(path=f"{OUT}/v11_call.png")
        await g("__wh.openOrder()"); await pg.wait_for_timeout(250)
        check(await g("!document.querySelector('#orders .oc.call')&&document.querySelector('#ovc').textContent.includes('Phone order')"), "on the delivery note it's a banner, not a card")
        await pg.click("#oGo"); await g("__wh.closeOv();__wh.G.phase='stock';__wh.G.phaseT=60")
        # hand in, in any order, bit by bit
        r = await g("""(()=>{const w=__wh,G=w.G;const q={items:[{p:w.knownProds()[0],n:2,got:0},{p:w.knownProds()[1],n:1,got:0},{p:w.invId(3,38,0),n:1,got:0}],at:G.rounds,due:G.rounds+2,pay:30};G.call=q;
          const s0=G.stars;G.hand=[q.items[2].p,q.items[0].p];w.serveCall();const a=[q.items[2].got,q.items[0].got,G.hand.length,G.call===q];
          G.hand=[w.knownProds()[2]];w.serveCall();const wrong=G.hand.length===1;G.hand=[];
          G.hand=[q.items[1].p,q.items[0].p];w.serveCall();return{a,wrong,done:G.call===null,paid:G.stars-s0}})()""")
        check(r["a"] == [1, 1, 0, True], f"handed in out of order, part at a time {r['a']}")
        check(r["wrong"], "a thing that isn't on it is refused")
        check(r["done"] and r["paid"] == 30, f"paid in full when complete ({r['paid']}★)")
        # tapping an empty hatch with a wanted thing in hand hands it in
        r = await g("""(()=>{const w=__wh,G=w.G;const p=w.knownProds()[0];G.call={items:[{p,n:1,got:0},{p:w.knownProds()[1],n:1,got:0}],at:G.rounds,due:G.rounds+2,pay:9};
          w.startRush(true);w.closeOv();for(const h of w.HS)h.cust=null;w.HS[1].open=true;w.HS[1].cd=99;G.hand=[p];w.serveAt(1);return G.call&&G.call.items[0].got===1})()""")
        check(r, "an empty hatch takes phone-order things")
        # it lapses when due
        r = await g("""(()=>{const w=__wh,G=w.G;G.call.due=G.rounds+1;w.endRush(false);return[G.call===null,!!G.lastRS.callLost,document.querySelector('#ovc').textContent.includes('phone order lapsed')]})()""")
        check(r == [True, True, True], f"unfinished, it lapses at the end of the rush it's due {r}")
        await g("__wh.closeOv()")
        # one comes in on its own after rush 3, now and then
        r = await g("""(()=>{const w=__wh,G=w.G;G.stars=50;let got=0;for(let i=0;i<40;i++){G.call=null;w.openOrder();if(G.call)got++}w.closeOv();return got})()""")
        check(10 <= r <= 32, f"a call comes with about half the deliveries from rush 3 ({r} of 40)")
        # it survives a reload
        await g("__wh.G.call=__wh.makeCall();__wh.G.phase='stock';__wh.G.phaseT=60;__wh.save()")
        n0 = await g("__wh.G.call.items.length")
        await pg.reload(); await pg.wait_for_function("!!window.__wh")
        check(await g("__wh.G.v===8&&!!__wh.G.call&&__wh.G.call.items.length") == n0, "save v8 keeps the phone order")

        # ---- the economy from zero stars, automatic ordering only ----
        ctx2 = await b.new_context(viewport={"width": 390, "height": 844}); pg = await ctx2.new_page()
        pg.on("pageerror", lambda e: errs.append(str(e))); g = lambda js: pg.evaluate(js)
        await pg.goto("file://" + SRC); await pg.wait_for_function("!!window.__wh"); await pg.click("#hX")
        log = []
        for r_ in range(15):
            await g("__wh.tick(600,1/30)")
            await g("__wh.closeOv();__wh.G.machSpare=[];__wh.startRush(true)")
            await g(SERVE)
            if await g("__wh.G.phase==='rush'"): await g("__wh.endRush(false)")
            await g("document.querySelector('#nx')&&document.querySelector('#nx').click()")
            if await g("__wh.G.phase==='down'"): await g("__wh.closeOv();document.querySelector('#act').click()")
            if await g("__wh.G.phase==='order'"):
                e = await g("(()=>{const G=__wh.G;return{r:G.rounds,before:G.stars,cost:Object.entries(G.ord).reduce((a,[p,n])=>a+n*G.price[p],0),went:Object.values(G.note.broke).reduce((a,b)=>a+b,0),served:G.lastRS.served,of:G.lastRS.total}})()")
                await g("document.querySelector('#oGo').click()")
                e["after"] = await g("__wh.G.stars"); log.append(e)
            await g("__wh.G.machSpare=[];__wh.closeOv()")
        for e in log: print("   ", e)
        check(log[-1]["after"] > 0 and sum(e["cost"] for e in log) > 0, f"from zero stars the shop stays afloat ({log[-1]['after']}★ after {log[-1]['r']} rushes)")
        check(all(e["cost"] <= e["before"] and e["after"] >= 0 for e in log), "it never spends more than you have")
        check(not errs, f"no page errors {errs[:2]}")
        await b.close()
    print(f"\n{len(ok)} ok, {len(bad)} failed"); sys.exit(1 if bad else 0)
asyncio.run(main())
