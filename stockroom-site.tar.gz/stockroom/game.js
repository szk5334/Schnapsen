/* Stockroom: the game, built from the claude.ai artifact's index.html (do not edit here). */
(()=>{
'use strict';
// ---------- world ----------
// The building is 32 wide. The shop floor is the west 24 columns; behind the east wall are two old
// storerooms (north and south) that open up when you knock the wall down on a day off.
const W=32,H=15,N=W*H,MAINW=24;
const DIRS=[[0,-1],[1,0],[0,1],[-1,0]];
const HX=[5,12,19];
const BAY={x0:0,y0:0,x1:7,y1:4};
const DOOR=[1,6];
const ix=(x,y)=>y*W+x, inF=(x,y)=>x>=0&&y>=0&&x<W&&y<H;
// The cold case (bottom left, 9 x 3, around hatch 1): the one place fresh things stack.
// It stacks like the floor; its front row (y 14, the wall edge) draws the most interest at hatch 1.
const CASE={x0:0,y0:12,x1:9,y1:15},CASE_H=0;
const CASEM=new Uint8Array(N);
for(let y=CASE.y0;y<CASE.y1;y++)for(let x=CASE.x0;x<CASE.x1;x++)CASEM[y*W+x]=1;
const colY=(x,y0,y1)=>{const a=[];for(let y=y0;y<=y1;y++)a.push([x,y]);return a},rowX=(y,x0,x1)=>{const a=[];for(let x=x0;x<=x1;x++)a.push([x,y]);return a};
// knockable pieces: pillars and wall sections. A wall section opens the storeroom behind it.
const PIECES=[
 {id:'p0',kind:'pillar',cells:[[9,5]],cost:12},{id:'p1',kind:'pillar',cells:[[15,5]],cost:12},
 {id:'p2',kind:'pillar',cells:[[9,10]],cost:12},{id:'p3',kind:'pillar',cells:[[15,10]],cost:12},
 {id:'p4',kind:'pillar',cells:[[28,3]],cost:12,need:['wn']},{id:'p5',kind:'pillar',cells:[[28,11]],cost:12,need:['ws']},
 {id:'wn',kind:'wall',name:'the north storeroom wall',cells:colY(24,0,6),room:{x0:25,y0:0,x1:32,y1:7},cost:45},
 {id:'ws',kind:'wall',name:'the south storeroom wall',cells:colY(24,8,14),room:{x0:25,y0:8,x1:32,y1:15},cost:60},
 {id:'wm',kind:'wall',name:'the wall between the storerooms',cells:rowX(7,24,31),cost:20,need:['wn','ws']}];
// CELL: 0 floor, 1 pillar, 2 wall, 3 closed storeroom. SOLID = anything but floor.
const CELL=new Uint8Array(N),SOLID=new Uint8Array(N);
const pieceDone=id=>G.bw.includes(id);
const pieceOpen=pc=>!pieceDone(pc.id)&&(pc.need||[]).every(pieceDone);
function rebuildMap(){CELL.fill(0);
 for(let y=0;y<H;y++)for(let x=MAINW;x<W;x++)CELL[ix(x,y)]=3;
 for(const pc of PIECES)if(pc.room&&pieceDone(pc.id))for(let y=pc.room.y0;y<pc.room.y1;y++)for(let x=pc.room.x0;x<pc.room.x1;x++)CELL[ix(x,y)]=0;
 for(const pc of PIECES)for(const[x,y]of pc.cells)CELL[ix(x,y)]=pieceDone(pc.id)?0:pc.kind==='pillar'?1:2;
 for(let k=0;k<N;k++)SOLID[k]=CELL[k]?1:0}
const openW=()=>pieceDone('wn')||pieceDone('ws')?W:MAINW;
const pieceAt=(x,y)=>PIECES.find(pc=>!pieceDone(pc.id)&&pc.cells.some(c=>c[0]===x&&c[1]===y));
const inBay=(x,y)=>x>=BAY.x0&&x<BAY.x1&&y>=BAY.y0&&y<BAY.y1;
const clamp=(v,a,b)=>v<a?a:v>b?b:v;
const rnd=a=>a[(Math.random()*a.length)|0];
function shuffle(a){for(let i=a.length-1;i>0;i--){const j=(Math.random()*(i+1))|0;[a[i],a[j]]=[a[j],a[i]]}return a}
function rng(seed){let a=seed>>>0;return()=>{a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}

// ---------- products: colour tile + pictogram ----------
const BG=['#e5484d','#f28c28','#f5c518','#46a758','#12a594','#3e63dd','#8e4ec6','#d6409f','#8d6748','#6f7280','#2b2b33','#efe6cf'];
const LIGHT=new Set([2,11,12]);
const BLANK_B=12,NONE_G=37;const COLS=[...BG,'#c9ced8'];
const FG=b=>b===12?'#3d4452':LIGHT.has(b)?'#26262b':'#fffaf0';
const circ=(cx,cy,r)=>`M${cx-r} ${cy}a${r} ${r} 0 1 1 ${2*r} 0a${r} ${r} 0 1 1 ${-2*r} 0Z`;
function poly(n,r,cx=50,cy=50,rot=-90,r2=0){let s='';const k=r2?2*n:n;for(let i=0;i<k;i++){const a=(rot+i*360/k)*Math.PI/180,rr=r2&&i%2?r2:r;s+=(i?'L':'M')+(cx+rr*Math.cos(a)).toFixed(1)+' '+(cy+rr*Math.sin(a)).toFixed(1)}return s+'Z'}
function sunRays(){let s='';for(let i=0;i<8;i++){const a=i*Math.PI/4,c=Math.cos(a),si=Math.sin(a);const p=(r,o)=>(50+r*c-o*si).toFixed(1)+' '+(50+r*si+o*c).toFixed(1);s+=`M${p(27,-6)}L${p(45,0)}L${p(27,6)}Z`}return s}
function flower(){let s='';for(let i=0;i<5;i++){const a=-Math.PI/2+i*2*Math.PI/5;s+=circ(+(50+23*Math.cos(a)).toFixed(1),+(50+23*Math.sin(a)).toFixed(1),15)}return s+circ(50,50,14)}
function spiral(){let s='M50 50';for(let t=0;t<=4.2*Math.PI;t+=0.25){const r=3+t*2.8;s+=`L${(50+r*Math.cos(t)).toFixed(1)} ${(50+r*Math.sin(t)).toFixed(1)}`}return s}
const PLUS='M39 14h22v25h25v22h-25v25h-22v-25h-25v-22h25Z';
const GL=[
 {p:circ(50,50,32)},
 {p:circ(50,50,35)+circ(50,50,17),rule:'evenodd'},
 {p:'M22 22h56v56h-56Z'},
 {p:'M50 10L90 50L50 90L10 50Z'},
 {p:'M50 13L89 82H11Z'},
 {p:poly(5,40,50,54,-90,17)},
 {p:'M50 86C14 60 8 38 20 26C30 16 44 18 50 30C56 18 70 16 80 26C92 38 86 60 50 86Z'},
 {p:'M60 12A38 38 0 1 0 88 66A32 32 0 1 1 60 12Z'},
 {p:circ(50,50,20)+sunRays()},
 {p:'M50 10C40 28 22 46 22 62A28 28 0 0 0 78 62C78 46 60 28 50 10Z'},
 {p:'M18 82C16 44 40 18 84 16C84 58 60 82 18 82Z',h:'M22 76L70 28L74 32L26 80Z'},
 {p:'M60 8L22 56H46L38 92L78 40H54Z'},
 {p:PLUS},
 {p:PLUS,rot:45},
 {p:'M50 10L86 48H63V90H37V48H14Z'},
 {s:'M12 36q9.5-14 19 0t19 0t19 0t19 0M12 66q9.5-14 19 0t19 0t19 0t19 0',lw:10},
 {p:'M26 74a16 16 0 0 1-2-32a24 24 0 0 1 46-6a19 19 0 0 1 6 38Z'},
 {p:'M10 50C26 24 58 24 72 50C58 76 26 76 10 50ZM68 50L92 30V70Z',h:circ(28,46,5)},
 {p:circ(32,50,20)+'M46 44h44v12h-8v14h-10v-14h-6v10h-10v-10h-10Z',h:circ(32,50,8)},
 {p:'M50 12C32 12 26 28 26 46V62L16 74H84L74 62V46C74 28 68 12 50 12ZM40 80H60A10 10 0 0 1 40 80Z'},
 {p:'M12 54C12 22 88 22 88 54ZM40 54h20v32h-20Z',h:circ(34,40,5)+circ(62,36,6)},
 {p:flower(),h:circ(50,50,8)},
 {p:'M50 12L88 46H78V86H22V46H12Z',h:'M42 62h16v24h-16Z'},
 {p:'M50 8L78 50H62L80 74H20L38 50H22ZM43 74h14v16h-14Z'},
 {p:'M16 26h56v28a28 28 0 0 1-56 0ZM70 34h8a14 14 0 0 1 0 28h-8v-9h8a5 5 0 0 0 0-10h-8Z'},
 {p:'M30 42h40v16h-40Z'+circ(28,38,11)+circ(28,62,11)+circ(72,38,11)+circ(72,62,11)},
 {p:'M50 32C60 22 84 24 84 52C84 78 62 92 50 84C38 92 16 78 16 52C16 24 40 22 50 32ZM52 30C52 18 62 8 74 8C74 20 64 30 52 30Z'},
 {s:spiral(),lw:8},
 {p:'M8 50C28 18 72 18 92 50C72 82 28 82 8 50Z',h:circ(50,50,17),p2:circ(50,50,9)},
 {p:'M30 20h40l20 22L50 88L10 42Z',h:'M10 40H90V45H10Z'},
 {p:'M12 78L18 28L35 52L50 20L65 52L82 28L88 78Z'},
 {p:'M14 64A36 36 0 0 1 86 64Z'},
 {p:poly(6,38)},
 {p:'M16 20h68v14h-68ZM16 43h68v14h-68ZM16 66h68v14h-68Z'},
 {p:circ(30,30,13)+circ(70,30,13)+circ(30,70,13)+circ(70,70,13)},
 {p:'M14 26L50 56L86 26V50L50 80L14 50Z'},
 {p:'M24 14h52v8L56 50L76 78v8H24v-8L44 50L24 22Z'},
 {}, // 37: no picture (dye tiles)
 // 38–42: flowers (tulip, rose, bells, daisy on a stem, lily); only ever flowers, always fresh
 {p:"M31 16L41 29L50 12L59 29L69 16L71 42C71 55 61 61 50 61C39 61 29 55 29 42ZM47 59h6v31h-6ZM54.4 84.5a13 5 -35 1 0 21.3 -14.9a13 5 -35 1 0 -21.3 14.9Z"},
 {p:"M27 35a23 23 0 1 1 46 0a23 23 0 1 1 -46 0ZM47 55h6v35h-6ZM24.6 67.0a12 5 30 1 0 20.8 12.0a12 5 30 1 0 -20.8 -12.0ZM54.6 87.0a12 5 -30 1 0 20.8 -12.0a12 5 -30 1 0 -20.8 12.0Z",h:"M37 33C39 21 59 19 63 31C57 25 44 25 37 33ZM41 43C47 50 58 48 63 39C59 52 44 54 41 43ZM47 31C53 29 57 33 55 37C53 34 50 33 47 35Z"},
 {p:"M33 57C33 46 36 39 42 39C48 39 51 46 51 57L47 54L43 57L39 54ZM51 49C51 38 54 31 60 31C66 31 69 38 69 49L65 46L61 49L57 46ZM68 56C68 45 71 38 77 38C83 38 86 45 86 56L82 53L78 56L74 53ZM21.0 90.7a14 5 -50 1 0 18.0 -21.4a14 5 -50 1 0 -18.0 21.4Z",s:"M24 90C24 54 42 26 80 26",lw:6},
 {p:"M56.0 34.0a9 5 0 1 0 18.0 0.0a9 5 0 1 0 -18.0 -0.0ZM54.2 38.2a9 5 45 1 0 12.7 12.7a9 5 45 1 0 -12.7 -12.7ZM50.0 40.0a9 5 90 1 0 0.0 18.0a9 5 90 1 0 -0.0 -18.0ZM45.8 38.2a9 5 135 1 0 -12.7 12.7a9 5 135 1 0 12.7 -12.7ZM44.0 34.0a9 5 180 1 0 -18.0 0.0a9 5 180 1 0 18.0 -0.0ZM45.8 29.8a9 5 225 1 0 -12.7 -12.7a9 5 225 1 0 12.7 12.7ZM50.0 28.0a9 5 270 1 0 -0.0 -18.0a9 5 270 1 0 0.0 18.0ZM54.2 29.8a9 5 315 1 0 12.7 -12.7a9 5 315 1 0 -12.7 12.7ZM47 46h6v44h-6ZM52.5 80.5a11 4 -30 1 0 19.1 -11.0a11 4 -30 1 0 -19.1 11.0Z",h:"M44 34a6 6 0 1 1 12 0a6 6 0 1 1 -12 0Z"},
 {p:"M50.0 38.0a15 7 -90 1 0 0.0 -30.0a15 7 -90 1 0 -0.0 30.0ZM48.3 35.0a15 7 30 1 0 26.0 15.0a15 7 30 1 0 -26.0 -15.0ZM51.7 35.0a15 7 150 1 0 -26.0 15.0a15 7 150 1 0 26.0 -15.0ZM47 44h6v46h-6ZM27.2 69.1a12 4 35 1 0 19.7 13.8a12 4 35 1 0 -19.7 -13.8Z",h:"M46 36a4 4 0 1 1 8 0a4 4 0 1 1 -8 0Z"}
];
// Fresh pictures (every colour of them): drop, leaf, fish, mushroom, flower, apple, and the five flowers. Fresh things only stack in the cold case.
const FRESH_G=new Set([9,10,17,20,21,26,38,39,40,41,42]);
const FLOWERS=[38,39,40,41,42],FLOWER_G=new Set(FLOWERS);
const GLP=GL.map(g=>({p:g.p&&new Path2D(g.p),s:g.s&&new Path2D(g.s),h:g.h&&new Path2D(g.h),p2:g.p2&&new Path2D(g.p2),lw:g.lw,rule:g.rule,rot:g.rot}));
function drawGlyph(g,gi,fg,bg,cx,cy,size){const d=GLP[gi];g.save();g.translate(cx-size/2,cy-size/2);g.scale(size/100,size/100);
 if(d.rot){g.translate(50,50);g.rotate(d.rot*Math.PI/180);g.translate(-50,-50)}
 g.fillStyle=fg;g.strokeStyle=fg;if(d.p)g.fill(d.p,d.rule||'nonzero');
 if(d.s){g.lineWidth=d.lw||8;g.lineCap='round';g.lineJoin='round';g.stroke(d.s)}
 if(d.h){g.fillStyle=bg;g.fill(d.h)} if(d.p2){g.fillStyle=fg;g.fill(d.p2)} g.restore()}
function rr(g,x,y,w,h,r){g.beginPath();g.moveTo(x+r,y);g.arcTo(x+w,y,x+w,y+h,r);g.arcTo(x+w,y+h,x,y+h,r);g.arcTo(x,y+h,x,y,r);g.arcTo(x,y,x+w,y,r);g.closePath()}
function mix(hex,t,to=0){const n=parseInt(hex.slice(1),16);const f=c=>Math.round(c+(to-c)*t);return `rgb(${f(n>>16)},${f(n>>8&255)},${f(n&255)})`}
let CAT=[],BATCH=[];const CAT_KEY=new Map();
function makeCat(seed){const R=rng(seed);const used=new Set();CAT=[];BATCH=[];
 const add=(b,g,arr)=>{const k=b*100+g;if(used.has(k)||(BATCH.length<2&&FRESH_G.has(g)))return;used.add(k);arr.push(CAT.length);CAT.push({b,g})};
 const nb=BG.length,ng=37;const first=[];let t=0;
 while(first.length<4&&t++<99){const b=(R()*nb)|0;if(first.some(p=>CAT[p].b===b))continue;add(b,(R()*ng)|0,first)}
 BATCH.push(first);let guard=0;
 while(CAT.length<240&&guard++<3000){const arr=[];const n=2+((R()*3)|0);const k=R();let tt=0;
  if(k<0.38){const b=(R()*nb)|0;while(arr.length<n&&tt++<40)add(b,(R()*ng)|0,arr)}
  else if(k<0.72){const g=(R()*ng)|0;while(arr.length<n&&tt++<40)add((R()*nb)|0,g,arr)}
  else while(arr.length<n&&tt++<40)add((R()*nb)|0,(R()*ng)|0,arr);
  if(arr.length)BATCH.push(arr)}
 CAT_KEY.clear();CAT.forEach((p,i)=>CAT_KEY.set(p.b*64+p.g,i))}
function paintTile(g,pid,px){const p=CAT[pid];const m=px*0.06,s=px-2*m,r=s*0.2;const bg=BG[p.b];
 g.fillStyle=mix(bg,0.35);rr(g,m,m+px*0.05,s,s-px*0.05,r);g.fill();
 g.fillStyle=bg;rr(g,m,m,s,s-px*0.06,r);g.fill();
 g.fillStyle='rgba(255,255,255,.14)';rr(g,m+s*0.08,m+s*0.06,s*0.84,s*0.16,s*0.08);g.fill();
 drawGlyph(g,p.g,FG(p.b),bg,px/2,px/2-px*0.03,s*0.64)}
// ---------- item codes ----------
// a "part" is colour b + picture g + quarter-turns r. Codes:
// 0..: supplier catalogue wholes (r=0) · 10000+: other wholes · 20000+: halves (side L,R,T,B) · 100000+: two-part things (axis 0 left|right, 1 top/bottom)
const SIDES=['L','R','T','B','TL','TR','BR','BL'];
// a two-part thing's axis: 0 left|right, 1 top/bottom, 2 \ (top-right + bottom-left triangles), 3 / (top-left + bottom-right)
const AX_SIDES=[[0,1],[2,3],[5,7],[4,6]],SIDE_AX=[0,0,1,1,3,2,3,2];
const SPLIT={vsplit:0,hsplit:1,dback:2,dfwd:3};
// Every picture has a clear top. Pictures that would look the same when turned (circle, square, plus…)
// carry a small cap bar along their top edge that turns with them, so every quarter turn, and every half, reads differently.
const SYM=[4,4,4,4,1,1,1,1,4,1,1,1,4,4,1,2,1,1,1,1,1,4,1,1,1,2,1,1,2,1,1,1,2,2,4,1,2, 1, 1,1,1,1,1];
const CAPPED=new Set(SYM.map((v,i)=>v>1?i:-1).filter(i=>i>=0));
const canonR=(g,r)=>g===NONE_G?0:((r%4)+4)%4;
const pkey=(b,g,r)=>(b*64+g)*4+canonR(g,r||0);
const unk=k=>{const r=k%4,q=(k-r)/4;return{b:(q/64)|0,g:q%64,r}};
const isCat=v=>v>=0&&v<10000;
const isFresh=v=>{const d=dec(v);if(!d)return false;return d.t==='c'?FRESH_G.has(d.a.g)||FRESH_G.has(d.c.g):FRESH_G.has(d.g)};
function wholeId(b,g,r=0){r=canonR(g,r);if(!r){const c=CAT_KEY.get(b*64+g);if(c!=null)return c}return 10000+pkey(b,g,r)}
const HINV0=60000; // inverse halves (v9.4): 60000 + side·4096 + pkey
function halfId(side,b,g,r=0,inv=false){return (inv&&b!==BLANK_B?HINV0:20000)+side*4096+pkey(b,g,r)}
// two-part things: 100000 + code·16777216 + pkey(a)·4096 + pkey(c), code = axis | 4 if the first part is inverse | 8 if the second is
function compId(axis,a,c){const ka=pkey(a.b,a.g,a.r),kc=pkey(c.b,c.g,c.r),ia=!!a.inv&&a.b!==BLANK_B,ic=!!c.inv&&c.b!==BLANK_B;
 if(ka===kc&&ia===ic)return ia?invId(a.b,a.g,a.r||0):wholeId(a.b,a.g,a.r||0);return 100000+(axis|(ia?4:0)|(ic?8:0))*16777216+ka*4096+kc}
// inverse things: the picture coloured, the tile left plain. Wholes 14096..19999; halves and parts of two-part things too (v9.4).
const INV0=14096;const invId=(b,g,r=0)=>INV0+pkey(b,g,r);
function dec(id){if(id==null||id<0)return null;
 if(id<10000){const p=CAT[id];return p?{t:'w',b:p.b,g:p.g,r:0}:null}
 if(id<INV0)return{t:'w',...unk(id-10000)};
 if(id<20000)return{t:'w',...unk(id-INV0),inv:true};
 if(id<HINV0){const q=id-20000;return{t:'h',side:(q/4096)|0,...unk(q%4096)}}
 if(id<100000){const q=id-HINV0;return{t:'h',side:(q/4096)|0,...unk(q%4096),inv:true}}
 const q=id-100000,cd=(q/16777216)|0,z=q%16777216,a=unk((z/4096)|0),c=unk(z%4096);if(cd&4)a.inv=true;if(cd&8)c.inv=true;return{t:'c',axis:cd&3,a,c}}
const isEmptyPart=d=>d&&d.b===BLANK_B&&d.g===NONE_G;
const isBlankWhole=d=>d&&d.t==='w'&&!d.inv&&(d.b===BLANK_B||d.g===NONE_G);
const isFlowerD=d=>!!d&&(d.t==='c'?FLOWER_G.has(d.a.g)||FLOWER_G.has(d.c.g):FLOWER_G.has(d.g));
const isFlower=v=>isFlowerD(dec(v));
const isBlankShape=d=>!!d&&d.t==='w'&&!d.inv&&d.b===BLANK_B&&d.g!==NONE_G;
const isDyeD=d=>!!d&&d.t==='w'&&!d.inv&&d.g===NONE_G&&d.b!==BLANK_B;
const colouredFlower=v=>{const d=dec(v);return isFlowerD(d)&&(d.t==='c'?d.a.b!==BLANK_B&&d.c.b!==BLANK_B:d.t==='w'&&d.b!==BLANK_B)};
function rotateId(id){const d=dec(id);
 if(d.t==='w')return d.inv?invId(d.b,d.g,d.r+1):wholeId(d.b,d.g,d.r+1);
 if(d.t==='h')return halfId([2,3,1,0,5,6,7,4][d.side],d.b,d.g,d.r+1,d.inv);
 const a={...d.a,r:d.a.r+1},c={...d.c,r:d.c.r+1};return [()=>compId(1,a,c),()=>compId(0,c,a),()=>compId(3,c,a),()=>compId(2,a,c)][d.axis]()}
function paintParts(g,px,parts,ghost){const m=px*0.06,s=px-2*m,r=s*0.2,hf=s/2;
 const cr=c=>c==='L'?[m-1,m-1,hf+1,px]:c==='R'?[m+hf,m-1,hf+1,px]:c==='T'?[m-1,m-1,s+2,hf+1]:[m-1,m+hf,s+2,px];
 if(ghost){g.save();g.strokeStyle='rgba(255,255,255,.4)';g.setLineDash([Math.max(2,px*0.07),Math.max(2,px*0.05)]);g.lineWidth=Math.max(1,px*0.03);rr(g,m+1,m+1,s-2,s-px*0.06-2,r);g.stroke();g.restore()}
 const TRI={TL:[0,0,px,0,0,px],TR:[0,0,px,0,px,px],BR:[px,0,px,px,0,px],BL:[0,0,px,px,0,px]};
 for(const pt of parts){const bg=pt.inv?'#f6f2e8':COLS[pt.b],fg=pt.inv?COLS[pt.b]:FG(pt.b);g.save();if(pt.clip){g.beginPath();const t=TRI[pt.clip];if(t){g.moveTo(t[0],t[1]);g.lineTo(t[2],t[3]);g.lineTo(t[4],t[5]);g.closePath()}else{const c=cr(pt.clip);g.rect(c[0],c[1],c[2],c[3])}g.clip()}
  g.fillStyle=mix(bg,0.35);rr(g,m,m+px*0.05,s,s-px*0.05,r);g.fill();g.fillStyle=bg;rr(g,m,m,s,s-px*0.06,r);g.fill();
  g.fillStyle='rgba(255,255,255,.14)';rr(g,m+s*0.08,m+s*0.06,s*0.84,s*0.16,s*0.08);g.fill();
  if(pt.inv){g.strokeStyle=COLS[pt.b];g.lineWidth=Math.max(1.5,px*0.06);rr(g,m+px*0.04,m+px*0.04,s-px*0.08,s-px*0.14,r*0.8);g.stroke()}
  if(pt.b===BLANK_B){g.save();rr(g,m,m,s,s-px*0.06,r);g.clip();g.strokeStyle='rgba(40,48,64,.16)';g.lineWidth=Math.max(1,px*0.035);g.beginPath();for(let t=-s;t<s*2;t+=px*0.13){g.moveTo(m+t,m);g.lineTo(m+t-s,m+s)}g.stroke();g.restore();
   g.strokeStyle='rgba(40,48,64,.45)';g.setLineDash([Math.max(2,px*0.06),Math.max(2,px*0.05)]);g.lineWidth=Math.max(1,px*0.025);rr(g,m+s*0.08,m+s*0.07,s*0.84,s*0.78,r*0.7);g.stroke();g.setLineDash([])}
  const gx=px/2,gy=px/2-px*0.03,sz=s*0.64;if(pt.r){g.translate(gx,gy);g.rotate(pt.r*Math.PI/2);g.translate(-gx,-gy)}if(pt.g!==NONE_G)drawGlyph(g,pt.g,fg,bg,gx,gy,sz);

  if(CAPPED.has(pt.g)){g.fillStyle=fg;rr(g,gx-sz*0.3,gy-sz*0.64,sz*0.6,sz*0.1,sz*0.05);g.fill()}g.restore()}
 if(parts.length===2){g.strokeStyle='rgba(20,22,28,.6)';g.lineWidth=Math.max(1.5,px*0.04);g.beginPath();
  const c0=parts[0].clip,e=r*0.3,yb=m+s-px*0.06;if(c0==='L'){g.moveTo(m+hf,m+1);g.lineTo(m+hf,m+s-px*0.07)}else if(c0==='T'){g.moveTo(m+1,m+hf);g.lineTo(m+s-1,m+hf)}
  else if(c0==='TR'){g.moveTo(m+e,m+e);g.lineTo(m+s-e,yb-e)}else{g.moveTo(m+e,yb-e);g.lineTo(m+s-e,m+e)}g.stroke()}}
// an inverse: a plain tile with a coloured rim, the picture in the colour
function paintInv(g,px,d){const m=px*0.06,s=px-2*m,r=s*0.2,col=COLS[d.b],pale='#f6f2e8';
 g.fillStyle='#cfc8b8';rr(g,m,m+px*0.05,s,s-px*0.05,r);g.fill();g.fillStyle=pale;rr(g,m,m,s,s-px*0.06,r);g.fill();
 g.strokeStyle=col;g.lineWidth=Math.max(1.5,px*0.06);rr(g,m+px*0.04,m+px*0.04,s-px*0.08,s-px*0.14,r*0.8);g.stroke();
 const gx=px/2,gy=px/2-px*0.03,sz=s*0.64;g.save();if(d.r){g.translate(gx,gy);g.rotate(d.r*Math.PI/2);g.translate(-gx,-gy)}
 drawGlyph(g,d.g,col,pale,gx,gy,sz);if(CAPPED.has(d.g)){g.fillStyle=col;rr(g,gx-sz*0.3,gy-sz*0.64,sz*0.6,sz*0.1,sz*0.05);g.fill()}g.restore()}
function paintItem(g,id,px){const d=dec(id);if(!d)return;
 if(d.t==='w')return d.inv?paintInv(g,px,d):paintParts(g,px,[{b:d.b,g:d.g,r:d.r}]);
 if(d.t==='h')return paintParts(g,px,[{b:d.b,g:d.g,r:d.r,inv:d.inv,clip:SIDES[d.side]}],true);
 const cl=[['L','R'],['T','B'],['TR','BL'],['TL','BR']][d.axis];paintParts(g,px,[{...d.a,clip:cl[0]},{...d.c,clip:cl[1]}])}
let tileCache=new Map(),tilePx=0;
function tileImg(pid,px){px=Math.max(8,Math.round(px));if(px!==tilePx){tileCache.clear();tilePx=px}
 let c=tileCache.get(pid);if(!c){c=document.createElement('canvas');c.width=c.height=px;paintItem(c.getContext('2d'),pid,px);tileCache.set(pid,c)}return c}
const ICON=new Map();
function iconURL(p,px=144){const key=p+'@'+px;let u=ICON.get(key);if(!u){const c=document.createElement('canvas');c.width=c.height=px;const g=c.getContext('2d');
 paintItem(g,p,px);u=c.toDataURL();ICON.set(key,u)}return u}

// ---------- state ----------
let G,HS,RS=null,FIND=null,FL=[],FLY=[],POP=new Map(),doorAnim=0,saveT=0,shakeT=0,torchArmed=false,camGoal=null,rackMode=false;
const BIN=ix(MAINW-1,H-1),HOLD=380;
// Upgrades: each has 3 or 5 levels, and every level shows exactly what it does.
const UPS=[
 {k:'carry',name:'Bigger arms',vals:[6,7,8,9,10,12],fmt:v=>`Hold ${v}`,cost:[20,34,56,90,140]},
 {k:'stack',name:'Taller stacks',vals:[4,5,6,7,8,10],fmt:v=>`Floor stacks of ${v}`,cost:[20,34,56,90,140]},
 {k:'patience',name:'Patient customers',vals:[1,1.15,1.3,1.45,1.6,1.8],fmt:v=>`${Math.round(v*100)}% time for 3★`,cost:[16,28,46,74,110]},
 {k:'clock',name:'Longer shifts',vals:[0,12,24,36,48,60],fmt:v=>`+${v}s every rush`,cost:[16,28,46,74,110]},
 {k:'deal',name:'Haggling',vals:[1,0.9,0.8,0.7],fmt:v=>v===1?'Full price crates':`${Math.round((1-v)*100)}% off every crate`,cost:[30,60,100]},
 {k:'finder',name:'Torch',vals:[0,3,5,8],fmt:v=>v?`${v} torches a rush`:'No torch',cost:[24,44,70]},
 {k:'speed',name:'Faster machines',vals:[2,1.6,1.25,0.95,0.7,0.45],fmt:v=>`${v}s a job`,cost:[18,30,50,80,120],needsMach:1},
 {k:'hatch3',name:'Third hatch',vals:[2,3],fmt:v=>`${v} hatches`,cost:[40]},
 {k:'bot',name:'Clunk the robot',vals:[0,1,2,3],fmt:v=>v?`Carries ${BOTL[v].carry}, fumbles ${['','often','sometimes','rarely'][v]}`:'No helper',cost:[40,70,110],
  desc:'A helper who carries strays (new stock in the bay, odd leftovers) over to the rest of that thing. He’s clumsy: he drops loads and mixes up lookalikes.'},
];
const UV=k=>{const u=UPS.find(u=>u.k===k);return u.vals[Math.min(G.up[k],u.vals.length-1)]};
const cap=()=>UV('carry');
// how many fit on a spot: fresh things stack only in the cold case (one to a spot anywhere else)
const capAt=(k,v=G.items[k])=>v>=0&&isFresh(v)&&!CASEM[k]?1:G.rack[k]?10:UV('stack');
const machTime=()=>UV('speed');

const rackCost=()=>10+4*G.racksBought;
const openN=()=>2+G.up.hatch3;
const fcMax=()=>UV('finder');
const rushLen=()=>75+12*Math.min(6,G.rounds)+UV('clock');
const custN=()=>Math.min(10,3+Math.floor(G.rounds*0.6))+G.up.hatch3;
function fresh(){G={v:7,seed:(Math.random()*2147483647)|0,items:new Array(N).fill(-1),cnt:new Array(N).fill(0),rack:new Array(N).fill(0),racksSpare:0,racksBought:0,hist:{},hot:null,ord:{},newLines:[],batch:0,dn:0,rounds:0,phase:'stock',phaseT:Infinity,
 stars:0,life:0,served:0,rc:{c:{},s:{}},ordR:{},dm:{},dd:{},sup:{},price:{},newMach:[],lastRS:null,mach:[],machSpare:[],unl:[],bw:[],bot:null,up:{carry:0,stack:0,patience:0,hatch3:0,finder:0,clock:0,deal:0,speed:0,bot:0},hand:[],help:true,lastDel:0,lastNew:0,fc:0,wait:false,pend:null,pendC:0,bd:-1,fx:0,fNew:0,hotD:null,bq:null}}
function makeHS(){HS=[0,1,2].map(i=>({open:i<openN(),cust:null,cd:0,pop:null,shake:0}))}
const free=(x,y)=>inF(x,y)&&!SOLID[ix(x,y)]&&G.items[ix(x,y)]===-1&&ix(x,y)!==BIN&&!CASEM[ix(x,y)];
const canPlace=(x,y)=>inF(x,y)&&!SOLID[ix(x,y)]&&G.items[ix(x,y)]===-1&&ix(x,y)!==BIN;
function stockCounts(){const c={};for(let k=0;k<N;k++){const v=G.items[k];if(v>=0)c[v]=(c[v]||0)+G.cnt[k]}for(const v of G.hand)if(v>=0)c[v]=(c[v]||0)+1;return c}
function totalStock(){let n=0;for(const v of G.hand)if(v>=0)n++;for(let k=0;k<N;k++)if(G.items[k]>=0)n+=G.cnt[k];return n}
function knownProds(){const a=[];for(let b=0;b<G.batch;b++)a.push(...BATCH[b]);return a}

// ---------- save ----------
// Co-op: on the website a street adapter (stockroom/coop.js) sets window.SR_COOP before this script runs.
// Without it (the artifact, or playing alone) every hook below is inert.
const CO=window.SR_COOP||null;
const KEY=CO?CO.key:'stockroom.v7';
function save(){try{localStorage.setItem(KEY,JSON.stringify(G))}catch(e){}}
function load(){try{const s=localStorage.getItem(KEY);if(!s)return false;const o=JSON.parse(s);if(!o||o.v!==7||!Array.isArray(o.items)||o.items.length!==N)return false;
 if(o.phaseT==null)o.phaseT=Infinity; // JSON writes Infinity as null
 G=o;return true}catch(e){return false}}

// ---------- sound ----------
let AC=null,SND=true;try{SND=localStorage.getItem('stockroom.snd')!=='0'}catch(e){}
// Big view (v9.2): bigger orders, hand and floor, stronger contrast. Saved per phone, not per game.
let BIGV=false;try{BIGV=localStorage.getItem('stockroom.big')==='1'}catch(e){}
function applyBig(){document.body.classList.toggle('bigv',BIGV);ordersDirty=true;handKey=''}
function ensureAudio(){if(!AC){try{AC=new(window.AudioContext||window.webkitAudioContext)()}catch(e){}}if(AC&&AC.state==='suspended')AC.resume()}
function beep(f,d=0.08,type='sine',v=0.07,slide=0,delay=0){if(!SND||!AC)return;const t=AC.currentTime+delay,o=AC.createOscillator(),g=AC.createGain();o.type=type;o.frequency.setValueAtTime(f,t);if(slide)o.frequency.exponentialRampToValueAtTime(f*slide,t+d);g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(0.0001,t+d);o.connect(g).connect(AC.destination);o.start(t);o.stop(t+d+0.02)}
const sPick=()=>beep(520+G.hand.length*40,0.07,'triangle',0.07,1.5),sDrop=()=>beep(380,0.09,'triangle',0.07,0.6),sErr=()=>beep(140,0.14,'square',0.04),
 sTick=()=>beep(900,0.03,'sine',0.03),sGive=n=>{for(let i=0;i<n;i++)beep(700+i*90,0.08,'sine',0.06,1.3,i*0.07)},sKnock=()=>{beep(220,0.05,'square',0.03);beep(200,0.05,'square',0.03,1,0.12)},
 sChime=()=>{beep(660,0.15,'sine',0.07);beep(880,0.15,'sine',0.07,1,0.09);beep(1320,0.25,'sine',0.06,1,0.18)},
 sBell=()=>{beep(1046,0.5,'sine',0.06);beep(1568,0.4,'sine',0.04,1,0.02)},sThud=()=>{beep(90,0.25,'sine',0.12,0.5);beep(60,0.3,'triangle',0.08,0.6,0.05)};

// ---------- UI helpers ----------
const $=s=>document.querySelector(s);
let toastTO=0;
function toast(t){const el=$('#toast');el.textContent=t;el.classList.add('on');clearTimeout(toastTO);toastTO=setTimeout(()=>el.classList.remove('on'),2400)}
const ovOpen=()=>!$('#ov').classList.contains('hidden');
function ov(html){$('#ovc').classList.remove('ord');$('#ovc').innerHTML=html;$('#ov').classList.remove('hidden')}
function closeOv(){$('#ov').classList.add('hidden');if(G&&G.phase==='order'&&!G.wait)setTimeout(showOrder,0)}
const fmt=t=>{t=Math.max(0,Math.ceil(t));return Math.floor(t/60)+':'+String(t%60).padStart(2,'0')};

// ---------- deliveries ----------
function deliver(){G.dn++;const k=G.dn,list=[];
 const nb=G.batch<BATCH.length?BATCH[G.batch++]:[];
 for(const p of nb){const n=k===1?4:3+((Math.random()*3)|0);for(let i=0;i<n;i++)list.push(p)}
 const target=Math.min(48,16+4*k,Math.max(12,300-totalStock()));const known=[];
 for(let b=0;b<G.batch;b++)for(const p of BATCH[b])if(!nb.includes(p))known.push(p);
 if(known.length){const cnt=stockCounts();let guard=0;
  while(list.length<target&&guard++<200){known.sort((a,b)=>(cnt[a]||0)-(cnt[b]||0));const p=known[(Math.pow(Math.random(),2)*known.length)|0];const n=2+((Math.random()*3)|0);for(let i=0;i<n;i++)list.push(p);cnt[p]=(cnt[p]||0)+n}}
 shuffle(list);place(list);G.lastDel=list.length;G.lastNew=nb.length;doorAnim=1;camGoal={x:(BAY.x0+BAY.x1)/2,y:(BAY.y0+BAY.y1)/2+1}}
function place(list){const cn={};for(const p of list)cn[p]=(cn[p]||0)+1;const piles=[];
 for(const p in cn){let n=cn[p];while(n>0){const m=Math.min(n,1+((Math.random()*3)|0));piles.push([+p,m]);n-=m}}shuffle(piles);
 const put=(k,j)=>{const[p,m]=piles[j];G.items[k]=p;G.cnt[k]=m;POP.set(k,-0.02*j)};list=piles;let i=0;
 for(let y=BAY.y0;y<BAY.y1&&i<list.length;y++)for(let x=BAY.x0;x<BAY.x1&&i<list.length;x++)if(canPlace(x,y)){put(ix(x,y),i);i++}
 if(i<list.length){const seen=new Uint8Array(N),q=[];
  for(let y=BAY.y0;y<BAY.y1;y++)for(let x=BAY.x0;x<BAY.x1;x++){q.push(ix(x,y));seen[ix(x,y)]=1}
  for(let h=0;h<q.length&&i<list.length;h++){const c=q[h],x=c%W,y=(c/W)|0;if(canPlace(x,y)){put(c,i);i++}
   for(const[dx,dy]of DIRS){const nx=x+dx,ny=y+dy;if(!inF(nx,ny))continue;const k=ix(nx,ny);if(seen[k]||SOLID[k])continue;seen[k]=1;q.push(k)}}}}

// ---------- picking up and putting down ----------
function handSlot(i){const el=$('#hand');const r=el.getBoundingClientRect();return[r.left+26+i*38,r.top+r.height/2]}
function pickAt(x,y){const k=ix(x,y),v=G.items[k];if(v===-1||v===-3)return;
 if(G.hand.length>=cap()){toast(`Hands full (${cap()}). Tap an empty spot to put the first one down.`);sErr();shakeT=0.35;return}
 G.hand.push(v);if(--G.cnt[k]<=0){G.items[k]=-1;G.cnt[k]=0}const[sx,sy]=w2s(x+0.5,y+0.5);FLY.push({p:v,x0:sx,y0:sy,slot:G.hand.length-1,t:0});sPick()}
function runLen(){if(!G.hand.length)return 0;let n=1;while(n<G.hand.length&&G.hand[n]===G.hand[0])n++;return n}
function takeRun(n){G.hand.splice(0,n)}
function putAt(x,y){if(!G.hand.length)return;if(!canPlace(x,y)){sErr();return}
 const k=ix(x,y),v=G.hand[0],n=Math.min(runLen(),capAt(k,v));takeRun(n);
 G.items[k]=v;G.cnt[k]=n;POP.set(k,0);sDrop()}
function addAt(x,y){const k=ix(x,y),v=G.items[k];if(v===-1){putAt(x,y);return}
 if(!G.hand.length){toast('Your hands are empty');return}
 if(G.hand[0]!==v){toast('That stack is a different thing');sErr();return}
 const room=capAt(k)-G.cnt[k];if(room<=0){toast(isFresh(v)&&!CASEM[k]?'Fresh things only stack in the cold case ❄':`That stack is full (${capAt(k)})`);sErr();return}
 const n=Math.min(room,runLen());takeRun(n);G.cnt[k]+=n;POP.set(k,0.12);sDrop()}
function binTap(){if(!G.hand.length){toast('The bin: throw things out here');return}const v=G.hand[0],n=runLen();takeRun(n);
 toast(`Threw out ${n}`);beep(200,0.14,'sawtooth',0.04,0.5)}
function placeRack(x,y){const k=ix(x,y);if(!inF(x,y)||SOLID[k]||k===BIN)return;if(CASEM[k]){toast('Racks can\'t go in the Display Case');return}if(G.rack[k]){toast('There’s already a rack there');return}
 G.rack[k]=1;G.racksSpare--;POP.set(k,0);sDrop();if(G.racksSpare<=0){rackMode=false;toast('Rack placed')}else toast(`Rack placed · ${G.racksSpare} left`);save()}

// ---------- machines ----------
const MACH={dye:{name:'Dye swapper',ins:2,desc:'Put in two whole things and their colours swap.',col:'#7a3f6b'},
 vsplit:{name:'Vertical splitter',ins:1,desc:'Splits a whole thing into a left half and a right half.',col:'#3f5f7a'},
 hsplit:{name:'Horizontal splitter',ins:1,desc:'Splits a whole thing into a top half and a bottom half.',col:'#3f7a66'},
 comb:{name:'Combiner',ins:2,desc:'Joins a left + right pair, or a top + bottom pair, into one two-part thing.',col:'#7a5f3f'},
 dback:{name:'Diagonal cutter \\',ins:1,desc:'Cuts a whole thing corner to corner along \\ into a top-right and a bottom-left triangle.',col:'#5a3f7a'},
 dfwd:{name:'Diagonal cutter /',ins:1,desc:'Cuts a whole thing corner to corner along / into a top-left and a bottom-right triangle.',col:'#3f4f8a'},
 rot:{name:'Rotator',ins:1,desc:'Turns a thing a quarter turn clockwise. Halves turn too: a left half becomes a top half.',col:'#5d6b2c'},
 recyc:{name:'Recycler',ins:0,desc:'Feed it spare halves, two-part things or blanks. It keeps each part\'s colour and picture; tap it with empty hands to take blanks from your recycled stock (every 2 parts of a colour or a picture make one).',col:'#2f6b4f'}};
MACH.strip={name:'Colour stripper',ins:1,desc:'Takes one whole coloured thing apart: out come its blank picture and a dye tile of its colour.',col:'#6b4a2f'};
const UNLOCKS=[{r:2,t:['dye']},{r:4,t:['vsplit','comb','recyc']},{r:6,t:['hsplit']},{r:7,t:['strip']},{r:8,t:['rot']},{r:10,t:['dback','dfwd']}];
let machMode=false;
function checkUnlocks(){let got=[];for(const u of UNLOCKS)if(G.rounds>=u.r)for(const t of u.t)if(!G.unl.includes(t)){G.unl.push(t);G.machSpare.push(t);got.push(t)}return got}
const machAt=k=>G.mach.find(m=>m.k===k);
function accepts(m,id){const d=dec(id);if(!d)return false;
 if(m.type in SPLIT)return d.t==='w'||(d.t==='c'&&d.axis===SPLIT[m.type]);
 if(m.type==='strip')return d.t==='w'&&d.b!==BLANK_B&&d.g!==NONE_G;
 if(m.type==='comb')return d.t==='h';
 if(m.type==='rot')return true;
 if(m.type==='dye')return d.t==='w';
 return d.t==='w'||d.t==='h'}
const WHY={vsplit:'The vertical splitter takes whole things (or left|right two-part things).',hsplit:'The horizontal splitter takes whole things (or top/bottom two-part things).',comb:'The combiner takes halves.',dye:'The dye swapper takes whole things only, not halves.',strip:'The colour stripper takes one whole coloured thing (not a blank, a dye tile or a half).',rot:'The rotator takes anything.',dback:'The \\ cutter takes whole things (or \\ two-part things).',dfwd:'The / cutter takes whole things (or / two-part things).'};
const COLNAME=['red','orange','yellow','green','teal','blue','purple','pink','brown','grey','black','cream','blank'];
function recycleCredit(id){const d=dec(id);if(!d)return 0;const add=(p,n)=>{if(p.b!==BLANK_B)G.rc.c[p.b]=(G.rc.c[p.b]||0)+n;if(p.g!==NONE_G)G.rc.s[p.g]=(G.rc.s[p.g]||0)+n};
 if(d.t==='h'){add(d,1);return 1}if(d.t==='c'){add(d.a,1);add(d.c,1);return 2}if(isBlankWhole(d)){add(d,2);return 2}return 0}
function recycleFeed(){if(!G.hand.length){showRecycle();return}
 let n=0,parts=0;while(G.hand.length){const got=recycleCredit(G.hand[0]);if(!got)break;G.hand.shift();n++;parts+=got}
 if(!n){toast('The recycler takes halves, two-part things and blanks, not whole stock');sErr();return}
 beep(500,0.12,'triangle',0.06,0.7);toast(`♻ Recycled ${n} thing${n>1?'s':''}: ${parts} parts saved`);save()}
// the recycled stock: every 2 parts of a colour or a picture make a blank you can take straight into your hands
function showRecycle(){const keys=[...Object.keys(G.rc.c).map(b=>'c'+b),...Object.keys(G.rc.s).map(g=>'s'+g)].filter(k=>refurbAvail(k)>0);
 let h=`<h2>♻ Recycled stock</h2><p class="olead">Two recycled parts make a blank: a plain colour tile or an unpainted picture. Tap one to take it. A blank picture and a colour tile in the dye swapper make the real thing.</p>`;
 h+=keys.length?`<div class="rgrid">`+keys.map(k=>`<button class="rb" data-rk="${k}"><img src="${iconURL(refurbId(k))}" alt=""><span>×${refurbAvail(k)}</span></button>`).join('')+`</div>`:`<p class="omuted">Nothing yet. Feed the recycler spare halves, two-part things or blanks.</p>`;
 h+=`<p class="omuted">Hands: ${G.hand.length}/${cap()}</p><div class="row"><button class="big" id="rX">Done</button></div>`;ov(h);
 $('#ovc').querySelectorAll('[data-rk]').forEach(b=>b.onclick=()=>takeRecycled(b.dataset.rk));$('#rX').onclick=closeOv}
function takeRecycled(k){if(refurbAvail(k)<1)return;if(G.hand.length>=cap()){toast(`Hands full (${cap()})`);sErr();return}
 const t=k[0],v=+k.slice(1);if(t==='c')G.rc.c[v]-=2;else G.rc.s[v]-=2;const id=refurbId(k);G.hand.push(id);sPick();save();showRecycle()}
function feed(m){if(m.type==='recyc')return recycleFeed();const M=MACH[m.type];
 if(m.t>0||m.out.length){toast(`${M.name} is busy`);return}
 if(!G.hand.length){toast(`${M.name}: ${M.desc}${m.inp.length?` (holding ${m.inp.length}, needs ${M.ins})`:''} Press and hold to move it.`);return}
 let took=0;while(m.inp.length<M.ins&&G.hand.length&&accepts(m,G.hand[0])){m.inp.push(G.hand.shift());took++}
 if(!took){toast(WHY[m.type]);sErr();return}
 beep(600,0.06,'triangle',0.06,1.3);if(m.inp.length>=M.ins){m.t=machTime();m.T=m.t}}
function recolour(id,b){const d=dec(id);return d.t==='w'?(d.inv&&b!==BLANK_B?invId(b,d.g,d.r):wholeId(b,d.g,d.r)):halfId(d.side,b,d.g,d.r,d.inv&&b!==BLANK_B)}
function runMachine(m){const out=[];
 if(m.type in SPLIT){const sd=AX_SIDES[SPLIT[m.type]],d=dec(m.inp[0]);
  if(d.t==='w')out.push(halfId(sd[0],d.b,d.g,d.r,d.inv),halfId(sd[1],d.b,d.g,d.r,d.inv));else out.push(halfId(sd[0],d.a.b,d.a.g,d.a.r,d.a.inv),halfId(sd[1],d.c.b,d.c.g,d.c.r,d.c.inv))}
 else if(m.type==='comb'){const a=dec(m.inp[0]),c=dec(m.inp[1]);const pair=(x,y)=>{const ax=SIDE_AX[x.side];return AX_SIDES[ax][0]===x.side&&AX_SIDES[ax][1]===y.side};
  if(FLOWER_G.has(a.g)!==FLOWER_G.has(c.g)){out.push(m.inp[0],m.inp[1]);toast('Flowers only join with other flowers')}
  else if(pair(a,c))out.push(compId(SIDE_AX[a.side],a,c));else if(pair(c,a))out.push(compId(SIDE_AX[c.side],c,a));
  else{out.push(m.inp[0],m.inp[1]);toast('Those don’t fit: left goes with right, top with bottom, and a triangle with the opposite corner')}}
 else if(m.type==='rot'){const o=rotateId(m.inp[0]);out.push(o);if(o===m.inp[0])toast('That one looks the same turned')}
 else if(m.type==='strip'){const d=dec(m.inp[0]);out.push(wholeId(BLANK_B,d.g,d.r),wholeId(d.b,NONE_G))}
 // the dye swapper: two things swap colours; an uncoloured thing + a dye tile gives the coloured thing AND its inverse
 else{const a=dec(m.inp[0]),c=dec(m.inp[1]);
  if(isBlankShape(a)&&isDyeD(c))out.push(wholeId(c.b,a.g,a.r),invId(c.b,a.g,a.r));
  else if(isBlankShape(c)&&isDyeD(a))out.push(wholeId(a.b,c.g,c.r),invId(a.b,c.g,c.r));
  else out.push(recolour(m.inp[0],c.b),recolour(m.inp[1],a.b))}
 m.inp=[];m.out=out.filter(id=>{const d=dec(id);return !(d&&(d.t==='w'||d.t==='h')&&isEmptyPart(d))});beep(880,0.1,'sine',0.06,1.2)}
function dropNear(k0,id){const seen=new Uint8Array(N),q=[k0];seen[k0]=1;
 for(let h=0;h<q.length;h++){const c=q[h];if(c!==k0){if(G.items[c]===id&&!CASEM[c]&&G.cnt[c]<capAt(c)){G.cnt[c]++;POP.set(c,0.12);return true}
   if(G.items[c]===-1&&c!==BIN&&!SOLID[c]&&!CASEM[c]){G.items[c]=id;G.cnt[c]=1;POP.set(c,0);return true}}
  const x=c%W,y=(c/W)|0;for(const[dx,dy]of DIRS){const nx=x+dx,ny=y+dy;if(!inF(nx,ny))continue;const kk=ix(nx,ny);if(seen[kk]||SOLID[kk])continue;seen[kk]=1;q.push(kk)}}return false}
function stepMachines(dt){for(const m of G.mach){if(m.t>0){m.t-=dt;if(m.t<=0){m.t=0;runMachine(m)}}
 if(m.out.length&&m.t<=0){while(m.out.length&&dropNear(m.k,m.out[0]))m.out.shift();if(m.out.length){m.wait=(m.wait||0)+dt;if(m.wait>3){m.wait=0;toast('No room around the machine for its output')}}}}}
function placeMachine(x,y){const k=ix(x,y);if(!G.machSpare.length){machMode=false;return}
 if(!inF(x,y)||SOLID[k]||k===BIN||CASEM[k]||G.items[k]!==-1){toast(CASEM[k]?'Machines can\'t go in the Display Case':'Machines need an empty spot');sErr();return}
 const type=G.machSpare.shift();G.mach.push({type,k,inp:[],t:0,out:[]});G.items[k]=-3;POP.set(k,0);sDrop();
 if(!G.machSpare.length){machMode=false;toast(`${MACH[type].name} placed. Tap it to see what it does.`)}else toast(`${MACH[type].name} placed · next: ${MACH[G.machSpare[0]].name}`);save()}
function liftMachine(m){if(m.t>0||m.inp.length||m.out.length){toast('Let the machine finish first');return}
 G.mach.splice(G.mach.indexOf(m),1);G.items[m.k]=-1;G.machSpare.unshift(m.type);machMode=true;rackMode=false;toast(`Tap a spot to move the ${MACH[m.type].name}`)}

// ---------- building work (days off) ----------
let demoMode=false,demoSel=null,demoSelT=0,DUST=[];
function dust(x,y,n){for(let i=0;i<n;i++){const a=Math.random()*6.283,v=0.6+Math.random()*1.8;DUST.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,t:0,r:0.08+Math.random()*0.14})}}
function solidHint(x,y){const c=CELL[ix(x,y)];
 if(c===1)toast('A pillar. On a day off you can knock pillars down (🔨 Building work).');
 else if(c===2)toast('A wall. There’s an old storeroom behind it: knock it down on a day off (🔨 Building work).');
 else toast('An old storeroom, boarded up. Knock its wall down on a day off to use it.')}
function demoTap(x,y){const pc=pieceAt(x,y);
 if(!pc){toast('Tap a pillar or a wall to knock it down');return}
 if(!pieceOpen(pc)){toast(pc.id==='wm'?'Open both storerooms first':'Knock down that storeroom’s wall first');sErr();return}
 if(G.stars<pc.cost){toast(`That costs ${pc.cost}★ to knock down (you have ${G.stars}★)`);sErr();return}
 if(demoSel!==pc.id){demoSel=pc.id;demoSelT=3;toast(`Knock down ${pc.kind==='pillar'?'this pillar':pc.name} for ${pc.cost}★? Tap it again.`);sTick();return}
 knockDown(pc)}
function knockDown(pc){G.stars-=pc.cost;G.bw.push(pc.id);demoSel=null;rebuildMap();
 for(const[x,y]of pc.cells)dust(x+0.5,y+0.5,pc.kind==='pillar'?18:6);sThud();beep(70,0.45,'sawtooth',0.05,0.4);beep(110,0.2,'square',0.03,0.5,0.08);
 let gained=pc.cells.length,cx=pc.cells[0][0]+0.5,cy=pc.cells[0][1]+0.5,found=0;
 if(pc.room){const R=pc.room,cells=[];for(let y=R.y0;y<R.y1;y++)for(let x=R.x0;x<R.x1;x++)if(!SOLID[ix(x,y)]){gained++;cells.push(ix(x,y))}
  cx=(R.x0+R.x1)/2;cy=(R.y0+R.y1)/2;camGoal={x:cx-2,y:cy};shuffle(cells);
  // whoever had the shop before left a few things behind
  const kn=shuffle(knownProds().slice()).slice(0,2+((Math.random()*2)|0));let j=0;
  for(const p of kn){let n=2+((Math.random()*3)|0);while(n>0&&j<cells.length){const m=Math.min(n,1+((Math.random()*3)|0)),k=cells[j++];G.items[k]=p;G.cnt[k]=m;POP.set(k,-0.05*j);n-=m;found+=m}}}
 else{const y=pc.cells[(pc.cells.length/2)|0];cx=y[0]+0.5;cy=y[1]+0.5}
 FL.push({x:cx,y:cy,txt:`+${gained} spots`,t:0,c:'#ffd23f'});
 toast(pc.room?`The wall’s down: ${gained} more spots${found?`, and ${found} old things someone left back there`:''}`:pc.kind==='pillar'?`Pillar gone: +1 spot`:`Wall gone: +${gained} spots`);
 if(!PIECES.some(pieceOpen))demoMode=false;save()}

// ---------- Clunk, the clumsy helper robot ----------
// Clunk carries strays (new stock in the bay, odd leftovers far from the rest) to wherever most of that
// thing already is. He's slow and clumsy: now and then he fumbles a load on the way, or mixes up two
// things that share a colour or a picture and takes it to the wrong pile.
const BOTL=[null,{sp:1.3,carry:2,slip:0.2,mix:0.18},{sp:1.8,carry:3,slip:0.1,mix:0.09},{sp:2.6,carry:4,slip:0.04,mix:0.04}];
const B={path:[],i:0,mode:'idle',scan:0.5,pause:0,src:-1,dst:-1,v:-1,slipAt:-1,mixed:false,wob:0,bump:0,blink:0};
const cheb=(a,b)=>Math.max(Math.abs(a%W-b%W),Math.abs(((a/W)|0)-((b/W)|0)));
const inBayK=k=>inBay(k%W,(k/W)|0);
const botLv=()=>G.bot&&G.up.bot?BOTL[UV('bot')]:null;
const passable=k=>!SOLID[k]&&G.items[k]!==-3&&k!==BIN;
const botCell=()=>ix(clamp(Math.floor(G.bot.x),0,W-1),clamp(Math.floor(G.bot.y),0,H-1));
function bfsFrom(k0){const d=new Int16Array(N).fill(-1),pr=new Int32Array(N).fill(-1),q=[k0];d[k0]=0;
 for(let h=0;h<q.length;h++){const c=q[h],x=c%W,y=(c/W)|0;for(const[dx,dy]of DIRS){const nx=x+dx,ny=y+dy;if(!inF(nx,ny))continue;const k=ix(nx,ny);if(d[k]>=0||!passable(k))continue;d[k]=d[c]+1;pr[k]=c;q.push(k)}}return{d,pr}}
function pathTo(bf,k){if(bf.d[k]<0)return null;const p=[];for(let c=k;bf.d[c]>0;c=bf.pr[c])p.push(c);return p.reverse()}
// for each thing on the floor: its home pile (outside the bay, with the most of it close by) and the group around it
const kindK=v=>''+v;
function clusters(){const by=new Map();for(let k=0;k<N;k++){const v=G.items[k];if(v>=0&&!CASEM[k]&&!isFresh(v)&&!(POP.get(k)<0)){const key=kindK(v);let a=by.get(key);if(!a)by.set(key,a={v,ks:[]});a.ks.push(k)}}
 const out=new Map();
 for(const[key,{v,f,ks}]of by){let home=-1,hs=-1;
  for(const k of ks){if(inBayK(k))continue;let sc=0;for(const j of ks)if(cheb(k,j)<=1)sc+=G.cnt[j];if(sc>hs){hs=sc;home=k}}
  if(home<0)continue;const set=new Set([home]);let grew=true;
  while(grew){grew=false;for(const j of ks)if(!set.has(j)&&!inBayK(j)){for(const i of set)if(cheb(i,j)<=1){set.add(j);grew=true;break}}}
  out.set(key,{v,f,home,set,ks})}return out}
// put n of v down at k0 or as close as possible (onto matching stacks with room first). Returns how many didn't fit.
function putNear(k0,v,n,avoidBay,maxD,touched){const d=new Int16Array(N).fill(-1),q=[k0];d[k0]=0;
 for(let h=0;h<q.length&&n>0;h++){const c=q[h];if(d[c]>maxD)break;
  if(!(avoidBay&&inBayK(c))){
   if(G.items[c]===v&&!CASEM[c]&&G.cnt[c]<capAt(c)){const m=Math.min(n,capAt(c)-G.cnt[c]);G.cnt[c]+=m;n-=m;POP.set(c,0.12);if(touched)touched.push(c)}
   else if(G.items[c]===-1&&c!==BIN&&!SOLID[c]&&!CASEM[c]){const m=Math.min(n,capAt(c,v));G.items[c]=v;G.cnt[c]=m;n-=m;POP.set(c,0);if(touched)touched.push(c)}}
  const x=c%W,y=(c/W)|0;for(const[dx,dy]of DIRS){const nx=x+dx,ny=y+dy;if(!inF(nx,ny))continue;const k=ix(nx,ny);if(d[k]>=0||SOLID[k])continue;d[k]=d[c]+1;q.push(k)}}
 return n}
function botUnload(k0,avoidBay,maxD,touched){const b=G.bot;
 while(b.carry.length){const v=b.carry[0];let n=0;while(n<b.carry.length&&b.carry[n]===v)n++;
  const left=putNear(k0,v,n,avoidBay,maxD,touched),done=n-left;b.carry.splice(0,done);if(left)return left}return 0}
function botSay(t,c){FL.push({x:G.bot.x,y:G.bot.y-0.9,txt:t,t:0,c:c||'#7fe3ff'})}
function botSettle(){if(!G.bot)return;if(G.bot.carry.length)botUnload(botCell(),false,99);B.mode='idle';B.path=[]}
function hireBot(){if(G.bot)return;const bf=bfsFrom(ix(21,2));let k=ix(21,2);if(!passable(k))for(let j=0;j<N;j++)if(bf.d[j]>=0&&passable(j)){k=j;break}
 G.bot={x:k%W+0.5,y:((k/W)|0)+0.5,carry:[],mine:{},on:true};B.mode='idle';B.scan=1}
function botPlan(){const b=G.bot,here=botCell(),bf=bfsFrom(here),cl=clusters();
 if(b.carry.length)return botPlanDeliver(bf,cl);
 for(const k in b.mine)if(G.items[k]!==b.mine[k])delete b.mine[k]; // piles he made stay put: he's sure he got them right
 let best=null,bd=1e9;
 for(const[,c]of cl){const v=c.v;for(const k of c.ks){if(c.set.has(k)||b.mine[k]===v)continue;const bay=inBayK(k);
  if(!bay){if(G.cnt[k]>2)continue;let md=99;for(const i of c.set)md=Math.min(md,cheb(i,k));if(md<4)continue}
  if(bf.d[k]<0)continue;const sc=bf.d[k]+(bay?0:40);if(sc<bd){bd=sc;best={k,v}}}}
 if(!best){B.mode='idle';if(G.items[here]!==-1){let pk=-1,pd=1e9;for(let k=0;k<N;k++)if(bf.d[k]>0&&bf.d[k]<pd&&G.items[k]===-1&&!inBayK(k)&&!CASEM[k]){pd=bf.d[k];pk=k}if(pk>=0){B.path=pathTo(bf,pk);B.i=0;B.mode='park'}}return}
 B.src=best.k;B.v=best.v;B.path=pathTo(bf,best.k);B.i=0;B.mode='fetch'}
function botPick(){const b=G.bot,L=botLv(),k=B.src;
 if(G.items[k]!==B.v){B.mode='idle';B.scan=0.6;botSay('?');return}
 const n=Math.min(G.cnt[k],L.carry);for(let i=0;i<n;i++)b.carry.push(B.v);
 G.cnt[k]-=n;if(G.cnt[k]<=0){G.items[k]=-1;G.cnt[k]=0}
 beep(640,0.05,'square',0.025,1.4);B.pause=0.45;botPlanDeliver(bfsFrom(botCell()),clusters())}
function botPlanDeliver(bf,cl){const b=G.bot,L=botLv(),v=b.carry[0],here=botCell();let tgt=cl.get(kindK(v));B.mixed=false;
 if(Math.random()<L.mix){const d=dec(v);const pts=x=>{const e=dec(x);return e.t==='c'?[e.a,e.c]:[e]},pv=pts(v);const alts=[...cl.values()].filter(c=>c.v!==v&&pts(c.v).some(p=>pv.some(q=>p.b===q.b||p.g===q.g)));if(alts.length){tgt=rnd(alts);B.mixed=true}}
 const p=tgt&&pathTo(bf,tgt.home);
 if(!p){botUnload(here,false,99);B.mode='idle';B.scan=1.5;return}
 B.dst=tgt.home;B.path=p;B.i=0;B.mode='carry';B.slipAt=p.length>3&&Math.random()<L.slip?1+((Math.random()*(p.length-2))|0):-1}
function botDeliver(){const b=G.bot,put=[],v=b.carry[0];const left=botUnload(B.dst,true,6,put);for(const k of put)b.mine[k]=v;if(left)botUnload(botCell(),false,99);
 B.mode='idle';B.scan=0.8;B.pause=0.4;beep(520,0.06,'square',0.025,0.8);botSay(B.mixed?'?':'♪')}
function botSlip(){botUnload(botCell(),false,99);B.mode='idle';B.scan=1.2;B.bump=0.7;beep(180,0.12,'square',0.05,0.5);beep(130,0.15,'square',0.04,0.6,0.1);botSay('oops!','#ffd23f')}
function stepBot(dt){const b=G.bot,L=botLv();if(!L)return;B.wob+=dt;if(B.bump>0)B.bump=Math.max(0,B.bump-dt);B.blink-=dt;if(B.blink<-3.2)B.blink=0.15;
 const work=b.on&&(G.phase==='stock'||G.phase==='down');
 if(!work){if(b.carry.length)botSettle();B.mode=b.on&&G.phase==='rush'?'nap':'idle';return}
 if(B.mode==='nap')B.mode='idle';
 if(B.pause>0){B.pause-=dt;return}
 if(B.mode==='idle'){B.scan-=dt;if(B.scan<=0){B.scan=1.2;botPlan()}return}
 if(B.i>=B.path.length){if(B.mode==='fetch')botPick();else if(B.mode==='carry')botDeliver();else{B.mode='idle';B.scan=1.2}return}
 const k=B.path[B.i];if(!passable(k)){B.mode='idle';B.scan=0.3;return}
 const tx=k%W+0.5,ty=((k/W)|0)+0.5,dx=tx-b.x,dy=ty-b.y,d=Math.hypot(dx,dy),st=L.sp*dt;
 if(d<=st){b.x=tx;b.y=ty;B.i++;if(B.mode==='carry'&&B.i===B.slipAt)botSlip()}else{b.x+=dx/d*st;b.y+=dy/d*st}}

// ---------- customers ----------
const FACES=['#f2c4a8','#d99a72','#b07450','#7a4b32','#f5d6bd','#c58c6b'];
const SHIRTS=['#e5484d','#3e63dd','#46a758','#8e4ec6','#f28c28','#12a594','#d6409f','#6f7280'];
// demand: every stocked-or-offered line has a steady popularity; one line at a time can be hot
const CRATE=3;
const popOf=p=>0.5+(((Math.imul(p+13,2246822519)^G.seed)>>>0)%1000)/1000;
const hotOf=p=>G.hot&&G.hot.p===p&&G.hot.left>0?2.5:1;
const dmOf=p=>G.dm[p]||1,dirOf=p=>G.dd[p]||0;
const weightOf=p=>popOf(p)*dmOf(p)*hotOf(p);
function wpick(list){let t=0;for(const p of list)t+=weightOf(p);if(!list.length||t<=0)return null;let r=Math.random()*t;for(const p of list){r-=weightOf(p);if(r<=0)return p}return list[list.length-1]}
const maxNow=()=>Math.min(6,2+((G.rounds/2)|0));
function eItems(){const types=1+(G.rounds>=1?0.45:0)+(G.rounds>=4?0.3:0);return types*(1+maxNow())/2}
const customShare=()=>G.mach.length?0.16+0.05*Math.min(3,G.mach.length):0;
function forecast(){const kn=knownProds();const tot=kn.reduce((a,p)=>a+weightOf(p),0)||1;const n=custN()*(1-customShare())*eItems();const f={};for(const p of kn)f[p]=n*weightOf(p)/tot;return f}
// custom customers want something no supplier sells; it's always craftable from what you have on hand
const CUSTOM_PRICE=10;
// what's in the case: catalogue line -> interest (front row 2, back row 1)
const CASEK=[];for(let k=0;k<N;k++)if(CASEM[k])CASEK.push(k);
function caseShown(){const m=new Map();for(const k of CASEK){const v=G.items[k];if(v>=0&&isCat(v)){const f=((k/W)|0)===H-1?2:1;m.set(v,Math.max(m.get(v)||0,f))}}return m}
// customers at the case hatch mostly want what's on display; elsewhere the case still draws a little interest
function pickLine(list,h){const sh=caseShown();
 if(h===CASE_H&&sh.size&&Math.random()<0.8){const l=list.filter(p=>sh.has(p));if(l.length){let t=0;for(const p of l)t+=weightOf(p)*sh.get(p);let r=Math.random()*t;for(const p of l){r-=weightOf(p)*sh.get(p);if(r<=0)return p}return l[l.length-1]}}
 const w=p=>weightOf(p)*(sh.has(p)?1.3:1);let t=0;for(const p of list)t+=w(p);if(!list.length||t<=0)return null;let r=Math.random()*t;for(const p of list){r-=w(p);if(r<=0)return p}return list[list.length-1]}
// flower customers want coloured flowers: ready ones, or ones you can make from a blank flower and a dye
const shownFlowers=()=>CASEK.map(k=>G.items[k]).filter(v=>v>=0&&colouredFlower(v));
function genFlower(av,h){const sh=fShapes();if(!sh.length)return null;const keys=Object.keys(av).map(Number).filter(p=>av[p]>0);
 const left={...av},take=p=>(left[p]||0)>0?(left[p]--,true):false;
 const ready=keys.filter(p=>colouredFlower(p)),dyes=[...new Set(keys.filter(p=>isDyeD(dec(p))).map(p=>dec(p).b))];
 const have=t=>t.every(p=>(left[p]||0)>=t.filter(q=>q===p).length);
 const order=[],need=[];const add=(p,n)=>{const o=order.find(o=>o.p===p);if(o)o.n+=n;else order.push({p,n,got:0})};
 if(h===CASE_H){const sf=shownFlowers().filter(p=>av[p]>0);if(sf.length&&Math.random()<0.8){const p=rnd(sf);take(p);add(p,1)}}
 const want=1+(Math.random()<0.4?1:0)-order.length;const two=G.mach.some(m=>m.type==='vsplit')&&G.mach.some(m=>m.type==='comb');
 for(let i=0;i<want;i++){
  const rd=ready.filter(p=>(left[p]||0)>0);if(rd.length&&Math.random()<0.3){const p=rnd(rd);take(p);add(p,1);continue}
  const g=rnd(sh),blank=wholeId(BLANK_B,g),dl=dyes.filter(b=>(left[wholeId(b,NONE_G)]||0)>0);if(!dl.length||!((left[blank]||0)>0))continue;
  const b=wdye(dl),r=Math.random();
  if(two&&r<0.15){const b2=wdye(dl.filter(x=>x!==b));const t=[blank,blank,wholeId(b,NONE_G),wholeId(b2,NONE_G)];if(b2==null||b2===b||!have(t))continue;t.forEach(take);need.push(...t);add(compId(0,{b,g,r:0},{b:b2,g,r:0}),1);continue}
  const t=[blank,wholeId(b,NONE_G)];t.forEach(take);need.push(...t);add(r<0.5?invId(b,g,0):wholeId(b,g,0),1)}
 if(!order.length)return null;const items=order.reduce((a,o)=>a+o.n,0);
 return{order,need,flower:true,t:0,t3:1.5*(30+12*items)*UV('patience'),face:rnd(FACES),shirt:rnd(SHIRTS)}}
// bouquet orders: a few coloured flowers due within a couple of rushes, handed in at any hatch
function makeBouquet(){const sh=fShapes(),dl=dyeLines();if(!sh.length)return null;const items=[];let pay=6;const nl=2+(Math.random()<0.5?1:0);
 for(let t=0;items.length<nl&&t<30;t++){const g=rnd(sh),b=wdye(dl.map(p=>dec(p).b)),inv=Math.random()<0.35;const p=inv?invId(b,g,0):wholeId(b,g,0);if(items.some(o=>o.p===p))continue;const n=1+((Math.random()*2)|0);items.push({p,n,got:0});pay+=n*(inv?6:5)}
 return{items,due:G.rounds+2+((Math.random()*2)|0),pay:Math.round(pay*1.4)}}
function serveBq(){const q=G.bq;if(!q)return;let moved=0;
 for(;;){const o=q.items.find(o=>o.got<o.n);if(!o||!G.hand.length||G.hand[0]!==o.p)break;G.hand.shift();o.got++;moved++}
 ordersDirty=true;
 if(!q.items.some(o=>o.got<o.n)){G.stars+=q.pay;G.life+=q.pay;if(G.phase==='rush'&&RS)RS.stars+=q.pay;G.bq=null;toast(`💐 Bouquet delivered · +${q.pay}★`);sChime();save();return}
 if(moved){sGive(moved);save()}else{sErr();toast(G.hand.length?'Not for the bouquet: it wants the highlighted flower next':'Your hands are empty')}}
// a custom thing's price grows with the machine steps its recipe takes (Seth, Nov 28): 1 step 10★, then +2★ a step (kept small: stars are meant to stay scarce)
const customPrice=n=>CUSTOM_PRICE+2*Math.max(0,(n||1)-1);
function genCustom(av,pref){const have=G.mach.map(m=>m.type);const keys=Object.keys(av).map(Number).filter(p=>av[p]>0);
 const wholes=keys.filter(p=>{const d=dec(p);return d&&d.t==='w'&&!d.inv&&!isBlankWhole(d)&&!FLOWER_G.has(d.g)}),halves=keys.filter(p=>{const d=dec(p);return d&&d.t==='h'&&!d.inv&&d.b!==BLANK_B&&d.g!==NONE_G&&!FLOWER_G.has(d.g)});
 let WH=wholes;if(pref&&Math.random()<0.75){const pw=wholes.filter(p=>pref.has(p));if(pw.length>=2)WH=pw}
 const kinds=[];if(have.includes('dye')&&wholes.length>=2)kinds.push('dye');
 if(have.includes('comb')&&wholes.length>=2)for(const t in SPLIT)if(have.includes(t))kinds.push(SPLIT[t],SPLIT[t]);
 const rot=have.includes('rot');if(rot)kinds.push('rot');
 if(!kinds.length)return null;const kind=rnd(kinds);
 // turns(d, k): rotator passes to turn whole d by k quarter turns (0 when the turn doesn't show)
 const turns=(d,k)=>{let id=wholeId(d.b,d.g,d.r),to=wholeId(d.b,d.g,d.r+k);for(let j=0;j<4;j++){if(id===to)return j;id=rotateId(id)}return 0};
 for(let tries=0;tries<12;tries++){const A=rnd(WH),B=rnd(WH.filter(p=>p!==A));if(B==null)return null;const a=dec(A),c=dec(B);let t,use=[A,B],steps;
  const tw=()=>rot&&Math.random()<0.25?1+((Math.random()*3)|0):0;
  if(kind==='rot'){const k=1+((Math.random()*3)|0);t=wholeId(a.b,a.g,a.r+k);use=[A];steps=turns(a,k)}
  else if(kind==='dye'){if(a.b===c.b||a.g===c.g)continue;const k=tw();t=wholeId(c.b,a.g,k);steps=1+turns({b:c.b,g:a.g,r:a.r},k-a.r)}
  else{const ax=kind;const hs=halves.filter(h=>SIDE_AX[dec(h).side]===ax);
   const kc=tw(),c2={...c,r:c.r+kc};if(hs.length&&Math.random()<0.6){const hid=rnd(hs),h=dec(hid);use=[hid,B];const first=h.side===AX_SIDES[ax][0];t=first?compId(ax,h,c2):compId(ax,c2,h);steps=2+turns(c,kc)}
   else{const ka=tw();t=compId(ax,{...a,r:a.r+ka},c2);steps=3+turns(a,ka)+turns(c,kc)}}
  if(!(steps>=1))continue;if(dec(t).t==='w'&&isCat(t))continue;if(av[t]>0)continue;genCustom.use=use;genCustom.steps=steps;return t}return null}
function newCust(h){const av=stockCounts();
 for(const hs of HS)if(hs.cust){for(const o of hs.cust.order)av[o.p]=(av[o.p]||0)-(o.n-o.got);
  // a custom customer's recipe holds its materials, so nobody else is promised the same things
  if(hs.cust.need&&nextLine(hs.cust))for(const p of hs.cust.need)av[p]=(av[p]||0)-1}
 if(G.fx&&Math.random()<(h===CASE_H&&shownFlowers().length?0.35:FLOWER_SHARE)){const c=genFlower(av,h);if(c){RS.flowers=(RS.flowers||0)+1;return c}}
 if(G.mach.length&&Math.random()<customShare()){const t=genCustom(av,h===CASE_H?caseShown():null);if(t!=null){RS.customs=(RS.customs||0)+1;
  const n=genCustom.steps||1;return{order:[{p:t,n:1,got:0,custom:true}],need:genCustom.use||[],steps:n,price:customPrice(n),t:0,t3:1.5*(36+8*G.mach.length+10*(n-1))*UV('patience'),face:rnd(FACES),shirt:rnd(SHIRTS),custom:true}}}
 const kn=knownProds();if(!kn.some(p=>av[p]>0))return null;
 const want=1+(G.rounds>=1&&Math.random()<0.45?1:0)+(G.rounds>=4&&Math.random()<0.3?1:0);
 const order=[],used=new Set();let tot=0;const maxN=maxNow();
 for(let i=0;i<want;i++){let p=pickLine(kn.filter(q=>!used.has(q)),h);if(p==null)break;
  if(!(av[p]>0)){RS.miss[p]=(RS.miss[p]||0)+1;used.add(p);continue}
  used.add(p);const n=1+((Math.random()*Math.min(av[p],maxN))|0);order.push({p,n,got:0});tot+=n}
 if(!order.length){const p=pickLine(kn.filter(q=>av[q]>0),h);if(p==null)return null;const n=1+((Math.random()*Math.min(av[p],maxN))|0);order.push({p,n,got:0});tot+=n}
 const types=order.length;
 return{order,t:0,t3:(10+4*tot+4*types)*UV('patience'),face:rnd(FACES),shirt:rnd(SHIRTS)}}
const rating=c=>c.t<=c.t3?3:c.t<=2*c.t3?2:1;
const nextLine=c=>c.order.find(o=>o.got<o.n);
function serveAt(h){if(ovOpen())return;const hs=HS[h];if(!hs||!hs.open)return;const c=hs.cust;
 if(!c){if(G.bq&&G.hand.length&&G.bq.items.some(o=>o.got<o.n&&o.p===G.hand[0])){serveBq();return}toast(G.phase==='rush'?'Nobody at that hatch yet':'The hatches are closed');return}
 let moved=0;
 for(;;){const o=nextLine(c);if(!o||!G.hand.length||G.hand[0]!==o.p)break;RS.sold[o.p]=(RS.sold[o.p]||0)+1;o.val=(o.val||0)+priceItem(o.p);G.hand.shift();o.got++;moved++}
 ordersDirty=true;
 if(!nextLine(c)){complete(h);return}
 if(moved){sGive(moved);if(G.hand.length){hs.shake=0.35;toast('Stopped at a wrong one: they want the highlighted picture next')}}
 else{sErr();hs.shake=0.4;toast(G.hand.length?'Wrong order: they want the highlighted picture next':'Your hands are empty')}}
const PRICE=2,HOT_PRICE=5,CRATE_COST=4;
const priceOf=p=>hotOf(p)>1?HOT_PRICE:PRICE;
// fresh things pay by freshness: 3★, 2★ or 1★ (trending ×2½); everything else as before
// flowers: 5★ (inverse 6★, two-tone 8★); ×1½ in a trending colour
function flowerPrice(p){const d=dec(p);let v=d.t==='c'?8:d.inv?6:5;const hc=d.t==='c'?hotCol(d.a.b)||hotCol(d.c.b):hotCol(d.b);return Math.max(2,v)*(hc?1.5:1)}
const priceItem=p=>isFlower(p)?flowerPrice(p):priceOf(p);
function complete(h){const hs=HS[h],c=hs.cust;const st=rating(c);let sale=0,hot=0;for(const o of c.order){if(o.custom){sale+=c.price||CUSTOM_PRICE;RS.made=(RS.made||0)+1;continue}sale+=o.val!=null?o.val:o.n*priceOf(o.p);if(hotOf(o.p)>1)hot+=o.n}
 RS.saleAcc=(RS.saleAcc||0)+sale;const pay=Math.floor(RS.saleAcc);RS.saleAcc-=pay;RS.sales+=pay;RS.hotSold+=hot;
 G.stars+=st+pay;G.life+=st+pay;RS.stars+=st+pay;RS.served++;if(st===3)RS.perfect++;
 hs.cust=null;hs.cd=1.5+Math.random()*2.5;FL.push({x:HX[h]+0.5,y:H-0.6,txt:'+'+'★'.repeat(st)+(pay?` +${pay}`:''),t:0,c:'#ffd23f'});ordersDirty=true;sChime()}
function startRush(early,cb,cl){botSettle();demoMode=false;G.wait=false;const bonus=cb!=null?(G.bd===G.rounds?0:cb):(early&&isFinite(G.phaseT)?Math.floor(G.phaseT/15):0);if(cb!=null)G.bd=G.rounds;
 G.phaseT=5;save();
 G.phase='rush';G.phaseT=cl||rushLen();RS={stars:bonus,served:0,perfect:0,total:0,missed:0,early:bonus,clean:false,drops:0,dropAt:[],sold:{},miss:{},sales:0,saleAcc:0,hotSold:0};
 if(G.rounds>=2){const L=G.phaseT,nd=G.rounds>=5?2:1,cn=custN();for(let i=0;i<nd;i++){const f=(i+0.4+0.4*Math.random())/nd;RS.dropAt.push({t:L*(1-0.8*f),s:Math.max(1,Math.round(cn*f))})}}G.stars+=bonus;G.life+=bonus;
 G.fc=fcMax();torchArmed=false;HS.forEach((h,i)=>{h.open=i<openN();h.cust=null;h.cd=0.6+i*2.2});ordersDirty=true;save();toast('Hatches open!');sBell()}
function stepRush(dt){G.phaseT-=dt;
 if(RS.dropAt.length&&(G.phaseT<=RS.dropAt[0].t||RS.served>=RS.dropAt[0].s)){RS.dropAt.shift();surprise()}
 HS.forEach((hs,hi)=>{if(!hs.open)return;if(hs.cust){hs.cust.t+=dt}else if(G.phaseT>6&&RS.total<custN()){hs.cd-=dt;if(hs.cd<=0){const c=newCust(hi);if(c){hs.cust=c;RS.total++;ordersDirty=true;sKnock()}else hs.cd=2}}});
 if(G.phaseT<=0)endRush(false);
 else if(!HS.some(h=>h.cust)&&(RS.total>=custN()||totalStock()===0))endRush(true)}
function surprise(){const kn=knownProds();if(!kn.length)return;const list=[];RS.drops++;
 if(Math.random()<0.5){const n=1+((Math.random()*3)|0);for(let i=0;i<n;i++)list.push(rnd(kn));place(list);toast(`Returns! ${n} thing${n>1?'s':''} back in the bay`)}
 else{const cnt=stockCounts();kn.sort((a,b)=>(cnt[a]||0)-(cnt[b]||0));const n=4+((Math.random()*5)|0);while(list.length<n){const p=kn[(Math.pow(Math.random(),2)*Math.min(kn.length,8))|0];const m=1+((Math.random()*3)|0);for(let i=0;i<m;i++)list.push(p)}place(list);toast(`The supplier sent extras: ${list.length} free things in the bay`)}
 doorAnim=1;sThud()}
function endRush(clean){for(const h of HS)if(h.cust){RS.missed++;h.cust=null}
 if(clean&&RS.served>0){RS.stars+=2;G.stars+=2;G.life+=2;RS.clean=true}
 
 for(const q of knownProds()){const h=G.hist[q]||(G.hist[q]=[]);h.unshift([RS.sold[q]||0,RS.miss[q]||0]);h.length=Math.min(h.length,3)}
 if(G.hot){G.hot.left--;if(G.hot.left<=0)G.hot=null}
 if(G.hotD){G.hotD.left--;if(G.hotD.left<=0)G.hotD=null}
 G.rounds++;if(G.bq&&G.rounds>=G.bq.due){RS.bqLost=1;G.bq=null}G.served+=RS.served;G.lastRS=RS;G.phase='sum';FIND=null;torchArmed=false;ordersDirty=true;save();sChime();showSummary()}
function openOrder(){ // the supplier's catalogue: new lines arrive now and then, one line may be trending
 G.newLines=[];if(G.batch<BATCH.length&&(G.dn<=5||G.dn%2===0)){G.newLines=BATCH[G.batch].slice();G.batch++}
 if(!G.hot&&G.rounds>=2&&Math.random()<0.65)G.hot={p:rnd(knownProds()),left:2};
 // the market drifts: each line can be rising, steady or falling, and the drift shows on the order page
 if(G.rounds>=1)for(const q of knownProds()){if(G.dd[q]==null||Math.random()<0.3)G.dd[q]=[-1,0,0,1][(Math.random()*4)|0];
  const m=(G.dm[q]||1)*(1+0.22*G.dd[q]);G.dm[q]=Math.max(0.35,Math.min(2.6,m));if(G.dm[q]<=0.35&&G.dd[q]<0)G.dd[q]=0;if(G.dm[q]>=2.6&&G.dd[q]>0)G.dd[q]=0}
 if(!G.fx&&G.rounds>=5){G.fx=1;G.fNew=1}
 if(G.fx){for(const q of dyeLines())drift(q);if(!G.hotD&&Math.random()<0.5)G.hotD={p:rnd(dyeLines()),left:2};
  if(!G.bq&&G.rounds>=6&&Math.random()<0.6){G.bq=makeBouquet();ordersDirty=true}}
 G.newMach=checkUnlocks();rollSupply();G.phase='order';G.ord={};G.ordR={};save();showOrder()}
// Supply is limited: each order the supplier only has a few crates of each line, sometimes none.
// Crate prices follow the market. Gaps in supply are what crafting (and, in co-op, next door) are for.
const PMULT={in:1.25,coming:1.1,steady:1,going:0.75,out:0.5};
// v9 flowers: blank flowers (3 shapes, all 5 from rush 9) and dye tiles, from rush 5
const fShapes=()=>G.fx?FLOWERS.slice(0,G.rounds>=9?5:3):[];
const fBlanks=()=>fShapes().map(g=>wholeId(BLANK_B,g)),dyeLines=()=>G.fx?BG.map((c,b)=>wholeId(b,NONE_G)):[],xLines=()=>fBlanks().concat(dyeLines());
const hotDOf=p=>G.hotD&&G.hotD.p===p&&G.hotD.left>0?2.5:1;
const dyeW=b=>{const p=wholeId(b,NONE_G);return popOf(p)*dmOf(p)*hotDOf(p)};
const hotCol=b=>hotDOf(wholeId(b,NONE_G))>1;
function wdye(cols){let t=0;for(const b of cols)t+=dyeW(b);let r=Math.random()*t;for(const b of cols){r-=dyeW(b);if(r<=0)return b}return cols[cols.length-1]}
const flowerW=p=>{const d=dec(p);return popOf(p)*(d.t==='c'?(dyeW(d.a.b)+dyeW(d.c.b))/2:dyeW(d.b))};
const FLOWER_SHARE=0.2;
const flowerDemand=()=>custN()*FLOWER_SHARE*1.6+(G.bq?G.bq.items.reduce((a,o)=>a+o.n-o.got,0)/2:0);
function drift(q){if(G.dd[q]==null||Math.random()<0.3)G.dd[q]=[-1,0,0,1][(Math.random()*4)|0];
 const m=(G.dm[q]||1)*(1+0.22*G.dd[q]);G.dm[q]=Math.max(0.35,Math.min(2.6,m));if(G.dm[q]<=0.35&&G.dd[q]<0)G.dd[q]=0;if(G.dm[q]>=2.6&&G.dd[q]>0)G.dd[q]=0}
function rollSupply(){const kn=knownProds();const avgW=(kn.reduce((a,p)=>a+weightOf(p),0)/(kn.length||1))||1;const f=forecast();G.sup={};G.price={};
 for(const p of kn){const mk=marketOf(p,avgW);let n;
  if(G.rounds<2)n=Math.max(2,Math.ceil(f[p]*2/CRATE));
  else{ // about 90% of expected demand on average, with real gaps; popular lines are the scarce ones
   let k=Math.random()<0.22?0:0.5+Math.random()*1.3;if(mk==='in')k*=0.75;if(mk==='going'||mk==='out')k*=1.3;if(hotOf(p)>1)k*=0.6;
   n=Math.round(f[p]*k/CRATE+Math.random()*0.5);if(G.newLines.includes(p))n=Math.max(n,1)}
  G.sup[p]=n;G.price[p]=Math.max(1,Math.round(CRATE_COST*PMULT[mk]*(hotOf(p)>1?1.4:1)*UV('deal')))}
 if(G.fx){const fd=flowerDemand(),sh=fShapes(),dl=dyeLines(),tw=dl.reduce((a,p)=>a+dyeW(dec(p).b),0)||1;
  for(const p of xLines()){const d=dec(p),dye=d.g===NONE_G;const fc=dye?fd*dyeW(d.b)/tw*1.3:fd/sh.length;const k=G.fNew?1.5:(Math.random()<0.15?0:0.6+Math.random()*1.2);
   G.sup[p]=Math.max(G.fNew?1:0,Math.round(fc*k*2/CRATE+Math.random()*0.6));
   G.price[p]=Math.max(1,Math.round(CRATE_COST*(dye?Math.min(1.4,Math.max(0.6,dmOf(p))):1)*(hotDOf(p)>1?1.4:1)*UV('deal')))}}}
const supOf=p=>G.sup[p]||0;
const priceAt=p=>G.price[p];
// The supplier knows the market: it values every crate count for each line over the next two rushes
// (crowds growing, trends and their price, rising/falling demand), then suggests the
// 2nd- and 3rd-best amounts. It never names the best one; finding it is the player's edge.
const crowdAt=r=>Math.min(10,3+Math.floor(r*0.6))+G.up.hatch3;
function eItemsAt(r){const types=1+(r>=1?0.45:0)+(r>=4?0.3:0);return types*(1+Math.min(6,2+((r/2)|0)))/2}
function expSales(stock,mean){if(stock<=0||mean<=0)return 0;let e=0,p=Math.exp(-mean),cdf=0;for(let d=0;d<stock;d++){cdf+=p;e+=Math.max(0,1-cdf);p*=mean/(d+1);if(1-cdf<1e-9)break}return e}
function lineValues(p,have,f){const m1=f[p]||0;const r=G.rounds;const crowd=crowdAt(r+1)*eItemsAt(r+1)/(crowdAt(r)*eItemsAt(r));
 const hot=hotOf(p)>1,hot2=hot&&G.hot.left>=2;const drift=Math.max(0.35,Math.min(2.6,dmOf(p)*(1+0.22*dirOf(p))))/dmOf(p);
 const m2=m1*crowd*drift*(hot&&!hot2?1/2.5:1);const pr1=hot?HOT_PRICE:PRICE,pr2=hot2?HOT_PRICE:PRICE;
 const ev=[];let worse=0;for(let k=0;k<=24;k++){const st=have+CRATE*k;const s1=expSales(st,m1),s12=expSales(st,m1+m2);const left=st-s12;
  ev.push(pr1*s1+pr2*(s12-s1)+0.6*left-CRATE_COST*k);if(k>0&&ev[k]<ev[k-1]){if(++worse>=3)break}else worse=0}
 const order=ev.map((v,k)=>k).sort((a,b)=>(ev[b]-ev[a])||(a-b));return{ev,best:order[0],second:order[1],third:order[2]}}
function supplierView(){const f=forecast(),st=stockCounts(),v={};for(const p of knownProds())v[p]=lineValues(p,st[p]||0,f);return v}
function suggestOrder(){const v=supplierView();G.ord={};for(const p in v)if(v[p].best&&v[p].second)G.ord[p]=v[p].second}
function bestOrder(){const v=supplierView();G.ord={};for(const p in v)if(v[p].best)G.ord[p]=v[p].best}
const ordCrates=()=>Object.values(G.ord).reduce((a,b)=>a+b,0);const ordRefurb=()=>Object.values(G.ordR).reduce((a,b)=>a+b,0);
const REFURB_PRICE=1;
const ordCost=()=>Object.entries(G.ord).reduce((a,[p,n])=>a+n*priceAt(+p),0)+Object.values(G.ordR).reduce((a,n)=>a+n,0)*REFURB_PRICE;
const refurbAvail=key=>{const t=key[0],v=+key.slice(1);return Math.floor(((t==='c'?G.rc.c[v]:G.rc.s[v])||0)/2)};
const refurbId=key=>{const t=key[0],v=+key.slice(1);return t==='c'?wholeId(v,NONE_G):wholeId(BLANK_B,v)};
function freeSpots(){let n=0;for(let k=0;k<N;k++)if(!SOLID[k]&&k!==BIN&&G.items[k]===-1)n++;return n}
function placeOrder(){const cost=ordCost();if(cost>G.stars)return;G.stars-=cost;const list=[];
 for(const p in G.ord)for(let i=0;i<G.ord[p]*CRATE;i++)list.push(+p);
 if(G.fNew){for(const p of fBlanks().slice(0,2))list.push(p,p);for(const p of dyeLines().slice().sort((a,b)=>dyeW(dec(b).b)-dyeW(dec(a).b)).slice(0,3))list.push(p);G.fNew=0}
 for(const key in G.ordR){const n=Math.min(G.ordR[key],refurbAvail(key));const t=key[0],v=+key.slice(1);if(t==='c')G.rc.c[v]-=2*n;else G.rc.s[v]-=2*n;for(let i=0;i<n;i++)list.push(refurbId(key))}G.ordR={};
 if(CO){G.pend=list;G.pendC=cost;G.wait=true;G.ord={};G.newMach=[];closeOv();toast('Order in. Waiting for next door…');save();return}
 landDelivery(list,cost)}
function landDelivery(list,cost){
 G.dn++;if(list.length){shuffle(list);place(list);doorAnim=1;camGoal={x:(BAY.x0+BAY.x1)/2,y:(BAY.y0+BAY.y1)/2+1}}
 G.lastDel=list.length;G.ord={};G.phase='stock';
 G.phaseT=Math.min(110,30+2*list.length);
 G.newMach=[];closeOv();if(G.machSpare.length){machMode=true;rackMode=false}
 toast(list.length?`Delivery! ${list.length} things in the bay${cost?` · −${cost}★`:''}`:'No delivery this time');if(list.length)sThud();save()}
function nextDelivery(){openOrder()}
function afterSummary(){if(CO){G.wait=true;save();toast('Waiting for next door…');return}if(G.rounds%3===0){G.phase='down';G.phaseT=Infinity;save();showShop()}else openOrder()}
let ordScroll=0;
// The supplier just reports the market, fashion-style: what's in, coming in, going out, out.
const MKT=[{k:'in',t:'In',d:'Wanted a lot right now'},{k:'coming',t:'Coming in',d:'Demand is rising'},{k:'steady',t:'Steady',d:'Holding level'},{k:'going',t:'Going out',d:'Demand is falling'},{k:'out',t:'Out',d:'Hardly anyone wants these'}];
function marketOf(p,avg){const lv=weightOf(p)/avg,d=dirOf(p);
 if(hotOf(p)>1)return'in';if(lv<0.6&&d<=0)return'out';if(d<0)return'going';if(d>0)return lv>=1.1?'in':'coming';return lv>=1.1?'in':'steady'}
function showOrder(){const f=forecast(),st=stockCounts(),kn=knownProds();const avgW=(kn.reduce((a,p)=>a+weightOf(p),0)/(kn.length||1))||1;
 const cells={};for(let k=0;k<N;k++)if(G.items[k]>=0)cells[G.items[k]]=(cells[G.items[k]]||0)+1;
 const rows=kn.map(p=>{const have=st[p]||0,fc=f[p]||0,add=(G.ord[p]||0)*CRATE,h=G.hist[p]||[];
  const cov=fc>0.05?have/fc:Infinity,cov2=fc>0.05?(have+add)/fc:Infinity;
  const sold=h.length?h.reduce((a,x)=>a+x[0],0)/h.length:null,miss=h.reduce((a,x)=>a+x[1],0);
  return{p,have,fc,add,cov,cov2,sold,miss,mk:marketOf(p,avgW),lv:weightOf(p)/avgW,need:2*fc-have,hot:hotOf(p)>1,dir:dirOf(p),isNew:G.newLines.includes(p),fresh:isFresh(p),cells:cells[p]||0}});
 const RK=new Map(kn.slice().sort((a,b)=>weightOf(b)-weightOf(a)).map((p,i)=>[p,i+1]));
 const MI=Object.fromEntries(MKT.map((m,i)=>[m.k,i]));rows.sort((a,b)=>(MI[a.mk]-MI[b.mk])||(b.hot-a.hot)||(b.lv-a.lv));
 const colOf=r=>{const c=r.cov2;if(c<1)return['#ff6b6b','short'];if(c<2)return['#ffd23f','tight'];if(c<=5)return['#7bd88f','good'];return['#8a90a0','plenty']};
 const fmtC=c=>c===Infinity?'∞':c.toFixed(1);
 let h=`<h2>Order stock</h2><p class="olead">Crates hold ${CRATE} of one kind. The supplier only has a few of each line, sometimes none, so make what's missing on your machines. Prices follow the market. Things sell for ${PRICE}★ (trending ${HOT_PRICE}★); fresh things pay by freshness, 3★, 2★ or 1★ (trending ×2½). Running out loses the sale. <b>#</b> is a line's interest rank, which sets the Display Case's layout. Rows are grouped by what's <b>in</b>, <b>coming in</b>, <b>going out</b> and <b>out</b>.</p>`;
 if(G.newMach.length)h+=`<p class="ohot" style="background:#22294a;border-color:#4a5aa0">🛠 New machine${G.newMach.length>1?'s':''} arriving: <b>${G.newMach.map(t=>MACH[t].name).join(' and ')}</b>. You'll place ${G.newMach.length>1?'them':'it'} after ordering. Customers will start asking for custom things.</p>`;
 if(G.fNew)h+=`<p class="ohot" style="background:#3a1d33;border-color:#a04a85">🌷 <b>Flowers have arrived.</b> Order blank flowers and dye tiles below. In the dye swapper, a blank flower and a dye tile give the coloured flower <i>and</i> its inverse. Flower customers come to any hatch. This delivery brings a few free ones to start.</p>`;
 if(G.bq){const q=G.bq,l=q.due-G.rounds;h+=`<p class="ohot" style="background:#3a1d33;border-color:#a04a85">💐 <b>Bouquet order</b>: ${q.items.map(o=>`<img src="${iconURL(o.p)}" alt="">×${o.n-o.got}`).join(' ')} · due in ${l} rush${l===1?'':'es'} · pays <b>${q.pay}★</b>. Hand it in at any hatch, or tap its card, whenever it's ready.</p>`}
 if(G.hot&&G.hot.left>0)h+=`<p class="ohot">🔥 Trending: <img src="${iconURL(G.hot.p)}" alt=""> is wanted 2½× as much and sells for ${HOT_PRICE}★ each, for the next ${G.hot.left} rush${G.hot.left>1?'es':''}.</p>`;
 h+=`<div class="olist">`;
 let lastMk='';for(const r of rows){if(r.mk!==lastMk){lastMk=r.mk;const m=MKT.find(m=>m.k===r.mk);const n=rows.filter(x=>x.mk===r.mk).length;h+=`<div class="ohead mk-${m.k}"><b>${m.t}</b> <span>${m.d} · ${n}</span></div>`}const[col,word]=colOf(r);const pct=r.cov2===Infinity?100:Math.min(100,r.cov2/5*100);
  const sp=supOf(r.p);const tags=[];tags.push(sp?`<span class="tg sup">Supplier has ${sp} · ${priceAt(r.p)}★ a crate</span>`:'<span class="tg miss">Out at the supplier</span>');tags.push(`<span class="tg">Interest #${RK.get(r.p)} of ${kn.length}</span>`);tags.push(r.fresh?`<span class="tg">Sells for ${r.hot?'7½/5/2½':'3/2/1'}★ by freshness</span>`:`<span class="tg">Sells for ${r.hot?HOT_PRICE:PRICE}★ each</span>`);if(r.isNew)tags.push('<span class="tg new">New line</span>');if(r.hot)tags.push('<span class="tg hot">🔥 Trending</span>');
  if(r.fresh)tags.push('<span class="tg fr">❄ Stacks only in the cold case</span>');
  tags.push(r.sold==null?'<span class="tg">No sales yet</span>':`<span class="tg">Sold ${r.sold.toFixed(1)}/rush</span>`);
  if(r.miss)tags.push(`<span class="tg miss">${r.miss} asked for while out</span>`);
  if(r.have)tags.push(`<span class="tg">In ${r.cells} spot${r.cells===1?'':'s'}</span>`);
  h+=`<div class="orow"><img src="${iconURL(r.p)}" alt=""><div class="om"><div class="o1"><b>Have ${r.have}</b> · next rush ~${r.fc.toFixed(1)} · lasts <b style="color:${col}">${fmtC(r.cov)}${r.add?` → ${fmtC(r.cov2)}`:''}</b> <span style="color:${col}">${word}</span></div>
   <div class="cbar"><i style="width:${pct}%;background:${col}"></i></div><div class="o2">${tags.join('')}</div></div>
   <div class="step"><button data-om="${r.p}"${r.add?'':' disabled'}>−</button><span>${G.ord[r.p]||0}</span><button data-op="${r.p}"${(G.ord[r.p]||0)>=sp?' disabled':''}>+</button></div></div>`}
 if(G.fx){const st2=stockCounts();
  const row=(p,title,tags)=>{const n=G.ord[p]||0,sp=supOf(p);return `<div class="orow"><img src="${iconURL(p)}" alt=""><div class="om"><div class="o1"><b>Have ${st2[p]||0}</b> · ${title}</div><div class="o2">${tags.join('')}</div></div><div class="step"><button data-om="${p}"${n?'':' disabled'}>−</button><span>${n}</span><button data-op="${p}"${n>=sp?' disabled':''}>+</button></div></div>`};
  const sup=p=>supOf(p)?`<span class="tg sup">Supplier has ${supOf(p)} · ${priceAt(p)}★ a crate</span>`:'<span class="tg miss">Out at the supplier</span>';
  h+=`<div class="ohead mk-flower"><b>🌷 Flowers</b> <span>blank flowers to colour · fresh</span></div>`;
  for(const p of fBlanks())h+=row(p,'blank flower',[sup(p),'<span class="tg fr">❄ Stacks only in the cold case</span>']);
  const dl=dyeLines().slice().sort((a,b)=>dyeW(dec(b).b)-dyeW(dec(a).b));
  h+=`<div class="ohead mk-dye"><b>🎨 Dyes</b> <span>colour tiles · the colours flower customers want most come first</span></div>`;
  dl.forEach((p,i)=>{const b=dec(p).b,dir=dirOf(p);h+=row(p,`${COLNAME[b]} dye`,[sup(p),`<span class="tg">Interest #${i+1} of ${dl.length}</span>`,hotDOf(p)>1?'<span class="tg hot">🔥 Trending: flowers in this colour pay ×1½</span>':'',dir>0?'<span class="tg">Rising ↑</span>':dir<0?'<span class="tg">Falling ↓</span>':''])})}
 h+=`</div>`;
 const c=ordCrates(),cost=ordCost(),fs=freeSpots(),need=Math.ceil(c*CRATE/2);const can=cost<=G.stars;
 h+=`<div class="osum"><div><b>${c}</b> crate${c===1?'':'s'} · ${c*CRATE} things${ordRefurb()?` + ${ordRefurb()} refurbished`:''} · cost <b style="color:${can?'#ffd23f':'#ff6b6b'}">${cost}★</b> of ★${G.stars}</div>
  <div class="omuted">Floor: ${fs} free spots · this needs about ${need}${need>fs?' <b style="color:#ff6b6b">(not enough room)</b>':''}</div>
  <div class="row" style="margin-top:8px"><button id="oClr">Clear</button><button class="big" id="oGo"${can?'':' disabled'}>${c||ordRefurb()?'Place order':'Skip delivery'}</button></div>
  ${can?'':`<div class="omuted" style="color:#ff6b6b">Need ${cost-G.stars}★ more: take a few things off the order.</div>`}</div>`;
 const card=$('#ovc');ordScroll=card.scrollTop;ov(h);card.classList.add('ord');card.scrollTop=ordScroll;
 card.querySelectorAll('[data-op]').forEach(b=>b.onclick=()=>{const p=+b.dataset.op;if((G.ord[p]||0)>=supOf(p))return;G.ord[p]=(G.ord[p]||0)+1;sTick();showOrder()});
 card.querySelectorAll('[data-rp]').forEach(b=>b.onclick=()=>{const k=b.dataset.rp;if((G.ordR[k]||0)>=refurbAvail(k))return;G.ordR[k]=(G.ordR[k]||0)+1;sTick();showOrder()});
 card.querySelectorAll('[data-rm]').forEach(b=>b.onclick=()=>{const k=b.dataset.rm;G.ordR[k]=Math.max(0,(G.ordR[k]||0)-1);if(!G.ordR[k])delete G.ordR[k];sTick();showOrder()});
 card.querySelectorAll('[data-om]').forEach(b=>b.onclick=()=>{const p=+b.dataset.om;G.ord[p]=Math.max(0,(G.ord[p]||0)-1);if(!G.ord[p])delete G.ord[p];sTick();showOrder()});
 $('#oClr').onclick=()=>{G.ord={};showOrder()};$('#oGo').onclick=()=>{card.classList.remove('ord');placeOrder()}}


// ---------- camera / view ----------
const cv=$('#c'),ctx=cv.getContext('2d');
let DPR=1,VW=0,VH=0,S=30,CX=0,CY=0,camX=W/2,camY=H/2,zoom=1,ROT=false,topH=0,botH=0;
const TOUCH=matchMedia('(pointer:coarse)').matches;
const EX=[-1.3,MAINW+2.3],EY=[-1.5,H+2.5];
function layout(){DPR=Math.min(2,devicePixelRatio||1);VW=innerWidth;VH=innerHeight;cv.width=Math.round(VW*DPR);cv.height=Math.round(VH*DPR);ROT=VH>VW*1.15}
function w2s(x,y){return ROT?[CX-(y-camY)*S,CY+(x-camX)*S]:[CX+(x-camX)*S,CY+(y-camY)*S]}
function s2w(sx,sy){return ROT?[camX+(sy-CY)/S,camY-(sx-CX)/S]:[camX+(sx-CX)/S,camY+(sy-CY)/S]}
const sdir=(x,y)=>ROT?[-y,x]:[x,y];
function wr(x,y,w,h){const a=w2s(x,y),b=w2s(x+w,y+h);return[Math.min(a[0],b[0]),Math.min(a[1],b[1]),Math.abs(b[0]-a[0]),Math.abs(b[1]-a[1])]}
function fr(x,y,w,h,c){const r=wr(x,y,w,h);ctx.fillStyle=c;ctx.fillRect(r[0],r[1],r[2],r[3])}
function camUpdate(dt){EX[1]=(openW()===W?W:MAINW+1)+1.3;topH=$('#hud').offsetHeight;botH=$('#bot').offsetHeight;
 const aw=VW,ah=Math.max(120,VH-topH-botH);const ex=EX[1]-EX[0],ey=EY[1]-EY[0];
 const fit=ROT?Math.min(aw/ey,ah/ex):Math.min(aw/ex,ah/ey);const minS=TOUCH?(BIGV?46:30):(BIGV?34:22);
 const base=Math.max(fit,minS);S=clamp(base*zoom,Math.min(fit,base)*0.85,96);
 CX=aw/2;CY=topH+ah/2;
 const hx=(ROT?ah:aw)/2/S,hy=(ROT?aw:ah)/2/S;
 if(camGoal){const k=Math.min(1,dt*4);camX+=(camGoal.x-camX)*k;camY+=(camGoal.y-camY)*k;if(Math.hypot(camGoal.x-camX,camGoal.y-camY)<0.05)camGoal=null}
 camX=ex<=2*hx?(EX[0]+EX[1])/2:clamp(camX,EX[0]+hx,EX[1]-hx);
 camY=ey<=2*hy?(EY[0]+EY[1])/2:clamp(camY,EY[0]+hy,EY[1]-hy)}

// ---------- input (touch / mouse only) ----------
addEventListener('keydown',e=>{if(ovOpen()&&e.key==='Escape'&&G.phase!=='order')closeOv()});
const ptrs=new Map();let gest=null;
cv.addEventListener('pointerdown',e=>{e.preventDefault();ensureAudio();try{cv.setPointerCapture(e.pointerId)}catch(_){}
 ptrs.set(e.pointerId,{x:e.clientX,y:e.clientY});
 if(ptrs.size===2){const[a,b]=[...ptrs.values()];gest={type:'pinch',d0:Math.hypot(a.x-b.x,a.y-b.y)||1,z0:zoom,m:[(a.x+b.x)/2,(a.y+b.y)/2]};return}
 if(ptrs.size>2)return;
 gest={type:'maybe',id:e.pointerId,sx:e.clientX,sy:e.clientY,lx:e.clientX,ly:e.clientY,t:performance.now()};});
cv.addEventListener('pointermove',e=>{const p=ptrs.get(e.pointerId);if(!p)return;p.x=e.clientX;p.y=e.clientY;if(!gest)return;
 if(gest.type==='pinch'){if(ptrs.size<2)return;const[a,b]=[...ptrs.values()];const d=Math.hypot(a.x-b.x,a.y-b.y);zoom=clamp(gest.z0*d/gest.d0,0.5,3);
  const m=[(a.x+b.x)/2,(a.y+b.y)/2];panBy(m[0]-gest.m[0],m[1]-gest.m[1]);gest.m=m;return}
 if(e.pointerId!==gest.id)return;
 if(gest.type==='maybe'&&Math.hypot(e.clientX-gest.sx,e.clientY-gest.sy)>10)gest.type='pan';
 if(gest.type==='pan')panBy(e.clientX-gest.lx,e.clientY-gest.ly);
 gest.lx=e.clientX;gest.ly=e.clientY});
function endPtr(e){if(!ptrs.has(e.pointerId))return;ptrs.delete(e.pointerId);
 if(gest&&gest.type==='maybe'&&gest.id===e.pointerId&&performance.now()-gest.t<600){const[wx,wy]=s2w(gest.sx,gest.sy);tap(wx,wy)}
 if(ptrs.size===0){gest=null}else if(gest&&gest.type==='pinch')gest={type:'done'}}
cv.addEventListener('pointerup',endPtr);cv.addEventListener('pointercancel',endPtr);
cv.addEventListener('wheel',e=>{e.preventDefault();zoom=clamp(zoom*Math.exp(-e.deltaY*0.0015),0.5,3)},{passive:false});
cv.addEventListener('contextmenu',e=>e.preventDefault());
function panBy(dx,dy){const[ax,ay]=s2w(0,0),[bx,by]=s2w(dx,dy);camX-=bx-ax;camY-=by-ay;camGoal=null}
function tap(wx,wy){if(ovOpen())return;const cx=Math.floor(wx),cy=Math.floor(wy),now=performance.now();
 if(demoMode){if(inF(cx,cy))demoTap(cx,cy);return}
 if(cy>=H){const h=HX.findIndex(x=>Math.abs(x+0.5-wx)<1.2);if(h>=0)serveAt(h);return}
 if(!inF(cx,cy))return;if(SOLID[ix(cx,cy)]){solidHint(cx,cy);return}
 if(rackMode){placeRack(cx,cy);return}
 if(machMode){placeMachine(cx,cy);return}
 if(ix(cx,cy)===BIN){binTap();return}
 if(G.items[ix(cx,cy)]===-3){const m=machAt(ix(cx,cy));if(m)feed(m);return}
 if(G.items[ix(cx,cy)]!==-1)pickAt(cx,cy);else if(G.hand.length)putAt(cx,cy)}
function hold(wx,wy){if(ovOpen())return;const cx=Math.floor(wx),cy=Math.floor(wy);
 if(inF(cx,cy)&&G.items[ix(cx,cy)]===-3&&!rackMode&&!machMode&&!demoMode){const m=machAt(ix(cx,cy));if(m){if(G.hand.length)feed(m);else liftMachine(m)}return}
 if(demoMode||rackMode||machMode||!inF(cx,cy)||SOLID[ix(cx,cy)]||ix(cx,cy)===BIN||CASEM[ix(cx,cy)]||G.items[ix(cx,cy)]===-1){tap(wx,wy);return}addAt(cx,cy)}

// ---------- HUD ----------
let ordersDirty=true,handKey='',actKey='',barRefs=[],ordPh='';
function renderOrders(){ordersDirty=false;const el=$('#orders');let h='';
 const show=G.phase==='rush';
 if(G.bq&&G.phase!=='order'&&G.phase!=='sum'){const q=G.bq,nx=q.items.find(o=>o.got<o.n),l=q.due-G.rounds;
  h+=`<div class="oc bq" data-h="bq"><b>💐</b><span class="cut">${l} rush${l===1?'':'es'} · ${q.pay}★</span>`+q.items.map(o=>`<span class="it${o.got>=o.n?' done':''}${o===nx?' nx':''}"><img src="${iconURL(o.p)}" alt="">×${Math.max(0,o.n-o.got)}</span>`).join('<span class="ar">›</span>')+'</div>'}
 if(show)HS.forEach((hs,i)=>{if(!hs.open)return;const c=hs.cust;
  if(!c){if(G.phase==='rush')h+=`<div class="oc idle" data-h="${i}"><b>${i+1}</b>…</div>`;return}
  const nx=nextLine(c);
  h+=`<div class="oc${c.custom?' cu':''}${c.flower?' fl':''}${i===CASE_H?' ch':''}" data-h="${i}"><b>${i+1}</b>${c.custom?'<span class="cut">✨<span class="cl"> Custom ·</span> '+(c.price||CUSTOM_PRICE)+'★</span>':''}${c.flower?'<span class="cut">🌷</span>':''}`+c.order.map(o=>`<span class="it${o.got>=o.n?' done':''}${o===nx?' nx':''}" data-p="${o.p}"><img src="${iconURL(o.p)}" alt="">×${Math.max(0,o.n-o.got)}</span>`).join('<span class="ar">›</span>')+'<span class="st"></span><i class="bar"></i>'+'</div>'});
 el.innerHTML=h;if(magH!=null)showMag(magH);barRefs=[...el.querySelectorAll('.oc')].map(n=>({h:+n.dataset.h,st:n.querySelector('.st'),bar:n.querySelector('.bar')})).filter(r=>r.h>=0)}
// ---------- the magnifier (v9.2): press and hold an order card to see it up close; let go to close ----------
document.body.insertAdjacentHTML('beforeend','<div id="mag" class="hidden"></div>');
let magT=0,magH=null,magUsed=false,magP=null;
const turnVis=(g,r)=>r%4&&((r*SYM[g])%4)!==0,TURN=['','¼','½','¾'];
function magLine(o,nx,craft){const d=dec(o.p);let parts='';const tb=(g,r)=>turnVis(g,r)?`<span class="mt">↻${TURN[r%4]}</span>`:'';
 if(d.t==='c'){const sd=AX_SIDES[d.axis];parts='<span class="eq">=</span>'+[d.a,d.c].map((q,k)=>`<span class="mp"><img src="${iconURL(halfId(sd[k],q.b,q.g,q.r,q.inv),216)}" alt="">${tb(q.g,q.r)}</span>`).join('<span class="eq">+</span>');
  if(isFlowerD(d))parts+='<span class="mb">two-tone</span>'}
 else if(d.t==='h')parts='<span class="mb">half</span>'+(d.inv?'<span class="mb">inverse</span>':'')+(craft&&turnVis(d.g,d.r)?`<span class="mb">↻${TURN[d.r%4]}</span>`:'');
 else{if(d.inv)parts+='<span class="mb">inverse</span>';if(craft&&turnVis(d.g,d.r))parts+=`<span class="mb">↻${TURN[d.r%4]}</span>`}
 return `<div class="mrow${o.got>=o.n?' done':''}${o===nx?' nx':''}"><img class="mbig" src="${iconURL(o.p,288)}" alt=""><span class="mcol"><span class="mn">×${Math.max(0,o.n-o.got)}</span><span class="mparts">${parts}</span></span></div>`}
function showMag(h){const m=$('#mag');let head,lines,nx,craft;
 if(h==='bq'){const q=G.bq;if(!q)return hideMag();const l=q.due-G.rounds;head=`<b>💐</b> Bouquet · ${l} rush${l===1?'':'es'} · ${q.pay}★`;lines=q.items;nx=q.items.find(o=>o.got<o.n);craft=true}
 else{const c=HS[+h]&&HS[+h].cust;if(!c)return hideMag();head=`<b>${+h+1}</b>${c.custom?'✨ Custom · '+(c.price||CUSTOM_PRICE)+'★ · '+(c.steps||1)+' step'+((c.steps||1)>1?'s':''):c.flower?'🌷 Flowers':+h===CASE_H?'Case hatch':'Hatch '+(+h+1)}`;lines=c.order;nx=nextLine(c);craft=!!(c.custom||c.flower)}
 magH=h;m.classList.toggle('many',lines.length>3);m.innerHTML=`<h3>${head}</h3>`+lines.map(o=>magLine(o,nx,craft)).join('');m.classList.remove('hidden')}
function hideMag(){magH=null;$('#mag').classList.add('hidden')}
{const O=$('#orders');O.addEventListener('contextmenu',e=>e.preventDefault());
 O.addEventListener('pointerdown',e=>{const oc=e.target.closest('.oc');magUsed=false;if(!oc)return;magP=[e.clientX,e.clientY];clearTimeout(magT);const h=oc.dataset.h;magT=setTimeout(()=>{magUsed=true;magP=null;showMag(h)},HOLD)});
 O.addEventListener('pointermove',e=>{if(magP&&Math.hypot(e.clientX-magP[0],e.clientY-magP[1])>14){clearTimeout(magT);magP=null}});
 const end=()=>{clearTimeout(magT);magP=null;if(magH!=null)hideMag()};addEventListener('pointerup',end);addEventListener('pointercancel',end)}
$('#orders').addEventListener('click',e=>{if(magUsed){magUsed=false;return}const oc=e.target.closest('.oc');if(!oc)return;ensureAudio();if(oc.dataset.h==='bq'){serveBq();return}const h=+oc.dataset.h;const c=HS[h]&&HS[h].cust;
 const it=e.target.closest('.it');
 if(torchArmed&&it&&G.phase==='rush'&&G.fc>0){torchArmed=false;G.fc--;FIND={p:+it.dataset.p,t:2.6};sTick();return}
 serveAt(h)});
$('#torch').addEventListener('click',()=>{ensureAudio();if(G.phase!=='rush'||G.fc<=0){toast('No torch left this rush');return}torchArmed=!torchArmed;toast(torchArmed?'Torch ready: tap a picture on an order':'Torch put away')});
$('#machB').addEventListener('click',()=>{ensureAudio();machMode=!machMode;rackMode=false;demoMode=false;if(machMode)toast(`Tap an empty spot for the ${MACH[G.machSpare[0]].name}`)});
$('#demoB').addEventListener('click',()=>{ensureAudio();demoMode=!demoMode;rackMode=false;machMode=false;demoSel=null;toast(demoMode?'Tap a pillar or wall to knock it down (price on the tag)':'Building work done for now')});
$('#botB').addEventListener('click',()=>{ensureAudio();if(!G.bot)return;G.bot.on=!G.bot.on;if(!G.bot.on)botSettle();toast(G.bot.on?'Clunk is back at work':'Clunk is switched off');save()});
$('#rackB').addEventListener('click',()=>{ensureAudio();rackMode=!rackMode;machMode=false;demoMode=false;if(rackMode)toast('Tap any spot to put a shelf rack there. It holds 10 of one kind.')});
$('#hand').addEventListener('click',()=>{ensureAudio();toast(G.hand.length?'They go out left to right. Tap an empty spot to put down the first one.':'Tap things on the floor to pick them up')});
$('#menuB').addEventListener('click',()=>{ensureAudio();showMenu()});
$('#act').addEventListener('click',()=>{ensureAudio();actPress()});
$('#shopB').addEventListener('click',()=>{ensureAudio();showShop()});
function actPress(){if(ovOpen())return;if(G.phase==='stock'){if(CO){CO.openHatches();return}startRush(true)}
 else if(G.phase==='down'){if(CO){G.wait=true;save();toast('Waiting for next door…');return}openOrder()}}
function hud(){let t;
 if(G.wait)t='Waiting for next door…';
 else if(G.phase==='stock'){const lab=CO&&CO.opening()?'Opening the hatches…':'Delivery';t=isFinite(G.phaseT)?`${lab} · ${fmt(G.phaseT)}`:lab}
 else if(G.phase==='rush')t=`Hatches open · ${fmt(G.phaseT)} · ${Math.max(0,custN()-RS.served)} to serve`;else if(G.phase==='down')t='Day off';else if(G.phase==='order')t='Ordering';else t='Closed';
 const ph=$('#phase');if(ph.textContent!==t)ph.textContent=t;ph.classList.toggle('hot',G.phase==='rush'&&G.phaseT<20);
 const st=`★ ${G.stars}`;if($('#stars').textContent!==st)$('#stars').textContent=st;
 const tc=$('#torch'),showT=G.phase==='rush'&&fcMax()>0;tc.classList.toggle('hidden',!showT);tc.classList.toggle('on',torchArmed);if(showT){const s='🔦 '+G.fc;if(tc.textContent!==s)tc.textContent=s}
 {const rb=$('#rackB'),sh=G.racksSpare>0&&G.phase!=='sum';rb.classList.toggle('hidden',!sh);rb.classList.toggle('on',rackMode);if(sh){const t2=rackMode?`Tap a spot for the rack (${G.racksSpare})`:`🗄 Place rack ×${G.racksSpare}`;if(rb.textContent!==t2)rb.textContent=t2}else if(rackMode)rackMode=false}
 {const mb=$('#machB'),sh=G.machSpare.length>0&&G.phase!=='sum'&&G.phase!=='order';mb.classList.toggle('hidden',!sh);mb.classList.toggle('on',machMode);if(sh){const t2=machMode?`Tap a spot for the ${MACH[G.machSpare[0]].name}`:`🛠 Place ${MACH[G.machSpare[0]].name}`;if(mb.textContent!==t2)mb.textContent=t2}else if(machMode)machMode=false}
 {const db=$('#demoB'),sh=G.phase==='down'&&PIECES.some(pieceOpen);db.classList.toggle('hidden',!sh);db.classList.toggle('on',demoMode);if(!sh)demoMode=false;const t2=demoMode?'🔨 Done':'🔨 Build';if(db.textContent!==t2)db.textContent=t2}
 {const bb=$('#botB'),sh=!!botLv();bb.classList.toggle('hidden',!sh);if(sh){const t2=!G.bot.on?'🤖 Off':B.mode==='nap'?'🤖 Zz':B.mode==='fetch'||B.mode==='carry'?'🤖 Busy':'🤖 Idle';bb.classList.toggle('off',!G.bot.on);if(bb.textContent!==t2)bb.textContent=t2}}
 if(ordersDirty||G.phase+(G.bq?'b':'')!==ordPh){ordPh=G.phase+(G.bq?'b':'');renderOrders()}
 for(const r of barRefs){const c=HS[r.h].cust;if(!c||!r.bar)continue;const rt=rating(c);
  const f=rt===3?1-c.t/c.t3:rt===2?1-(c.t-c.t3)/c.t3:0.04;r.bar.style.width=(Math.max(0.04,f)*100).toFixed(1)+'%';
  r.bar.style.background=rt===3?'#7bd88f':rt===2?'#ffd23f':'#ff6b6b';const s='★'.repeat(rt)+'☆'.repeat(3-rt);if(r.st.textContent!==s)r.st.textContent=s}
 const hk=G.hand.join(',')+'/'+cap();if(hk!==handKey){handKey=hk;
  $('#hand').innerHTML=(G.hand.length?G.hand.map((p,i)=>{const im=`<img src="${iconURL(p)}" alt=""${i===0?' class="first"':''}>`;return im}).join(''):'<span class="cap">Hands empty</span>')+`<span class="cap">${G.hand.length}/${cap()}</span>`}
 $('#hand').classList.toggle('shake',shakeT>0);
 let ak;if(G.phase==='stock'){const b=isFinite(G.phaseT)?Math.floor(G.phaseT/15):0;ak='s'+b+(CO&&CO.opening()?'o':'')}else ak=G.phase;if(G.wait)ak+='w';
 if(ak!==actKey){actKey=ak;const a=$('#act');a.classList.toggle('hidden',!(G.phase==='stock'||G.phase==='down')||!!G.wait);
  if(G.phase==='stock'){const b=isFinite(G.phaseT)?Math.floor(G.phaseT/15):0;a.textContent='Open hatches'+(b?` · +${b}★`:'');a.disabled=!!(CO&&CO.opening())}
  else if(G.phase==='down'){a.textContent='Order stock';a.disabled=false}
  $('#shopB').classList.toggle('hidden',G.phase!=='down'||!!G.wait)}}

// ---------- overlays ----------
const HELP=`<h2>Stockroom</h2><p>Deliveries land in the yellow bay. Put everything away wherever you like. Nothing has a name, so your system is the only map.</p><ul>
<li><b>Tap</b> a thing to pick one up. You can hold 6; they line up bottom left in the order you picked them.</li>
<li><b>Tap an empty spot</b> to put down the first thing you're holding, plus any more of the same kind right behind it, as one stack.</li>
<li><b>Press and hold</b> a stack to add more of the same kind to it. Floor stacks hold 4; shelf racks (bought on days off) hold 10.</li>
<li>When the hatches open, customers show what they want <b>in order</b>, left to right. Pick things up in that order, then tap the customer or their card. They take things one at a time until the next one is wrong.</li>
<li>Quick service earns more stars. Rushes bring surprises: extra deliveries and returns land in the bay.</li>
<li>Some pictures are <b>fresh</b> (every colour of them, their halves too, and flowers). Fresh things only stack in <b>the cold case</b> (bottom left, around hatch 1, ❄). Anywhere else they sit one to a spot, with a little ❄ to say where they belong. Nothing spoils.</li>
<li>The cold case works like the floor (tap to take one, tap to put down). Anything can go in it. Customers at hatch 1 mostly ask for what's in the cold case, the front row by the wall most of all, custom orders too.</li>
<li>Between rushes you order stock from the supplier. Supply is limited (a few crates of each line, sometimes none) and prices follow the market. Each thing sold pays 2★ (trending things 5★); running out loses sales, unless you can make it on your machines. The order page shows everything you need: stock, the next-rush forecast, how long each line lasts, lost sales, and what's in, coming in, going out and out.</li>
<li><b>Machines</b> arrive as you go: a dye swapper, then a vertical splitter and combiner, then a horizontal splitter, then a rotator (a quarter turn clockwise; a left half becomes a top half), then two diagonal cutters, \\ and /, which cut corner to corner into triangles. The combiner joins a triangle with the opposite corner's triangle. Tap a machine with things in hand to feed it (the front of your hand goes in first); what it makes pops out beside it. Press and hold a machine with empty hands to move it.</li>
<li><b>Recycler:</b> feed it spare halves, two-part things or blanks. It saves each part's colour and picture. <b>Tap it with empty hands</b> (any time, even in a rush) to open your recycled stock: every 2 parts of a colour or picture make a <b>blank</b> you can take straight into your hands, a plain colour tile or an unpainted picture. Put a blank picture and a colour tile into the dye swapper (it takes whole things only) to make the real thing, even when the supplier is out.</li>
<li><b>Hard to see?</b> Press and hold any order to see it up close, with custom things shown as their parts. ☰ → <b>Big view</b> makes the orders, your hands and the floor bigger, with stronger contrast (saved on this phone).</li>
<li><b>Flowers</b> arrive after a few rushes: blank flowers and dye tiles on the order page. Put a blank flower and a dye tile in the dye swapper: out comes the coloured flower <b>and its inverse</b> (the flower coloured, the tile left plain). Flowers are fresh (they stack only in the cold case) and only join with other flowers. Flower customers (🌷) want coloured flowers; the dye that's trending pays ×1½. Now and then a <b>bouquet order</b> (💐) comes in: a few flowers due within a couple of rushes, handed in at any hatch or by tapping its card. The <b>colour stripper</b> takes a coloured thing apart into its blank picture and a dye tile.</li>
<li><b>Custom customers</b> (purple cards) want things no supplier sells, like a star that's red on the left and blue on the right. Work out the recipe and make it; they pay 10★ for a one-step recipe and 2★ more for each extra step (the card shows the price; hold it to see the steps). Inverse things cut, turn and join like any other. Spare halves are worth keeping: later customers may want them.</li>
<li>Every third rush is followed by a day off to tidy up, buy shelf racks and spend stars. Upgrades have 3 or 5 levels, and each one shows exactly what you get.</li>
<li><b>Building work</b> (days off): tap 🔨 and knock down pillars, or the east wall to open the old storerooms behind it. Tap the same pillar or wall twice to confirm.</li>
<li><b>Clunk the robot</b> (an upgrade) carries strays over to the rest of that thing: new stock in the bay, and odd leftovers far from their pile. He leaves fresh things to you. He's clumsy, so check his work. Tap 🤖 to switch him on or off.</li>
<li>Pinch or scroll to zoom; drag the floor to look around.</li></ul>`;
function showHelp(){ov(HELP+`<div class="row"><button class="big" id="hX">Let's sort</button></div>`);$('#hX').onclick=()=>{G.help=false;save();closeOv()}}
function showSummary(){const r=G.lastRS;const nxt=G.rounds%3===0?'Day off':'Order stock';
 ov(`<h2>Hatches closed</h2><div class="bigstars">+${r.stars}★</div><p style="text-align:center">Served ${r.served} of ${r.total} customer${r.total===1?'':'s'} · ${r.perfect} perfect${r.clean?'<br>Everyone served +2★':''}${r.early?`<br>Opened early +${r.early}★`:''}${r.made?`<br>Custom things made: ${r.made}`:''}${r.flowers?`<br>Flower customers: ${r.flowers}`:''}${r.bqLost?'<br>💐 The bouquet order lapsed':''}<br>Sales +${r.sales}★${r.hotSold?` (incl. ${r.hotSold} trending)`:''}${(()=>{const m=Object.values(r.miss||{}).reduce((a,b)=>a+b,0);return m?`<br>${m} sale${m>1?'s':''} lost: asked for things you were out of`:''})()}</p><div class="row"><button class="big" id="nx">${nxt}</button></div>`);
 $('#nx').onclick=()=>{closeOv();afterSummary()}}
function showShop(){let h=`<h2>${G.phase==='down'?'Day off':'Upgrades'}</h2><p style="margin:0 0 6px">No customers today. Tidy up, rethink your system, spend stars. You have <b style="color:#ffd23f">★ ${G.stars}</b>.</p>`;
 for(const u of UPS){if(u.needsMach&&!G.unl.length)continue;const lv=G.up[u.k],max=u.cost.length,c=u.cost[lv];
  const now=u.fmt(u.vals[lv]),nxt=lv<max?u.fmt(u.vals[lv+1]):'';
  h+=`<div class="up"><div class="t"><b>${u.name}</b>${u.desc?`<small>${u.desc}</small>`:''}<small>${lv<max?`${now} <b style="color:#7bd88f">→ ${nxt}</b>`:`${now} · maxed`}</small><span class="pips">${'<i class="on"></i>'.repeat(lv)}${'<i></i>'.repeat(max-lv)}</span></div>${lv>=max?'<span style="color:#7bd88f;font-weight:700">Done</span>':`<button data-u="${u.k}"${G.stars<c?' disabled':''}>★ ${c}</button>`}</div>`}
 h+=`<div class="up"><div class="t"><b>Shelf rack</b><small>Holds 10 of one kind. Put it anywhere, even under a stack you already have.${G.racksSpare?` (${G.racksSpare} waiting to be placed)`:''}</small></div><button id="buyRack"${G.stars<rackCost()?' disabled':''}>★ ${rackCost()}</button></div>`;
 const op=PIECES.filter(pieceOpen);if(G.phase==='down'&&op.length){const pc=op.filter(p=>p.kind==='pillar').length,wl=op.filter(p=>p.kind==='wall');
  h+=`<div class="up"><div class="t"><b>Building work</b><small>Knock down ${pc?`pillars (12★ each)`:''}${pc&&wl.length?' and ':''}${wl.length?`walls (${wl.map(p=>p.cost+'★').join(', ')})`:''} for more floor. Behind the east wall are two old storerooms.</small></div><button id="buildB">🔨 Start</button></div>`}
 h+=`<div class="row"><button class="big" id="shX">Back to the floor</button></div>`;ov(h);
 if($('#buildB'))$('#buildB').onclick=()=>{closeOv();demoMode=true;rackMode=false;machMode=false;demoSel=null;camGoal={x:MAINW-4,y:H/2};toast('Tap a pillar or wall to knock it down (price on the tag)')};
 $('#buyRack').onclick=()=>{if(G.stars<rackCost())return;G.stars-=rackCost();G.racksBought++;G.racksSpare++;sChime();save();showShop()};
 $('#shX').onclick=()=>{closeOv();if(G.racksSpare>0){rackMode=true;toast('Tap any spot to place your rack')}};
 document.querySelectorAll('[data-u]').forEach(b=>b.onclick=()=>{const u=UPS.find(u=>u.k===b.dataset.u);const c=u.cost[G.up[u.k]];if(G.stars<c)return;
  G.stars-=c;G.up[u.k]++;if(u.k==='hatch3')HS[2].open=true;if(u.k==='bot'&&!G.bot){hireBot();toast('Clunk rolls in. He’ll carry strays over to their friends. Mostly.')}handKey='';sChime();save();showShop()})}
function showMenu(){ov(`<h2>Stockroom</h2><p>Rush ${G.rounds+1} · ★ ${G.stars} to spend · ★ ${G.life} earned in all · ${G.served} customers served</p>
 <div class="row" style="justify-content:flex-start"><button id="mH">How to play</button><button id="mS">Sound: ${SND?'on':'off'}</button><button id="mB">Big view: ${BIGV?'on':'off'}</button>${G.phase==='down'?'<button id="mU">Upgrades</button>':''}${CO?'<button id="mT">Street</button>':'<button id="mN">New stockroom</button>'}</div>
 <div class="row"><button class="big" id="mX">Back</button></div>`);
 $('#mX').onclick=closeOv;$('#mH').onclick=()=>{ov(HELP+`<div class="row"><button class="big" id="hX">Back</button></div>`);$('#hX').onclick=closeOv};
 $('#mS').onclick=()=>{SND=!SND;try{localStorage.setItem('stockroom.snd',SND?'1':'0')}catch(e){}showMenu()};
 $('#mB').onclick=()=>{BIGV=!BIGV;try{localStorage.setItem('stockroom.big',BIGV?'1':'0')}catch(e){}applyBig();toast(BIGV?'Big view on. Press and hold an order to see it up close':'Big view off');showMenu()};
 if($('#mU'))$('#mU').onclick=showShop;if($('#mT'))$('#mT').onclick=()=>CO.showStreet();
 if($('#mN'))$('#mN').onclick=()=>{ov(`<h2>Start over?</h2><p>This clears your stockroom, stars and upgrades.</p><div class="row"><button id="nN">Keep going</button><button class="big" id="nY">Start over</button></div>`);
  $('#nN').onclick=closeOv;$('#nY').onclick=()=>{try{localStorage.removeItem(KEY)}catch(e){}closeOv();newGame()}}}

// ---------- drawing ----------
function drawPerson(x,y,c,shake){let[sx,sy]=w2s(x,y);sx+=Math.sin(shake*60)*S*0.12*(shake>0?1:0);const r=S*0.3;
 ctx.fillStyle=c.shirt;ctx.beginPath();ctx.ellipse(sx,sy+r*1.25,r*1.25,r*0.75,0,Math.PI,0);ctx.fill();
 ctx.fillStyle=c.face;ctx.beginPath();ctx.arc(sx,sy,r,0,7);ctx.fill();
 ctx.fillStyle='#2a2a30';ctx.beginPath();ctx.arc(sx-r*0.35,sy-r*0.05,r*0.12,0,7);ctx.arc(sx+r*0.35,sy-r*0.05,r*0.12,0,7);ctx.fill();
 ctx.strokeStyle='#2a2a30';ctx.lineWidth=r*0.1;ctx.beginPath();
 if(shake>0||(G.phase==='rush'&&c.t>c.t3*2)){ctx.moveTo(sx-r*0.3,sy+r*0.45);ctx.lineTo(sx+r*0.3,sy+r*0.45)}else ctx.arc(sx,sy+r*0.2,r*0.32,0.3,Math.PI-0.3);ctx.stroke()}
function star(cx,cy,r,on){ctx.fillStyle=on?'#ffd23f':'rgba(255,255,255,.18)';ctx.beginPath();for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,rr2=i%2?r*0.45:r;ctx.lineTo(cx+rr2*Math.cos(a),cy+rr2*Math.sin(a))}ctx.closePath();ctx.fill()}
function drawStructure(){
 // closed storerooms: dark, boarded up, labelled
 for(const pc of PIECES)if(pc.room&&!pieceDone(pc.id)){const R=pc.room,r=wr(R.x0,R.y0,R.x1-R.x0,R.y1-R.y0);
  ctx.fillStyle='#17191f';ctx.fillRect(r[0],r[1],r[2],r[3]);ctx.save();ctx.beginPath();ctx.rect(r[0],r[1],r[2],r[3]);ctx.clip();
  ctx.strokeStyle='rgba(120,96,70,.35)';ctx.lineWidth=Math.max(3,S*0.28);ctx.beginPath();for(let t=-r[3];t<r[2]+r[3];t+=S*1.4){ctx.moveTo(r[0]+t,r[1]);ctx.lineTo(r[0]+t-r[3]*0.6,r[1]+r[3])}ctx.stroke();ctx.restore();
  const[lx,ly]=w2s((R.x0+R.x1)/2,(R.y0+R.y1)/2);ctx.fillStyle='rgba(243,239,230,.55)';ctx.font=`700 ${Math.round(S*0.42)}px system-ui`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('Old storeroom',lx,ly)}
 for(let k=0;k<N;k++){const c=CELL[k];if(c!==1&&c!==2)continue;const x=k%W,y=(k/W)|0;
  if(c===1){const pc=pieceAt(x,y);if(pc&&!(pc.need||[]).every(pieceDone))continue;fr(x+0.04,y+0.04,0.92,0.92,'#4a5163');fr(x+0.04,y+0.04,0.92,0.16,'#5b6376');continue}
  const r=wr(x,y,1,1);ctx.fillStyle='#454a59';ctx.fillRect(r[0],r[1],r[2],r[3]);ctx.strokeStyle='rgba(20,22,28,.45)';ctx.lineWidth=Math.max(1,S*0.04);ctx.beginPath();
  for(const t of[1/3,2/3]){const a=w2s(x,y+t),b=w2s(x+1,y+t);ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1])}
  for(const[t,y0,y1]of[[0.5,0,1/3],[0.2,1/3,2/3],[0.8,1/3,2/3],[0.5,2/3,1]]){const a=w2s(x+t,y+y0),b=w2s(x+t,y+y1);ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1])}ctx.stroke()}}
function drawDemo(){if(!demoMode)return;const pulse=0.5+0.5*Math.sin(performance.now()/140);
 {ctx.strokeStyle='rgba(255,159,67,.9)';ctx.setLineDash([6,4]);ctx.lineWidth=2;const r=wr(0,0,openW(),H);ctx.strokeRect(r[0]+2,r[1]+2,r[2]-4,r[3]-4);ctx.setLineDash([])}
 for(const pc of PIECES){if(!pieceOpen(pc))continue;const sel=demoSel===pc.id,can=G.stars>=pc.cost;
  for(const[x,y]of pc.cells){const r=wr(x+0.05,y+0.05,0.9,0.9);if(sel){ctx.fillStyle=`rgba(255,159,67,${0.25+0.35*pulse})`;ctx.fillRect(r[0],r[1],r[2],r[3])}
   ctx.strokeStyle=sel?'#ffd7a8':'rgba(255,159,67,.85)';ctx.lineWidth=2;ctx.setLineDash([4,3]);ctx.strokeRect(r[0],r[1],r[2],r[3]);ctx.setLineDash([])}
  const m=pc.cells[(pc.cells.length/2)|0],[tx,ty]=w2s(m[0]+0.5,m[1]+0.5),txt=`🔨 ${pc.cost}★`;ctx.font=`800 ${Math.round(S*0.34)}px system-ui`;const tw=ctx.measureText(txt).width+S*0.3,th=S*0.5;
  ctx.fillStyle=sel?'#ff9f43':'rgba(20,22,28,.92)';rr(ctx,tx-tw/2,ty-th/2,tw,th,th/2);ctx.fill();ctx.strokeStyle='#ff9f43';ctx.lineWidth=1.5;ctx.stroke();
  ctx.fillStyle=sel?'#1d1f24':can?'#ffd7a8':'#ff8a8a';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(txt,tx,ty+1)}}
function drawBot(){const b=G.bot;if(!botLv())return;const[sx,sy]=w2s(b.x,b.y);const r=S*0.46,moving=B.mode==='fetch'||B.mode==='carry'||B.mode==='park';
 const tilt=Math.sin(B.wob*9)*(moving?0.07:0.02)+(B.bump>0?Math.sin(B.bump*22)*0.4*B.bump:0),hop=moving?Math.abs(Math.sin(B.wob*9))*r*0.08:0;
 ctx.save();ctx.translate(sx,sy-hop);ctx.rotate(tilt);ctx.globalAlpha=b.on?1:0.7;
 ctx.fillStyle='rgba(0,0,0,.28)';ctx.beginPath();ctx.ellipse(0,r*0.98+hop,r*0.95,r*0.26,0,0,7);ctx.fill();
 ctx.fillStyle='#2b2d33';rr(ctx,-r*0.86,r*0.42,r*0.52,r*0.5,r*0.16);ctx.fill();rr(ctx,r*0.34,r*0.42,r*0.52,r*0.5,r*0.16);ctx.fill();
 ctx.fillStyle='#b85f26';rr(ctx,-r*0.8,-r*0.28,r*1.6,r*0.92,r*0.22);ctx.fill();ctx.fillStyle='#ef8a3c';rr(ctx,-r*0.8,-r*0.34,r*1.6,r*0.82,r*0.22);ctx.fill();
 ctx.fillStyle='rgba(255,255,255,.22)';rr(ctx,-r*0.6,-r*0.26,r*1.2,r*0.14,r*0.07);ctx.fill();
 ctx.fillStyle='#3b3f4a';ctx.beginPath();ctx.arc(-r*0.42,r*0.12,r*0.1,0,7);ctx.arc(r*0.42,r*0.12,r*0.1,0,7);ctx.fill();
 ctx.strokeStyle='#d8dde6';ctx.lineWidth=Math.max(1.5,r*0.09);ctx.lineCap='round';ctx.beginPath();ctx.moveTo(r*0.1,-r*1.12);ctx.lineTo(r*0.3,-r*1.5);ctx.stroke();
 ctx.fillStyle=b.on&&B.mode!=='nap'&&Math.sin(B.wob*5)>0?'#ffd23f':'#6b6450';ctx.beginPath();ctx.arc(r*0.3,-r*1.52,r*0.12,0,7);ctx.fill();
 ctx.fillStyle='#d8dde6';rr(ctx,-r*0.62,-r*1.16,r*1.24,r*0.78,r*0.26);ctx.fill();ctx.fillStyle='#1c2430';rr(ctx,-r*0.5,-r*1.06,r*1.0,r*0.56,r*0.18);ctx.fill();
 ctx.fillStyle=ctx.strokeStyle='#7fe3ff';ctx.lineWidth=Math.max(1.2,r*0.08);
 if(B.mode==='nap'||!b.on||B.blink>0){ctx.beginPath();ctx.moveTo(-r*0.32,-r*0.78);ctx.lineTo(-r*0.12,-r*0.78);ctx.moveTo(r*0.12,-r*0.78);ctx.lineTo(r*0.32,-r*0.78);ctx.stroke()}
 else if(B.bump>0){ctx.font=`800 ${Math.round(r*0.4)}px system-ui`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('× ×',0,-r*0.78)}
 else{ctx.beginPath();ctx.arc(-r*0.22,-r*0.8,r*0.09,0,7);ctx.arc(r*0.22,-r*0.8,r*0.09,0,7);ctx.fill()}
 ctx.restore();
 if(b.carry.length){const z=S*0.72,img=tileImg(b.carry[0],z*DPR);const ty=sy-hop-r*1.1-z;ctx.drawImage(img,sx-z/2+tilt*z,ty,z,z);
  if(b.carry.length>1){const br=Math.max(6,S*0.16);ctx.fillStyle='#14161c';ctx.beginPath();ctx.arc(sx+z*0.42,ty+z*0.15,br,0,7);ctx.fill();ctx.fillStyle='#fff';ctx.font=`800 ${Math.round(br*1.2)}px system-ui`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(String(b.carry.length),sx+z*0.42,ty+z*0.15+0.5)}}
 if(B.mode==='nap'){const t=performance.now()/600;ctx.fillStyle='rgba(200,220,255,.8)';ctx.font=`800 ${Math.round(S*0.3)}px system-ui`;ctx.textAlign='center';ctx.fillText('z',sx+r*0.8,sy-r*1.4-(t%1)*S*0.3);ctx.fillText('z',sx+r*1.1,sy-r*1.8-((t+0.5)%1)*S*0.3)}}
// the cold case: frosted glass, a faint line behind its front row, a glass front on the wall, ❄ in the corner
function drawZones(){
 fr(CASE.x0,CASE.y0,CASE.x1-CASE.x0,CASE.y1-CASE.y0,'rgba(120,190,255,.13)');
 const r=wr(CASE.x0+0.04,CASE.y0+0.04,CASE.x1-CASE.x0-0.08,CASE.y1-CASE.y0-0.08);ctx.strokeStyle='rgba(150,220,255,.8)';ctx.lineWidth=Math.max(2,S*0.07);ctx.strokeRect(r[0],r[1],r[2],r[3]);
 const m=w2s(0.1,H-1),n=w2s(CASE.x1-0.1,H-1);ctx.strokeStyle='rgba(150,220,255,.25)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(m[0],m[1]);ctx.lineTo(n[0],n[1]);ctx.stroke();
 const g1=w2s(0,H-0.03),g2=w2s(CASE.x1,H-0.03);ctx.strokeStyle='rgba(190,245,255,.9)';ctx.lineWidth=Math.max(3,S*0.1);ctx.beginPath();ctx.moveTo(g1[0],g1[1]);ctx.lineTo(g2[0],g2[1]);ctx.stroke();
 const[sx,sy]=w2s(CASE.x1-0.2,CASE.y0+0.22);ctx.fillStyle='rgba(190,230,255,.85)';ctx.font=`${Math.round(S*0.34)}px system-ui`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('❄',sx,sy)}
// a small ❄ on fresh things outside the cold case: they belong in it
function drawCold(r){const z=Math.max(9,S*0.3);ctx.fillStyle='rgba(20,22,28,.75)';ctx.beginPath();ctx.arc(r[0]+r[2]*0.16,r[1]+r[3]*0.17,z*0.62,0,7);ctx.fill();
 ctx.fillStyle='#bfe6ff';ctx.font=`${Math.round(z)}px system-ui`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('❄',r[0]+r[2]*0.16,r[1]+r[3]*0.17+0.5)}
function draw(){ctx.setTransform(DPR,0,0,DPR,0,0);ctx.fillStyle='#14161c';ctx.fillRect(0,0,VW,VH);
 fr(-1.3,H+1,W+2.6,1.5,'#1d2029');
 fr(-1,-1,W+2,H+2,'#3d4352');fr(-1,-1,W+2,0.12,'#4d5466');
 fr(0,0,W,H,'#2a2f3b');
 ctx.strokeStyle='rgba(255,255,255,.05)';ctx.lineWidth=1;ctx.beginPath();
 for(let x=1;x<W;x++){const a=w2s(x,0),b=w2s(x,H);ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1])}
 for(let y=1;y<H;y++){const a=w2s(0,y),b=w2s(W,y);ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1])}ctx.stroke();
 drawZones();
 fr(BAY.x0,BAY.y0,BAY.x1-BAY.x0,BAY.y1-BAY.y0,'rgba(255,210,63,.07)');
 {const r=wr(BAY.x0+0.06,BAY.y0+0.06,BAY.x1-BAY.x0-0.12,BAY.y1-BAY.y0-0.12);ctx.strokeStyle='rgba(255,210,63,.7)';ctx.lineWidth=Math.max(2,S*0.07);ctx.setLineDash([S*0.35,S*0.25]);ctx.strokeRect(r[0],r[1],r[2],r[3]);ctx.setLineDash([])}
 {const op=Math.max(0,doorAnim);fr(DOOR[0],-1,DOOR[1]-DOOR[0],1,op>0?mix('#5a6276',op*0.6,255):'#555d70');
  ctx.strokeStyle='rgba(0,0,0,.25)';ctx.lineWidth=1;ctx.beginPath();for(let k=1;k<5;k++){const a=w2s(DOOR[0],-1+k/5),b=w2s(DOOR[1],-1+k/5);ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1])}ctx.stroke()}
 drawStructure();
 HX.forEach((x,i)=>{const hs=HS[i];
  fr(x+0.06,H+0.06,0.88,0.88,hs.open?'#56627d':'#2e333f');
  if(i===CASE_H){const r=wr(x+0.03,H+0.03,0.94,0.94);ctx.strokeStyle='rgba(150,230,240,.9)';ctx.lineWidth=Math.max(2,S*0.07);ctx.strokeRect(r[0],r[1],r[2],r[3])}
  if(!hs.open){ctx.strokeStyle='#454b59';ctx.lineWidth=2;ctx.beginPath();for(let k=1;k<6;k++){const a=w2s(x+0.06,H+k/6),b=w2s(x+0.94,H+k/6);ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1])}ctx.stroke()}
  else if(hs.cust)drawPerson(x+0.5,H+0.55,hs.cust,hs.shake);
  fr(x-0.05,H-0.04,1.1,0.12,'#9aa1b0');
  const[bx,by]=w2s(x+0.5,H+1.6);ctx.fillStyle=hs.open?'#ffd23f':'#454b59';ctx.beginPath();ctx.arc(bx,by,S*0.26,0,7);ctx.fill();
  ctx.fillStyle='#1d1f24';ctx.font=`800 ${Math.round(S*0.34)}px system-ui`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(String(i+1),bx,by+1);
  if(hs.cust){const rt=rating(hs.cust);for(let k=0;k<3;k++){const[qx,qy]=w2s(x+1.15+k*0.42,H+1.6);star(qx,qy,S*0.17,k<rt)}}});
 const px=S*DPR;
 // racks
 for(let k=0;k<N;k++)if(G.rack[k]){const x=k%W,y=(k/W)|0;const r=wr(x+0.02,y+0.02,0.96,0.96);ctx.fillStyle='#4a3b2c';ctx.fillRect(r[0],r[1],r[2],r[3]);
  ctx.strokeStyle='#9c7a52';ctx.lineWidth=Math.max(1.5,S*0.06);ctx.strokeRect(r[0]+1,r[1]+1,r[2]-2,r[3]-2);
  ctx.beginPath();ctx.moveTo(r[0],r[1]+r[3]*0.5);ctx.lineTo(r[0]+r[2],r[1]+r[3]*0.5);ctx.stroke()}
 // bin
 {const bx=BIN%W,by=(BIN/W)|0;const[cx0,cy0]=w2s(bx+0.5,by+0.5);const b=S*0.62;ctx.fillStyle='#596273';rr(ctx,cx0-b*0.4,cy0-b*0.3,b*0.8,b*0.75,b*0.12);ctx.fill();
  ctx.fillStyle='#7a8496';rr(ctx,cx0-b*0.5,cy0-b*0.45,b,b*0.16,b*0.06);ctx.fill();ctx.strokeStyle='#3d4352';ctx.lineWidth=Math.max(1,S*0.04);
  for(const o of[-0.18,0,0.18]){ctx.beginPath();ctx.moveTo(cx0+o*b,cy0-b*0.15);ctx.lineTo(cx0+o*b,cy0+b*0.35);ctx.stroke()}}
 for(const m of G.mach){const x=m.k%W,y=(m.k/W)|0;const r=wr(x+0.04,y+0.04,0.92,0.92);const M=MACH[m.type];
  ctx.fillStyle=mix(M.col,0.4);rr(ctx,r[0],r[1]+r[3]*0.06,r[2],r[3]*0.94,r[2]*0.18);ctx.fill();ctx.fillStyle=M.col;rr(ctx,r[0],r[1],r[2],r[3]*0.9,r[2]*0.18);ctx.fill();
  const cx=r[0]+r[2]/2,cy=r[1]+r[3]*0.45,u=r[2]*0.26;ctx.strokeStyle='rgba(255,255,255,.85)';ctx.fillStyle='rgba(255,255,255,.85)';ctx.lineWidth=Math.max(1.5,S*0.05);
  if(m.type==='vsplit'||m.type==='hsplit'){ctx.strokeRect(cx-u,cy-u,2*u,2*u);ctx.setLineDash([3,2]);ctx.beginPath();if(m.type==='vsplit'){ctx.moveTo(cx,cy-u-3);ctx.lineTo(cx,cy+u+3)}else{ctx.moveTo(cx-u-3,cy);ctx.lineTo(cx+u+3,cy)}ctx.stroke();ctx.setLineDash([])}
  else if(m.type==='dback'||m.type==='dfwd'){ctx.strokeRect(cx-u,cy-u,2*u,2*u);ctx.setLineDash([3,2]);ctx.beginPath();if(m.type==='dback'){ctx.moveTo(cx-u-2,cy-u-2);ctx.lineTo(cx+u+2,cy+u+2)}else{ctx.moveTo(cx-u-2,cy+u+2);ctx.lineTo(cx+u+2,cy-u-2)}ctx.stroke();ctx.setLineDash([])}
  else if(m.type==='comb'){ctx.strokeRect(cx-u,cy-u,u*0.85,2*u);ctx.strokeRect(cx+u*0.15,cy-u,u*0.85,2*u);ctx.font=`800 ${Math.round(u*1.1)}px system-ui`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('+',cx,cy+u*1.45)}
  else if(m.type==='recyc'){ctx.font=`800 ${Math.round(u*2)}px system-ui`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('♻',cx,cy+u*0.15)}
  else if(m.type==='rot'){ctx.beginPath();ctx.arc(cx,cy,u*0.85,-Math.PI*0.4,Math.PI*1.25);ctx.stroke();const ex=cx+u*0.85*Math.cos(Math.PI*1.25),ey=cy+u*0.85*Math.sin(Math.PI*1.25);ctx.beginPath();ctx.moveTo(ex-u*0.35,ey-u*0.05);ctx.lineTo(ex+u*0.05,ey-u*0.45);ctx.lineTo(ex+u*0.3,ey+u*0.05);ctx.closePath();ctx.fill()}
  else if(m.type==='strip'){ctx.strokeRect(cx-u,cy-u,2*u,2*u);ctx.fillRect(cx-u,cy-u,u,2*u);ctx.beginPath();ctx.moveTo(cx+u*0.3,cy+u*1.25);ctx.lineTo(cx+u*1.1,cy+u*1.25);ctx.stroke()}
  else{ctx.fillStyle='#ff6b6b';ctx.beginPath();ctx.arc(cx-u*0.45,cy,u*0.55,0,7);ctx.fill();ctx.fillStyle='#5b8cff';ctx.beginPath();ctx.arc(cx+u*0.45,cy,u*0.55,0,7);ctx.fill();ctx.fillStyle='rgba(255,255,255,.9)';ctx.font=`800 ${Math.round(u*0.9)}px system-ui`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('⇄',cx,cy+u*1.35)}
  m.inp.forEach((id,i)=>{const z=r[2]*0.36;ctx.drawImage(tileImg(id,z*DPR),r[0]+i*z*0.8-z*0.15,r[1]-z*0.25,z,z)});
  if(m.t>0){ctx.strokeStyle='#ffd23f';ctx.lineWidth=3;ctx.beginPath();ctx.arc(r[0]+r[2]/2,r[1]+r[3]/2,r[2]*0.56,-Math.PI/2,-Math.PI/2+2*Math.PI*(1-m.t/(m.T||1)));ctx.stroke()}}
 for(let y=0;y<H;y++)for(let x=0;x<W;x++){const k=ix(x,y),v=G.items[k];if(v===-1||v===-3)continue;let r=wr(x,y,1,1);
  if(r[0]>VW||r[1]>VH||r[0]+r[2]<0||r[1]+r[3]<0)continue;
  const pt=POP.get(k);if(pt!=null){if(pt<0)continue;const sc=0.55+0.45*Math.min(1,pt/0.16)+Math.sin(Math.min(1,pt/0.25)*Math.PI)*0.08;const cxp=r[0]+r[2]/2,cyp=r[1]+r[3]/2;r=[cxp-r[2]*sc/2,cyp-r[3]*sc/2,r[2]*sc,r[3]*sc]}
  const img=tileImg(v,px),n=G.cnt[k];
  if(n>2){ctx.globalAlpha=0.55;ctx.drawImage(img,r[0]-r[2]*0.1,r[1]-r[3]*0.14,r[2]*0.92,r[3]*0.92);ctx.globalAlpha=1}
  if(n>1){ctx.globalAlpha=0.8;ctx.drawImage(img,r[0]-r[2]*0.05,r[1]-r[3]*0.07,r[2]*0.96,r[3]*0.96);ctx.globalAlpha=1}
  ctx.drawImage(img,r[0]+(n>1?r[2]*0.04:0),r[1]+(n>1?r[3]*0.04:0),r[2]*(n>1?0.96:1),r[3]*(n>1?0.96:1));
  if(n>1){const bx=r[0]+r[2]*0.82,by=r[1]+r[3]*0.8,br=Math.max(7,S*0.2);ctx.fillStyle=n>=capAt(k)?'#ffd23f':'#14161c';ctx.beginPath();ctx.arc(bx,by,br,0,7);ctx.fill();
   ctx.fillStyle=n>=capAt(k)?'#14161c':'#fff';ctx.font=`800 ${Math.round(br*1.25)}px system-ui`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(String(n),bx,by+0.5)}
  if(v>=0&&!CASEM[k]&&isFresh(v))drawCold(r)}
 for(let k=0;k<N;k++)if(G.rack[k]&&G.items[k]!==-1){const r=wr(k%W+0.03,((k/W)|0)+0.03,0.94,0.94);ctx.strokeStyle='#c59a62';ctx.lineWidth=Math.max(2,S*0.07);ctx.strokeRect(r[0],r[1],r[2],r[3])}
 drawBot();drawDemo();
 for(const d of DUST){const[dx,dy]=w2s(d.x,d.y);ctx.globalAlpha=Math.max(0,0.7*(1-d.t/1.1));ctx.fillStyle='#c9c2b4';ctx.beginPath();ctx.arc(dx,dy,d.r*S*(1+d.t),0,7);ctx.fill()}ctx.globalAlpha=1;
 // hold-to-stack progress
 if(gest&&gest.type==='maybe'&&!rackMode&&!machMode){const el=performance.now()-gest.t;if(el>110){const[wx,wy]=s2w(gest.sx,gest.sy);const cx=Math.floor(wx),cy=Math.floor(wy);
  if(inF(cx,cy)&&G.items[ix(cx,cy)]!==-1&&G.hand.length&&G.hand[0]===G.items[ix(cx,cy)]){const[sx,sy]=w2s(cx+0.5,cy+0.5);ctx.strokeStyle='#7bd88f';ctx.lineWidth=4;ctx.beginPath();ctx.arc(sx,sy,S*0.62,-Math.PI/2,-Math.PI/2+2*Math.PI*Math.min(1,(el-110)/(HOLD-110)));ctx.stroke()}}}
 if(machMode){ctx.strokeStyle='rgba(150,170,255,.9)';ctx.setLineDash([6,4]);ctx.lineWidth=2;const r=wr(0,0,openW(),H);ctx.strokeRect(r[0]+2,r[1]+2,r[2]-4,r[3]-4);ctx.setLineDash([])}
 if(rackMode){ctx.strokeStyle='rgba(156,122,82,.9)';ctx.setLineDash([6,4]);ctx.lineWidth=2;const r=wr(0,0,openW(),H);ctx.strokeRect(r[0]+2,r[1]+2,r[2]-4,r[3]-4);ctx.setLineDash([])}
 if(FIND){const a=0.5+0.5*Math.sin(performance.now()/120);ctx.strokeStyle=`rgba(255,255,255,${0.5+0.5*a})`;ctx.lineWidth=3;
  for(let k=0;k<N;k++)if(G.items[k]===FIND.p){const r=wr(k%W-0.08,((k/W)|0)-0.08,1.16,1.16);ctx.strokeRect(r[0],r[1],r[2],r[3])}}
 for(const f of FLY){const[tx,ty]=handSlot(f.slot);const u=Math.min(1,f.t/0.22),e=1-(1-u)*(1-u);const sz=S*(1-0.3*e);
  ctx.drawImage(tileImg(f.p,S*DPR),f.x0+(tx-f.x0)*e-sz/2,f.y0+(ty-f.y0)*e-sz/2-Math.sin(u*Math.PI)*S*0.6,sz,sz)}
 for(const f of FL){const[sx,sy0]=w2s(f.x,f.y);const sy=sy0-f.t*S*0.9;ctx.globalAlpha=Math.max(0,1-f.t/1.4);ctx.fillStyle=f.c;ctx.font=`800 ${Math.round(S*0.5)}px system-ui`;ctx.textAlign='center';ctx.textBaseline='middle';
  ctx.strokeStyle='rgba(0,0,0,.6)';ctx.lineWidth=3;ctx.strokeText(f.txt,sx,sy);ctx.fillText(f.txt,sx,sy);ctx.globalAlpha=1}}

// ---------- loop ----------
function update(dt){
 for(const[k,t]of POP){const n=t+dt;if(n>0.3)POP.delete(k);else POP.set(k,n)}
 for(const f of FLY)f.t+=dt;FLY=FLY.filter(f=>f.t<0.22);
 for(const d of DUST){d.t+=dt;d.x+=d.vx*dt;d.y+=d.vy*dt;d.vx*=0.93;d.vy*=0.93}DUST=DUST.filter(d=>d.t<1.1);
 if(shakeT>0)shakeT-=dt;for(const h of HS)if(h.shake>0)h.shake=Math.max(0,h.shake-dt);
 if(ovOpen()&&!CO)return; // co-op never pauses: the street's clock keeps running
 if(CO&&(G.phase==='stock'||G.phase==='rush')){const e=CO.endAt(G.phase,G.rounds);if(e)G.phaseT=Math.max(0,(e-CO.now())/1000);else if(G.phase==='stock')G.phaseT=Infinity}
 if(G.phase==='stock'){if(isFinite(G.phaseT)&&!CO){G.phaseT-=dt;if(G.phaseT<=0)startRush(false)}}
 else if(G.phase==='rush')stepRush(dt);
 stepMachines(dt);
 stepBot(dt);
 if(demoSelT>0){demoSelT-=dt;if(demoSelT<=0)demoSel=null}
 if(FIND){FIND.t-=dt;if(FIND.t<=0)FIND=null}
 for(const f of FL)f.t+=dt;FL=FL.filter(f=>f.t<1.4);
 if(doorAnim>0)doorAnim-=dt*0.4;
 saveT+=dt;if(saveT>4&&(G.phase==='stock'||G.phase==='down')){saveT=0;save()}}
let last=performance.now();
function frame(t){const dt=Math.min(0.05,(t-last)/1000);last=t;
 if(gest&&gest.type==='maybe'&&performance.now()-gest.t>=HOLD){gest.type='held';const[wx,wy]=s2w(gest.sx,gest.sy);hold(wx,wy)}update(dt);camUpdate(dt);hud();draw();requestAnimationFrame(frame)}
function newGame(){fresh();if(CO)G.seed=CO.seed;rebuildMap();makeCat(G.seed);makeHS();B.mode='idle';B.path=[];demoMode=false;deliver();G.phase='stock';G.phaseT=Infinity;ordersDirty=true;handKey='';actKey='';save();showHelp()}
function init(){layout();
 if(load()){makeCat(G.seed);rebuildMap();makeHS();
  if(G.phase==='rush'){G.phase='stock';G.phaseT=5}
  if(G.help)showHelp();else if(G.phase==='sum'&&!G.wait)showSummary();else if(G.phase==='order'&&!G.wait)showOrder()}
 else newGame();
 applyBig();camX=(BAY.x0+BAY.x1)/2;camY=(BAY.y0+BAY.y1)/2+2;POP.clear();requestAnimationFrame(frame)}
addEventListener('resize',layout);
document.addEventListener('visibilitychange',()=>{if(document.hidden&&G&&(G.phase==='stock'||G.phase==='down'))save()});
window.__wh={get G(){return G},get HS(){return HS},tap,tick:(n=60,dt=1/60)=>{for(let i=0;i<n;i++)update(dt)},
 startRush,endRush,recycleFeed,refurbId,refurbAvail,isBlankWhole,dec,halfId,wholeId,compId,rotateId,nextDelivery,openOrder,placeOrder,forecast,suggestOrder,bestOrder,supplierView,addAt,binTap,placeRack,surprise,hold,setRackMode:v=>{rackMode=v},stockCounts,save,w2s,s2w,closeOv,ovOpen,serveAt,cat:()=>CAT,isFresh,runMachine,paintItem,genCustom,checkUnlocks,showShop,knockDown,demoTap,PIECES,pieceAt,hireBot,botPlan,clusters,B,CELL,SOLID,rebuildMap,setDemo:v=>{demoMode=v},customPrice,newCust,recycleCredit,showMag,hideMag,setBig:v=>{BIGV=!!v;applyBig()},iconURL,genFlower,makeBouquet,serveBq,invId,isFlower,colouredFlower,flowerPrice,fBlanks,dyeLines,dyeW,rollSupply,FLOWERS,showRecycle,takeRecycled,accepts,
 caseShown,newCust,priceItem,landDelivery,runLen,putAt,pickAt,CASE,CASEM,CASEK,capAt,knownProds};
// What the street adapter may do to this warehouse: read where it is, and move it on when the street does.
if(CO)CO.attach({
 info:()=>({ph:G.phase,d:G.rounds,w:!!G.wait,put:G.pend?Math.min(110,30+2*G.pend.length):0,rl:rushLen()}),
 land(){if(G.phase!=='order')return;const l=G.pend||[],c=G.pendC||0;G.pend=null;G.pendC=0;G.wait=false;G.ord={};landDelivery(l,c)},
 rush(b,L){if(G.phase==='stock')startRush(false,b,L)},
 end(){if(G.phase==='rush')endRush(false)},
 toDown(){G.wait=false;G.phase='down';G.phaseT=Infinity;actKey='';save();showShop()},
 toOrder(){G.wait=false;actKey='';openOrder()},
 ov,closeOv,ovOpen,toast,save:()=>save()});
init();
})();
