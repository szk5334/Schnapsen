# Stockroom on the website (handoff; stripped by the deploy workflow)

Stockroom is a Wilmot's Warehouse–style sorting game. Single player lives in a claude.ai artifact; co-op ("two shops,
one street") lives here, because the artifact sandbox can't reach the relay. **It ships as its own tarball,
`stockroom-site.tar.gz`, beside `schnapsen-site.tar.gz`** (Seth, Nov 26: "Keep stockroom in a separate tar ball from
schnapsen"). The deploy workflow unpacks every tarball, so nothing else changes.

## Files

```
stockroom.html          the page: the artifact's markup + styles, then config.js and stockroom/coop.js
stockroom/coop.js       the street: the street door (open / join by code / play alone), presence, the shared clock
stockroom/game.js       the game, cut from the artifact's index.html by tools/build_pages.py (never edit here)
stockroom/tools/        build_pages.py (artifact index.html → these files); coop_hooks.py, v8_fresh_case.py,
                        v81_recycle.py, v82_reserve.py, v9_flowers.py, v92_bigview.py (one-off patches: how v7.4 to v9.2 were made)
stockroom/tests/        sr16_street.py (two players), sr17_solo.py (single player), sr18_case.py (case, cooler,
                        freshness), sr19_soak.py (12 rounds with Clunk), sr20_recycle.py, sr21_reserve.py,
                        sr22_flowers.py (flowers, dyes, stripper, inverses, bouquets),
                        sr23_bigview.py (Big view, hold-to-magnify)
```

**Shared with Schnapsen at runtime, not copied:** `app/net/relay.js`, `app/net/local.js`, `app/net/mesh.js`,
`app/util.js`, `app/ident.js`, `vendor/nostr.js`, and `config.js`. They come from the Schnapsen tarball, so the two
tarballs never overwrite each other's files. If the mesh API (`openMesh`, `people`, `setPresence`, `peerOf`) ever
changes there, Stockroom follows.

## Rooms and keys
- Rooms are prefixed `stock-`: one room per street, `stock-street-CODE`. Same relays and Nostr kinds as Schnapsen
  (24747/24748); the prefix is the "game tag" (Seth, Nov 26: reuse the kinds with a tag). No lobby room: codes only.
- Identity is shared with Schnapsen (`sx.cid`, `sx.name`). Stockroom's keys: `sr.session` {code}, `sr.st.CODE` (the
  street), and the warehouse save `stockroom.v6.[as.NAME.]street.CODE.SEED`. Playing alone uses the artifact's own
  key, `stockroom.v6`.

## The street (co-op step 1)
- **Street state** `st = {code, owner, seed, seats[≤2], status open|on, d, ph, end, bonus, n}` rides in every seated
  phone's presence; the highest `n` wins. Before the start only the opener changes it (seats whoever comes with the
  code, up to two). **The first seated person who is here moves it on** (after 4 s of listening, 8 s if someone
  seated hasn't been heard).
- **Each phone reports** `sr = {p, w, o, put, rl}` in its presence: position `p = d*10 + {sum 0, down 1, order 2,
  stock 3, rush 4}` (d = rushes done = `G.rounds`), waiting at a barrier, asked to open the hatches, put-away seconds
  for its order, its rush length.
- **Rules:** order → stock when every shop has ordered (put-away = the longest, at least 30 s); stock → rush when
  anyone opens the hatches or put-away runs out (early bonus = whole 15 s left, the same for everyone, paid once per
  rush even across reloads: `G.bd`); rush → summary when the clock runs out or every shop has served everyone
  (rush length = the longest anyone has); summary → order (or day off after every 3rd rush) when everyone has pressed
  on; day off → order when everyone has pressed Order stock.
- **Who counts:** seated people who are here, or were here within the last 60 s (with what they last reported), so a
  reload never costs anyone their order or their rush. After that the street carries on without them; when they
  come back, their warehouse steps forward to the street's position (missed rushes end empty, missed orders land
  empty).
- **Catch-up** (`reconcile`): one step per tick (250 ms) until the warehouse's position reaches the street's.
- **Deadlines** are wall-clock ms from the phone moving the street on; phones keep clocks within a second.
- **Traffic:** presence changes only at phase changes. A five-rush test session over local relays: about 100–160
  events on the house relay, ~10 spare copies on the public ones.

## Game hooks (in the artifact's index.html since v7.4; inert without `window.SR_COOP`)
`CO = window.SR_COOP`: save `KEY`, street `seed` for new games, `openHatches()`, `opening()`, `endAt(ph, d)`,
`now()`, `showStreet()`, `attach(api)`. The game hands back `info, land, rush, end, toDown, toOrder, ov, closeOv,
ovOpen, toast, save`. In co-op: ordering parks the order (`G.pend`, `G.wait`) until the street lands it; summary
and day off wait (`G.wait`); the clock never pauses for overlays; no sheep; the menu has Street instead of New
stockroom.

## v8 – v9 game (Nov 27): the Display Case, the Cooler, freshness, recycling, flowers, the colour stripper
The game file is the artifact's v9.2 (Big view in ☰, saved per phone as `stockroom.big`; press and hold an order card
to magnify it) (save `v:6`, key `stockroom.v6`; co-op saves `stockroom.v6.…`). Flowers (blank
flowers, dye tiles and their trend, flower customers, bouquet orders, the case's flower section), the colour stripper
and inverses work the same on the street as alone (Seth, Nov 27). Flower and dye markets are per shop, like the rest of
the market until shared ordering (step 4). Details in the
project doc `claude/stockroom-handoff.md`. In co-op, put-away time also counts the case: `info.put` adds 3 s for
each case spot that would need a change after the parked order lands.

## Build and test
```
# fetch the live artifact's index.html (v7.4 or later: it carries the hooks), then from the site root:
python3 stockroom/tools/build_pages.py index.html stockroom/coop.js OUT   # OUT/stockroom.html, OUT/stockroom/*.js
python3 -m http.server 8765          # from the site root (Schnapsen tarball + this one unpacked)
python3 stockroom/tests/sr16_street.py            # two tabs over ?local (BroadcastChannel)
SR_RELAY=1 python3 stockroom/tests/sr16_street.py # two browsers over local relays: needs config.js pointing at
                                     # tests/relay-server.mjs on 7815 (house) and 7816/7817 (public stand-ins)
python3 stockroom/tests/sr17_solo.py index.html   # single player on the artifact file
```
Last run (Nov 28, build 2026-11-28.1, game v9.2): see the commit message for the counts. (Nov 26: sr16 48/48 over local relays.)
Not tried: two real phones over the Cloudflare relay (it only accepts https://szk5334.github.io).

## Next (co-op build order, see the project doc claude/stockroom-coop-design.md)
3. One customer stream and the street strip. 4. Shared ordering and street reputation. 5. Alley door (west wall),
neighbour requests, work orders, the machine split. 6. Front of house. 7. Street orders, windows, awards.
