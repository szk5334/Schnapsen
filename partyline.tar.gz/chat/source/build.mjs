/* Build Party Line into ONE self-contained index.html (plus an optional service worker and manifest for
 * installing). Run from this folder:  node build.mjs   →  dist/chat/{index.html, sw.js, manifest.webmanifest} */
import { build } from "esbuild";
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { createHash } from "node:crypto";

const NM = "/home/claude/work/deps/node_modules";
const r = await build({
  entryPoints: ["src/main.js"], bundle: true, format: "iife", minify: true, target: "es2020",
  platform: "browser", write: false, legalComments: "none", nodePaths: [NM],
});
const js = r.outputFiles[0].text.replace(/<\/script/gi, "<\\/script");
const css = readFileSync("src/style.css", "utf8");
const hash = createHash("sha256").update(js + css).digest("hex").slice(0, 12);
const scriptBody = `/* build ${hash} */${js}`;
const sri = t => "'sha256-" + createHash("sha256").update(t, "utf8").digest("base64") + "'";
/* Only THIS build's script and stylesheet may run. Inline style attributes stay allowed (colours per person). */
const csp = ["default-src 'none'", `script-src ${sri(scriptBody)}`, `style-src ${sri(css)}`, "style-src-attr 'unsafe-inline'",
  "img-src data:", "connect-src wss: https://*.metered.live ws://localhost:*", "manifest-src 'self'", "worker-src 'self'", "base-uri 'none'", "form-action 'none'"].join("; ");

const icon = "data:image/svg+xml," + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#141924"/><circle cx="32" cy="32" r="11" fill="#f2a93b"/><circle cx="32" cy="32" r="19" fill="none" stroke="#f2a93b" stroke-opacity=".35" stroke-width="3"/></svg>`);

const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover, interactive-widget=resizes-content">
<meta name="theme-color" content="#141924">
<meta name="referrer" content="no-referrer">
<meta http-equiv="Content-Security-Policy" content="${csp}">
<title>Party Line</title>
<link rel="icon" href="${icon}">
<link rel="manifest" href="manifest.webmanifest">
<style>${css}</style>
</head>
<body>
<div id="app"></div>
<noscript>Party Line needs JavaScript.</noscript>
<script>${scriptBody}</script>
</body>
</html>
`;

mkdirSync("dist/chat", { recursive: true });
writeFileSync("dist/chat/index.html", html);
writeFileSync("dist/chat/manifest.webmanifest", JSON.stringify({
  name: "Party Line", short_name: "Party Line", start_url: "./", scope: "./", display: "standalone",
  background_color: "#141924", theme_color: "#141924",
  icons: [{ src: icon, sizes: "any", type: "image/svg+xml", purpose: "any" }],
}, null, 1));
/* The service worker keeps one exact build on the phone. A new build is only used after the page is
 * reloaded with the new worker installed — the version you are running never changes under you. */
writeFileSync("dist/chat/sw.js", `const V = "pl-${hash}";
self.addEventListener("install", e => e.waitUntil(caches.open(V).then(c => c.addAll(["./", "./index.html", "./manifest.webmanifest"]))));
self.addEventListener("activate", e => e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== V).map(k => caches.delete(k)))).then(() => self.clients.claim())));
self.addEventListener("fetch", e => {
  const u = new URL(e.request.url);
  if (e.request.method !== "GET" || u.origin !== location.origin) return;
  e.respondWith(caches.match(e.request, { ignoreSearch: true }).then(hit => hit || fetch(e.request)));
});
`);
console.log("built", hash, (html.length / 1024).toFixed(0) + " KB");
