/* CRYPTO — who you are, and how a channel's messages are locked.
 *
 * Identity: two P-256 key pairs per device, made on first run and kept in local storage.
 *   sign   ECDSA — every message is signed, so a name can't be impersonated
 *   box    ECDH  — private messages are sealed to this key
 * Your id is the first 16 hex of SHA-256(sign public key). Names are just labels; ids are who you are.
 *
 * Channels: a channel secret (public channels: derived from the name; private: random, carried in the
 * invite link's #fragment, never sent anywhere) is stretched with HKDF into
 *   - an AES-256-GCM key for message bodies, and
 *   - an HMAC key that turns the hour into a rotating tag, so relays see unrelated-looking tags
 *     instead of a channel name, and the tags change every hour.
 */
import { LS, enc, dec, b64, unb64, hex, concat } from "./util.js";

const S = crypto.subtle;
const ECDSA = { name: "ECDSA", namedCurve: "P-256" };
const ECDH = { name: "ECDH", namedCurve: "P-256" };

/* ------------------------------------------------------------------ identity */
let idP = null;
export function identity() {
  if (idP) return idP;
  idP = (async () => {
    let saved = LS.get("id");
    if (!saved) {
      const sk = await S.generateKey(ECDSA, true, ["sign", "verify"]);
      const bk = await S.generateKey(ECDH, true, ["deriveBits"]);
      saved = {
        signPriv: await S.exportKey("jwk", sk.privateKey), signPub: b64(await S.exportKey("raw", sk.publicKey)),
        boxPriv: await S.exportKey("jwk", bk.privateKey), boxPub: b64(await S.exportKey("raw", bk.publicKey)),
      };
      LS.set("id", saved);
    }
    const signKey = await S.importKey("jwk", saved.signPriv, ECDSA, false, ["sign"]);
    const boxKey = await S.importKey("jwk", saved.boxPriv, ECDH, false, ["deriveBits"]);
    return { id: await idOf(saved.signPub), spk: saved.signPub, bpk: saved.boxPub, signKey, boxKey };
  })();
  return idP;
}
export async function idOf(spkB64) { return hex(await S.digest("SHA-256", unb64(spkB64))).slice(0, 16); }

/* ------------------------------------------------------------------ signatures */
const canon = o => JSON.stringify(o, Object.keys(o).sort());
export async function signMsg(body) {
  const me = await identity();
  const m = { ...body, fid: me.id, spk: me.spk, bpk: me.bpk };
  const sig = await S.sign({ name: "ECDSA", hash: "SHA-256" }, me.signKey, enc.encode(canon(m)));
  return { ...m, sig: b64(sig) };
}
const verifyCache = new Map();
export async function verifyMsg(m) {
  try {
    if (!m || typeof m !== "object" || typeof m.sig !== "string" || typeof m.spk !== "string") return false;
    const { sig, ...rest } = m;
    if (await idOf(m.spk) !== m.fid) return false;
    let pk = verifyCache.get(m.spk);
    if (!pk) { pk = await S.importKey("raw", unb64(m.spk), ECDSA, false, ["verify"]); verifyCache.set(m.spk, pk); }
    return await S.verify({ name: "ECDSA", hash: "SHA-256" }, pk, unb64(sig), enc.encode(canon(rest)));
  } catch { return false; }
}

/* ------------------------------------------------------------------ channel keys */
async function hkdf(secretBytes, info, len = 32) {
  const base = await S.importKey("raw", secretBytes, "HKDF", false, ["deriveBits"]);
  return new Uint8Array(await S.deriveBits({ name: "HKDF", hash: "SHA-256", salt: enc.encode("party-line/v1"), info: enc.encode(info) }, base, len * 8));
}
const keyCache = new Map();
/* A channel's working keys from its secret. */
export async function channelKeys(secret) {
  const cacheable = typeof secret === "string";
  if (cacheable && keyCache.has(secret)) return keyCache.get(secret);
  const p = (async () => {
    const sb = typeof secret === "string" ? enc.encode(secret) : secret;
    const aes = await S.importKey("raw", await hkdf(sb, "body"), "AES-GCM", false, ["encrypt", "decrypt"]);
    const mac = await S.importKey("raw", await hkdf(sb, "tag"), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    const room = hex(await hkdf(sb, "room", 16));          // direct-link room name + password
    return { aes, mac, room };
  })();
  if (cacheable) keyCache.set(secret, p);
  return p;
}
export const publicSecret = name => "public:#" + name;
export const newSecret = () => b64(crypto.getRandomValues(new Uint8Array(18))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");

export const hourOf = ts => Math.floor(ts / 3600e3);
export async function tagFor(keys, hour) {
  return hex(await S.sign("HMAC", keys.mac, enc.encode("h:" + hour))).slice(0, 32);
}

/* Padded to a bucket size so message lengths don't stand out. */
function pad(bytes) {
  const sizes = [256, 512, 1024, 2048, 4096, 8192];
  const target = sizes.find(s => s >= bytes.length + 4) || bytes.length + 4;
  const out = new Uint8Array(target);
  new DataView(out.buffer).setUint32(0, bytes.length);
  out.set(bytes, 4);
  crypto.getRandomValues(out.subarray(4 + bytes.length));
  return out;
}
const unpad = b => b.subarray(4, 4 + new DataView(b.buffer, b.byteOffset).getUint32(0));

export async function seal(keys, obj) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = new Uint8Array(await S.encrypt({ name: "AES-GCM", iv }, keys.aes, pad(enc.encode(JSON.stringify(obj)))));
  return b64(concat(iv, ct));
}
export async function open(keys, box) {
  try {
    const raw = unb64(box);
    const pt = new Uint8Array(await S.decrypt({ name: "AES-GCM", iv: raw.subarray(0, 12) }, keys.aes, raw.subarray(12)));
    return JSON.parse(dec.decode(unpad(pt)));
  } catch { return null; }
}

/* ------------------------------------------------------------------ private messages
 * A DM conversation's secret is ECDH(my box key, their box key): both sides compute the same thing and
 * nobody else can. To reach someone who may not have opened the conversation yet, the sender also seals a
 * copy to the recipient's INBOX: a throwaway ECDH key + their box key, so the outside reveals no sender. */
export async function pairSecret(theirBpk) {
  const me = await identity();
  const pub = await S.importKey("raw", unb64(theirBpk), ECDH, false, []);
  const bits = new Uint8Array(await S.deriveBits({ name: "ECDH", public: pub }, me.boxKey, 256));
  const ids = [me.bpk, theirBpk].sort().join("|");
  return concat(bits, enc.encode(ids));
}
export async function inboxKeys(bpk) { return channelKeys("inbox:" + bpk); }   // only the TAG matters; bodies use sealTo

export async function sealTo(theirBpk, obj) {
  const eph = await S.generateKey(ECDH, true, ["deriveBits"]);
  const pub = await S.importKey("raw", unb64(theirBpk), ECDH, false, []);
  const bits = new Uint8Array(await S.deriveBits({ name: "ECDH", public: pub }, eph.privateKey, 256));
  const keys = await channelKeys(concat(bits, enc.encode("inbox")));
  const epub = b64(await S.exportKey("raw", eph.publicKey));
  return { e: epub, box: await seal(keys, obj) };
}
export async function openSealed(env) {
  try {
    const me = await identity();
    const pub = await S.importKey("raw", unb64(env.e), ECDH, false, []);
    const bits = new Uint8Array(await S.deriveBits({ name: "ECDH", public: pub }, me.boxKey, 256));
    return open(await channelKeys(concat(bits, enc.encode("inbox"))), env.box);
  } catch { return null; }
}

/* A short, speakable fingerprint for checking someone in person. */
export function fingerprint(id) { return (id || "").slice(0, 8).replace(/(....)/, "$1 "); }
