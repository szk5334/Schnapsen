/* LOCAL STAND-IN for the direct transport: BroadcastChannel between tabs of one browser (?local). */
import { uid } from "../util.js";

/* The P2P stand-in: same shape as net/p2p.js's trystero transport. */
export function localP2P() {
  return {
    kind: "local",
    join(roomId) {
      const selfId = uid().slice(0, 8);
      const c = new BroadcastChannel("sx-p2p-" + roomId);
      const peers = new Set(); const seen = new Map();
      const actions = new Map();
      let onJoin = () => {}, onLeave = () => {};
      c.onmessage = e => {
        const m = e.data; if (m.from === selfId) return;
        if (m.k === "here" || m.k === "hello") {
          seen.set(m.from, Date.now());
          if (!peers.has(m.from)) { peers.add(m.from); if (m.k === "here") c.postMessage({ k: "hello", from: selfId }); onJoin(m.from); }
        } else if (m.k === "leave") { if (peers.delete(m.from)) onLeave(m.from); }
        else if (m.k === "act" && (!m.to || m.to === selfId)) { const a = actions.get(m.name); a && a.cb && a.cb(m.data, m.from); }
      };
      c.postMessage({ k: "here", from: selfId });
      const hb = setInterval(() => {
        c.postMessage({ k: "hello", from: selfId });
        const now = Date.now();
        for (const p of [...peers]) if (now - (seen.get(p) || 0) > 6000) { peers.delete(p); onLeave(p); }
      }, 2000);
      return {
        selfId,
        set onPeerJoin(f) { onJoin = f; peers.forEach(p => f(p)); },
        set onPeerLeave(f) { onLeave = f; },
        peers: () => [...peers],
        action(name) {
          const a = { cb: null };
          actions.set(name, a);
          return {
            send(data, to) { c.postMessage({ k: "act", from: selfId, name, data, to: to || null }); },
            set onMessage(f) { a.cb = f; },
          };
        },
        leave() { clearInterval(hb); c.postMessage({ k: "leave", from: selfId }); c.close(); },
      };
    },
  };
}
