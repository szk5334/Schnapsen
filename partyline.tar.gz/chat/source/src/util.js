/* Shared helpers. */

/* ?as=NAME gives a tab its own storage, so one browser can be several people while testing. */
const NS = (() => { try { const a = new URLSearchParams(location.search).get("as"); return "pl." + (a ? a + "." : ""); } catch { return "pl."; } })();
export const LS = {
  get(k, d = null) { try { const v = localStorage.getItem(NS + k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem(NS + k, JSON.stringify(v)); } catch {} },
  del(k) { try { localStorage.removeItem(NS + k); } catch {} },
  wipe() { try { Object.keys(localStorage).filter(k => k.startsWith(NS)).forEach(k => localStorage.removeItem(k)); } catch {} },
};

export const uid = () => {
  const b = crypto.getRandomValues(new Uint8Array(12));
  return [...b].map(x => x.toString(16).padStart(2, "0")).join("");
};

/* A tiny observable value. */
export function cell(v) {
  const subs = new Set();
  return {
    get: () => v,
    set(n) { if (typeof n === "function") n = n(v); if (n === v) return; v = n; subs.forEach(f => f(v)); },
    sub(f) { subs.add(f); return () => subs.delete(f); },
  };
}

export const enc = new TextEncoder(), dec = new TextDecoder();
export function b64(buf) {
  const u = buf instanceof Uint8Array ? buf : new Uint8Array(buf); let s = "";
  for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000));
  return btoa(s);
}
export const unb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
export const hex = buf => [...new Uint8Array(buf)].map(x => x.toString(16).padStart(2, "0")).join("");
export const unhex = h => Uint8Array.from(h.match(/../g).map(x => parseInt(x, 16)));
export const concat = (...parts) => { const n = parts.reduce((a, p) => a + p.length, 0), o = new Uint8Array(n); let i = 0; for (const p of parts) { o.set(p, i); i += p.length; } return o; };

/* Nick colours, chosen to read on the dark ground. */
export const COLORS = ["#ff8a7a", "#ffc46b", "#e6e36a", "#8fe08a", "#6fd6c8", "#7cb8ff", "#b49cff", "#f39ad8"];
export const colorFor = id => { let h = 0; for (const ch of String(id || "")) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return COLORS[h % COLORS.length]; };
export const initials = name => {
  const p = String(name || "?").trim().split(/\s+/).filter(Boolean);
  return !p.length ? "?" : (p.length === 1 ? p[0].slice(0, 2) : p[0][0] + p[1][0]).toUpperCase();
};
export const cleanName = s => String(s || "").replace(/[\u0000-\u001f]/g, "").replace(/\s+/g, " ").trim().slice(0, 20);
export const cleanChan = s => String(s || "").toLowerCase().replace(/^#/, "").replace(/[^a-z0-9_-]/g, "").slice(0, 24);
export const clock = ts => { const d = new Date(ts); return d.getHours() + ":" + String(d.getMinutes()).padStart(2, "0"); };
export function ago(ts) {
  const s = (Date.now() - ts) / 1000;
  if (s < 60) return "now"; if (s < 3600) return Math.floor(s / 60) + "m"; if (s < 86400) return Math.floor(s / 3600) + "h";
  return Math.floor(s / 86400) + "d";
}
export const sample = (arr, n) => { const a = arr.slice(); for (let i = a.length - 1; i > 0; i--) { const j = (crypto.getRandomValues(new Uint32Array(1))[0]) % (i + 1); [a[i], a[j]] = [a[j], a[i]]; } return a.slice(0, n); };

let titleTimer = null; const baseTitle = typeof document !== "undefined" ? document.title : "";
export function nudge(text) {
  try { if (navigator.vibrate && (!navigator.userActivation || navigator.userActivation.hasBeenActive)) navigator.vibrate(30); } catch {}
  if (typeof document === "undefined" || !document.hidden) return;
  clearInterval(titleTimer); let on = false;
  titleTimer = setInterval(() => { document.title = (on = !on) ? text : baseTitle; }, 900);
  const stop = () => { if (!document.hidden) { clearInterval(titleTimer); document.title = baseTitle; document.removeEventListener("visibilitychange", stop); } };
  document.addEventListener("visibilitychange", stop);
}
