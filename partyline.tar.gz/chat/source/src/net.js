/* THE NETWORK — channels, people, messages. Two carriers under one roof:
 *
 *   direct   a WebRTC room per channel (Trystero). Fast, no third party once linked.
 *   relays   sealed events on Nostr relays under throwaway keys and hourly-rotating tags. Works when a
 *            direct link can't form, and holds messages for 7 days so people get them later.
 *
 * Every message is sealed with the channel's key and signed by its author's identity key, sent on both
 * carriers, and de-duplicated by id on arrival. Neither carrier ever sees a name, a channel or a word.
 */
import { LS, cell, uid, cleanName, cleanChan, colorFor, nudge } from "./util.js";
import { identity, signMsg, verifyMsg, channelKeys, publicSecret, newSecret, tagFor, hourOf, seal, open,
         pairSecret, inboxKeys, sealTo, openSealed } from "./crypto.js";
import { relayPool, KIND_STORED, KIND_EPHEMERAL } from "./relays.js";

const HISTORY_HOURS = 72, KEEP = 300, BEACON_MS = 45000, STALE_MS = 130000;
const QUICK_DEFAULT = ["👋", "👍", "lol", "brb", "omw", "yes", "no", "gn"];

export async function startNet({ p2p, relays }) {
  const me0 = await identity();
  const me = cell({ fid: me0.id, bpk: me0.bpk, name: LS.get("name", ""), color: LS.get("color", colorFor(me0.id)) });
  const prefs = cell({ quick: QUICK_DEFAULT, muted: [], ...LS.get("prefs", {}) });
  prefs.sub(v => LS.set("prefs", v));
  const pool = relays && relays.length ? relayPool(relays) : null;

  /* ---------------- joined channels ---------------- */
  let saved = LS.get("chans");
  if (!saved || !saved.length) saved = [{ id: "#lobby", kind: "public", name: "lobby" }];
  const chans = cell(saved.map(c => ({ ...c, unread: LS.get("u." + c.id, 0), last: LS.get("l." + c.id, 0) })));
  const active = cell(LS.get("active", "#lobby"));
  active.sub(v => LS.set("active", v));
  const persistChans = () => LS.set("chans", chans.get().map(({ unread, last, ...c }) => c));
  const directory = cell([]);                       // [{ name, count }] public channels seen in lobby beacons
  const dirSeen = new Map();                        // name -> Map(fid -> ts)
  const contacts = new Map(Object.entries(LS.get("contacts", {})));   // fid -> { name, color, bpk }
  const saveContacts = () => LS.set("contacts", Object.fromEntries(contacts));

  const rt = new Map();                             // chId -> runtime
  const msgsOf = id => (rt.get(id) || {}).msgs || cell(LS.get("m." + id, []));

  /* ---------------- per-channel runtime ---------------- */
  async function secretOf(c) {
    if (c.kind === "public") return publicSecret(c.name);
    if (c.kind === "private") return c.secret;
    if (c.kind === "dm") return pairSecret(c.peer.bpk);
  }
  async function start(c) {
    if (rt.has(c.id)) return rt.get(c.id);
    const r = { c, msgs: cell(LS.get("m." + c.id, [])), people: cell([]), typing: cell({}), offs: [], keys: null, ids: new Set(), rate: new Map(), peopleMap: new Map() };
    r.msgs.get().forEach(m => r.ids.add(m.id));
    rt.set(c.id, r);
    r.keys = await channelKeys(await secretOf(c));
    wireDirect(r); wireRelays(r);
    refreshPeople(r);
    beacon(r);
    r.beat = setInterval(() => beacon(r), BEACON_MS + Math.random() * 5000);
    r.sweep = setInterval(() => sweep(r), 15000);
    return r;
  }
  function stop(id) {
    const r = rt.get(id); if (!r) return;
    clearInterval(r.beat); clearInterval(r.sweep);
    sendBoth(r, { t: "bye", ch: id, ts: Date.now() }, true);
    r.offs.forEach(f => { try { f(); } catch {} });
    if (r.direct) r.direct.leave();
    rt.delete(id);
  }

  /* direct carrier */
  function wireDirect(r) {
    if (!p2p) return;
    const d = p2p.join("pl-" + r.keys.room, { password: r.keys.room });
    r.direct = d;
    r.dm = d.action("m");
    d.onPeerJoin = id => { beacon(r, id); const back = r.msgs.get().slice(-40); if (back.length) backlog(r, back, id); };
    d.onPeerLeave = id => { const left = [...r.peopleMap.values()].filter(p => p.peer === id); left.forEach(p => { p.peer = null; }); refreshPeople(r); };
    r.dm.onMessage = (box, peerId) => receive(r, box, peerId);
  }
  async function backlog(r, list, peerId) {
    for (const m of list) if (m.raw) { const box = await seal(r.keys, m.raw); r.dm.send(box, peerId); }
  }

  /* relay carrier */
  function wireRelays(r) {
    if (!pool) return;
    let unsub = null, hourNow = -1;
    const resub = async () => {
      const h = hourOf(Date.now());
      if (h === hourNow) return;
      hourNow = h;
      const stored = [], live = [];
      for (let i = -1; i < HISTORY_HOURS; i++) stored.push(await tagFor(r.keys, h - i));
      for (let i = -1; i < 2; i++) live.push(await tagFor(r.keys, h - i));
      if (unsub) unsub();
      unsub = pool.subscribe([
        { kinds: [KIND_STORED], "#t": stored, since: Math.floor(Date.now() / 1000) - HISTORY_HOURS * 3600, limit: 500 },
        { kinds: [KIND_EPHEMERAL], "#t": live, since: Math.floor(Date.now() / 1000) - 120 },
      ], ev => receive(r, ev.content, null));
    };
    resub();
    const t = setInterval(resub, 60000);
    r.offs.push(() => { clearInterval(t); if (unsub) unsub(); });
  }

  /* ---------------- sending ---------------- */
  async function sendBoth(r, body, ephemeral) {
    const m = await signMsg(body);
    const box = await seal(r.keys, m);
    if (r.dm) r.dm.send(box);
    if (pool) pool.publish(ephemeral ? KIND_EPHEMERAL : KIND_STORED, await tagFor(r.keys, hourOf(Date.now())), box);
    return m;
  }
  function pubChannels() { return chans.get().filter(c => c.kind === "public").map(c => c.name); }
  async function beacon(r, toPeer) {
    const w = me.get(); if (!w.name) return;
    const body = { t: "pres", ch: r.c.id, ts: Date.now(), name: w.name, color: w.color, ...(r.c.id === "#lobby" ? { chans: pubChannels() } : {}) };
    if (toPeer && r.dm) { const m = await signMsg(body); r.dm.send(await seal(r.keys, m), toPeer); return; }
    if (document.hidden && !toPeer) return;            // a background tab stops announcing itself
    sendBoth(r, body, true);
  }

  /* ---------------- receiving ---------------- */
  async function receive(r, box, peerId) {
    const m = await open(r.keys, box);
    if (!m || !(await verifyMsg(m))) return;            // not for this channel, or forged
    if (m.ch !== r.c.id) return;                        // replayed from another channel
    if (prefs.get().muted.includes(m.fid) && m.t !== "pres") return;
    if (m.ts > Date.now() + 5 * 60e3) m.ts = Date.now();
    noteContact(m);
    if (m.t === "pres" || m.t === "bye" || m.t === "typing") return seenPerson(r, m, peerId);
    if (r.ids.has(m.id) || !limit(r, m.fid)) return;
    seenPerson(r, m, peerId, true);
    if (m.t === "msg") addMsg(r, { id: String(m.id).slice(0, 40), fid: m.fid, name: cleanName(m.name), color: m.color, text: String(m.text || "").slice(0, 1000), re: m.re || null, ts: m.ts, raw: m, reacts: {} });
    else if (m.t === "react") addReact(r, m);
  }
  const dmIdFor = fid => "@" + [me.get().fid, fid].sort().join(":");
  function limit(r, fid) {
    const now = Date.now(), b = r.rate.get(fid) || { t: now, n: 0 };
    if (now - b.t > 60000) { b.t = now; b.n = 0; }
    b.n++; r.rate.set(fid, b);
    return b.n <= 30;
  }
  function noteContact(m) {
    if (m.fid === me.get().fid) return;
    const prev = contacts.get(m.fid);
    if (!prev || prev.name !== m.name || prev.bpk !== m.bpk) { contacts.set(m.fid, { name: cleanName(m.name), color: m.color, bpk: m.bpk }); saveContacts(); }
  }
  function seenPerson(r, m, peerId, quiet) {
    if (!r.peopleMap) r.peopleMap = new Map();
    if (m.fid === me.get().fid) return;
    if (m.t === "bye") { r.peopleMap.delete(m.fid); refreshPeople(r); return; }
    if (m.t === "typing") { r.typing.set(t => ({ ...t, [m.fid]: Date.now() + 4000 })); return; }
    const p = r.peopleMap.get(m.fid) || {};
    r.peopleMap.set(m.fid, { ...p, fid: m.fid, name: cleanName(m.name), color: m.color, bpk: m.bpk, last: Date.now(), peer: peerId || p.peer || null });
    if (m.chans && r.c.id === "#lobby") {
      for (const n of m.chans.slice(0, 30)) { const name = cleanChan(n); if (!name) continue; if (!dirSeen.has(name)) dirSeen.set(name, new Map()); dirSeen.get(name).set(m.fid, Date.now()); }
      refreshDirectory();
    }
    if (!quiet) refreshPeople(r);
  }
  function sweep(r) {
    if (!r.peopleMap) return;
    const now = Date.now();
    for (const [k, p] of r.peopleMap) if (!p.peer && now - p.last > STALE_MS) r.peopleMap.delete(k);
    refreshPeople(r); refreshDirectory();
  }
  function refreshPeople(r) {
    const w = me.get();
    const list = [{ fid: w.fid, name: w.name, color: w.color, self: true }, ...[...(r.peopleMap || new Map()).values()]];
    r.people.set(list);
    r.typing.set(t => { const n = {}; const now = Date.now(); for (const k in t) if (t[k] > now) n[k] = t[k]; return n; });
  }
  function refreshDirectory() {
    const now = Date.now(), out = [];
    for (const [name, m] of dirSeen) { for (const [f, ts] of m) if (now - ts > STALE_MS) m.delete(f); if (m.size) out.push({ name, count: m.size }); }
    out.sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
    directory.set(out);
  }

  function addMsg(r, msg) {
    r.ids.add(msg.id);
    const list = r.msgs.get().concat([msg]).sort((a, b) => a.ts - b.ts).slice(-KEEP);
    // reactions that arrived before their message
    const pend = (r.pendingReacts || []).filter(x => x.to === msg.id);
    pend.forEach(x => applyReact(msg, x));
    r.msgs.set(list);
    LS.set("m." + r.c.id, list);
    const mine = msg.fid === me.get().fid;
    const c = chans.get().find(x => x.id === r.c.id);
    if (!mine && c) {
      const unread = active.get() === r.c.id && !document.hidden ? 0 : (c.unread || 0) + 1;
      updateChan(r.c.id, { unread, last: msg.ts });
      const w = me.get();
      if (r.c.kind === "dm" || (w.name && msg.text.toLowerCase().includes("@" + w.name.toLowerCase()))) nudge("New message");
    } else if (c) updateChan(r.c.id, { last: msg.ts });
  }
  function applyReact(msg, m) {
    const set = new Set(msg.reacts[m.e] || []);
    if (set.has(m.fid)) set.delete(m.fid); else set.add(m.fid);
    msg.reacts = { ...msg.reacts, [m.e]: [...set] };
    if (!msg.reacts[m.e].length) { const { [m.e]: _, ...rest } = msg.reacts; msg.reacts = rest; }
  }
  function addReact(r, m) {
    r.ids.add(m.id);
    const e = String(m.e || "").slice(0, 8);
    const list = r.msgs.get().slice(); const i = list.findIndex(x => x.id === m.to);
    if (i < 0) { (r.pendingReacts = r.pendingReacts || []).push({ ...m, e }); return; }
    const msg = { ...list[i] }; applyReact(msg, { ...m, e }); list[i] = msg;
    r.msgs.set(list); LS.set("m." + r.c.id, list);
  }
  function updateChan(id, patch) {
    chans.set(cs => cs.map(c => (c.id === id ? { ...c, ...patch } : c)));
    if ("unread" in patch) LS.set("u." + id, patch.unread);
    if ("last" in patch) LS.set("l." + id, patch.last);
  }

  /* ---------------- inbox: the first word of a private conversation ---------------- */
  if (pool) {
    const ik = await inboxKeys(me0.bpk);
    let unsub = null, hourNow = -1;
    const resub = async () => {
      const h = hourOf(Date.now()); if (h === hourNow) return; hourNow = h;
      const tags = []; for (let i = 0; i < HISTORY_HOURS; i++) tags.push(await tagFor(ik, h - i));
      if (unsub) unsub();
      unsub = pool.subscribe([{ kinds: [KIND_STORED], "#t": tags, since: Math.floor(Date.now() / 1000) - HISTORY_HOURS * 3600 }], async ev => {
        let env; try { env = JSON.parse(ev.content); } catch { return; }
        const m = await openSealed(env);
        if (!m || m.t !== "knock" || !(await verifyMsg(m)) || m.fid === me0.id) return;
        if (prefs.get().muted.includes(m.fid)) return;
        noteContact(m);
        await ensureDM({ fid: m.fid, name: cleanName(m.name), color: m.color, bpk: m.bpk }, false);
      });
    };
    resub(); setInterval(resub, 60000);
  }
  async function knock(peer) {
    if (!pool) return;
    const key = "k." + peer.fid, day = Math.floor(Date.now() / 86400e3);
    if (LS.get(key) === day) return;
    LS.set(key, day);
    const w = me.get();
    const m = await signMsg({ t: "knock", ts: Date.now(), name: w.name, color: w.color });
    const env = await sealTo(peer.bpk, m);
    const ik = await inboxKeys(peer.bpk);
    pool.publish(KIND_STORED, await tagFor(ik, hourOf(Date.now())), JSON.stringify(env), 3);
  }
  async function ensureDM(peer, focus) {
    const id = dmIdFor(peer.fid);
    let c = chans.get().find(x => x.id === id);
    if (!c) {
      c = { id, kind: "dm", name: peer.name, peer: { fid: peer.fid, name: peer.name, color: peer.color, bpk: peer.bpk }, unread: 0, last: Date.now() };
      chans.set(cs => cs.concat([c])); persistChans();
    }
    await start(c);
    if (focus) active.set(id);
    return id;
  }

  /* ---------------- boot ---------------- */
  for (const c of chans.get()) start(c);
  me.sub(() => { for (const r of rt.values()) beacon(r); });
  document.addEventListener("visibilitychange", () => { if (!document.hidden) { for (const r of rt.values()) beacon(r); const a = active.get(); updateChan(a, { unread: 0 }); } });

  const baseUrl = () => location.origin + location.pathname;
  const api = {
    me, prefs, chans, active, directory, contacts,
    status: pool ? pool.status : cell({}),
    relayUrls: pool ? pool.urls : [],
    runtime: id => rt.get(id),
    messages: id => msgsOf(id),
    people: id => (rt.get(id) || {}).people || cell([]),
    typingOf: id => (rt.get(id) || {}).typing || cell({}),
    setName(n) { const name = cleanName(n); LS.set("name", name); me.set(v => ({ ...v, name })); },
    setColor(c) { LS.set("color", c); me.set(v => ({ ...v, color: c })); },
    focus(id) { active.set(id); updateChan(id, { unread: 0 }); },
    async join(name) {
      const n = cleanChan(name); if (!n) return null;
      const id = "#" + n;
      if (!chans.get().some(c => c.id === id)) { const c = { id, kind: "public", name: n, unread: 0, last: Date.now() }; chans.set(cs => cs.concat([c])); persistChans(); await start(c); for (const r of rt.values()) if (r.c.id === "#lobby") beacon(r); }
      api.focus(id); return id;
    },
    async createPrivate(name) {
      const n = cleanChan(name) || "private";
      const secret = newSecret(), id = "*" + n + "." + secret.slice(0, 6);
      const c = { id, kind: "private", name: n, secret, unread: 0, last: Date.now() };
      chans.set(cs => cs.concat([c])); persistChans(); await start(c); api.focus(id);
      return id;
    },
    inviteLink(id) {
      const c = chans.get().find(x => x.id === id); if (!c) return "";
      if (c.kind === "public") return baseUrl() + "#c=" + encodeURIComponent(c.name);
      if (c.kind === "private") return baseUrl() + "#p=" + encodeURIComponent(c.name) + "." + c.secret;
      return "";
    },
    async openLink(hash) {
      const h = (hash || "").replace(/^#/, "");
      if (h.startsWith("c=")) return api.join(decodeURIComponent(h.slice(2)));
      if (h.startsWith("p=")) {
        const raw = decodeURIComponent(h.slice(2)), dot = raw.lastIndexOf(".");
        const n = cleanChan(raw.slice(0, dot)), secret = raw.slice(dot + 1).replace(/[^A-Za-z0-9_-]/g, "");
        if (!n || secret.length < 16) return null;
        const id = "*" + n + "." + secret.slice(0, 6);
        if (!chans.get().some(c => c.id === id)) { const c = { id, kind: "private", name: n, secret, unread: 0, last: Date.now() }; chans.set(cs => cs.concat([c])); persistChans(); await start(c); }
        api.focus(id); return id;
      }
      return null;
    },
    leave(id) {
      if (id === "#lobby") return;
      stop(id);
      chans.set(cs => cs.filter(c => c.id !== id)); persistChans();
      ["m.", "u.", "l."].forEach(k => LS.del(k + id));
      if (active.get() === id) active.set("#lobby");
      for (const r of rt.values()) if (r.c.id === "#lobby") beacon(r);
    },
    async dm(person) { const id = await ensureDM(person, true); api.focus(id); return id; },
    async send(id, text, re) {
      const r = rt.get(id); const body = String(text || "").trim().slice(0, 1000);
      if (!r || !body) return;
      const w = me.get();
      const m = await sendBoth(r, { t: "msg", id: uid(), ch: id, ts: Date.now(), name: w.name, color: w.color, text: body, ...(re ? { re } : {}) });
      addMsg(r, { id: m.id, fid: w.fid, name: w.name, color: w.color, text: body, re: re || null, ts: m.ts, raw: m, reacts: {} });
      if (r.c.kind === "dm") knock(r.c.peer);
    },
    async react(id, msgId, e) {
      const r = rt.get(id); if (!r) return;
      const m = await sendBoth(r, { t: "react", id: uid(), ch: id, ts: Date.now(), name: me.get().name, color: me.get().color, to: msgId, e });
      addReact(r, m);
    },
    async typing(id) {
      const r = rt.get(id); if (!r || !r.dm) return;
      const now = Date.now(); if (now - (r.lastTyping || 0) < 2500) return; r.lastTyping = now;
      const w = me.get();
      r.dm.send(await seal(r.keys, await signMsg({ t: "typing", ch: id, ts: now, name: w.name, color: w.color })));
    },
    mute(fid) { prefs.set(p => ({ ...p, muted: [...new Set([...p.muted, fid])] })); },
    unmute(fid) { prefs.set(p => ({ ...p, muted: p.muted.filter(x => x !== fid) })); },
    linked() { let n = 0; for (const r of rt.values()) if (r.direct) n += r.direct.peers().length; return n; },
    wipe() { for (const id of [...rt.keys()]) stop(id); LS.wipe(); location.hash = ""; location.reload(); },
  };
  return api;
}
