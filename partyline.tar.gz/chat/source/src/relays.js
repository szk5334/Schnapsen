/* RELAYS — a minimal Nostr client, used as an encrypted postbox.
 *
 * Every event is signed by a brand-new throwaway key, so nothing on a relay links two messages to the
 * same person. Content is already sealed (crypto.js); the only readable field is a rotating tag. Each
 * message goes to a random 2 or 3 relays of the pool; readers listen on all of them.
 *
 *   stored events (kind 4747)     kept by relays for 7 days (NIP-40 expiration): history, offline delivery
 *   ephemeral events (kind 24747) passed on and forgotten: presence beacons
 */
import { schnorr } from "@noble/curves/secp256k1";
import { sha256 } from "@noble/hashes/sha256";
import { bytesToHex } from "@noble/hashes/utils";
import { cell, enc, sample } from "./util.js";

export const KIND_STORED = 4747, KIND_EPHEMERAL = 24747;
const KEEP_DAYS = 7;

export const DEFAULT_RELAYS = [
  "wss://relay.damus.io", "wss://nos.lol", "wss://relay.primal.net",
  "wss://nostr.mom", "wss://relay.nostr.net", "wss://offchain.pub",
];

function makeEvent(kind, tag, content) {
  const sk = schnorr.utils.randomSecretKey ? schnorr.utils.randomSecretKey() : schnorr.utils.randomPrivateKey();
  const pubkey = bytesToHex(schnorr.getPublicKey(sk));
  const created_at = Math.floor(Date.now() / 1000);
  const tags = [["t", tag]];
  if (kind === KIND_STORED) tags.push(["expiration", String(created_at + KEEP_DAYS * 86400)]);
  const id = bytesToHex(sha256(enc.encode(JSON.stringify([0, pubkey, created_at, kind, tags, content]))));
  const sig = bytesToHex(schnorr.sign(id, sk));
  return { id, pubkey, created_at, kind, tags, content, sig };
}

export function relayPool(urls) {
  const status = cell({});                          // url -> "connecting" | "open" | "closed"
  const conns = new Map();
  const subs = new Map();                           // subId -> { filters, cb }
  const seen = new Set();
  let n = 0;

  const setStatus = (u, s) => status.set(v => ({ ...v, [u]: s }));
  function connect(url, attempt = 0) {
    let ws;
    try { ws = new WebSocket(url); } catch { setStatus(url, "closed"); return; }
    const c = { ws, url, queue: [], open: false };
    conns.set(url, c);
    setStatus(url, "connecting");
    ws.onopen = () => {
      c.open = true; attempt = 0; setStatus(url, "open");
      for (const [id, s] of subs) ws.send(JSON.stringify(["REQ", id, ...s.filters]));
      c.queue.splice(0).forEach(m => ws.send(m));
    };
    ws.onmessage = e => {
      let m; try { m = JSON.parse(e.data); } catch { return; }
      if (m[0] === "EVENT") {
        const ev = m[2], s = subs.get(m[1]);
        if (!s || !ev || seen.has(ev.id)) return;
        seen.add(ev.id); if (seen.size > 5000) seen.clear();
        s.cb(ev);
      }
    };
    ws.onclose = () => {
      c.open = false; setStatus(url, "closed");
      const wait = Math.min(60000, 2000 * 2 ** attempt) + Math.random() * 1000;
      setTimeout(() => { if (conns.get(url) === c) connect(url, attempt + 1); }, wait);
    };
    ws.onerror = () => {};
  }
  urls.forEach(u => connect(u));
  const send = (c, m) => (c.open ? c.ws.send(m) : c.queue.push(m));

  return {
    status,
    urls,
    publish(kind, tag, content, spread = 2) {
      const ev = makeEvent(kind, tag, content);
      seen.add(ev.id);                                // don't echo our own back
      const live = [...conns.values()].filter(c => c.open);
      const pick = sample(live.length >= spread ? live : [...conns.values()], spread + (Math.random() < 0.5 ? 1 : 0));
      const m = JSON.stringify(["EVENT", ev]);
      pick.forEach(c => send(c, m));
      return ev.id;
    },
    subscribe(filters, cb) {
      const id = "s" + (++n) + Math.random().toString(36).slice(2, 6);
      subs.set(id, { filters, cb });
      const m = JSON.stringify(["REQ", id, ...filters]);
      for (const c of conns.values()) send(c, m);
      return () => {
        subs.delete(id);
        const x = JSON.stringify(["CLOSE", id]);
        for (const c of conns.values()) if (c.open) c.ws.send(x);
      };
    },
  };
}
