import { h, render } from "preact";
import { useState, useEffect, useRef, useLayoutEffect } from "preact/hooks";
import htm from "htm";
import { clock, initials, COLORS, ago } from "./util.js";
import { fingerprint } from "./crypto.js";

const html = htm.bind(h);
const REACTS = ["👍", "❤️", "😂", "😮", "😢", "🙏"];

function useCell(c) {
  const [v, setV] = useState(() => (c ? c.get() : null));
  useEffect(() => { if (!c) return; setV(c.get()); return c.sub(setV); }, [c]);
  return v;
}
function useTick(ms) { const [, s] = useState(0); useEffect(() => { const t = setInterval(() => s(n => n + 1), ms); return () => clearInterval(t); }, [ms]); }

const Av = ({ p, big }) => html`<span class=${"av" + (big ? " big" : "")} style=${"--c:" + ((p && p.color) || "#888")} aria-hidden="true">${initials(p && p.name)}</span>`;

function Sheet({ title, onClose, children }) {
  useEffect(() => { const f = e => e.key === "Escape" && onClose(); addEventListener("keydown", f); return () => removeEventListener("keydown", f); }, []);
  return html`<div class="scrim" onClick=${onClose}>
    <div class="sheet" role="dialog" aria-modal="true" aria-label=${title} onClick=${e => e.stopPropagation()}>
      <div class="sheet-h"><h2>${title}</h2><button class="x" onClick=${onClose}>Close</button></div>
      ${children}
    </div></div>`;
}

/* ================================================================== app */
export function mount(net, el) { render(html`<${App} net=${net}/>`, el); }

function App({ net }) {
  const me = useCell(net.me);
  if (!me.name) return html`<${Gate} net=${net}/>`;
  return html`<${Main} net=${net}/>`;
}

function Gate({ net }) {
  const [v, setV] = useState("");
  const ok = v.trim().length > 0;
  return html`<div class="screen gate">
    <h1 class="mark">Party Line</h1>
    <p class="lede">Channels and private messages with whoever else has this page open.</p>
    <form onSubmit=${e => { e.preventDefault(); ok && net.setName(v); }}>
      <label for="nm">What should people call you?</label>
      <input id="nm" value=${v} maxlength="20" autocomplete="nickname" onInput=${e => setV(e.currentTarget.value)} autofocus/>
      <button class="btn primary" disabled=${!ok}>Come in</button>
    </form>
  </div>`;
}

function Main({ net }) {
  const chans = useCell(net.chans);
  const active = useCell(net.active);
  const [sheet, setSheet] = useState(null);           // { k: "add" | "me" | "people" | "person" | "chan", ... }
  const c = chans.find(x => x.id === active) || chans[0];
  useEffect(() => { if (c && c.id !== active) net.focus(c.id); }, [c && c.id]);

  return html`<div class="screen main">
    <nav class="strip" aria-label="Channels">
      ${chans.map(x => html`<button key=${x.id} class=${"jack" + (x.id === c.id ? " on" : "") + (x.kind === "dm" ? " dm" : "")}
          onClick=${() => net.focus(x.id)} aria-current=${x.id === c.id}>
        ${x.kind === "dm" ? html`<${Av} p=${x.peer}/>` : html`<span class="sig">${x.kind === "private" ? "*" : "#"}</span>`}
        <span class="jn">${x.name}</span>
        ${x.unread > 0 && x.id !== c.id && html`<b class="dot">${x.unread > 9 ? "9+" : x.unread}</b>`}
      </button>`)}
      <button class="jack add" onClick=${() => setSheet({ k: "add" })} aria-label="Join or create a channel">+</button>
      <button class="jack me" onClick=${() => setSheet({ k: "me" })} aria-label="You and settings"><${Av} p=${net.me.get()}/></button>
    </nav>
    <${Channel} key=${c.id} net=${net} c=${c} openPeople=${() => setSheet({ k: "people" })} openPerson=${p => setSheet({ k: "person", p })} openChan=${() => setSheet({ k: "chan" })}/>
    ${sheet && sheet.k === "add" && html`<${AddSheet} net=${net} close=${() => setSheet(null)}/>`}
    ${sheet && sheet.k === "me" && html`<${MeSheet} net=${net} close=${() => setSheet(null)}/>`}
    ${sheet && sheet.k === "people" && html`<${PeopleSheet} net=${net} c=${c} close=${() => setSheet(null)} pick=${p => setSheet({ k: "person", p })}/>`}
    ${sheet && sheet.k === "person" && html`<${PersonSheet} net=${net} p=${sheet.p} close=${() => setSheet(null)}/>`}
    ${sheet && sheet.k === "chan" && html`<${ChanSheet} net=${net} c=${c} close=${() => setSheet(null)}/>`}
  </div>`;
}

/* ================================================================== a channel */
function Channel({ net, c, openPeople, openPerson, openChan }) {
  const msgs = useCell(net.messages(c.id)) || [];
  const people = useCell(net.people(c.id)) || [];
  const typing = useCell(net.typingOf(c.id)) || {};
  const prefs = useCell(net.prefs);
  const me = useCell(net.me);
  const [txt, setTxt] = useState("");
  const [re, setRe] = useState(null);
  const [sel, setSel] = useState(null);
  const listRef = useRef(null), stick = useRef(true), inputRef = useRef(null);
  useTick(3000);

  useLayoutEffect(() => { const el = listRef.current; if (el && stick.current) el.scrollTop = el.scrollHeight; }, [msgs.length, c.id]);
  const onScroll = e => { const el = e.currentTarget; stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 60; };
  const byId = new Map(msgs.map(m => [m.id, m]));
  const here = people.length;
  const now = Date.now();
  const typers = people.filter(p => !p.self && typing[p.fid] > now).map(p => p.name);
  const nameOf = new Map(); people.forEach(p => nameOf.set(p.fid, p.name));

  const send = (t, reTo) => { net.send(c.id, t, reTo || null); setRe(null); stick.current = true; };
  const submit = e => { e.preventDefault(); if (!txt.trim()) return; send(txt, re && re.id); setTxt(""); };
  const mention = name => { setTxt(t => (t && !t.endsWith(" ") ? t + " " : t) + "@" + name + " "); inputRef.current && inputRef.current.focus(); };

  const title = c.kind === "dm" ? c.name : (c.kind === "private" ? "*" : "#") + c.name;
  let prev = null;
  return html`<section class="chan" aria-label=${title}>
    <header class="ch-h">
      <button class="ch-t" onClick=${openPeople}>
        <b>${title}</b>
        <span>${c.kind === "dm" ? (people.length > 1 ? "here now" : "private") : here > 1 ? `${here} here` : "just you"}</span>
      </button>
      <button class="btn ghost" onClick=${openChan}>More</button>
    </header>

    <ol class="msgs" ref=${listRef} onScroll=${onScroll} aria-live="polite">
      ${msgs.length === 0 && html`<li class="sys">${c.kind === "dm" ? `Start a conversation with ${c.name}.` : c.id === "#lobby" ? "Say hello. Everyone with this page open lands here first." : "Nothing said yet."}</li>`}
      ${msgs.map(m => {
        const fold = prev && prev.fid === m.fid && m.ts - prev.ts < 4 * 60e3 && !m.re;
        prev = m;
        const mine = m.fid === me.fid;
        const parent = m.re && byId.get(m.re);
        const mentioned = !mine && me.name && m.text.toLowerCase().includes("@" + me.name.toLowerCase());
        const open = sel === m.id;
        return html`<li key=${m.id} class=${"msg" + (fold ? " fold" : "") + (mentioned ? " ping" : "") + (open ? " open" : "")}>
          ${parent && html`<div class="quote"><span style=${"color:" + parent.color}>${parent.name}</span> ${parent.text.slice(0, 80)}</div>`}
          <div class="line" onClick=${() => setSel(open ? null : m.id)}>
            ${!fold && html`<button class="who" style=${"color:" + (m.color || "inherit")} onClick=${e => { e.stopPropagation(); if (!mine) openPerson({ fid: m.fid, name: m.name, color: m.color, bpk: m.raw && m.raw.bpk }); }}>${m.name}</button>`}
            <span class="txt">${m.text}</span>
            ${!fold && html`<time>${clock(m.ts)}</time>`}
          </div>
          ${Object.keys(m.reacts || {}).length > 0 && html`<div class="reacts">${Object.entries(m.reacts).map(([e, who]) => html`<button class=${"rx" + (who.includes(me.fid) ? " mine" : "")} onClick=${() => net.react(c.id, m.id, e)} title=${who.map(f => nameOf.get(f) || (f === me.fid ? "you" : "someone")).join(", ")}>${e} ${who.length}</button>`)}</div>`}
          ${open && html`<div class="acts">
            ${REACTS.map(e => html`<button class="rxb" onClick=${() => { net.react(c.id, m.id, e); setSel(null); }} aria-label=${"React " + e}>${e}</button>`)}
            <button class="act" onClick=${() => { setRe(m); setSel(null); inputRef.current && inputRef.current.focus(); }}>Reply</button>
            ${!mine && html`<button class="act" onClick=${() => { mention(m.name); setSel(null); }}>Mention</button>`}
          </div>`}
        </li>`;
      })}
    </ol>

    <div class="typing">${typers.length ? `${typers.join(", ")} ${typers.length > 1 ? "are" : "is"} typing…` : ""}</div>
    ${re && html`<div class="replying"><span>Replying to <b style=${"color:" + re.color}>${re.name}</b>: ${re.text.slice(0, 60)}</span><button class="x" onClick=${() => setRe(null)}>Cancel</button></div>`}
    <div class="quick" aria-label="Quick replies">
      ${prefs.quick.map(q => html`<button key=${q} class="chip" onClick=${() => send(q, re && re.id)}>${q}</button>`)}
    </div>
    <form class="composer" onSubmit=${submit}>
      <input ref=${inputRef} value=${txt} placeholder=${c.kind === "dm" ? `Message ${c.name}` : `Message ${title}`} maxlength="1000"
        enterkeyhint="send" autocomplete="off" aria-label="Message"
        onInput=${e => { setTxt(e.currentTarget.value); net.typing(c.id); }}/>
      <button class="btn primary" disabled=${!txt.trim()}>Send</button>
    </form>
  </section>`;
}

/* ================================================================== sheets */
function AddSheet({ net, close }) {
  const dir = useCell(net.directory) || [];
  const chans = useCell(net.chans);
  const [name, setName] = useState(""), [pname, setPname] = useState(""), [link, setLink] = useState("");
  const joined = new Set(chans.map(c => c.id));
  const list = dir.filter(d => !joined.has("#" + d.name));
  const join = async n => { await net.join(n); close(); };
  return html`<${Sheet} title="Channels" onClose=${close}>
    ${list.length > 0 && html`<h3>Open now</h3><ul class="dir">${list.map(d => html`<li><button class="row" onClick=${() => join(d.name)}><b>#${d.name}</b><span>${d.count} ${d.count === 1 ? "person" : "people"}</span></button></li>`)}</ul>`}
    <h3>Join or start a channel</h3>
    <form class="inline" onSubmit=${e => { e.preventDefault(); name.trim() && join(name); }}>
      <input value=${name} placeholder="#name" onInput=${e => setName(e.currentTarget.value)} autocapitalize="none" maxlength="25"/>
      <button class="btn" disabled=${!name.trim()}>Join</button>
    </form>
    <h3>Private channel</h3>
    <p class="muted">Only people with its link can find it or read it.</p>
    <form class="inline" onSubmit=${async e => { e.preventDefault(); const id = await net.createPrivate(pname); const l = net.inviteLink(id); try { navigator.share ? await navigator.share({ title: "Party Line", url: l }) : await navigator.clipboard.writeText(l); } catch {} close(); }}>
      <input value=${pname} placeholder="name" onInput=${e => setPname(e.currentTarget.value)} autocapitalize="none" maxlength="24"/>
      <button class="btn">Create and share</button>
    </form>
    <h3>Have a link?</h3>
    <form class="inline" onSubmit=${async e => { e.preventDefault(); const i = link.indexOf("#"); if (i >= 0 && await net.openLink(link.slice(i))) close(); }}>
      <input value=${link} placeholder="Paste it here" onInput=${e => setLink(e.currentTarget.value)} autocapitalize="none"/>
      <button class="btn" disabled=${!link.includes("#")}>Open</button>
    </form>
  <//>`;
}

function PeopleSheet({ net, c, close, pick }) {
  const people = useCell(net.people(c.id)) || [];
  return html`<${Sheet} title=${people.length > 1 ? `${people.length} here` : "Just you here"} onClose=${close}>
    <ul class="people">${people.map(p => html`<li><button class="row" disabled=${p.self} onClick=${() => pick(p)}><${Av} p=${p}/><b>${p.self ? p.name + " (you)" : p.name}</b><span class="fp">${fingerprint(p.fid)}</span></button></li>`)}</ul>
  <//>`;
}

function PersonSheet({ net, p, close }) {
  const prefs = useCell(net.prefs);
  const muted = prefs.muted.includes(p.fid);
  const known = p.bpk || (net.contacts.get(p.fid) || {}).bpk;
  return html`<${Sheet} title=${p.name} onClose=${close}>
    <div class="person"><${Av} p=${p} big/><div><b>${p.name}</b><p class="muted">Code <span class="fp">${fingerprint(p.fid)}</span>. Compare it in person to be sure it's really them.</p></div></div>
    <div class="menu">
      ${known && html`<button class="row" onClick=${async () => { await net.dm({ ...p, bpk: known }); close(); }}>Message privately</button>`}
      <button class="row" onClick=${() => { muted ? net.unmute(p.fid) : net.mute(p.fid); close(); }}>${muted ? "Unmute" : "Mute"}</button>
    </div>
  <//>`;
}

function ChanSheet({ net, c, close }) {
  const link = net.inviteLink(c.id);
  const [copied, setCopied] = useState(false);
  const share = async () => { try { if (navigator.share) await navigator.share({ title: "Party Line", url: link }); else { await navigator.clipboard.writeText(link); setCopied(true); } } catch {} };
  return html`<${Sheet} title=${c.kind === "dm" ? c.name : (c.kind === "private" ? "*" : "#") + c.name} onClose=${close}>
    <div class="menu">
      ${link && html`<button class="row" onClick=${share}>${copied ? "Link copied" : "Invite someone"}</button>`}
      ${c.kind === "private" && html`<p class="muted pad">Anyone with the link can join and read new messages.</p>`}
      ${c.id !== "#lobby" && html`<button class="row danger" onClick=${() => { net.leave(c.id); close(); }}>${c.kind === "dm" ? "Close conversation" : "Leave channel"}</button>`}
    </div>
  <//>`;
}

function MeSheet({ net, close }) {
  const me = useCell(net.me), prefs = useCell(net.prefs), status = useCell(net.status) || {};
  const [name, setName] = useState(me.name), [quick, setQuick] = useState(prefs.quick.join(", "));
  const [confirm, setConfirm] = useState(false);
  useTick(2000);
  const open = Object.values(status).filter(s => s === "open").length, total = Object.keys(status).length;
  return html`<${Sheet} title="You" onClose=${close}>
    <form class="inline" onSubmit=${e => { e.preventDefault(); net.setName(name); }}>
      <input value=${name} maxlength="20" onInput=${e => setName(e.currentTarget.value)} aria-label="Your name"/>
      <button class="btn" disabled=${!name.trim() || name === me.name}>Save</button>
    </form>
    <div class="swatches" role="radiogroup" aria-label="Your colour">${COLORS.map(col => html`<button role="radio" aria-checked=${me.color === col} class=${"sw" + (me.color === col ? " on" : "")} style=${"--c:" + col} onClick=${() => net.setColor(col)}></button>`)}</div>
    <p class="muted">Your code: <span class="fp">${fingerprint(me.fid)}</span></p>
    <h3>Quick replies</h3>
    <form class="inline" onSubmit=${e => { e.preventDefault(); net.prefs.set(p => ({ ...p, quick: quick.split(",").map(s => s.trim()).filter(Boolean).slice(0, 12) })); }}>
      <input value=${quick} onInput=${e => setQuick(e.currentTarget.value)} aria-label="Quick replies, separated by commas"/>
      <button class="btn">Save</button>
    </form>
    <h3>Connection</h3>
    <p class="muted">${total ? `${open} of ${total} relays reachable` : "Relays off"}${net.linked() ? `, ${net.linked()} direct ${net.linked() === 1 ? "link" : "links"}` : ""}</p>
    <h3>This device</h3>
    ${confirm
      ? html`<button class="btn danger wide" onClick=${() => net.wipe()}>Erase everything on this device</button>`
      : html`<button class="btn wide" onClick=${() => setConfirm(true)}>Erase my history and identity…</button>`}
  <//>`;
}
