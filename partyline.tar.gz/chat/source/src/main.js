/* Boot. Settings come from window.PL_CONFIG (optional), plus URL switches used for testing:
 *   ?local         direct links between tabs of one browser (BroadcastChannel) instead of WebRTC
 *   ?nodirect      no direct links at all — relays only
 *   ?relay=URL     use this relay instead of the public pool (repeatable)
 *   ?as=NAME       separate storage per tab                                                */
import { startNet } from "./net.js";
import { DEFAULT_RELAYS } from "./relays.js";
import { localP2P } from "./net/local.js";
import { trysteroP2P } from "./net/p2p.js";
import { mount } from "./ui.js";

const q = new URLSearchParams(location.search);
const cfg = window.PL_CONFIG || {};

async function ice() {
  if (cfg.iceServers && cfg.iceServers.length) return cfg.iceServers;
  if (!cfg.turnCredentialsUrl) return null;
  try {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 4000);
    const r = await fetch(cfg.turnCredentialsUrl, { signal: ctl.signal }); clearTimeout(t);
    const j = await r.json(); return Array.isArray(j) ? j : null;
  } catch { return null; }
}

async function boot() {
  const relays = q.getAll("relay").length ? q.getAll("relay") : (cfg.relays && cfg.relays.length ? cfg.relays : DEFAULT_RELAYS);
  const p2p = q.has("nodirect") ? null : q.has("local") ? localP2P() : trysteroP2P({ p2pAppId: "szk5334-partyline", turn: await ice() });
  const net = await startNet({ p2p, relays });
  window.__pl = net;
  if (/^#(c|p)=/.test(location.hash)) { await net.openLink(location.hash); history.replaceState(null, "", location.pathname + location.search); }
  mount(net, document.getElementById("app"));
  if ("serviceWorker" in navigator && location.protocol === "https:") navigator.serviceWorker.register("sw.js").catch(() => {});
}
boot().catch(e => {
  console.error(e);
  document.getElementById("app").innerHTML = '<div class="screen gate"><p>Couldn’t start.</p><pre class="err"></pre><button class="btn" onclick="location.reload()">Reload</button></div>';
  document.querySelector(".err").textContent = String((e && e.message) || e);
});
