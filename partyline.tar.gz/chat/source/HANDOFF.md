# Party Line — overlay chat (handoff)

IRC-shaped chat where every open copy of the page is a node. One self-contained `index.html`
(installable; also runs as a saved file). No server of its own, no accounts.

## Carriers
- **Direct**: a Trystero WebRTC room per channel (Nostr + WebTorrent discovery). Fast; fails on
  hostile NATs (no TURN in the single file).
- **Relays**: Nostr events, sealed. Throwaway secp256k1 key per event, content AES-256-GCM, padded
  to 256/512/…, tag = HMAC(channel key, hour) truncated — rotates hourly, unlinkable across channels.
  Stored kind 4747 with NIP-40 expiry (7 days) → history + offline delivery. Ephemeral kind 24747 →
  presence beacons every ~45 s. Each event to a random 2–3 of the pool. Readers subscribe to all.
- Both carriers always; dedupe by message id.

## Identity & privacy
- P-256 ECDSA (signing) + P-256 ECDH (sealing) per device, in localStorage. id = SHA-256(sign pub)[:16].
- Every inner message signed; verified on arrival; `ch` inside the signature blocks cross-channel replay.
- Public channel secret = "public:#name" (anyone can derive — public by design, but relays still can't
  read or group it without knowing the name). Private channel secret = 18 random bytes in the link's
  `#p=name.SECRET` fragment (fragments are never sent to a web server).
- DMs: secret = ECDH(me, them). First contact: a signed "knock" sealed to the recipient's box key with a
  throwaway ECDH key, posted under the recipient's rotating inbox tag (≤ once/day/peer).
- Rate limit 30 msgs/min/sender/channel. Mute per person.
- CSP: only this build's script and stylesheet (sha256 hashes), connections only to wss:, Metered
  (TURN, future), localhost (tests). No third-party fonts or assets.

## Files
`src/` (main, net, crypto, relays, ui, util, style.css, net/p2p, net/local) · `build.mjs` → `dist/chat/`
· `tests/` (crypto unit tests, local NIP-01 relay, Playwright e2e, saved-file + CSP test).

## Test results (last run)
crypto 20/20 · e2e relay-only 21/21 · e2e direct+relay 22/22 · saved-file + CSP 4/4.
The e2e test reads both relays' logs: no names, channel names or words appear; every event has a
distinct key; sizes fall in 2 buckets.

## Known limits
- Relays see IP addresses and timing (use Tor Browser to hide IPs; direct links are disabled there).
- Public relays may drop the custom kinds or not honour expiry; the pool has 6 for redundancy.
- localStorage is plaintext at rest (wipe button erases everything; passphrase-at-rest is next).
- Fingerprints are TOFU — compare the code in person for anything important.
- Not externally audited.
