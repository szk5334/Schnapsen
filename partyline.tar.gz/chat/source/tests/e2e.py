"""Party Line end to end, in real Chromium, against two local relays.

Relay-only mode (?nodirect) is the case that matters: two phones that can't link directly.
Checks: lobby chat, presence, public channel discovery, private channel by link, private messages,
reactions + replies, offline delivery, late joiner history, and what the relays actually saw."""
import asyncio, json, os, subprocess, sys, time
from playwright.async_api import async_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "shots"); os.makedirs(OUT, exist_ok=True)
BASE = "http://localhost:8780/chat/index.html"
R = "&relay=ws://localhost:7777&relay=ws://localhost:7778"
MODE = sys.argv[1] if len(sys.argv) > 1 else "nodirect"
CHROME = "/opt/pw-browsers/chromium-1194/chrome-linux/chrome"
results = []
def check(c, msg): results.append((bool(c), msg)); print(("ok   " if c else "FAIL ") + msg)

async def main():
    procs = [subprocess.Popen(["node", os.path.join(HERE, "relay.mjs"), str(p), f"/tmp/relay-{p}.log"], stdout=subprocess.DEVNULL) for p in (7777, 7778)]
    srv = subprocess.Popen([sys.executable, "-m", "http.server", "8780", "-d", os.path.join(HERE, "..", "dist")], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(1.2)
    try:
        async with async_playwright() as p:
            b = await p.chromium.launch(executable_path=CHROME, args=["--no-sandbox"])
            ctx = await b.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, is_mobile=True, has_touch=True)
            errs = []
            async def page(tag, name=None):
                pg = await ctx.new_page()
                pg.on("pageerror", lambda e: errs.append(f"[{tag}] {e}"))
                pg.on("console", lambda m: errs.append(f"[{tag}] {m.text}") if m.type == "error" and "WebSocket" not in m.text else None)
                await pg.goto(f"{BASE}?{MODE}&as={tag}{R}")
                if name:
                    await pg.fill("#nm", name); await pg.click("text=Come in")
                await pg.wait_for_selector(".strip", timeout=10000)
                return pg
            async def say(pg, text):
                await pg.fill(".composer input", text); await pg.press(".composer input", "Enter")
            async def sees(pg, text, t=12000):
                try: await pg.wait_for_selector(f".msgs >> text={text}", timeout=t); return True
                except Exception: return False

            A = await page("a", "Seth"); B = await page("b", "Jamie")
            await say(A, "hello from the relays")
            check(await sees(B, "hello from the relays"), "lobby message reaches the other phone")
            await say(B, "hi Seth")
            check(await sees(A, "hi Seth"), "and back")
            await A.wait_for_selector(".ch-t >> text=2 here", timeout=60000)
            check(True, "presence: both see 2 here")
            await A.screenshot(path=f"{OUT}/01-lobby.png")

            # public channel discovery
            await B.click(".jack.add"); await B.fill(".inline input >> nth=0", "schnapsen"); await B.click("button:has-text('Join')")
            await say(B, "anyone for cards")
            await A.click(".jack.add")
            found = False
            for _ in range(60):
                if await A.locator(".dir >> text=#schnapsen").count(): found = True; break
                await asyncio.sleep(1)
                await A.click(".x"); await A.click(".jack.add")
            check(found, "a new public channel shows up in the other phone's list")
            await A.screenshot(path=f"{OUT}/02-channels.png")
            await A.click(".dir >> text=#schnapsen")
            check(await sees(A, "anyone for cards"), "joining a channel brings its earlier messages")

            # private channel by link
            await A.evaluate("navigator.share = undefined")
            await A.context.grant_permissions(["clipboard-read", "clipboard-write"])
            await A.click(".jack.add"); await A.fill(".inline input >> nth=1", "cats"); await A.click("button:has-text('Create and share')")
            await A.wait_for_selector(".ch-t >> text=*cats")
            link = await A.evaluate("__pl.inviteLink(__pl.active.get())")
            check("#p=cats." in link and len(link.split(".")[-1]) >= 20, "private channel gets a link carrying its secret")
            await say(A, "niles knocked the cup over")
            await B.click(".jack.add"); await B.fill(".inline input >> nth=2", link); await B.click("button:has-text('Open')")
            check(await sees(B, "niles knocked the cup over"), "the link opens the private channel and its history")
            C = await page("c", "Ollie")
            await C.wait_for_timeout(3000)
            dirs = await C.evaluate("__pl.directory.get().map(d => d.name)")
            check("cats" not in dirs, "a private channel is never listed")

            # private message
            await A.click(".jack >> text=lobby")
            await A.click(".ch-t"); await A.click(".people >> text=Jamie"); await A.click("text=Message privately")
            await A.wait_for_selector(".jack.dm >> text=Jamie")
            await say(A, "psst, just you")
            dm = False
            for _ in range(40):
                if await B.locator(".jack.dm >> text=Seth").count(): dm = True; break
                await asyncio.sleep(0.5)
            check(dm, "a private conversation appears on the recipient's phone by itself")
            await B.click(".jack.dm >> text=Seth")
            check(await sees(B, "psst, just you"), "the private message arrives")
            check(not await sees(C, "psst, just you", 2000), "a third person never sees it")
            await B.screenshot(path=f"{OUT}/03-dm.png")

            # reactions + reply + quick chip
            await B.click(".msgs >> text=psst, just you"); await B.click(".rxb >> nth=0")
            await A.wait_for_selector(".rx >> text=👍", timeout=12000)
            check(True, "a reaction reaches the sender")
            await A.click(".msgs >> text=psst, just you"); await A.click(".act >> text=Reply")
            await say(A, "seriously")
            await B.wait_for_selector(".quote >> text=psst", timeout=12000)
            check(True, "a reply carries its quote")
            await B.click(".chip >> text=lol")
            check(await sees(A, "lol"), "a quick reply sends with one tap")
            await A.screenshot(path=f"{OUT}/04-react-reply.png")

            # offline delivery
            await B.close()
            await A.click(".jack >> text=lobby")
            await say(A, "while you were out")
            await asyncio.sleep(1)
            B = await page("b")
            await B.click(".jack >> text=lobby")
            check(await sees(B, "while you were out"), "a message sent while the other phone was closed is there when it opens")

            # late joiner
            D = await page("d", "Niles")
            check(await sees(D, "hello from the relays"), "someone arriving later sees the lobby's recent history")
            await D.screenshot(path=f"{OUT}/05-late.png")

            # what did the relays see?
            events = []
            for port in (7777, 7778):
                with open(f"/tmp/relay-{port}.log") as f:
                    events += [json.loads(l) for l in f if l.strip()]
            blob = json.dumps(events)
            words = ["Seth", "Jamie", "Ollie", "Niles", "hello", "relays", "schnapsen", "cats", "psst", "lobby", "while you were out"]
            leaked = [w for w in words if w.lower() in blob.lower()]
            check(not leaked, f"relays saw none of the names, channels or words ({len(events)} events checked){' — LEAKED: ' + str(leaked) if leaked else ''}")
            byid = {e["id"]: e for e in events}
            pks = [e["pubkey"] for e in byid.values()]
            check(len(set(pks)) == len(pks), f"every one of {len(pks)} distinct events was signed by a different throwaway key")
            sizes = sorted(set(len(e["content"]) for e in events))
            check(len(sizes) <= 6, f"message sizes fall into a few padded buckets ({len(sizes)} distinct)")
            uniq = {}
            for e in events: uniq[e["id"]] = uniq.get(e["id"], 0) + 1
            per = {}
            for port in (7777, 7778):
                with open(f"/tmp/relay-{port}.log") as f: per[port] = sum(1 for l in f if l.strip())
            check(all(v > 0 for v in per.values()), f"traffic is scattered across both relays {per}")

            # dedupe when both carriers deliver (only meaningful with ?local)
            if MODE == "local":
                n = await A.evaluate("__pl.messages('#lobby').get().filter(m => m.text === 'while you were out').length")
                check(n == 1, "a message delivered both directly and by relay shows once")
            bad = [e for e in errs if "favicon" not in e]
            check(not bad, "no page errors" + ("" if not bad else ": " + " | ".join(bad[:5])))
            await b.close()
    finally:
        for pr in procs: pr.terminate()
        srv.terminate()
    good = sum(1 for c, _ in results if c)
    print(f"\n{good}/{len(results)} passed ({MODE})")

asyncio.run(main())
