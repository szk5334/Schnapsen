// Unit tests for the crypto layer: signatures, tampering, keys, padding, sealed inbox, tags.
const mem = new Map();
globalThis.localStorage = { getItem: k => (mem.has(k) ? mem.get(k) : null), setItem: (k, v) => mem.set(k, String(v)), removeItem: k => mem.delete(k), key: i => [...mem.keys()][i] };
Object.defineProperty(globalThis.localStorage, "length", { get: () => mem.size });
globalThis.location = { search: "" };
const C = await import("../src/crypto.js");

let pass = 0, fail = 0;
const ok = (c, msg) => { if (c) pass++; else { fail++; console.log("FAIL", msg); } };

const me = await C.identity();
ok(/^[0-9a-f]{16}$/.test(me.id), "id is 16 hex");

const m = await C.signMsg({ t: "msg", id: "x1", ch: "#lobby", ts: 1, name: "Seth", text: "hello" });
ok(await C.verifyMsg(m), "honest message verifies");
ok(!(await C.verifyMsg({ ...m, text: "hellp" })), "edited text rejected");
ok(!(await C.verifyMsg({ ...m, name: "Jamie" })), "changed name rejected");
ok(!(await C.verifyMsg({ ...m, ch: "#other" })), "moved to another channel rejected");
ok(!(await C.verifyMsg({ ...m, fid: "0000000000000000" })), "claimed id that doesn't match the key rejected");
ok(!(await C.verifyMsg({ ...m, sig: m.sig.slice(0, -4) + "AAAA" })), "corrupted signature rejected");

// someone else's key claiming my id
mem.clear(); const C2 = await import("../src/crypto.js?2"); const other = await C2.identity();
const forged = await C2.signMsg({ t: "msg", id: "x2", ch: "#lobby", ts: 2, name: "Seth", text: "it's me, honest" });
ok(await C.verifyMsg(forged), "other identity's own message verifies");
ok(forged.fid !== me.id, "but it carries a different id — names can't borrow ids");
ok(!(await C.verifyMsg({ ...forged, fid: me.id })), "other key claiming my id rejected");

// channel keys
const k1 = await C.channelKeys(C.publicSecret("lobby")), k2 = await C.channelKeys(C.publicSecret("lobby2"));
const box = await C.seal(k1, { a: 1, text: "secret words" });
ok(JSON.stringify(await C.open(k1, box)) === JSON.stringify({ a: 1, text: "secret words" }), "seal/open round trip");
ok((await C.open(k2, box)) === null, "wrong channel key cannot open");
const raw = Uint8Array.from(atob(box), c => c.charCodeAt(0)); raw[20] ^= 1;
ok((await C.open(k1, btoa(String.fromCharCode(...raw)))) === null, "flipped ciphertext bit rejected");
const short = await C.seal(k1, { t: "x" }), long = await C.seal(k1, { t: "x".repeat(150) });
ok(short.length === long.length, "padding hides small length differences");

// private secrets
const s1 = C.newSecret(), s2 = C.newSecret();
ok(s1 !== s2 && s1.length >= 22, "private secrets are random and long");

// tags rotate per hour and per channel
const t1 = await C.tagFor(k1, 100), t2 = await C.tagFor(k1, 101), t3 = await C.tagFor(k2, 100);
ok(t1 !== t2 && t1 !== t3 && t1.length === 32, "tags rotate by hour and differ by channel");

// sealed inbox: only the recipient opens it
const env = await C2.sealTo(me.bpk, { hi: "jamie" });
ok(JSON.stringify(await C.openSealed(env)) === JSON.stringify({ hi: "jamie" }), "recipient opens sealed inbox note");
ok((await C2.openSealed(env)) === null, "sender's own key cannot open it");
ok(!JSON.stringify(env).includes(other.bpk) && !JSON.stringify(env).includes(other.spk), "sealed note carries no sender key on the outside");

// pair secret is symmetric
const a = await C.pairSecret(other.bpk), b = await C2.pairSecret(me.bpk);
ok(Buffer.from(a).equals(Buffer.from(b)), "both sides derive the same private-conversation secret");

console.log(`${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
