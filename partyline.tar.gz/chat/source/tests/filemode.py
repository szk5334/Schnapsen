import asyncio, subprocess, time, os
from playwright.async_api import async_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
async def main():
    r = subprocess.Popen(["node", f"{HERE}/relay.mjs", "7790", "/tmp/relay-7790.log"], stdout=subprocess.DEVNULL); time.sleep(1)
    try:
        async with async_playwright() as p:
            b = await p.chromium.launch(executable_path="/opt/pw-browsers/chromium-1194/chrome-linux/chrome", args=["--no-sandbox"])
            ctx = await b.new_context(viewport={"width":390,"height":844})
            url = "file://" + os.path.abspath(f"{HERE}/../dist/chat/index.html") + "?nodirect&relay=ws://localhost:7790"
            A = await ctx.new_page(); errs=[]; A.on("pageerror", lambda e: errs.append(str(e)))
            await A.goto(url + "&as=fa"); await A.fill("#nm","Seth"); await A.click("text=Come in"); await A.wait_for_selector(".strip")
            B = await ctx.new_page(); await B.goto(url + "&as=fb"); await B.fill("#nm","Jamie"); await B.click("text=Come in"); await B.wait_for_selector(".strip")
            await A.fill(".composer input","from a saved file"); await A.press(".composer input","Enter")
            await B.wait_for_selector(".msgs >> text=from a saved file", timeout=10000)
            print("ok   runs as a saved file opened from the phone's storage, and messages go through")
            ran = await A.evaluate("""() => { window.__inj = 0; const s = document.createElement('script'); s.textContent = 'window.__inj = 1'; document.body.appendChild(s); return new Promise(r => setTimeout(() => r(window.__inj), 300)); }""")
            print(("ok   " if ran == 0 else "FAIL ") + "an injected script is blocked by the security policy")
            leak = await A.evaluate("""() => new Promise(r => { document.addEventListener('securitypolicyviolation', e => r('blocked by policy: ' + e.violatedDirective), { once: true }); fetch('https://example.com/x').catch(() => {}); setTimeout(() => r('not blocked by policy'), 1500); })""")
            print(("ok   " if leak.startswith('blocked') else "FAIL ") + "the page can't phone home to arbitrary sites (" + leak + ")")
            img = await A.evaluate("""() => new Promise(r => { document.addEventListener('securitypolicyviolation', e => r('blocked by policy: ' + e.violatedDirective), { once: true }); const i = new Image(); i.src = 'https://example.com/pixel.png'; setTimeout(() => r('not blocked by policy'), 1500); })""")
            print(("ok   " if img.startswith('blocked') else "FAIL ") + "tracking pixels are blocked (" + img + ")")
            print("page errors:", errs or "none")
            await b.close()
    finally: r.terminate()
asyncio.run(main())
