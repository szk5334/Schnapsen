/* A tiny NIP-01 relay for testing: EVENT, REQ (kinds, #t, since, limit), CLOSE, EOSE.
 * Stores regular events, forwards ephemeral ones (kind 20000–29999) without storing.
 * Usage: node relay.mjs [port]   — also logs every event so a test can inspect what a relay sees. */
import { WebSocketServer } from "ws";
import { appendFileSync, writeFileSync } from "node:fs";

const port = +(process.argv[2] || 7777);
const LOG = process.argv[3] || "/tmp/relay-" + port + ".log";
writeFileSync(LOG, "");
const store = [];
const subs = new Map();          // ws -> Map(id -> filters)
const match = (f, ev) =>
  (!f.kinds || f.kinds.includes(ev.kind)) &&
  (!f.since || ev.created_at >= f.since) &&
  (!f["#t"] || ev.tags.some(t => t[0] === "t" && f["#t"].includes(t[1])));

const wss = new WebSocketServer({ port });
wss.on("connection", ws => {
  subs.set(ws, new Map());
  ws.on("message", raw => {
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (m[0] === "EVENT") {
      const ev = m[1];
      appendFileSync(LOG, JSON.stringify(ev) + "\n");
      const eph = ev.kind >= 20000 && ev.kind < 30000;
      if (!eph) store.push(ev);
      ws.send(JSON.stringify(["OK", ev.id, true, ""]));
      for (const [c, map] of subs) for (const [id, fs] of map) if (fs.some(f => match(f, ev))) c.send(JSON.stringify(["EVENT", id, ev]));
    } else if (m[0] === "REQ") {
      const [, id, ...fs] = m;
      subs.get(ws).set(id, fs);
      for (const f of fs) {
        const hits = store.filter(ev => match(f, ev)).slice(-(f.limit || 500));
        hits.forEach(ev => ws.send(JSON.stringify(["EVENT", id, ev])));
      }
      ws.send(JSON.stringify(["EOSE", id]));
    } else if (m[0] === "CLOSE") subs.get(ws).delete(m[1]);
  });
  ws.on("close", () => subs.delete(ws));
});
console.log("relay on", port, "log", LOG);
