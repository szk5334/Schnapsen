import React from "react";
import { SUIT_GLYPH, displayRank, isNumbered } from "../state/constants.js";
import { ENG } from "../engine/core.js";

/* The same deck bridge draws — pips and indices, no images, four-colour. Schnapsen only uses five ranks,
   so the ten is the only card that needs a pip pattern at all.

   Every card ALSO carries a plaintext token — the suit glyph then the rank, ♠A, ♥T — which the pip themes
   hide and the TEXT theme shows instead of the card face. One card component, two ways of being looked at.
   The ten becomes a T so that every card in the deck is exactly two characters wide, which is the whole
   point of setting a card game in a monospace font: the hand lines up. */
/* Pip layouts. The ten already had one; the numbered deck needs 2, 3 and 4 as well — a card that says
   "3" and then shows you a single big glyph is a card that has learned nothing from being renamed. All
   coordinates live inside the inlay (x 29-71, y 22-78), which card.test.mjs asserts. */
const PIPS = {
  "10":[[39,30],[61,30],[50,37],[39,44],[61,44],[39,58],[61,58],[50,65],[39,72],[61,72]],
  "2" :[[50,32],[50,68]],
  "3" :[[50,30],[50,50],[50,70]],
  "4" :[[39,32],[61,32],[39,68],[61,68]],
};
const suitClass = (su)=> su==="S"?"s-sp":su==="H"?"s-he":su==="D"?"s-di":"s-cl";
const TXT_RANK = { "10":"T" };                       // A K Q J stay themselves; the ten needs one column
const txt = (r)=> TXT_RANK[r] || displayRank(r);
const Plain = ({c})=>(
  <span className="bc-t" aria-hidden="true"><span className="bc-g">{SUIT_GLYPH[c.suit]}</span>{txt(c.rank)}</span>
);
const Corner = ({rank, glyph, pos})=>(
  <div className={"idx "+pos}><span className="ir">{rank}</span>{glyph!=null && <span className="is">{glyph}</span>}</div>
);

function Card({c, faceDown, onClick, disabled, selected, small, showVal}){
  if(faceDown || !c || c.back) return <div onClick={onClick} className={"brback"+(small?" sm":"")} style={{cursor:onClick?"pointer":"default"}}/>;
  const g = SUIT_GLYPH[c.suit];
  const cls = ["brcard", suitClass(c.suit), small?"sm":"", selected?"sel":"",
               (onClick&&!disabled)?"clk":"", disabled?"dis":""].filter(Boolean).join(" ");
  /* the twinkle phase. Derived from the card's id, so it is stable for the life of the card and every
     card in the hand is at a different point in its gradient — twenty cards, twenty phases, no marching
     in step. A random() here would reshuffle on every render and the whole deck would strobe. */
  const phase = ((c.id * 2654435761) >>> 0) % 1000 / 1000;
  const shown = displayRank(c.rank);                    // "K" or "4", depending on the deck you chose
  const pips  = PIPS[shown];
  const idxGlyph = (shown.length > 1) ? null : g;       // the ten has no room for a suit under its index
  let center;
  if(c.rank==="A") center = <div className="ctr"><span className="pip ace" style={{left:"50%",top:"50%"}}>{g}</span></div>;
  else if(pips) center = <div className="ctr">{pips.map(([x,y],i)=>(
    <span key={i} className={"pip"+(y>50?" flip":"")} style={{left:x+"%",top:y+"%"}}>{g}</span>))}</div>;
  else center = <div className="mid fc">{shown}</div>;
  return (
    <div onClick={disabled?undefined:onClick} className={cls} style={{"--tw": (-phase * 6).toFixed(2) + "s"}}>
      {/* the inlay: equidistant from the card edge on all four sides. The corner indices had to shrink
          to make room — a uniformly-inset rectangle CANNOT clear an index that is 11px wide on a 42px
          card without collapsing to 12px across. Geometry, not taste. */}
      <div className="inlay" aria-hidden="true"/>
      <Corner rank={shown} glyph={idxGlyph} pos="tl"/>
      <Corner rank={shown} glyph={idxGlyph} pos="br"/>
      {center}
      <Plain c={c}/>
      {showVal && <span className="val num">{ENG.CARDVAL[c.rank]}</span>}
    </div>
  );
}
export { Card, PIPS, suitClass, TXT_RANK };
