/* =======================================================================
   SCHNAPSEN CORE — 20 cards, French-suited.
   A(11) 10(10) K(4) Q(3) J(2).  Rank A > 10 > K > Q > J.  120 card points in the deck.
   ===================================================================== */

const ENG = (function(){
  const SUITS = ["S","H","D","C"];                 // display order

  /* ------------------------------------------------------------------ THE PACK
   * Two packs. "classic": Schnapsen's 20 (five ranks). "royal" (Royal House, Nov 2026): 32 cards, eight ranks,
   * A 10 K Q J 4 3 2 worth 21 20 14 13 12 4 3 2 (356 in the pack; every court is its 2/3/4 twin plus ten), 200 to go
   * out, 100 the Schneider line. The deck is a match-level choice held here, as the 22/24-card decks once were:
   * the reducer, the bot and the match set it before they touch the engine. Every variant name that isn't
   * "royal" means the 20-card pack (old saves and older peers that still say "22"/"24" included). */
  const PACKS = {
    classic: { ranks:["J","Q","K","10","A"],
               power:{ J:1, Q:2, K:3, "10":4, A:5 },
               val:{ J:2, Q:3, K:4, "10":10, A:11 },
               points:120, out:66, half:33, swap:["J"],
               melds:[{ kind:"KQ", ranks:["K","Q"] }] },
    royal:   { ranks:["2","3","4","J","Q","K","10","A"],
               power:{ "2":1, "3":2, "4":3, J:4, Q:5, K:6, "10":7, A:8 },
               val:{ "2":2, "3":3, "4":4, J:12, Q:13, K:14, "10":20, A:21 },
               points:356, out:200, half:100, swap:["2","J"],
               melds:[{ kind:"KQ", ranks:["K","Q"] }, { kind:"34", ranks:["4","3"] }] },
  };
  let _v = "classic";
  const normVariant = (v)=> v==="royal" ? "royal" : "classic";
  function setVariant(v){ _v = normVariant(v); }
  function getVariant(){ return _v; }
  const P = ()=> PACKS[_v];
  const isRoyal = ()=> _v==="royal";
  function ranks(){ return P().ranks; }
  function handSize(){ return 5; }
  /* The trump card(s) that may swap for the turn-up: the J (the classic "2") in the 20-card pack; the 2 or the J
   * in Royal House (lowest first: a player holding both gives the 2). */
  function exchangeRanks(){ return P().swap; }
  function exchangeRank(){ return P().swap[0]; }
  function inDeck(r){ return P().ranks.indexOf(r)!==-1; }
  /* The pack, in a fixed order: suit by suit, low to high. */
  function cards(){
    const out=[];
    for(const s of SUITS) for(const r of P().ranks) out.push({ rank:r, suit:s });
    return out;
  }

  /* RANKVAL / CARDVAL keep their classic shape for old callers; power() and val() read the active pack. */
  const RANKVAL = PACKS.classic.power;
  const CARDVAL = PACKS.classic.val;

  let _uid = 1;
  function makeDeck(){
    return cards().map(c=>({ id:_uid++, rank:c.rank, suit:c.suit }));
  }
  function shuffle(a, rnd){
    a=a.slice(); const R = rnd || Math.random;
    for(let i=a.length-1;i>0;i--){ const j=(R()*(i+1))|0; const t=a[i]; a[i]=a[j]; a[j]=t; }
    return a;
  }
  const val   = (c)=> P().val[c.rank];
  const power = (c)=> P().power[c.rank];
  const key   = (c)=> c.rank+"."+c.suit;

  /* Does `b` (the follow) beat `a` (the lead)? */
  function follows(a, b, trump){
    if(b.suit===a.suit) return power(b) > power(a);
    return b.suit===trump;                         // a trump on a non-trump lead
  }
  /* Winner of a two-card trick. led = the leader's card, fol = the follower's. */
  function trickWinner(led, fol, trump, ledSeat, folSeat){
    return follows(led, fol, trump) ? folSeat : ledSeat;
  }

  /* ---------------- LEGAL PLAYS ----------------
   * While the stock is OPEN you may play anything at all — that freedom is the whole first half of
   * Schnapsen. The moment the stock is exhausted OR closed, three obligations bite, IN ORDER:
   *   1. follow suit,
   *   2. and if you can beat the led card in that suit, you must,
   *   3. if you are void in the led suit you must trump (any trump; there is only one card to beat).
   * Only when you can do none of those may you throw whatever you like.
   */
  /* `mode`: false / "free" = anything; "follow" (Royal House's middle phase) = follow suit if you can, otherwise
   * anything; true / "strict" = all three obligations. */
  function legalFollows(hand, led, trump, mode){
    if(!mode || mode==="free") return hand.slice();
    const suited = hand.filter(c=>c.suit===led.suit);
    if(mode==="follow") return suited.length ? suited : hand.slice();
    if(suited.length){
      const higher = suited.filter(c=>power(c) > power(led));
      // heading the trick is only required among cards of the led suit
      if(led.suit===trump) return higher.length ? higher : suited;
      return higher.length ? higher : suited;
    }
    const trumps = hand.filter(c=>c.suit===trump);
    if(trumps.length) return trumps;
    return hand.slice();
  }
  /* ---------------- MARRIAGES ----------------
   * A marriage is named by a KEY. The K + Q of a suit is the suit itself ("H"), exactly as before, so classic
   * logs, saves and messages are unchanged. Royal House adds the common marriage, the 4 + 3 of a suit, keyed
   * "H3". Each key can be declared once per deal by each player. */
  const meldKey   = (suit, kind)=> kind==="34" ? suit+"3" : suit;
  const meldSuitOf = (key)=> key ? key[0] : null;
  const meldKindOf = (key)=> key && key.length>1 ? "34" : "KQ";
  const meldRanks  = (key)=> meldKindOf(key)==="34" ? ["4","3"] : ["K","Q"];
  const isMeldCard = (c, key)=> c.suit===meldSuitOf(key) && meldRanks(key).indexOf(c.rank)!==-1;
  /* The marriage a card belongs to (its key), in the active pack, or null. */
  function meldKeyOf(c){
    for(const m of P().melds) if(m.ranks.indexOf(c.rank)!==-1) return meldKey(c.suit, m.kind);
    return null;
  }
  /* The other half of a card's marriage. */
  function partnerRank(c){
    for(const m of P().melds){ const i = m.ranks.indexOf(c.rank); if(i!==-1) return m.ranks[1-i]; }
    return null;
  }

  /* Leading is free, EXCEPT immediately after declaring a marriage: you must lead one of its two cards. */
  function legalLeads(hand, meldSuit){
    if(!meldSuit) return hand.slice();
    return hand.filter(c=>isMeldCard(c, meldSuit));
  }

  /* Which marriages does this hand hold? Keys, high marriage (K + Q) first. */
  function marriagesIn(hand){
    const out=[];
    for(const m of P().melds) for(const su of SUITS){
      if(m.ranks.every(r=>hand.some(c=>c.suit===su && c.rank===r))) out.push(meldKey(su, m.kind));
    }
    return out;
  }
  /* MARRIAGE VALUES (Seth, Nov 2026). "classic" is 20 / 40. "34" is 17 / 34: the royal marriage is made of the
   * 3 and the 4 of trumps, so it scores 34, and a plain marriage is half of it. 34 still clears Schneider (33)
   * on its own. HOUSE RULES PLAY 17/34 (Seth, Nov 10 2026); classic tables keep 20/40.
   * ROYAL HOUSE (32 cards): the royal marriage K + Q is 40, 80 in trumps; the common marriage 4 + 3 is 20, 40 in
   * trumps. meldValue(key, trump, d) reads the deal: Royal House by the pack, else `d.marriages` if set
   * (experiments), else 17/34 when `d.house`, else the module default (classic unless setMarriages says otherwise). */
  const MARRIAGES = { classic:{ plain:20, royal:40 }, "34":{ plain:17, royal:34 } };
  const ROYAL_MELDS = { KQ:{ plain:40, royal:80 }, "34":{ plain:20, royal:40 } };
  let _marr = "classic";
  const normMarriages = (m)=> MARRIAGES[m] ? m : "classic";
  function setMarriages(m){ _marr = normMarriages(m); }
  function getMarriages(){ return _marr; }
  const marriagesOf = (d)=> isRoyal() ? "royal" : d && d.marriages ? normMarriages(d.marriages) : d && d.house ? "34" : _marr;
  const meldValue = (key, trump, d)=>{
    const su = meldSuitOf(key);
    const m = isRoyal() ? ROYAL_MELDS[meldKindOf(key)] : MARRIAGES[marriagesOf(d)];
    return su===trump ? m.royal : m.plain;
  };

  const sortDisplay = (hand, trump)=> hand.slice().sort((a,b)=>{
    const ta = a.suit===trump ? 1:0, tb = b.suit===trump ? 1:0;
    if(ta!==tb) return tb-ta;                                  // trumps first
    const sa=SUITS.indexOf(a.suit), sb=SUITS.indexOf(b.suit);
    if(sa!==sb) return sa-sb;
    return power(a)-power(b);                                  // low -> high inside a suit
  });

  const api = { SUITS, RANKVAL, CARDVAL,
           makeDeck, shuffle, val, power, key, follows, trickWinner,
           legalFollows, legalLeads, marriagesIn, meldValue, sortDisplay,
           setVariant, getVariant, normVariant, handSize, exchangeRank, inDeck, cards,
           setMarriages, getMarriages, normMarriages, marriagesOf,
           isRoyal, exchangeRanks, meldKey, meldSuitOf, meldKindOf, meldRanks, isMeldCard, meldKeyOf, partnerRank };
  /* RANKS: the five ranks, low to high (a getter, as when it tracked the deck variant). */
  Object.defineProperty(api, "RANKS", { get: ranks, enumerable:true });
  /* The pack's numbers, also getters: DECK_POINTS 120 / 356, OUT (going out) 66 / 200, HALF (Schneider) 33 / 100. */
  Object.defineProperty(api, "DECK_POINTS", { get: ()=> P().points, enumerable:true });
  Object.defineProperty(api, "OUT",  { get: ()=> P().out,  enumerable:true });
  Object.defineProperty(api, "HALF", { get: ()=> P().half, enumerable:true });
  return api;
})();

export { ENG };
