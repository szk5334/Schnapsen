import { ENG } from "./core.js";

/* =======================================================================
   RULES — one deal of Schnapsen, as a state machine.

   The deal object (the part the engine owns):

     trump        "S"|"H"|"D"|"C"
     up           the face-up trump card (conceptually the LAST card of the stock), or null once drawn
     stock        the face-DOWN cards, stock[0] = next to draw.  total left = stock.length + (up?1:0)
     hands        {0:[card], 1:[card]}
     trick        [] | [{seat,card}]         (at most one entry — the lead — before it resolves)
     turn         seat to act
     lead         seat on lead for this trick
     closed       bool          — someone flipped the turn-up
     closedBy     seat|null
     closeSnap    {pts,tricks}  — the OPPONENT's state at the moment of closing (this is what they score by)
     meldSuit     suit|null     — you just declared; you must now lead its K or Q
     meldedSuits  [Set,Set]     — a marriage may only be declared once
     reveals      [{seat,id}]   — cards PUBLICLY known to be in a hand (the turn-up, however it was taken)
     trickPts     [n,n]         — points taken in tricks
     meldPts      [n,n]         — points declared (they only COUNT once you have won a trick)
     tricksWon    [n,n]
     phase        "play" | "scored"

   THE ONE NON-OBVIOUS RULE, and everything downstream depends on it:
   marriage points are worthless until you win a trick — so a player's real score is
   `effPts`, never `trickPts + meldPts`.
   ===================================================================== */

/* The target and the Schneider line belong to the pack (66 / 33, or Royal House's 200 / 100): read them live. */
const out = ()=> ENG.OUT;
const half = ()=> ENG.HALF;
const other = (p)=> p^1;

/* A player's score AS IT COUNTS. Melds are provisional: 40 declared with no trick yet is 0. */
function effPts(d, p){ return d.trickPts[p] + (d.tricksWon[p] > 0 ? d.meldPts[p] : 0); }
/* The stock is "open" until it runs dry or someone closes it. Strict play begins the instant it isn't. */
function stockLeft(d){ return d.stock.length + (d.up ? 1 : 0); }
function isStrict(d){ return d.closed || stockLeft(d)===0; }
/* ROYAL HOUSE plays the stock in two piles: the first 10 face-down cards (pile A, five tricks of FREE play), then
 * the last 11 and the turn-up (pile B, six tricks where you must FOLLOW suit), then STRICT play for the last five
 * tricks. Closing goes straight to strict. The 20-card game has only free and strict. */
const FOLLOW_AT = 11;
function playMode(d){
  if(isStrict(d)) return "strict";
  if(ENG.isRoyal() && d.stock.length <= FOLLOW_AT) return "follow";
  return "free";
}
/* THE DOUBLE (Royal House). `cube` is what the deal is worth (1, 2, 4, ...); `cubeOwner` the only player who may
 * double next (null: either); `offer` the seat whose double is waiting for an answer. Absent on a 20-card deal. */
const cubeOf = (d)=> d.cube || 1;

function newDeal(dealer, rnd){
  const h = ENG.handSize();                          // 5 (classic) or 6 (24-card)
  const deck = ENG.shuffle(ENG.makeDeck(), rnd);
  const hands = { 0:deck.slice(0,h), 1:deck.slice(h,2*h) };
  const up = deck[2*h];
  const stock = deck.slice(2*h+1);                    // classic 9 face-down, 24-card 11
  return {
    trump: up.suit, up, stock, hands,
    trick: [], turn: other(dealer), lead: other(dealer),   // forehand (non-dealer) leads
    closed:false, closedBy:null, closeSnap:null,
    meldSuit:null, meldedSuits:[[],[]],
    trickPts:[0,0], meldPts:[0,0], tricksWon:[0,0],
    lastTrick:null, dealer, phase:"play", result:null,
    reveals:[], log:[],
  };
}

/* ---------------- what may I do right now? ---------------- */
/* The trump card this player would give for the turn-up, or null. Royal House: the 2 or the J of trumps (the 2
 * first), never when the turn-up is itself the 2 or the J (they can't swap for each other), and only once a deal:
 * the first exchange is the only one. */
function exchangeCard(d, p){
  const rs = ENG.exchangeRanks();
  if(ENG.isRoyal()){
    if(d.up && d.up.suit===d.trump && rs.indexOf(d.up.rank)!==-1) return null;
    if((d.log||[]).some(e=>e.k==="exchange")) return null;
  }
  for(const r of rs){ const c = d.hands[p].find(x=>x.suit===d.trump && x.rank===r); if(c) return c; }
  return null;
}
function canExchange(d, p){
  if(d.phase!=="play" || d.turn!==p || d.trick.length || d.offer!=null) return false;
  if(d.closed || !d.up || d.meldSuit) return false;
  return !!exchangeCard(d, p);
}
function canClose(d, p){
  if(d.phase!=="play" || d.turn!==p || d.trick.length || d.offer!=null) return false;
  return !d.closed && !!d.up && !d.meldSuit;
}
function meldOptions(d, p){
  if(d.phase!=="play" || d.turn!==p || d.trick.length || d.meldSuit || d.offer!=null) return [];
  return ENG.marriagesIn(d.hands[p])
    .filter(k => d.meldedSuits[p].indexOf(k)===-1)
    .map(k => ({ suit:k, key:k, kind:ENG.meldKindOf(k), value: ENG.meldValue(k, d.trump, d) }));
}
function canClaim(d, p){
  return d.phase==="play" && d.turn===p && d.trick.length===0 && d.offer==null;
}
function legalCards(d, p){
  if(d.phase!=="play" || d.turn!==p || d.offer!=null) return [];
  if(d.trick.length===0) return ENG.legalLeads(d.hands[p], d.meldSuit);
  return ENG.legalFollows(d.hands[p], d.trick[0].card, d.trump, playMode(d));
}
/* Royal House: on your lead, before you play (and before declaring), while the stock is open, you may double if
 * the cube is in the middle or yours. */
function canDouble(d, p){
  if(!ENG.isRoyal() || d.phase!=="play" || d.turn!==p || d.trick.length || d.offer!=null) return false;
  if(d.closed || stockLeft(d)===0 || d.meldSuit) return false;
  return d.cubeOwner==null || d.cubeOwner===p;
}
const canAnswer = (d, p)=> d.phase==="play" && d.offer!=null && d.offer!==p && d.turn===p;

/* ---------------- the moves ---------------- */
function exchange(d, p){
  if(!canExchange(d,p)) return d;
  const j = exchangeCard(d, p);
  const upc = d.up;
  d.hands[p] = d.hands[p].filter(c=>c.id!==j.id).concat([upc]);
  d.up = j;
  /* Your opponent WATCHED you take that card. It is not a secret, and a bot that re-deals it into the
   * face-down stock when it samples is fooling itself. Record every public acquisition of the turn-up. */
  d.reveals = d.reveals.concat([{ seat:p, id:upc.id }]);
  d.log = (d.log||[]).concat([{ k:"exchange", seat:p, card:upc, gave:j }]);
  return d;
}
function close(d, p){
  if(!canClose(d,p)) return d;
  const o = other(p);
  d.closed = true; d.closedBy = p;
  /* THE SNAPSHOT. A closer is scored against where the opponent stood WHEN THE STOCK WAS CLOSED, not
   * where they end up — so shutting someone out and then letting them scrape a trick back still pays 3.
   * It is also what they pay if the close fails. Take it here, once, and never recompute it. */
  d.closeSnap = { pts: effPts(d,o), tricks: d.tricksWon[o] };
  d.log = (d.log||[]).concat([{ k:"close", seat:p, oppPts:d.closeSnap.pts, oppTricks:d.closeSnap.tricks }]);
  return d;
}
/* "Double." The other player must now accept (the deal is worth twice as much, and only they may double next)
 * or decline (the deal ends: the doubler wins it at its value before the double). */
function double(d, p){
  if(!canDouble(d,p)) return d;
  d.offer = p; d.turn = other(p);
  d.log = (d.log||[]).concat([{ k:"double", seat:p, cube:cubeOf(d) }]);
  return d;
}
function take(d, p){
  if(!canAnswer(d,p)) return d;
  d.cube = cubeOf(d) * 2; d.cubeOwner = p; d.turn = d.offer; d.offer = null;
  d.log = (d.log||[]).concat([{ k:"take", seat:p, cube:d.cube }]);
  return d;
}
function drop(d, p){
  if(!canAnswer(d,p)) return d;
  const w = d.offer;
  d.offer = null;
  d.log = (d.log||[]).concat([{ k:"drop", seat:p, cube:cubeOf(d) }]);
  return finish(d, { reason:"drop", winner:w });
}
function meld(d, p, key, opts){
  if(!meldOptions(d,p).some(m=>m.suit===key)) return d;
  const v = ENG.meldValue(key, d.trump, d);
  const suit = ENG.meldSuitOf(key), kind = ENG.meldKindOf(key);
  d.meldPts[p] += v;
  d.meldedSuits[p] = d.meldedSuits[p].concat([key]);
  d.meldSuit = key;                        // you must now lead one of its two cards
  d.log = (d.log||[]).concat([{ k:"meld", seat:p, suit, value:v, counts:d.tricksWon[p]>0, ...(kind==="34" ? { kind, key } : {}) }]);
  /* A marriage can take you out on the spot — and when it does the deal ends THERE, with the trick
   * never played. (Close the stock, lead the trump ace, declare 40, and you are home.) */
  if(!(opts && opts.strictClaim) && effPts(d,p) >= out()) return finish(d, { reason:"claim", claimant:p });
  return d;
}

/* Play one card. Resolves the trick, draws, and ends the deal when it should.
 * `autoClaim` — the app counts for you, so reaching 66 ends the deal in your favour immediately.
 * With strict claiming ON you must press "Declare 66" yourself, exactly as at a real table. */
function play(d, p, cardId, opts){
  if(d.phase!=="play" || d.turn!==p) return d;
  const legal = legalCards(d, p);
  const c = legal.find(x=>x.id===cardId);
  if(!c) return d;
  const autoClaim = !(opts && opts.strictClaim);

  d.hands[p] = d.hands[p].filter(x=>x.id!==c.id);

  if(d.trick.length===0){                                   // ---- the lead ----
    d.trick = [{ seat:p, card:c }];
    d.meldSuit = null;
    d.turn = other(p);
    return d;
  }

  // ---- the follow: resolve ----
  const ledSeat = d.trick[0].seat, led = d.trick[0].card;
  const w = ENG.trickWinner(led, c, d.trump, ledSeat, p);
  const l = other(w);
  const pts = ENG.val(led) + ENG.val(c);
  d.trickPts[w] += pts;
  d.tricksWon[w] += 1;
  d.lastTrick = { trick:[d.trick[0], {seat:p, card:c}], winner:w, pts };
  d.log = (d.log||[]).concat([{ k:"trick", lead:ledSeat, led, fol:c, winner:w, pts }]);
  d.trick = [];
  d.turn = w; d.lead = w;

  // ---- the draw (winner first, loser second; the turn-up is always the very last card) ----
  if(!d.closed && stockLeft(d) > 0){
    for(const who of [w, l]){
      if(d.stock.length)      d.hands[who].push(d.stock.shift());
      else if(d.up){
        d.hands[who].push(d.up);
        d.reveals = d.reveals.concat([{ seat:who, id:d.up.id }]);
        d.log = d.log.concat([{ k:"tookup", seat:who, card:d.up }]);   // public: everyone saw who took the turn-up
        d.up = null;
      }
    }
  }

  if(autoClaim && effPts(d, w) >= out()) return finish(d, { reason:"claim", claimant:w });
  if(d.hands[0].length===0 && d.hands[1].length===0)
    return finish(d, { reason: d.closed ? "closedOut" : "exhausted" });
  return d;
}

/* Declaring 66. Right → you win. Wrong → you have just handed the deal away.  */
function claim(d, p){
  if(!canClaim(d,p)) return d;
  return finish(d, { reason:"claim", claimant:p });
}

/* ---------------- HOW THE DEAL IS SCORED ----------------
 *
 * A deal ends one of three ways, and each pays differently:
 *
 *   claim      someone declared 66.  Right: 3 / 2 / 1 by how badly the loser is beaten.
 *                                    Wrong: the OPPONENT takes 2 (3 if they hold no tricks).
 *   exhausted  the stock ran out and nobody ever got to 66 — the last trick wins the deal, flat 1.
 *   closedOut  a closed deal ran to the end of the cards.  The closer needed 66 and either has it or hasn't.
 *
 * And the one rule everybody gets wrong: A CLOSER IS PAID BY THE SNAPSHOT. Both the reward for a
 * successful close and the penalty for a failed one read `closeSnap` — the opponent's position at the
 * moment the turn-up went face down — never their final position.
 */
function gpForWin(d, winner){
  const loser = other(winner);
  if(d.closed && d.closedBy===winner){                        // a successful close
    const s = d.closeSnap || { pts:effPts(d,loser), tricks:d.tricksWon[loser] };
    if(s.tricks===0) return 3;
    if(s.pts < half()) return 2;
    return 1;
  }
  if(d.closed && d.closedBy===loser){                         // a FAILED close — the closer pays
    const s = d.closeSnap || { pts:0, tricks:d.tricksWon[winner] };
    return s.tricks===0 ? 3 : 2;                              // "you shut me out and STILL didn't make it"
  }
  const lp = effPts(d, loser);                                // an ordinary deal
  if(d.tricksWon[loser]===0) return 3;                        // schwarz — not a single trick
  if(lp < half()) return 2;                                   // schneider
  return 1;
}

function finish(d, how){
  let winner, gp, head, why;
  const OUT = out();
  if(how.reason==="drop"){
    /* A declined double: the doubler wins the deal at its value before the double. No Schneider, no Schwarz. */
    winner = how.winner; gp = cubeOf(d);
    head = "The double was declined";
    why  = gp > 1 ? `The deal was worth ${gp}.` : "";
  } else if(how.reason==="claim"){
    const p = how.claimant, o = other(p);
    if(effPts(d,p) >= OUT){
      winner = p; gp = gpForWin(d, p);
      head = `${OUT} — declared and made`;
      why  = `${effPts(d,p)} card points.`;
    } else {
      winner = o;
      gp = (d.closed && d.closedBy===p)
        ? gpForWin(d, o)
        : (d.tricksWon[o]===0 ? 3 : 2);
      head = "A false claim";
      why  = `Declared ${OUT} holding only ${effPts(d,p)}.`;
    }
  } else if(how.reason==="closedOut"){
    const p = d.closedBy, o = other(p);
    if(effPts(d,p) >= OUT){ winner = p; gp = gpForWin(d, p); head = "The close came home"; why = `${effPts(d,p)} card points.`; }
    else { winner = o; gp = gpForWin(d, o); head = "The close failed"; why = `Closed, then finished on ${effPts(d,p)}.`; }
  } else {                                                     // exhausted, nobody ever reached 66
    winner = d.lastTrick ? d.lastTrick.winner : 0;
    gp = 1;
    head = `Neither side reached ${OUT}`;
    why  = "The last trick takes the deal.";
  }
  /* The cube multiplies whatever the deal paid (a declined double has already been paid at the cube's value). */
  const cube = cubeOf(d);
  const base = gp;
  if(how.reason!=="drop") gp = gp * cube;
  d.phase = "scored";
  d.result = {
    winner, gp, head, why, reason: how.reason, ...(d.cube ? { cube, base } : {}),
    pts: [effPts(d,0), effPts(d,1)],
    tricks: [d.tricksWon[0], d.tricksWon[1]],
    closedBy: d.closedBy, closeSnap: d.closeSnap,
    schwarz: d.tricksWon[other(winner)]===0,
  };
  return d;
}

const RULES = { newDeal, effPts, stockLeft, isStrict, playMode, other, cubeOf,
                canExchange, exchangeCard, canClose, canClaim, meldOptions, legalCards, canDouble, canAnswer,
                exchange, close, meld, play, claim, double, take, drop, gpForWin, finish };
/* OUT / HALF follow the pack (66 / 33, or 200 / 100). */
Object.defineProperty(RULES, "OUT",  { get: out,  enumerable:true });
Object.defineProperty(RULES, "HALF", { get: half, enumerable:true });

export { RULES, effPts, stockLeft, isStrict, playMode, other, cubeOf };
