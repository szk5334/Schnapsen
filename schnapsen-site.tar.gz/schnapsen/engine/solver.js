import { ENG } from "./core.js";

/* =======================================================================
   THE ENDGAME SOLVER — exact, not heuristic.

   Once the stock is closed or exhausted there are no more draws, no more hidden information to acquire,
   and at most five tricks left. That is a *finite game*, so it should not be guessed at: this solves it
   outright with alpha-beta over the real rules (follow suit, head the trick, trump when void), including
   marriages, including the 66-ends-it-now rule, and returns the exact game-point outcome.

   Two places use it, and the difference between them is the whole design:

     • STOCK EXHAUSTED — the opponent's hand is *deducible* (20 cards, all of them accounted for). The
       solve is genuinely perfect-information, and its answer is the truth, not an estimate. A human
       expert does exactly this, in their head, and it is why the last five tricks decide most deals.

     • STOCK CLOSED — five of the unseen cards are in the opponent's hand and the rest are face-down and
       will never be seen. So we sample: deal the unseen cards many ways, solve each one exactly, and
       average. (bot.js drives that; this file just solves one deal at a time.)

   The value returned is SIGNED GAME POINTS for `me`: +3 is a schwarz for us, -2 is a failed close.
   Nothing is normalised or squashed — the bot is choosing between real outcomes at their real prices.

   Build 2026-11-01.1 fixed two things (the review's own solver had worked around both):
     • HOUSE RULES. An open deal that runs out with nobody on 66 scores nothing at a house table (the pot
       takes it), not "last trick wins 1". The deal object carries `house`, so the solver reads it there.
       Before, the bot fought for a last trick that is worth nothing at those tables.
     • THE MEMO. Alpha-beta values are bounds when the search is cut off, and the memo stored them as if they
       were exact, ignoring the window they came from. It now stores each value with its kind (exact, at
       least, at most) and only reuses it where that is valid. And every first move is searched with the full
       window, so the per-move values the bot AVERAGES over sampled worlds are exact, not cut-off bounds.
   ===================================================================== */

const OUT = ENG.OUT;
const other = (p)=> p^1;

/* The node. Flat, cheap to copy, and it carries exactly what scoring needs and nothing more. */
function nodeFrom(d){
  return {
    h: [d.hands[0].slice(), d.hands[1].slice()],
    trump: d.trump,
    turn: d.turn,
    led: d.trick.length ? d.trick[0].card : null,
    ledSeat: d.trick.length ? d.trick[0].seat : null,
    tp: [d.trickPts[0], d.trickPts[1]],
    mp: [d.meldPts[0], d.meldPts[1]],
    tw: [d.tricksWon[0], d.tricksWon[1]],
    ms: [d.meldedSuits[0].slice(), d.meldedSuits[1].slice()],
    meldSuit: d.meldSuit,
    closed: d.closed, closedBy: d.closedBy,
    closeSnap: d.closeSnap ? { pts:d.closeSnap.pts, tricks:d.closeSnap.tricks } : null,
    lastWinner: d.lastTrick ? d.lastTrick.winner : null,
    house: !!d.house, marriages: ENG.marriagesOf(d),
  };
}
const eff = (n,p)=> n.tp[p] + (n.tw[p] > 0 ? n.mp[p] : 0);

/* The same payout table as rules.js — a closer is judged on the snapshot, everyone else on the finish. */
function gpForWin(n, winner){
  const loser = other(winner);
  if(n.closed && n.closedBy===winner){
    const s = n.closeSnap || { pts:eff(n,loser), tricks:n.tw[loser] };
    if(s.tricks===0) return 3;
    if(s.pts < 33)   return 2;
    return 1;
  }
  if(n.closed && n.closedBy===loser){
    const s = n.closeSnap || { pts:0, tricks:n.tw[winner] };
    return s.tricks===0 ? 3 : 2;
  }
  if(n.tw[loser]===0) return 3;
  if(eff(n,loser) < 33) return 2;
  return 1;
}
/* Out of cards. A closed deal that never reached 66 is a failed close; an open one goes to the last trick
 * (classic) or scores nothing (house rules: no 66, no score). */
function outOfCards(n, me){
  let winner;
  if(n.closed){
    const c = n.closedBy;
    winner = (eff(n,c) >= OUT) ? c : other(c);
  } else {
    if(n.house) return 0;
    winner = (n.lastWinner!=null) ? n.lastWinner : n.turn;
  }
  const gp = n.closed ? gpForWin(n, winner) : 1;
  return winner===me ? gp : -gp;
}

const idsOf = (a)=> { let s=""; for(let i=0;i<a.length;i++) s += a[i].id + ","; return s; };
function keyOf(n){
  return idsOf(n.h[0]) + "|" + idsOf(n.h[1]) + "|" + n.turn + "|" + (n.led?n.led.id:0) + "|" +
         n.tp[0] + "," + n.tp[1] + "|" + n.mp[0] + "," + n.mp[1] + "|" + n.tw[0] + "," + n.tw[1] + "|" +
         (n.meldSuit||"-") + "|" + n.ms[0].join("") + "," + n.ms[1].join("");
}

/* Play one card in a node; returns the child. Melds are folded in here: leading the K or Q of a marriage
 * you still hold declares it, which is never worse than not declaring, so the search does it for free. */
function step(n, card, me){
  const p = n.turn;
  const c = { h:[n.h[0].slice(), n.h[1].slice()], trump:n.trump, turn:n.turn, led:n.led, ledSeat:n.ledSeat,
              tp:n.tp.slice(), mp:n.mp.slice(), tw:n.tw.slice(),
              ms:[n.ms[0].slice(), n.ms[1].slice()], meldSuit:n.meldSuit,
              closed:n.closed, closedBy:n.closedBy, closeSnap:n.closeSnap, lastWinner:n.lastWinner, house:n.house, marriages:n.marriages };
  c.h[p] = c.h[p].filter(x=>x.id!==card.id);

  if(c.led===null){                                   // ---- leading ----
    if((card.rank==="K"||card.rank==="Q") && c.ms[p].indexOf(card.suit)===-1
       && c.h[p].some(x=>x.suit===card.suit && (x.rank==="K"||x.rank==="Q"))){
      c.mp[p] += ENG.meldValue(card.suit, c.trump, c);
      c.ms[p] = c.ms[p].concat([card.suit]);
      /* 66 ON THE DECLARATION. The deal stops right here — the trick is never finished. */
      if(eff(c,p) >= OUT) return { done:true, v: (p===me ? gpForWin(c,p) : -gpForWin(c,p)) };
    }
    c.led = card; c.ledSeat = p; c.meldSuit = null; c.turn = other(p);
    return { done:false, n:c };
  }

  // ---- following: the trick resolves ----
  const w = ENG.trickWinner(c.led, card, c.trump, c.ledSeat, p);
  c.tp[w] += ENG.val(c.led) + ENG.val(card);
  c.tw[w] += 1;
  c.lastWinner = w;
  c.led = null; c.ledSeat = null; c.turn = w;
  if(eff(c,w) >= OUT) return { done:true, v: (w===me ? gpForWin(c,w) : -gpForWin(c,w)) };
  if(c.h[0].length===0 && c.h[1].length===0) return { done:true, v: outOfCards(c, me) };
  return { done:false, n:c };
}

function movesFor(n){
  const p = n.turn;
  if(n.led===null) return ENG.legalLeads(n.h[p], n.meldSuit);
  return ENG.legalFollows(n.h[p], n.led, n.trump, true);   // the solver only ever runs in strict play
}

/* Alpha-beta. `me` maximises; the opponent minimises. Budgeted, because this runs on a phone.
 * Fail-soft, with a memo that remembers what kind of value it stored: EXACT inside the window, LOWER (the true
 * value is at least this) after a cut-off, UPPER (at most this) when nothing beat alpha. `me` is fixed for a
 * whole solve and the memo lives for one solve, so the key needs no `me`. */
const EXACT = 0, LOWER = 1, UPPER = 2;
function search(n, me, alpha, beta, memo, budget){
  if(budget.n++ > budget.cap) return null;                 // give up honestly rather than stall the UI
  const k = keyOf(n);
  const hit = memo.get(k);
  if(hit !== undefined){
    if(hit.f === EXACT) return hit.v;
    if(hit.f === LOWER){ if(hit.v >= beta) return hit.v; if(hit.v > alpha) alpha = hit.v; }
    else               { if(hit.v <= alpha) return hit.v; if(hit.v < beta) beta = hit.v; }
    if(alpha >= beta) return hit.v;
  }
  const a0 = alpha, b0 = beta;

  const maxing = (n.turn===me);
  const mv = movesFor(n);
  let best = maxing ? -Infinity : Infinity;

  for(const card of mv){
    const r = step(n, card, me);
    let v;
    if(r.done) v = r.v;
    else { v = search(r.n, me, alpha, beta, memo, budget); if(v===null) return null; }
    if(maxing){ if(v > best) best = v; if(best > alpha) alpha = best; }
    else      { if(v < best) best = v; if(best < beta)  beta  = best; }
    if(alpha >= beta) break;
  }
  memo.set(k, { v:best, f: best <= a0 ? UPPER : best >= b0 ? LOWER : EXACT });
  return best;
}

/* Solve the position for `me`. Returns { card, value, moves:[{card,value}] } — the per-move values are
 * signed game points from `me`'s point of view: +3 means "this line wins the deal three ways". Every first
 * move gets the full window, so every value in `moves` is exact (the bot averages them across worlds). */
function solve(deal, me, cap){
  const n0 = nodeFrom(deal);
  const memo = new Map();
  const budget = { n:0, cap: cap || 120000 };
  const mv = movesFor(n0);
  if(!mv.length) return null;

  const scored = [];
  for(const card of mv){
    const r = step(n0, card, me);
    let v;
    if(r.done) v = r.v;
    else { v = search(r.n, me, -Infinity, Infinity, memo, budget); if(v===null) return null; }
    scored.push({ card, value:v });
  }
  scored.sort((a,b)=> b.value - a.value);
  return { card: scored[0].card, value: scored[0].value, moves: scored };
}

export { solve, nodeFrom, gpForWin, eff as nodeEff };
