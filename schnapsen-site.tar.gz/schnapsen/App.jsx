import React, { useReducer, useEffect, useRef } from "react";
import { ENG } from "./engine/core.js";
import { RULES, effPts, stockLeft, isStrict, other } from "./engine/rules.js";
import { SETUP, reducer, botAction } from "./state/reducer.js";
import { who, seatPersona, PROFILES } from "./state/personas.js";
import { SUIT_GLYPH, setRankMode, displayRank } from "./state/constants.js";
import { THEME_CSS } from "./ui/css.js";
import { UIErrorBoundary } from "./ui/errorBoundary.jsx";
import { Hand } from "./ui/hand.jsx";
import { StatusBar, TabBar, OppStrip, YouStrip, StockZone, TrickZone, ActionBar, ScoreSheet, HighScores, G } from "./ui/table.jsx";
import { Log } from "./ui/log.jsx";
import { TalkDock } from "./ui/chat.jsx";
import { PointsSummary, ReplayDeck, useBanking, PlayPointsHUD, CoachLog, useDealGrades } from "./ui/score.jsx";
import { FxLayer, fxBurst, fxFly, fxStream } from "./ui/fx.jsx";
import { AmbientRain, TrickRain, Fireworks } from "./ui/rain.jsx";
import { Setup, RulesScreen, Seg } from "./ui/setup.jsx";
import { OnlineBar, OnlineScreens, SpectatorView, useGameNet } from "./ui/online.js";
import { loadTheme, saveTheme, loadInitials, saveInitials, loadSettings, saveSettings, loadCampaign, saveCampaign, loadScores, recordBummerl } from "./ui/storage.js";

export default function App(){
  const [s, dispatch] = useReducer(reducer, SETUP);
  const [theme, setTheme] = React.useState(()=>loadTheme());
  const [set, setSet] = React.useState(()=>loadSettings());
  const [initials, setInits] = React.useState(()=>loadInitials());
  const [scores, setScores] = React.useState(()=>loadScores());
  const [campaign, setCampaign] = React.useState(()=>loadCampaign());
  const [menuOpen, setMenuOpen] = React.useState(false);
  const [showRules, setShowRules] = React.useState(false);
  const [tab, setTab] = React.useState("game");
  const [sel, setSel] = React.useState(null);

  useEffect(()=>{ saveTheme(theme); }, [theme]);
  useEffect(()=>{ saveSettings(set); }, [set]);
  const setInitials = (v)=>{ const c=(v||"").toUpperCase().replace(/[^A-Z]/g,"").slice(0,3); setInits(c); saveInitials(c); };

  const timer = useRef(null);
  const netRef = useRef(null);
  const recordedRef = useRef(null);

  /* ---------------- multiplayer ----------------
   * Identical contract to bridge: a GUEST never runs the rules, it just SENDS its action to the host and
   * renders whatever snapshot comes back. The host is the only machine that owns the deal. That is what
   * makes cheating structurally impossible rather than merely discouraged — a guest's client has never
   * been told what is in the other hand or the stock (see adapter.js/redactFor).
   */
  /* every decision the human makes, with the position as it stood when they made it. The grader
     re-derives the opponent's hand by sampling — it never peeks at the snapshot's other seat — so
     capturing full state here is safe and is what lets us price the move afterwards. */
  const [moves, setMoves] = React.useState([]);
  const sRef = React.useRef(null);
  sRef.current = s;

  /* a new deal wipes the capture. This MUST sit with the other top-level hooks: App returns early for
     the spectator and lobby screens, and a hook below those returns is a hook that sometimes does not
     run — which is exactly the "rendered more hooks than during the previous render" crash. */
  React.useEffect(()=>{
    if(s.mode==="play" && s.phase==="play" && !(s.trick||[]).length && !(s.log||[]).length)
      setMoves(cur => cur.length ? [] : cur);
  }, [s.mode, s.phase, (s.trick||[]).length, (s.log||[]).length]);

  /* set before any child renders this pass, so every card in the tree agrees on what a King is called */
  setRankMode(set.numerals ? "values" : "faces");

  const dealKey = s.roundEndedAt || 0;
  /* The result screen's feedback is permanent. The LIVE feedback is the toggle — so `finish` forces the
     grader to catch up the moment the deal is scored, whether the coach was switched on or not. */
  const grades = useDealGrades(moves, !!set.coach, s.phase==="scored");
  const banking = useBanking(moves, grades, dealKey);   // career + bounty, headless — always banks

  const apply = React.useCallback((action)=>{
    const st = sRef.current;
    if(st && st.mode==="play" && st.phase==="play" && action.seat!=null && st.brains[action.seat]==="human")
      setMoves(cur => cur.concat([{ snap: st, seat: action.seat, action }]));
    if(netRef.current && netRef.current.role==="guest"){ netRef.current.send(action); return; }
    dispatch(action);
  }, []);

  const net = useGameNet({
    onAction: (a)=>dispatch(a),                                     // host: a guest's action, already seat-checked
    onResume: (state)=>dispatch({type:"__SYNC__", state}),
    onGoSolo: ()=>dispatch({type:"TO_SETUP"}),
    onSeatChange: (seat, brain, name)=>dispatch({type:"SET_BRAIN_LIVE", seat, brain:(brain==="human"?"human":"fritzl"), name:(name!=null?name:"")}),
  });
  netRef.current = net;
  const online = net.role !== "off";
  const focus = online ? Math.max(0, net.seat) : 0;

  /* ---------------- document scroll lock ----------------
   * The shell locks the ROOT hard: `html,body{height:100%; overflow:hidden; overscroll-behavior:none}`.
   * That is only needed for the LIVE CARD TABLE, whose fixed root pins to the visible viewport. Every OTHER
   * view — setup, lobby, spectator, and the tall RESULT and LOG reports — is a normal, scrollable page, and
   * on this phone the ONLY thing that reliably scrolls is the document itself (a fixed root with an inner
   * overflow:auto pane does not). So we lock the body for the live table alone and hand every report screen
   * back to normal document scrolling: overflow VISIBLE (not `auto` — an <html> set to overflow:auto becomes
   * its own scroll container and, at height:auto, never overflows, so it never scrolls) and height:auto so
   * the body grows past the viewport and the window scrolls the ordinary way. */
  const liveTable = s.mode==="play" && s.phase!=="scored" && tab!=="log"
                    && net.role!=="lobby" && net.role!=="spectate";
  useEffect(()=>{
    const nodes = [document.documentElement, document.body];
    const prev = nodes.map(n => ({ overflow:n.style.overflow, height:n.style.height, minHeight:n.style.minHeight, osb:n.style.overscrollBehavior }));
    for(const n of nodes){
      n.style.overflow = liveTable ? "hidden" : "visible";
      n.style.height   = liveTable ? "100%"   : "auto";
      n.style.overscrollBehavior = liveTable ? "none" : "auto";
    }
    document.body.style.minHeight = liveTable ? "" : "100%";
    return ()=>{ nodes.forEach((n,i)=>{ n.style.overflow=prev[i].overflow; n.style.height=prev[i].height; n.style.minHeight=prev[i].minHeight; n.style.overscrollBehavior=prev[i].osb; }); };
  }, [liveTable]);

  /* Closing the stock is the biggest single decision in the game and it happened with no ceremony at
     all — one frame the deck was open, the next it said CLOSED. Now you throw the switch: a jet of white
     runs from the button into the deck, and the deck flips when the jet arrives. */
  const closeStock = React.useCallback((ev)=>{
    const btn = ev && ev.currentTarget;
    const deck = document.querySelector(".br .sc-stock");
    const beat = (btn && deck) ? fxStream(btn, deck) : 0;
    setTimeout(()=> apply({type:"CLOSE", seat:focus}), beat);
  }, [focus, apply]);   // eslint-disable-line


  useEffect(()=>{ if(net.role==="host" && s.mode==="play") net.broadcastState(s, net.names, s.target); },
    [s, net.names, net.role]);                                       // eslint-disable-line
  useEffect(()=>{ if(net.role==="guest" && net.snap) dispatch({type:"__SYNC__", state: net.snap}); },
    [net.snapV]);                                                    // eslint-disable-line

  /* The host starts the game the shell's lobby set up: whoever is seated is human, anyone missing is a bot. */
  const startOnline = React.useCallback((tgt)=>{
    const brains = [0,1].map(i => (net.roster||[]).some(r=>r.seat===i) ? "human" : "fritzl");
    const names  = [0,1].map(i => (net.names && net.names[i]) || "");
    dispatch({type:"START", brains, names, target: tgt || 7, dealer:0});
  }, [net.roster, net.names]);                                       // eslint-disable-line

  /* ---------------- the bots ----------------
   * They also cover a seat whose human has dropped, so a disconnect never freezes the table. */
  useEffect(()=>{
    if(netRef.current && netRef.current.role==="guest") return;
    if(s.mode!=="play" || s.phase!=="play") return;
    const seat = s.turn;
    const down = net.role==="host" && net.isSeatDown && net.isSeatDown(seat);
    if(s.brains[seat]==="human" && !down) return;
    const bs = (s.brains[seat]==="human") ? {...s, brains: s.brains.map((b,i)=> i===seat ? "fritzl" : b)} : s;
    /* THE BEAT. When a trick has just resolved, both cards are sitting face-up on the table and the
       player is trying to add 11 and 4 and keep a running count. Snatching them away in 620ms makes
       that impossible, and counting to 66 is not an optional part of this game — it IS the game. So the
       bot waits a full second longer before it leads to the next trick. It costs nothing and it is the
       difference between a game you can follow and a game that happens at you. */
    const justResolved = !(s.trick||[]).length && !!s.lastTrick;
    const delay = down ? 2000 : (justResolved ? 1600 : 620);
    timer.current = setTimeout(()=>{
      const d = botAction(bs, seat);
      if(d && d.action) dispatch(d.action);
    }, delay);
    return ()=>clearTimeout(timer.current);
  }, [s, net.role]);                                                 // eslint-disable-line

  useEffect(()=>{ setSel(null); }, [s.turn, s.phase, (s.trick||[]).length]);

  /* ---------------- persistence ----------------
   * The in-progress Bummerl is saved after every deal (solo only — an online Bummerl belongs to the host's
   * room, not to this device), and a finished one is banked into the high scores exactly once.
   */
  useEffect(()=>{
    if(!(s.mode==="play" && s.phase==="scored" && s.roundEndedAt)) return;
    if(recordedRef.current === s.roundEndedAt) return;
    recordedRef.current = s.roundEndedAt;

    if(s.bummerlDone){
      /* BOTH SEATS GO IN THE BOOK. Online, every device that watched the Bummerl end banks both players'
       * results, so the board fills with everyone you have ever sat across from. A bot has no initials
       * and recordBummerl drops it on the floor. */
      const entries = [0,1].map(i=>{
        const ini = (i===focus && !online) ? initials
                  : (s.brains[i]==="human" ? ((s.names && s.names[i]) || (i===focus ? initials : "")) : "");
        const won = s.bummerlWinner===i;
        const deals = (s.sheet||[]).length;
        return { ini, won,
          gpFor: s.gp[i], gpAgainst: s.gp[other(i)],
          deals, dealsWon: (s.sheet||[]).filter(r=>r.winner===i).length,
          schneider: won && s.gp[other(i)]===0 };
      });
      setScores(recordBummerl(entries));
      if(!online){ saveCampaign(null); setCampaign(null); }
    } else if(!online){
      const snap = { brains:[...s.brains], names:[...s.names], target:s.target, gp:[...s.gp],
                     bummerlNo:s.bummerlNo, dealNo:s.dealNo, sheet:[...(s.sheet||[])],
                     dealer:s.dealer, strictClaim:!!s.strictClaim, ts:Date.now() };
      saveCampaign(snap); setCampaign(snap);
    }
  }, [s.phase, s.roundEndedAt]);                                     // eslint-disable-line


  /* ---------------- chrome (the same furniture on every screen) ---------------- */
  const chrome = (
    <>
      {menuOpen && (
        <div className="overlay" onClick={()=>setMenuOpen(false)}>
          <div className="sheetmodal" onClick={(e)=>e.stopPropagation()}>
            <div className="smhead"><b className="dl-title">MENU</b><button className="dl-x" onClick={()=>setMenuOpen(false)}>×</button></div>
            <div className="smbody">
              <div className="menu-row"><span className="lbl2">Theme</span>
                <div className="toggle">
                  {[["casino","C"],["neon","N"],["blue","B"],["red","R"],["black","K"],["cream","W"],["text","T"],["large","L"]].map(([t,l])=>(
                    <button key={t} className={theme===t?"on":""} onClick={()=>setTheme(t)}>{l}</button>
                  ))}
                </div>
              </div>
              <div className="menu-row"><span className="lbl2">Numbered deck</span>
                <button className={"btn ghost"+(set.numerals?" on":"")} onClick={()=>setSet(v=>({...v, numerals:!v.numerals}))}>{set.numerals?"On ✓":"Off"}</button></div>
              <div className="hint" style={{fontSize:10,textAlign:"left"}}>Faces show point values — J becomes 2, Q 3, K 4. Same deck, same rules.</div>
              <div className="menu-row"><span className="lbl2">Live coach</span>
                <button className={"btn ghost"+(set.coach?" on":"")} onClick={()=>setSet(v=>({...v, coach:!v.coach}))}>{set.coach?"On ✓":"Off"}</button></div>
              <div className="hint" style={{fontSize:10,textAlign:"left"}}>Grades each play as you make it. Off, you still get the full review after the deal.</div>
              <div className="menu-row"><span className="lbl2">Memory mode</span>
                <button className={"btn ghost"+(set.memory?" on":"")} onClick={()=>setSet(v=>({...v, memory:!v.memory}))}>{set.memory?"On ✓":"Off"}</button></div>
              <div className="hint" style={{fontSize:10,textAlign:"left"}}>Hides your opponent's running score — count it yourself, like a Schnapsen player.</div>
              {s.mode==="play" && <ScoreSheet s={s}/>}
              <div className="menu-acts">
                <button className="btn ghost" onClick={()=>{setMenuOpen(false); setShowRules(true);}}>Rules</button>
                <button className="btn ghost" onClick={()=>{setMenuOpen(false); dispatch({type:"TO_SETUP"});}}>Setup</button>
              </div>
            </div>
          </div>
        </div>
      )}
      {showRules && <RulesScreen onClose={()=>setShowRules(false)}/>}
    </>
  );

  /* ---------------- lobby / spectator ----------------
   * These are tall, static screens. They scroll natively: a body-overflow effect (below) unlocks the
   * document whenever we are NOT at the play table, so normal-flow content taller than the phone can
   * scroll the ordinary way. The play table re-locks the body so its fixed root can pin to the viewport. */
  if(net.role==="spectate")
    return <div className="br" data-theme={theme}><style>{THEME_CSS}</style><SpectatorView net={net}/></div>;
  if(net.role==="lobby" || (online && s.mode!=="play"))
    return <div className="br" data-theme={theme}><style>{THEME_CSS}</style><OnlineScreens net={net} onStart={startOnline}/></div>;

  /* ---------------- setup ---------------- */
  if(s.mode==="setup"){
    /* Normal flow, scrolled by the document itself. The body-overflow effect above unlocks the page on
       the setup screen, so this can be taller than the phone and simply scroll — the ordinary way, which
       is the way that actually works on mobile Chrome once the fixed play screen has locked the body. */
    return (
      <div className="br" data-theme={theme} style={{minHeight:"100vh", background:"var(--bg)", padding:14}}>
        <style>{THEME_CSS}</style>
        <OnlineBar net={net} hideChat/>
        <div className="app">
          <header>
            <div className="wordmark">SCHNAPSEN</div>
          </header>
          <div className="hint">
            Austria's national card game — a race to 66, <b>with no obligation to follow suit</b> until somebody shuts the stock.
          </div>
          <UIErrorBoundary>
            <Setup s={s} dispatch={dispatch} initials={initials} setInitials={setInitials} scores={scores}
              theme={theme} setTheme={setTheme}
              onStart={()=>dispatch({type:"START", brains:s.brains, names:[initials,""], target:s.target, dealer:0})}
              onShowRules={()=>setShowRules(true)}
              campaign={campaign}
              onResume={()=>{ recordedRef.current=null; dispatch({type:"RESUME", ...campaign, names:[initials,""]}); }}
              onDiscard={()=>{ saveCampaign(null); setCampaign(null); }}/>
          </UIErrorBoundary>
        </div>
        {chrome}
      </div>
    );
  }

  /* ---------------- the table ---------------- */
  /* Is the table waiting on YOU? Everything the hand can do is downstream of this one line. */
  const myTurn = s.mode==="play" && s.phase==="play" && s.turn===focus && s.brains[focus]==="human";

  const sv = { ...s, memory: set.memory };
  const me = effPts(s, focus);
  const canAct = myTurn;
  const legal = canAct ? new Set(RULES.legalCards(s, focus).map(c=>c.id)) : null;

  /* Tap once to select, tap the same card again to play it. Two taps, no gesture to learn. */
  const onPick  = (c, el)=>{ if(!canAct) return;
    if(sel===c.id){
      /* Fire the comet, THEN hold the card back until its middle reaches the table. The card used to be
         in the trick before its own particles had left your hand, which made the trail look like an
         afterthought rather than the card's own flight. */
      const beat = fxFly(el, c.suit) || 0;
      setSel(null);
      setTimeout(()=> apply({type:"PLAY", seat:focus, cardId:c.id}), beat);
    }
    else { fxBurst(el, c.suit); setSel(c.id); } };

  const turnText = s.phase==="scored" ? ""
    : canAct
      ? (s.trick.length ? "Your turn — follow" : s.meldSuit ? `Declared ${SUIT_GLYPH[s.meldSuit]} — lead the king or the queen` : "Your lead")
      : `${who(s, s.turn)} is thinking…`;


  /* You took the trick: rain the suit of the card that WON it — not the card you played, the card that
     took it, which is the same thing when you win and is the point of the whole flourish. It falls until
     you play your next card, which is exactly the window in which the trick is still yours to enjoy. */
  const lt = s.lastTrick;
  const winSuit = (lt && lt.winner===focus && !(s.trick||[]).length)
    ? ((lt.trick.find(x=>x.seat===lt.winner)||{}).card||{}).suit || null : null;
  const winSeed = (s.log||[]).length;

  const trickMsg = s.trick.length
    ? (s.trick[0].seat===focus ? "you led — waiting" : <><b>{who(s, other(focus))}</b> led {displayRank(s.trick[0].card.rank)}{G(s.trick[0].card.suit)}</>)
    : s.lastTrick
      ? <>last trick: <b>{who(s, s.lastTrick.winner)}</b> took {s.lastTrick.pts}</>
      : "first lead";


  const r = s.result;
  const iWon = r && r.winner===focus;
  const needMore = s.target>0 ? s.target - s.gp[focus] : null;

  /* Live table pins to the viewport (fixed root, locked body). The result and log are tall reports, so they
     drop the fixed root and become a normal, document-scrolling page — the header and tabs stay put via
     position:sticky. This is the same "let the document scroll" cure that fixed the setup screen. */
  const shellStyle = liveTable
    ? {position:"fixed", inset:0, background:"var(--bg)", display:"flex", flexDirection:"column"}
    : {position:"static", minHeight:"100dvh", background:"var(--bg)", display:"flex", flexDirection:"column"};
  return (
    <div className={"br"+(liveTable?"":" report")} data-theme={theme} style={shellStyle}>
      <FxLayer/>
      <style>{THEME_CSS}</style>
      {/* No chat button in the banner: the talk dock at the bottom of the table is permanently open and
          carries the same room chat, so the banner button would only duplicate it. */}
      <OnlineBar net={net} hideChat/>
      <div className="stage">
        <StatusBar s={s} focus={focus} onMenu={()=>setMenuOpen(true)} turnText={turnText}/>

        <div className="gscreen">
          <AmbientRain on={!!winSuit} seed={winSeed}/>
          <TrickRain suit={winSuit} seed={winSeed}/>
          <UIErrorBoundary>
          {tab==="log" ? (
            <div className="logscroll">
              {s.phase==="scored" && moves.length>0 && <>
                <PointsSummary moves={moves} grades={grades} banking={banking}/>
                <ReplayDeck moves={moves} grades={grades}/>
              </>}
              <CoachLog moves={moves} grades={grades} on={!!set.coach}/>
              <Log s={sv} focus={focus}/>
            </div>
          ) : s.phase==="scored" && r ? (
            <div className="sc-result">
              <Fireworks on={iWon}/>
              <div className="result">
                <div className={"rhead "+(iWon?"won":"lost")}>{iWon ? r.head : r.head}</div>
                <div className="rgp num">+{r.gp}<small>game points to {who(s, r.winner)}</small></div>
                <div className="rdetail">
                  {r.why}<br/>
                  Cards: <b className="num">{r.pts[focus]}</b> – <b className="num">{r.pts[other(focus)]}</b> ·
                  {" "}Tricks: <b className="num">{r.tricks[focus]}</b> – <b className="num">{r.tricks[other(focus)]}</b>
                  {r.closedBy!=null && <><br/>{who(s, r.closedBy)} closed the stock with {who(s, other(r.closedBy))} on {r.closeSnap ? r.closeSnap.pts : 0} and {r.closeSnap ? r.closeSnap.tricks : 0} {r.closeSnap && r.closeSnap.tricks===1 ? "trick" : "tricks"}.</>}
                  {r.schwarz && <><br/><b style={{color:"var(--yellow)"}}>Schwarz — {who(s, other(r.winner))} did not take a single trick.</b></>}
                </div>
                {/* Feedback moved to the LOG tab. The result screen shows only the deal outcome now — a clean,
                    short, always-fits card. The play-points detail, replay and bounty live under LOG. */}
                {moves.length>0 && <div className="rdetail" style={{marginTop:6,fontSize:11}}>
                  Play points this deal: <b className={"num "+(grades.reduce((x,g)=>x+(g?g.pts:0),0)>=0?"pp-good":"pp-bad")}>
                  {grades.reduce((x,g)=>x+(g?g.pts:0),0)>=0?"+":""}{grades.reduce((x,g)=>x+(g?g.pts:0),0)}</b>
                  {" "}· see the LOG tab for the full review.</div>}
                {s.bummerlDone
                  ? <div className="rbig">{who(s, s.bummerlWinner)} {s.bummerlWinner===focus?"win":"wins"} the Bummerl {s.gp[s.bummerlWinner]}–{s.gp[other(s.bummerlWinner)]}{s.schneiderBummerl ? " · SCHNEIDER" : ""}</div>
                  : <div className="rdetail" style={{marginTop:8}}>{needMore} more game {needMore===1?"point":"points"} and the Bummerl is yours.</div>}
              </div>
              <ScoreSheet s={s}/>
              {s.bummerlDone && <div className="setcard"><div className="lbl2">High scores · this device</div><HighScores table={scores} meIni={online ? (net.names[focus]||net.myInitials) : initials} limit={5}/></div>}
              <div className="bar">
                {(!online || net.role==="host")
                  ? (s.bummerlDone
                      ? <button className="btn primary" onClick={()=>apply({type:"NEW_BUMMERL"})}>New Bummerl</button>
                      : <button className="btn primary" onClick={()=>apply({type:"NEXT_DEAL"})}>Next deal</button>)
                  : <div className="hint">waiting for the host…</div>}
                <button className="btn ghost" onClick={()=>setMenuOpen(true)}>Menu</button>
              </div>
            </div>
          ) : (
            <div className="sctable">
              <PlayPointsHUD grades={grades} moves={moves} on={!!set.coach}/>
              <OppStrip s={sv} seat={other(focus)} focus={focus} hidden={set.memory}/>
              <div className="sc-mid">
                <StockZone s={s}/>
                <TrickZone s={s} focus={focus} message={trickMsg}/>
              </div>
              <YouStrip s={s} seat={focus}/>
              <ActionBar s={s} seat={focus} dispatch={apply} canAct={canAct} onClose={closeStock}/>
              <div className="sc-hand">
                <div className="sc-handl">
                  Your hand
                  {canAct && <em>tap to select · tap again to play</em>}
                  {s.meldSuit && <em style={{color:"var(--purple)"}}>must lead K or Q of {SUIT_GLYPH[s.meldSuit]}</em>}
                </div>
                <Hand hand={s.hands[focus]} trump={s.trump} legalIds={legal} active={canAct}
                  selId={sel} onPick={onPick} showVal/>
              </div>
              <TalkDock s={s} net={net} online={!!online} focus={focus}/>
            </div>
          )}
          </UIErrorBoundary>
        </div>

        <TabBar tab={tab} onTab={setTab} phase={s.phase} yourTurn={myTurn}/>
      </div>
      {chrome}
    </div>
  );
}
