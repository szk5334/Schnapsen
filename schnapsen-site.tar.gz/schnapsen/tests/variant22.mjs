/* The 22-card deck: the 9 of hearts and the 9 of spades only, ranked A > 10 > 9 > K > Q > J, worth 0.
 * Geometry, trick power, strict-play heading, the bot's picture of the unseen cards, and self-play. */
import { ENG } from "../engine/core.js";
import { RULES, stockLeft } from "../engine/rules.js";
import { decide, sampleDeal } from "../engine/bot.js";

function mulberry(a){ return function(){ a|=0; a=a+0x6D2B79F5|0; let t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }
let pass=0, fail=0;
const ok = (c,m)=> c ? (pass++) : (fail++, console.error("  FAIL:", m));
const C = (rank, suit, id)=> ({ id: id||0, rank, suit });
const K = c=> c.rank+"."+c.suit;

/* ---------- geometry ---------- */
ENG.setVariant("22");
ok(ENG.getVariant()==="22", "variant flips to 22");
const deck = ENG.makeDeck();
ok(deck.length===22, `deck is 22 (got ${deck.length})`);
const nines = deck.filter(c=>c.rank==="9").map(c=>c.suit).sort().join();
ok(nines==="H,S", `only the heart and spade 9s (got ${nines})`);
ok(new Set(deck.map(K)).size===22, "no duplicate cards");
ok(deck.reduce((s,c)=>s+ENG.val(c),0)===120, "still 120 points");
ok(ENG.handSize()===5, "five cards each");
ok(ENG.exchangeRank()==="J", "the trump J (the 2) still swaps for the turn-up");
ok(!ENG.inDeck("9","D") && !ENG.inDeck("9","C") && ENG.inDeck("9","H") && ENG.inDeck("9","S"), "inDeck knows which 9s exist");
ok(ENG.cards().length===22, "cards() lists the pack");
for(const su of ["H","S"]){
  const order = ["J","Q","K","9","10","A"].map(r=>ENG.power(C(r,su)));
  ok(order.every((v,i)=> i===0 || v>order[i-1]), `${su}: J < Q < K < 9 < 10 < A`);
}
ok(ENG.val(C("9","H"))===0, "the 9 is worth nothing");

/* ---------- tricks ---------- */
ok(ENG.follows(C("K","H"), C("9","H"), "D"), "9 takes the K of its suit");
ok(ENG.follows(C("J","S"), C("9","S"), null), "9 takes the J at no-trumps");
ok(!ENG.follows(C("10","H"), C("9","H"), "D"), "9 does not take the 10");
ok(!ENG.follows(C("9","H"), C("K","H"), "D"), "K does not take the 9");
ok(ENG.follows(C("9","H"), C("10","H"), "D"), "10 takes the 9");
ok(ENG.follows(C("A","D"), C("9","S"), "S"), "the trump 9 ruffs a side ace");
ok(ENG.follows(C("9","S"), C("Q","S"), "C")===false, "a lower card of the suit loses to a led 9");
ok(ENG.follows(C("K","S"), C("9","S"), "S"), "trump 9 over trump K");
// strict play: holding the 9 and the J of the led suit, you must head a led K with the 9
const strictF = ENG.legalFollows([C("9","H",1), C("J","H",2), C("A","C",3)], C("K","H"), "C", true);
ok(strictF.length===1 && strictF[0].id===1, "strict: must head the K with the 9");
const strictF2 = ENG.legalFollows([C("9","H",1), C("J","H",2)], C("10","H"), "C", true);
ok(strictF2.length===2, "strict: a 10 led, the 9 cannot head it, either card may follow");
const sorted = ENG.sortDisplay([C("A","H",1), C("9","H",2), C("K","H",3), C("10","H",4), C("J","H",5)], "D").map(c=>c.rank).join();
ok(sorted==="J,K,9,10,A", `hand sorts by power (got ${sorted})`);

/* ---------- the deal ---------- */
const d0 = RULES.newDeal(0, mulberry(7));
ok(d0.hands[0].length===5 && d0.hands[1].length===5, "both seats hold 5");
ok(stockLeft(d0)===12, `11 face down + the turn-up (got ${stockLeft(d0)})`);
ok(d0.hands[0].length+d0.hands[1].length+d0.stock.length+1===22, "all 22 accounted for");

/* ---------- the bot never imagines a ♦9 or ♣9, and deduces the endgame exactly ---------- */
let badWorld=0, worlds=0, exactMiss=0, exactChecks=0;
for(let g=0; g<120; g++){
  const rnd = mulberry(500+g);
  const d = RULES.newDeal(g%2, rnd);
  for(let guard=0; guard<200 && d.phase==="play"; guard++){
    const p = d.turn;
    const w = sampleDeal(d, p, rnd); worlds++;
    const all = [...w.hands[0], ...w.hands[1], ...w.stock, ...(w.up?[w.up]:[])];
    const played = (d.log||[]).filter(e=>e.k==="trick").flatMap(e=>[e.led,e.fol]).concat(d.trick.map(t=>t.card));
    const keys = all.concat(played).map(K);
    if(keys.some(k=>k==="9.D"||k==="9.C") || new Set(keys).size!==keys.length || keys.length!==22) badWorld++;
    if(!d.closed && stockLeft(d)===0){
      exactChecks++;
      const truth = d.hands[1-p].map(K).sort().join(), guess = w.hands[1-p].map(K).sort().join();
      if(truth!==guess) exactMiss++;
    }
    const dec = decide(d, p, { brain: g%2 ? "greta" : "fritzl", rnd });
    const a = dec.action;
    if(a.type==="PLAY") RULES.play(d,p,a.cardId,{}); else if(a.type==="MELD") RULES.meld(d,p,a.suit,{});
    else if(a.type==="EXCHANGE") RULES.exchange(d,p); else if(a.type==="CLOSE") RULES.close(d,p); else RULES.claim(d,p);
  }
}
ok(badWorld===0, `every sampled world is the real 22-card pack (${badWorld} bad of ${worlds})`);
ok(exactChecks>0 && exactMiss===0, `exhausted stock: the opponent's hand is deduced exactly (${exactChecks} checks, ${exactMiss} misses)`);

/* ---------- self-play ---------- */
function runDeal(seed, brain){
  const rnd = mulberry(seed);
  const d = RULES.newDeal(seed%2, rnd);
  let guard=0;
  while(d.phase==="play"){
    if(++guard>400) return { term:false, d };
    const p=d.turn;
    const dec=decide(d,p,{ brain, rnd, strictClaim:false });
    if(!dec) return { term:false, d };
    const a=dec.action;
    if(a.type==="PLAY"){
      if(!RULES.legalCards(d,p).some(c=>c.id===a.cardId)) return { term:false, d, illegal:true };
      RULES.play(d,p,a.cardId,{});
    } else if(a.type==="MELD") RULES.meld(d,p,a.suit,{});
    else if(a.type==="EXCHANGE") RULES.exchange(d,p);
    else if(a.type==="CLOSE") RULES.close(d,p);
    else if(a.type==="CLAIM") RULES.claim(d,p);
  }
  return { term:true, d };
}
let terminated=0, illegal=0, ptViol=0, steals=0, ninesPlayed=0;
const N=400, brains=["fritzl","greta","resi","poldi"];
for(let g=0; g<N; g++){
  const { term, d, illegal:il } = runDeal(9000+g, brains[g%4]);
  if(term) terminated++; if(il) illegal++;
  if(d.trickPts[0]+d.trickPts[1]>120) ptViol++;
  for(const e of d.log||[]) if(e.k==="trick"){
    const nine = e.led.rank==="9" ? e.led : e.fol.rank==="9" ? e.fol : null;
    if(nine) ninesPlayed++;
    const other = nine===e.led ? e.fol : e.led;
    if(nine && other.suit===nine.suit && ["K","Q","J"].includes(other.rank)) steals++;
  }
}
ok(terminated===N, `all ${N} deals terminated (got ${terminated})`);
ok(illegal===0, `no illegal bot actions (got ${illegal})`);
ok(ptViol===0, "trick points never exceed 120");
ok(steals>0, `the 9 takes K/Q/J in play (${steals} times, ${ninesPlayed} nines played)`);

/* ---------- the other decks are untouched ---------- */
ENG.setVariant("24");
ok(ENG.makeDeck().length===24 && ENG.power(C("9","H"))===0, "24 deck: four 9s, lowest");
ENG.setVariant("classic");
ok(ENG.makeDeck().length===20 && ENG.power(C("K","H"))===3 && ENG.exchangeRank()==="J", "classic unchanged");
ok(ENG.normVariant("22")==="22" && ENG.normVariant("x")==="classic", "normVariant");

console.log(`\n${pass} passed, ${fail} failed  —  22-card deck (two 9s)`);
process.exit(fail?1:0);
