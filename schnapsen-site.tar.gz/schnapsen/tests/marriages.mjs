/* MARRIAGE VALUES: 20/40 (classic) vs 17/34 (the 3 and 4 of trumps make 34).
 * Paired deals: every seed is played once under each scale, same bots, same shuffle, house rules on
 * (the turn-up always names trumps; no 66, no score). Prints the shape of the game under each scale and, with
 * --skill, how much better a strong bot does against a weaker one (seats swapped each pair).
 *   node marriages.mjs --n=2000                       shape: fritzl vs fritzl
 *   node marriages.mjs --n=2000 --b0=greta --b1=ignaz  skill gap
 */
import { ENG } from "../engine/core.js";
import { RULES, other } from "../engine/rules.js";
import { decide } from "../engine/bot.js";

function mulberry(a){ return function(){ a|=0; a=a+0x6D2B79F5|0; let t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }
const ARG = Object.fromEntries(process.argv.slice(2).map(x=>{const [k,v]=x.split("=");return [k.replace(/^--/,""),v??"1"];}));
const N = +(ARG.n || 500), SEED = +(ARG.seed || 1);
const B0 = ARG.b0 || "fritzl", B1 = ARG.b1 || "fritzl";
const OUT = 66;

/* House payout, signed for seat 0 (same arithmetic as app/house.js; the pot is ignored here). */
function house(d){
  const r = d.result;
  if(r.reason === "exhausted"){
    const p = r.pts[0] >= OUT ? 0 : r.pts[1] >= OUT ? 1 : -1;
    if(p < 0) return { winner:-1, gp:0 };
    const o = other(p);
    return { winner:p, gp: r.tricks[o] === 0 ? 3 : r.pts[o] < 33 ? 2 : 1 };
  }
  return { winner:r.winner, gp:r.gp };
}

function play(seed, scale, brains){
  const rnd = mulberry(seed);
  const d = RULES.newDeal(seed % 2, rnd);
  d.house = true; d.marriages = scale;            // house payout, but the scale under test
  const dealt = [0,1].map(p => ENG.marriagesIn(d.hands[p]));
  const royalDealt = [0,1].map(p => d.trump && dealt[p].includes(d.trump));
  const rb = mulberry(seed * 7919 + 13);                       // the bots' own dice, identical across scales
  for(let guard=0; d.phase === "play" && guard < 400; guard++){
    const p = d.turn;
    const a = decide(d, p, { brain: brains[p], rnd: rb }).action;
    if(a.type==="PLAY") RULES.play(d, p, a.cardId, {});
    else if(a.type==="MELD") RULES.meld(d, p, a.suit, {});
    else if(a.type==="EXCHANGE") RULES.exchange(d, p);
    else if(a.type==="CLOSE") RULES.close(d, p);
    else if(a.type==="CLAIM") RULES.claim(d, p);
  }
  const h = house(d);
  return { ...h, reason: d.result.reason, closed: d.closed, closedBy: d.closedBy, nt: d.trump === null,
           melds: d.meldPts.slice(), tricks: d.trickPts.slice(), royalDealt,
           tricksNeeded: h.winner >= 0 ? OUT - d.meldPts[h.winner] : null,
           len: (d.log||[]).filter(e=>e.k==="trick").length };
}

const SCALES = ["classic", "34"];
const S = Object.fromEntries(SCALES.map(k=>[k,{ n:0, gp:0, gpSq:0, tiers:{0:0,1:0,2:0,3:0}, closes:0, closeFail:0, scoreless:0,
  meldPts:0, meldDeals:0, meldCarried:0, wins:0, royalHeld:0, royalWon:0, tricks:0, strongGp:0, strongSq:0, flips:0 }]));
let pairsFlipped = 0, dSum = 0, dSq = 0;   // paired difference in the strong bot's gp (17/34 minus 20/40)
const t0 = Date.now();
for(let i=0;i<N;i++){
  const seed = SEED*100000 + i;
  const swap = i % 2 === 1;                                    // the strong brain sits in each seat half the time
  const brains = swap ? [B1, B0] : [B0, B1];
  const strongSeat = swap ? 1 : 0;
  const res = {}, sgp = {};
  for(const k of SCALES){
    const r = play(seed, k, brains); res[k] = r; const s = S[k];
    s.n++; s.tiers[r.gp]++; s.tricks += r.len;
    if(r.winner < 0) s.scoreless++;
    if(r.closed){ s.closes++; if(r.winner !== r.closedBy) s.closeFail++; }
    s.meldPts += r.melds[0] + r.melds[1];
    if(r.melds[0] + r.melds[1] > 0) s.meldDeals++;
    /* the winner's trick points alone would not have reached 66: the marriage carried the deal */
    if(r.winner >= 0 && r.tricks[r.winner] < OUT) s.meldCarried++;
    for(const p of [0,1]) if(r.royalDealt[p]){ s.royalHeld++; if(r.winner === p) s.royalWon++; }
    const sg = r.winner < 0 ? 0 : (r.winner === strongSeat ? r.gp : -r.gp);
    s.strongGp += sg; s.strongSq += sg*sg; sgp[k] = sg;
  }
  const dd = sgp["34"] - sgp.classic; dSum += dd; dSq += dd*dd;
  if(res.classic.winner !== res["34"].winner) pairsFlipped++;
}
const ms = Date.now()-t0;

const pct = (a,b)=> b ? (100*a/b).toFixed(1)+"%" : "–";
const row = (label, f)=> console.log(label.padEnd(34) + SCALES.map(k=>String(f(S[k])).padStart(14)).join(""));
console.log(`${N} paired deals, house rules, ${B0} vs ${B1} (seats swapped each pair), ${ms} ms`);
console.log("".padEnd(34) + "        20/40" + "         17/34");
row("game points per deal", s=> ((s.tiers[1]+2*s.tiers[2]+3*s.tiers[3])/s.n).toFixed(3));
row("  1 / 2 / 3 gp (%)", s=> [1,2,3].map(t=>Math.round(100*s.tiers[t]/s.n)).join(" / "));
row("scoreless (feeds the pot)", s=> pct(s.scoreless, s.n));
row("closed", s=> pct(s.closes, s.n));
row("  closer failed", s=> pct(s.closeFail, s.closes));
row("tricks played per deal", s=> (s.tricks/s.n).toFixed(2));
row("meld points per deal", s=> (s.meldPts/s.n).toFixed(1));
row("winner short of 66 on tricks", s=> pct(s.meldCarried, s.n - s.scoreless));
row("wins when dealt royal marriage", s=> pct(s.royalWon, s.royalHeld));
if(B0 !== B1){
  row(`${B0} edge, gp per deal`, s=> { const m=s.strongGp/s.n, se=Math.sqrt((s.strongSq/s.n - m*m)/s.n); return `${m.toFixed(3)}±${se.toFixed(3)}`; });
}
if(B0 !== B1){ const m = dSum/N, se = Math.sqrt((dSq/N - m*m)/N);
  console.log(`change in ${B0}'s edge, paired: ${m>=0?"+":""}${m.toFixed(3)} ± ${se.toFixed(3)} gp per deal`); }
console.log(`deals whose winner changed: ${pct(pairsFlipped, N)}`);
