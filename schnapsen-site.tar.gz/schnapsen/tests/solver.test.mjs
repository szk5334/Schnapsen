// The endgame solver against an independent brute force (app/review.js's plain minimax, a separate piece of
// code), on strict positions from real bot deals: exhausted and closed, classic and house rules, all three
// decks. Every first move's value must match exactly, not just the best one, because the bot averages them.
//   node solver.test.mjs [deals]
import { ENG } from "../engine/core.js";
import { RULES, isStrict } from "../engine/rules.js";
import { decide } from "../engine/bot.js";
import { solve } from "../engine/solver.js";
import { exactValue } from "../../app/review.js";

function mulberry(a){ return function(){ a|=0; a=a+0x6D2B79F5|0; let t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }
const clone = w => ({
  ...w,
  hands: { 0: w.hands[0].slice(), 1: w.hands[1].slice() },
  stock: w.stock.slice(), trick: w.trick.slice(),
  trickPts: w.trickPts.slice(), meldPts: w.meldPts.slice(), tricksWon: w.tricksWon.slice(),
  meldedSuits: [w.meldedSuits[0].slice(), w.meldedSuits[1].slice()],
  closeSnap: w.closeSnap ? { ...w.closeSnap } : null,
  reveals: (w.reveals || []).slice(), log: (w.log || []).slice(),
});
/* Play `card` for the side to move the way the solver does: leading the K or Q of a marriage declares it. */
function child(d, card){
  const c = clone(d), p = c.turn;
  if(!c.trick.length && (card.rank==="K"||card.rank==="Q") && RULES.meldOptions(c, p).some(m=>m.suit===card.suit))
    RULES.meld(c, p, card.suit, {});
  if(c.phase === "play") RULES.play(c, p, card.id, {});
  return c;
}

const N = +(process.argv[2] || 40);
let pass = 0, fail = 0, bestWrong = 0, bestCost = 0, positions = 0, moves = 0, exhausted = 0, closed = 0, nt = 0, houseZero = 0;
const t0 = Date.now();
for(const variant of ["classic", "22", "24"]){
  ENG.setVariant(variant);
  for(const house of [false, true]){
    for(let g = 0; g < N; g++){
      const rnd = mulberry(7000 + g * 7 + (house ? 1 : 0) + variant.length * 1000);
      const d = RULES.newDeal(g % 2, rnd);
      d.house = house;
      if(house && rnd() < 0.2) d.trump = null;                       // a no-trump deal now and then
      const closeAt = rnd() < 0.4 ? 1 + ((rnd() * 4) | 0) : 99;      // force a close on some deals
      let tricks = 0;
      for(let guard = 0; guard < 200 && d.phase === "play"; guard++){
        const p = d.turn;
        if(!d.trick.length && tricks >= closeAt && RULES.canClose(d, p)){ RULES.close(d, p); continue; }
        if(isStrict(d) && d.hands[p].length <= 5){
          positions++; if(d.closed) closed++; else exhausted++; if(d.trump === null) nt++;
          for(const me of [0, 1]){
            const r = solve(d, me, 2e6);
            if(!r){ fail++; console.log("FAIL solver gave up", variant, house, g); continue; }
            let top = -Infinity; const truths = [];
            for(const m of r.moves){
              moves++;
              const c = child(d, m.card);
              const truth = exactValue(c, me, house);
              if(house && !d.closed && truth === 0) houseZero++;
              truths.push(truth); if(truth > top) top = truth;
              if(truth === m.value) pass++;
              else { fail++; if(fail < 8) console.log("FAIL", variant, house ? "house" : "classic", d.closed ? "closed" : "exhausted", "deal", g, "seat", me, ENG.key(m.card), "solver", m.value, "truth", truth); }
            }
            if(d.turn === me && truths[0] < top){ bestWrong++; bestCost += top - truths[0]; }   // the move it would play
          }
        }
        const dec = decide(d, p, { brain: "fritzl", rnd });
        if(!dec) break;
        const a = dec.action;
        if(a.type === "PLAY") { RULES.play(d, p, a.cardId, {}); if(!d.trick.length) tricks++; }
        else if(a.type === "MELD") RULES.meld(d, p, a.suit, {});
        else if(a.type === "EXCHANGE") RULES.exchange(d, p);
        else if(a.type === "CLOSE") RULES.close(d, p);
        else if(a.type === "CLAIM") RULES.claim(d, p);
      }
    }
  }
}
ENG.setVariant("classic");
if(bestWrong) console.log(`the chosen move was not the best in ${bestWrong} positions, costing ${bestCost} game points in all`);
const ok = fail === 0 && bestWrong === 0 && closed > 20 && exhausted > 20 && houseZero > 0;
console.log(`${ok ? "ok" : "FAILED"}: solver ${pass}/${pass + fail} move values exact on ${positions} positions (${exhausted} exhausted, ${closed} closed, ${nt} no-trump; ${houseZero} house lines worth nothing), ${Date.now() - t0} ms`);
process.exit(ok ? 0 : 1);
