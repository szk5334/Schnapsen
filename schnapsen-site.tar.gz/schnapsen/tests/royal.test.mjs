/* ROYAL HOUSE — the 32-card rules, engine level. node royal.test.mjs [deals]
 * (The double was tried in build 2026-11-11.1 and taken out on Nov 12.) */
import { ENG } from "../engine/core.js";
import { RULES, effPts, stockLeft, playMode, other } from "../engine/rules.js";
import { decide } from "../engine/bot.js";
import { solve } from "../engine/solver.js";

let pass = 0, fail = 0;
const t = (name, fn) => { try { fn(); pass++; console.log("  ok  " + name); } catch (e) { fail++; console.log("FAIL  " + name + "\n      " + e.message); } };
const eq = (a, b, m) => { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error((m || "") + " expected " + JSON.stringify(b) + " got " + JSON.stringify(a)); };
const ok = (c, m) => { if (!c) throw new Error(m || "expected true"); };

ENG.setVariant("royal");
let uid = 5000;
const C = (r, s) => ({ id: uid++, rank: r, suit: s });
const fill = n => { const out = []; for (let i = 0; i < n; i++) out.push(C("2", "C")); return out; };
function rig({ trump = "S", up, stock = fill(21), h0 = [], h1 = [], turn = 0 } = {}) {
  return {
    trump, up: up === undefined ? C("A", trump) : up, stock, hands: { 0: h0, 1: h1 },
    trick: [], turn, lead: turn, closed: false, closedBy: null, closeSnap: null,
    meldSuit: null, meldedSuits: [[], []], trickPts: [0, 0], meldPts: [0, 0], tricksWon: [0, 0],
    lastTrick: null, dealer: 1, phase: "play", result: null, reveals: [], log: [],
  };
}
const RNG = seed => () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };

console.log("\n— the pack —");
t("32 cards, 356 card points, 200 to go out, 100 the Schneider line", () => {
  const d = ENG.makeDeck();
  eq(d.length, 32); eq(d.reduce((a, c) => a + ENG.val(c), 0), 356);
  eq([ENG.OUT, ENG.HALF, RULES.OUT, RULES.HALF, ENG.DECK_POINTS], [200, 100, 200, 100, 356]);
});
t("rank A > 10 > K > Q > J > 4 > 3 > 2, worth 21 20 14 13 12 4 3 2", () => {
  const rs = ["A", "10", "K", "Q", "J", "4", "3", "2"];
  eq(rs.map(r => ENG.power({ rank: r })), [8, 7, 6, 5, 4, 3, 2, 1]);
  eq(rs.map(r => ENG.val({ rank: r })), [21, 20, 14, 13, 12, 4, 3, 2]);
});
t("a fresh deal: five cards each, the turn-up, 21 face down", () => {
  const d = RULES.newDeal(0, RNG(7));
  eq([d.hands[0].length, d.hands[1].length, d.stock.length, !!d.up], [5, 5, 21, true]);
  eq(d.trump, d.up.suit);
});
t("variant names: only \"royal\" is the 32-card pack", () => {
  eq([ENG.normVariant("royal"), ENG.normVariant("22"), ENG.normVariant(undefined)], ["royal", "classic", "classic"]);
});

console.log("\n— three phases —");
t("free for tricks 1-5, follow for 6-11, strict for 12-16 (one whole deal)", () => {
  const d = RULES.newDeal(1, RNG(11)); const seen = [];
  while (d.phase === "play") {
    if (!d.trick.length) seen.push(playMode(d));
    const p = d.turn, l = RULES.legalCards(d, p);
    RULES.play(d, p, l[0].id, { strictClaim: true });
    if (d.phase === "play" && d.hands[0].length === 0) break;
  }
  const want = [...Array(5).fill("free"), ...Array(6).fill("follow"), ...Array(5).fill("strict")];
  eq(seen.join(","), want.slice(0, seen.length).join(","));
  ok(seen.length >= 16 || d.phase === "scored", "played " + seen.length);
});
t("follow phase: must follow suit, need not head it or trump", () => {
  const d = rig({ stock: fill(11), h1: [C("2", "H"), C("A", "H"), C("A", "S")] });
  d.trick = [{ seat: 0, card: C("K", "H") }]; d.turn = 1;
  eq(playMode(d), "follow");
  eq(RULES.legalCards(d, 1).map(c => c.rank + c.suit).sort(), ["2H", "AH"]);
  const v = rig({ stock: fill(11), h1: [C("2", "D"), C("A", "S")] });
  v.trick = [{ seat: 0, card: C("K", "H") }]; v.turn = 1;
  eq(RULES.legalCards(v, 1).length, 2, "void: anything");
});
t("free phase: anything", () => {
  const d = rig({ stock: fill(12), h1: [C("2", "H"), C("A", "S")] });
  d.trick = [{ seat: 0, card: C("K", "H") }]; d.turn = 1;
  eq(playMode(d), "free"); eq(RULES.legalCards(d, 1).length, 2);
});
t("closing goes straight to strict, from the free phase", () => {
  const d = rig({ h0: [C("A", "S")], h1: [C("2", "H"), C("A", "H"), C("3", "S")] });
  RULES.close(d, 0); eq(playMode(d), "strict");
  d.trick = [{ seat: 0, card: C("K", "H") }]; d.turn = 1;
  eq(RULES.legalCards(d, 1).map(c => c.rank), ["A"]);
});

console.log("\n— marriages —");
t("royal marriage K+Q 40, 80 in trumps; common marriage 4+3 20, 40 in trumps", () => {
  const d = rig({ trump: "S", h0: [C("K", "H"), C("Q", "H"), C("4", "H"), C("3", "H"), C("K", "S")] });
  const m = RULES.meldOptions(d, 0);
  eq(m.map(x => [x.suit, x.value]), [["H", 40], ["H3", 20]]);
  const e = rig({ trump: "S", h0: [C("K", "S"), C("Q", "S"), C("4", "S"), C("3", "S")] });
  eq(RULES.meldOptions(e, 0).map(x => x.value), [80, 40]);
});
t("declaring the common marriage: lead the 4 or the 3, once per deal", () => {
  const d = rig({ trump: "S", h0: [C("4", "H"), C("3", "H"), C("A", "D")] });
  d.tricksWon[0] = 1;
  RULES.meld(d, 0, "H3", { strictClaim: true });
  eq(d.meldPts[0], 20); eq(d.meldSuit, "H3");
  eq(RULES.legalCards(d, 0).map(c => c.rank).sort(), ["3", "4"]);
  eq(d.log[d.log.length - 1].kind, "34");
  ok(RULES.meldOptions(d, 0).length === 0, "nothing to declare while one is pending");
  RULES.play(d, 0, d.hands[0].find(c => c.rank === "4").id, { strictClaim: true });
  eq(RULES.meldOptions(d, 0).length, 0);
});
t("a marriage takes you out at 200 on the spot", () => {
  const d = rig({ trump: "S", h0: [C("K", "S"), C("Q", "S")] });
  d.trickPts[0] = 125; d.tricksWon[0] = 3; d.trickPts[1] = 99; d.tricksWon[1] = 2;
  RULES.meld(d, 0, "S", {});
  eq([d.phase, d.result.winner, d.result.gp], ["scored", 0, 2], "205 against 99: Schneider");
});

console.log("\n— the exchange —");
t("the 2 of trumps swaps first; then nobody may (once a deal)", () => {
  const d = rig({ trump: "S", up: C("K", "S"), h0: [C("2", "S"), C("J", "S")], h1: [C("A", "H")] });
  eq(RULES.exchangeCard(d, 0).rank, "2");
  RULES.exchange(d, 0);
  ok(d.hands[0].some(c => c.rank === "K"), "took the K"); eq(d.up.rank, "2");
  ok(!RULES.canExchange(d, 0), "no second exchange");
  d.turn = 1; d.hands[1].push(C("J", "H"));
  ok(!RULES.canExchange(d, 1));
});
t("the J may swap too", () => {
  const d = rig({ trump: "S", up: C("A", "S"), h0: [C("J", "S")] });
  ok(RULES.canExchange(d, 0)); RULES.exchange(d, 0); eq(d.up.rank, "J");
});
t("the 2 and the J never swap for each other", () => {
  ok(!RULES.canExchange(rig({ trump: "S", up: C("2", "S"), h0: [C("J", "S")] }), 0));
  ok(!RULES.canExchange(rig({ trump: "S", up: C("J", "S"), h0: [C("2", "S")] }), 0));
});

console.log("\n— scoring —");
t("going out pays 1 / 2 (under 100) / 3 (no trick)", () => {
  const mk = (pts, tw) => { const d = rig(); d.trickPts = [200, pts]; d.tricksWon = [5, tw]; return d; };
  eq([RULES.gpForWin(mk(100, 2), 0), RULES.gpForWin(mk(99, 2), 0), RULES.gpForWin(mk(0, 0), 0)], [1, 2, 3]);
});

console.log("\n— whole deals —");
const N = +(process.argv[2] || 120);
t(`${N} bot deals: legal throughout, cards conserved, 356 when played out, the solver agrees with itself`, () => {
  let played = 0, melds34 = 0, swaps = 0, closes = 0;
  for (let i = 0; i < N; i++) {
    const rnd = RNG(1000 + i);
    const d = RULES.newDeal(i & 1, rnd); d.house = true;
    let g = 0;
    while (d.phase === "play" && g++ < 200) {
      const p = d.turn;
      const dec = decide(d, p, { brain: i % 3 ? "fritzl" : "greta", rnd });
      ok(dec, "the bot always has a move");
      const a = dec.action;
      ok(!/DOUBLE|TAKE|DROP/.test(a.type), "no doubling");
      const before = JSON.stringify([d.turn, d.trick, d.hands, d.meldSuit, d.up, d.closed]);
      if (a.type === "PLAY") { ok(RULES.legalCards(d, p).some(c => c.id === a.cardId), "legal play"); RULES.play(d, p, a.cardId, {}); }
      else if (a.type === "MELD") { if (a.suit.length > 1) melds34++; RULES.meld(d, p, a.suit, {}); }
      else if (a.type === "EXCHANGE") { swaps++; RULES.exchange(d, p); }
      else if (a.type === "CLOSE") { closes++; RULES.close(d, p); }
      else if (a.type === "CLAIM") RULES.claim(d, p);
      ok(before !== JSON.stringify([d.turn, d.trick, d.hands, d.meldSuit, d.up, d.closed]) || d.phase !== "play", "the move did something: " + a.type);
      const held = d.hands[0].length + d.hands[1].length + d.stock.length + (d.up ? 1 : 0) + d.trick.length;
      const won = d.log.filter(e => e.k === "trick").length * 2;
      eq(held + won, 32, "cards conserved");
    }
    ok(d.phase === "scored", "deal ended");
    if (d.result.reason === "exhausted") eq(d.trickPts[0] + d.trickPts[1], 356, "every point taken");
    played++;
  }
  console.log(`      ${played} deals: ${swaps} exchanges, ${melds34} common marriages, ${closes} closes`);
});
t("solver: strict royal endgames, every first move exact against plain minimax", () => {
  let n = 0;
  for (let i = 0; i < 40; i++) {
    const rnd = RNG(77 + i);
    const d = RULES.newDeal(0, rnd); d.house = true;
    for (let k = 0; k < 4 && d.phase === "play"; k++) { const l = RULES.legalCards(d, d.turn); RULES.play(d, d.turn, l[(rnd() * l.length) | 0].id, {}); RULES.play(d, d.turn, RULES.legalCards(d, d.turn)[0].id, {}); }
    if (d.phase !== "play") continue;
    RULES.close(d, d.turn);
    const r = solve(d, d.turn, 1e7);
    for (const m of r.moves) {
      const w = JSON.parse(JSON.stringify(d)); RULES.play(w, w.turn, m.card.id, {});
      eq(mm(w, d.turn), m.value, "move " + m.card.rank + m.card.suit);
      n++;
    }
  }
  ok(n > 50, "positions: " + n);
});
/* plain minimax over the real rules (marriages declared whenever a lead allows; never worse) */
function mm(d, me) {
  if (d.phase === "scored") return d.result.winner === me ? d.result.gp : -d.result.gp;
  const p = d.turn, vals = [];
  const tries = [];
  for (const c of RULES.legalCards(d, p)) {
    const w = JSON.parse(JSON.stringify(d));
    const mk = !w.trick.length && ENG.meldKeyOf(c);
    if (mk && RULES.meldOptions(w, p).some(m => m.suit === mk)) { RULES.meld(w, p, mk, {}); if (w.phase === "scored") { tries.push(w); continue; } }
    RULES.play(w, p, c.id, {}); tries.push(w);
  }
  for (const w of tries) vals.push(mm(w, me));
  return p === me ? Math.max(...vals) : Math.min(...vals);
}

console.log(`\n${pass} passed, ${fail} failed — royal house`);
process.exit(fail ? 1 : 0);
