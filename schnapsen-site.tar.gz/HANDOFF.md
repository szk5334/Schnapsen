# Schnapsen — serverless rebuild (handoff)

Lobby-first, phone-first, no backend. Everything multiplayer is peer-to-peer; the only third parties are
public Nostr relays, which introduce devices to each other and see an encrypted handshake, nothing more.
(This file is stripped by the deploy workflow.)

## What runs where

| Concern | How |
|---|---|
| Lobby presence, open tables | Trystero room `lobby`. A table is advertised in its owner's presence, so it is listed exactly while the owner is here. No database. |
| Lobby + table chat | Same meshes. Device-to-device over WebRTC (DTLS). New arrivals get the last 50 messages from whoever is present; each device keeps 120 locally. |
| Seats and options before the deal | The table owner's device (presence carries `{seats, opts, status, matchId}`). |
| The game | **Lockstep, no host.** Both devices run the unmodified engine on their own view of the deal. |
| Shuffling | **Mental poker** (SRA commutative encryption, RFC 2409 1024-bit safe prime, cards as quadratic residues). Four passes; neither device knows the order. |
| Seeing a card | The other device sends its per-position key for that one card. Plays, marriages and the trump swap carry the mover's key. |
| Honesty | End of every deal: both publish all keys; each device re-checks every shuffle pass and replays the deal face-up through the real engine. Silent by design: nothing about it is shown; "Next deal" simply enables once both sides have settled. The verdict is in `view.audit` if a UI for it is ever wanted. |
| Watchers | Seated devices broadcast `publicView` (scores, turn, log). Never a hand. |
| Solo vs bot | Entirely local (`openSolo`), bots as before. Online tables are two humans: a bot seat can't be hidden from the device running it. |

## Files

```
index.html            loads config.js (optional, repo root, NOT in the tarball) then app/boot.js
config.example.js     TURN relay URL, custom relays, p2p app id
app/boot.js           picks transport (?local = BroadcastChannel stand-in for 2-tab testing)
app/hub.js            lobby mesh: who's here, tables, lobby chat
app/session.js        solo; table seats/options; opens the match once dealt
app/chat.js           chat over a mesh (backlog sync, typing, local copy)
app/net/mesh.js       presence + topics over one Trystero room
app/net/p2p.js        Trystero, Nostr + WebTorrent discovery in parallel; one peer id, each message sent once          app/net/local.js   same surface over BroadcastChannel
app/mp/sra.js         BigInt SRA arithmetic     app/mp/deck.js     the four passes, open(), audit()
app/mp/match.js       the lockstep match: per-deal message log, key gifts, moves, audit, resume
app/ui/*.js           Preact + htm, no build step
vendor/               esbuild bundles of preact+htm and trystero 0.26 (self-hosted, no CDN at runtime)
schnapsen/engine, state   the engine, byte-identical to the Aug 22 build
```

## Invariants

- Engine untouched. Online play builds deals with `match.buildDeal` (mirrors `rules.newDeal`), because
  `newDeal` uses `Math.random` and a global id counter. Card ids online are canonical positions 1..N.
- A back is `{id: -(pos+1), back:true, pos}`; turning it over replaces it in place.
- Every match message is `{t, n (deal), s (sender seq), from (seat)}`; peers apply in seq order and
  de-duplicate. On (re)join each side resends its whole current-deal log plus the previous deal's.
- "Next deal" stays disabled until the audit has run (normally well under a second).
- No player-facing text mentions devices, keys, servers, shuffling or checks.
- `?as=NAME` namespaces localStorage so one browser can be two people (with `?local`).

## Tests

```
cd schnapsen/tests && node rules.test.mjs && node variant24.mjs && node guest.test.mjs   # engine gates
cd tests && node mp.test.mjs      # 2 simulated devices, 14 deals x (20-card, 24-card, 15% packet loss)
cd tests && node cheat.test.mjs   # audit catches reneges and rigged decks
tests/browser/*.py                # Playwright, two tabs with ?local: lobby, chat, seats, deal, reloads,
                                  # dropout, watcher, audited deals, solo (edit the chromium path)
```

Last run: rules 27/27, variant24 21/21, guest clean, mp 42/42 deals audited with 0 desyncs and 0 leaks,
cheat 5/5 reneges and 6/6 rigged decks caught, browser flows all green.

## Hidden connection page

`#/net` (linked from nowhere): relay/tracker socket states, peers per room and which network found them,
lobby presence, and WebRTC join errors (errors there mean TURN is needed).

## Not verified here

Real WebRTC between two phones over the public relays could not be exercised from the build sandbox
(relays unreachable). The real Trystero bundle loads and degrades cleanly. First real test: two phones.

## Next

- Contracts system (Sept–Oct sessions) lives in a different tarball; wire it in once the table is final.
- QOL list in the conversation; the cheap ones first: rematch, reactions, sound, unread on tab title.
