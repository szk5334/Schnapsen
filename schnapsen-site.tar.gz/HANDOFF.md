# Schnapsen — serverless rebuild (handoff)

Lobby-first, phone-first, no backend. Everything multiplayer travels sealed through public Nostr relays;
phones never connect to each other (Oct 23: the WebRTC/Trystero transport is gone — direct links failed
between real phones without a TURN server). Relays see throwaway keys, hourly tags and padded ciphertext.
(This file is stripped by the deploy workflow.)

## What runs where

| Concern | How |
|---|---|
| Transport | `app/net/relay.js`: each room (lobby, `table-CODE`) is an AES-256-GCM key + HMAC tag key from HKDF(app id, room). Every event: one secp256k1 key per page load (since .5; was one per event), one tag = HMAC(room, hour), body padded to 256…32768. Data kind 24748, control kind 24747: both ephemeral, nothing stored (since .5; data was stored kind 4747 with a 6 h NIP-40 expiry). |
| Delivery | Sequence numbers: one stream to everyone, one per recipient. Heartbeats (25 s, plus "tips" 2, 6 and 14 s after a burst) carry the latest numbers and the sender's relays (4-hex fingerprints). Holes → "want" after 1.5 s, asked again every 2–6 s while the sender is present; sender re-sends or says "gone". Reconnect asks each relay for what it missed (`since`). Routing (since .5): private → 1 shared relay; to everyone → covering set, no spare; unknown → 2 at random. Messages to the same people within 25 ms go as one batch event (`mb`); resends answering a want go as one batch. A relay answering OK=false is skipped 10 min and the event goes elsewhere. |
| Relay rules (build .2; budgets since .5, see "Being a good guest") | Public relays defend against spam: per-IP rate limits that become bans (relay.damus.io is reported to IP-ban), web-of-trust write filters (offchain.pub's operator runs one), logins/payment. So: NIP-11 read first (auth/payment/restricted_writes/PoW → never written to); per-relay token bucket (now 2 deep, +1 per 20 s, shared by nos.lol + nostr.mom); low budgets → 1 copy instead of 2, then another relay, then an outbox; routine heartbeats skipped first. Replies read by NIP-01 prefix: `rate-limited:` rests the relay 1→30 min; `blocked:`/`restricted:`/`auth-required:`/`pow:` (or "web of trust", "paid"...) retire it for 24 h, remembered in localStorage; CLOSED/AUTH the same. 4 failed connects in a row → retry every 10 min (an IP ban looks like this). Pool: damus, nos.lol, primal, ditto, coinos, nostr.mom, relay.nostr.net, snort. |
| Lobby presence, open tables | Room `lobby`. A table is advertised in its owner's presence, so it is listed exactly while the owner is here. No database. Presence carries a version so a late copy can't undo a newer one. Gone = `bye` on page close (pre-sealed, sent synchronously, since build 2026-10-26.4), or 140 s unheard (`STALE_MS`). |
| Lobby + table chat | Same rooms. New arrivals get the last 50 messages from whoever is present; each device keeps 120 locally. |
| Seats and options before the deal | The table owner's device (presence carries `{seats, opts, status, matchId}`). |
| The game | **Lockstep, no host.** Both devices run the unmodified engine on their own view of the deal. |
| Shuffling | **Mental poker**: commutative encryption on secp256k1 (k·P; since build 2026-10-29.1, before that SRA over a 1024-bit prime). Cards are hashed to the curve (RFC 9380). Four passes; neither device knows the order. Multiplication in wasm libsecp256k1, JavaScript fallback. |
| Seeing a card | The other device sends its per-position key for that one card. Plays, marriages and the trump swap carry the mover's key. |
| Stuck deals | `match.js` safety net: waiting on the other device 30 s (15 s before .5) with nothing arriving, and nothing of ours still queued for budget (`mesh.backlog()`) → re-send all of ours from this deal. Receiving such a re-send means they're stuck → echo ours once (tagged so echoes never echo). |
| Honesty | End of every deal: both publish all keys; each device re-checks every shuffle pass and replays the deal face-up through the real engine. Silent by design: nothing about it is shown; "Next deal" simply enables once both sides have settled. The verdict is in `view.audit` if a UI for it is ever wanted. |
| Watchers | Seated devices broadcast `publicView` (scores, turn, log). Never a hand. |
| Solo vs bot | Entirely local (`openSolo`), bots as before. Online tables are two humans: a bot seat can't be hidden from the device running it. |
| House rules (build .3) | `app/house.js`, a layer over the untouched engine; the default for new tables and solo. Table option `house` (Rules: House / Classic / With nines) and `piles` ("up"/"down"). Turned Ace → `trump = null` (the engine needs nothing else: no card is ever a trump, no swap, every marriage 20). Exhausted with nobody on 66 → no score, sheet row `{scoreless:true}`; the **pot is the run of scoreless rows at the foot of the sheet**, so it rides the sheet through deals, reloads and the lockstep ctx. Next scorer gets `gp + pot` (row `.pot`). Engine `result` is left as is, so the audit still compares engine-to-engine. House tables show values (2/3/4) via `setRankMode`, and face-up won cards as five rank piles inside the felt (both scores public; "Face down" hides the opponent's). |

## Files

```
index.html            loads config.js (optional, repo root, NOT in the tarball) then app/boot.js
config.example.js     custom relays, app id
app/boot.js           picks transport: relays, or ?local = BroadcastChannel stand-in for 2-tab testing
app/hub.js            lobby mesh: who's here, tables, lobby chat
app/session.js        solo; table seats/options; opens the match once dealt
app/house.js          house rules: reducer wrapper, pot, won-card list
app/chat.js           chat over a mesh (backlog sync, typing, local copy)
app/net/mesh.js       presence + topics over one Trystero room
app/net/relay.js      the relay transport (pool, sealing, routing, repair)     app/net/local.js   same surface over BroadcastChannel
app/mp/ec.js          curve locks: wasm multiply (JS fallback), hash-to-curve cards     app/mp/deck.js   the four passes, open(), audit()
app/mp/match.js       the lockstep match: per-deal message log, key gifts, moves, audit, resume
app/ui/*.js           Preact + htm, no build step
vendor/               esbuild bundles of preact+htm, nostr.js (noble-curves schnorr + sha256) and ec.js (noble-curves
                      secp256k1 Point + hash-to-curve); secp256k1.wasm (libsecp256k1 from tiny-secp256k1 2.2.3, MIT); self-hosted
app/fonts/            the web fonts, self-hosted (fonts.css + woff2 subsets + OFL licences; tools/fonts.py rebuilds)
schnapsen/engine, state   the engine, byte-identical to the Aug 22 build
```

## Invariants

- Engine untouched, apart from the additive 22-card deck (build 2026-10-28.4; see "Two nines"). Online play builds deals with `match.buildDeal` (mirrors `rules.newDeal`), because
  `newDeal` uses `Math.random` and a global id counter. Card ids online are canonical positions 1..N.
- A back is `{id: -(pos+1), back:true, pos}`; turning it over replaces it in place.
- Every match message is `{t, n (deal), s (sender seq), from (seat)}`; peers apply in seq order and
  de-duplicate. On (re)join each side resends its whole current-deal log plus the previous deal's.
- "Next deal" stays disabled until the audit has run (normally well under a second).
- No player-facing text mentions devices, keys, servers, shuffling or checks.
- `?as=NAME` namespaces localStorage so one browser can be two people (with `?local`).

## Tests

```
tests/gates.sh                    # EVERY non-network gate below, nproc at a time, one summary line each (since 2026-10-28.4)
cd schnapsen/tests && node rules.test.mjs && node guest.test.mjs   # engine gates
cd schnapsen/tests && node royal.test.mjs [deals]   # Royal House engine: phases, marriages, exchange, the double
cd tests && node royal.house.test.mjs [bummerls]   # Royal House Bummerls through the reducer layer
python3 tests/browser/royal.py    # Royal House in the browser (serve on :8765): fit after every move, double online
cd schnapsen/tests && node marriages.mjs --n=2000 [--b0=greta --b1=ignaz]   # 20/40 vs 17/34, paired deals
cd tests && node house.test.mjs   # house rules with bots: 150 Bummerls, turned-Ace share, pot, sheet sums
cd tests && node mp.test.mjs      # 2 simulated devices, 14 deals x 4 runs (classic, 15% loss, house, house + loss),
                                  # one process per run, nproc at once, no pacing; `node mp.test.mjs house 0.15` runs one
cd tests && node cheat.test.mjs   # audit catches reneges and rigged decks (fails if any slip through, since 2026-10-28.4)
cd tests && node ec.test.mjs      # curve shuffle: wasm = JS byte for byte, algebra, refusals, full deck + audit, tampering
cd tests && node house.relay.test.mjs  # own relay first, public fallback when it dies, back when it returns (~5 min)
cd tests && node zombie.test.mjs  # dead-but-open sockets, a relay restart, network back, goodbye on the wire (~3 min)
cd tests && node relay.test.mjs   # the real transport through 3 local relays (one lossy, one refusing):
                                  # presence, messages, deals, a relay dying, a reload, a player away
python3 tests/browser/relays.py   # two separate browsers over local relays (writes config.js; delete it after)
# relay tests need `ws` (npm i ws) resolvable from tests/, e.g. a node_modules symlink
node tests/browser/selfhosted.cjs # every screen, both transports: no request leaves the site except to the relay
                                  # pool; all six font faces load, and only from app/fonts/
tests/browser/*.py                # Playwright, two tabs with ?local: lobby, chat, seats, deal, reloads,
                                  # dropout, watcher, audited deals, solo (edit the chromium path)
```

Last run (Oct 23, build .2): rules 27/27, variant24 21/21, guest clean, mp 42/42 audited, 0 desyncs/leaks;
cheat: every renege and rigged deck caught; relay.test 14/14 at a brisk human pace (1.2 s/move) with a
web-of-trust relay (got 2 events, then dropped), a login-only relay by NIP-11 (got 0), a 30/min rate-limited
relay (0 refusals, never banned), a 30%-lossy relay and a relay dying mid-deal; browser relays.py 19/19
(next deal dealt in ~5 s; checker reads Yes/No with reasons); ?local flows all green.
The match re-sends only what the other side hasn't applied ("ak" on the wire), at low priority, backing off
15→60 s; re-sends answering a "want" go out only with budget in hand and at most every 8 s per message
(an earlier version queued them and fed back on itself: 417 waiting, 800 events per relay).

Build .3 (Oct 23, house rules + restyle): rules 27/27, variant24 21/21, guest clean, house 16692/0 (756 deals,
21.6% no-trump, 19 scoreless, pot paid), mp 70/70 audited incl. house runs (no-trump deals and a pot paid under
15% loss), cheat all caught, relay.test 14/14, browser flows green (house is now the default).
Browser relays.py: 19/19 on 1 of 3 runs. The other 2 failed at "Jamie closes the page: Seth sees 'stepped away'"
(90 s window): the banner does appear, just after the window, so Jamie's `bye` on pagehide didn't get out and the
80 s fallback fired. The .2 build passed that step 3 of 3 runs; per-run relay traffic is not higher on .3. Cause not
found: `bye` is best-effort (signed + sealed inside pagehide, behind any queued message). Watch for it on two phones.
Also in .3: the Google Fonts stylesheet loads non-blocking (it used to hold up config.js and the first render).
(Superseded by build 2026-10-26.3: fonts are self-hosted, see "Self-contained" below.)

## Look (build .3)

"The green room": casino baize `#0e3a2b` with a 1px gold pinstripe every 14px on every surface, square corners,
gold double rules on the header, felt, sheets and chat. Limelight for the wordmark, headings, scores and card
indices; Josefin Sans for everything else (names and table codes too: Limelight's G reads as C). Primary buttons
and selected segments are a metallic gold gradient. The lobby header is a marquee with a slow bulb chase (the only
self-moving thing; off under reduced motion). Card backs: green, gold pinstripe, double gold frame. Suits are the
house deck's: spades #16307e, hearts #c8231c, diamonds #d29e00 (darkened from #e9b300 for legibility), clubs #1d7a3b.
Fonts are self-hosted in app/fonts/ (since build 2026-10-26.3); nothing loads from another site.

## Large print (build 2026-10-24.1)

Refocused on large type and high contrast, same green-and-gold room. Base text 20px; ivory #fffbef on #0a2f22
(about 14:1), secondary text #dde4d3 (about 11:1), 2px gold rules on controls, 56px buttons, 50px segments.
Limelight only for the wordmark and headings; scores, card indices and everything read in play are bold Josefin.
Suit colours deepened to 4.5:1 or better on the card face (diamonds a dark amber #946500).
Cards sit square: no tilted or offset trick cards. The trick has two fixed slots (theirs left, yours right, an
empty dashed slot until a card lands); the turned card stands upright beside the stock. The hand sizes itself to
fit one row, up to 100px a card (`--n` on `.hand`). Suits are drawn SVG (`SuitIcon` in ui/cards.js), not font
glyphs: no text face has them, and phones filled the heart from a different, larger symbol font. The heart path
is scaled .92 to balance its solid mass. Also fixed: the stock's "Trumps" label shared the class `trump` with
trump cards, which washed out the trump cards' ink (old bug).

## Fixed table geometry (build 2026-10-24.1, later)

Every band of the table has one height for the whole game (opponent row 44, felt flexes with the screen only,
won-card rows 96 each, middle row 150+, status 32, actions 56 single row, hand = card height + lift). The
"stepped away" banner overlays instead of pushing. Checked by playing whole deals at 390x844, 412x915 and
360x780 and measuring every band after each move: zero shifts, no scrolling, including a four-card pile.

## One screen (build 2026-10-24.8)

The play screen is `height: 100svh` (small viewport: browser bars showing), so it is laid out once and never moves
when Chrome's bars slide. `.game` is a grid: 40 | well (minmax(0,1fr)) | 40 | 30 | 52 | hand. The well is a size
container; pile rows are min(96px, 25%) of it, minis are sized from their row (cqh), stock and trick cards from
their cells. Hand cards are min(116px, 12.6svh) wide and overlap only as much as the cards held need to fit
(`--c`), square and in line, corner index always visible. Corner index enlarged (rank .29w, suit .2w); pips .15w
on columns 40%/62%. Checked: whole deals at 412x750, 360x640, 390x844, 412x915: no scrolling, nothing past the
bottom edge, zero shifts during play.
Build .9: `.card { isolation: isolate }`, so a card's raised index and pips (z-index 1, above its ornament) stay
inside that card; an overlapping card now covers them.
Build .10: unplayable cards are greyed but opaque (grayscale + darken filter and a tinted ::after layer, no
opacity); in the hand, playable cards (z 2) come in front of unplayable ones (z 1), the selected card in front of all (z 3).

## The deck (build 2026-10-24.2)

- Pips: standard French layouts (2, 3, 4, 9, 10, Ace) in a field between the corner indices; lower half
  inverted; indices top-left and, inverted, bottom-right (`PIPS` in ui/cards.js). Suits are drawn SVG.
- Ornament (`tools/ornament.py` generates `app/ui/ornament.js`; symbols injected once, drawn with `<use>`):
  faint gold lace ground, gold double frame, illuminated index corner (gold bracket, ultramarine rule,
  vermilion dots, rosette), a flower bouquet in the free corners, top crest of filigree, a flowered vine
  garland down the free edge, all drawn for the top half and turned 180 degrees for the bottom. The Ace gets
  a lace rosette and flower wreath; the 2 and 4 a smaller medallion in their empty middle.
  References (PySolFC cardsets): Nicu's Ornamental corners, Ovale Salon ace rosettes, Dondorf and Hamburg 1864
  floral cartouches.
- Classic courts: the traditional double-headed K, Q, J from Seth's vector "Poker cards" set, cropped at the
  frame, in-frame suit marks recoloured to the house four colours, 200px WebP in app/courts/ (320 KB total).
  `tools/courts.py` rebuilds them (paths point at the session's unpacked copy). The set's licence wasn't in
  the zip; worth confirming if the site goes beyond friends.
- Back: after PySolFC tksol back101 (scroll-chain border, mirrored scroll band, mirrored "66") in deep gold on a
  powder blue and powder indigo wash, smoothed into one continuous gradient (build .3): a diagonal gradient
  #cfe2f6 → #b3c6f0 → #9c9fe2 under three heavily blurred layers of the old blotches (12, 35, 48), each layer
  one group under one filter; no tide lines, no grain. The hand-count backs are two radial blots of the same colours.
  Build .4: a soft white glow (blurred ellipse) behind each "66" so it reads off the wash.
  Build .7: elaborated, drawn as one half turned 180 degrees: blooms on the outer chain's corners, a gold lace
  ground over the inner panel, gold curls and a bouquet in each inner corner, flowering vines down both sides,
  and a centre medallion (ring of filigree curls, pale disc with a tick ring, a wreath of eight small flowers).
- Enamel pips (build .4, `PipIcon` in ui/cards.js): card pips are filled with a per-suit radial gradient (dark core
  → suit colour), get a near-white fade just inside the edge from the `pip-edge` filter (alpha eroded, blurred,
  subtracted, so it follows the real shape), and a stroke a shade darker than the middle (`PIP_LINE`).
  Build .6: the corner suit marks (cards and won-card piles) use `PipIcon` too; the corner numbers stay plain
  bold text, by Seth's choice. (`RankMark` and the `rk-edge` filter, the enamel number tried in .5, are still
  in the code, unused.) Tokens in logs and labels stay flat.

## Grandma prints and the 70s back (build 2026-10-24.11)

Replaces the face ornament (lace, bouquets, garland, crest, Ace wreath, 2/4 medallion) and the watercolour back.
`tools/wallpaper.py` (imported by `tools/ornament.py`) draws twenty SVG pattern tiles, one per card, in four suit
palettes, laid at .34 opacity behind each face through a radial fade mask (weaker in the middle), under the gold
frame (`orn-frame`). Nines borrow the ten's print.
  ♥ Ace chintz roses · K rose-and-ribbon stripe · Q strawberries · J polka dots + rosebuds · 10 doily lace
  ♠ Ace wisteria · K damask · Q violets · J forget-me-nots · 10 gingham
  ♦ Ace 70s daisies · K tulips · Q rose trellis · J calico · 10 sunflowers
  ♣ Ace hydrangea · K sweet peas · Q pansies · J feedsack · 10 toile sprigs
Back: 70s flower-power daisies in tomato red, denim blue, avocado green and mustard (one per suit) on cream, a
brown-and-mustard band, the gold frame, "66" in a brown pill cartouche. Hand-count backs: four colour dots.
Old ornament code (half/ace/mid symbols, watercolour filters) is still in ornament.py, unused.

## Cooper Hewitt prints (build 2026-10-24.12)

The face backgrounds are now cutouts from 20 Cooper Hewitt, Smithsonian Design Museum wallpaper scans (Seth's
Archive.zip, 25 scans, 5 unused). `tools/prints.py <scans> app/prints` crops a 5:7 piece per card (the `CUTS`
table: file, centre, width), tints it 32% toward the suit colour, and writes 250x350 WebP (about 300 KB for all
20). Build .13: tint lowered to 12%, shown at .62 opacity. A second set, app/cyano/, renders each cutout as a
one-colour sun print (contrast-stretched, shadows in the suit's ink, highlights to cream, faint wash and grain),
shown at .55; Menu → "Card faces" switches per phone (`prefs.faces`: print | cyano). Earlier: each face showed its print at .42 opacity through the `wp-fade` centre-fade mask, under the gold frame; nines
use the ten's. The drawn grandma prints in tools/wallpaper.py are no longer used on faces (the 70s back still is).
Licence: Cooper Hewitt images are often Smithsonian Open Access (CC0), but each object should be checked for the
CC0 badge on its si.edu page; not verified here.

## Lily backs (build 2026-10-24.14)

The back is the lily wallpaper Seth linked first (CHSDM-154584), cut by `back_images()` in tools/prints.py into
app/backs/: `back-print.webp` (the paper as is) and `back-cyano.webp` (Prussian-blue cyanotype, positive: pale
ground, blue lilies; Seth preferred it to the negative). It follows the "Card faces" menu choice. Gold frame and a "66" pill cartouche on top; the
hand-count backs are flat washes of the same colours. The 70s flower-power back (tools/wallpaper.py) is retired.

## Nines, zeros, and house rules with 0s (build 2026-10-24.16)

The 9s have their own prints (both sets): 9♥ poppy bouquet, 9♠ pansies (sampler), 9♦ beige trellis, 9♣ pastel
watercolour, from papers not used elsewhere. House rules no longer force 20 cards: the table options are now
Rules (House | Classic) and Deck (20 cards | 24). House + 24 is "house rules with 0s": the engine's 24-card deck,
with the 9 printed as 0 (`VALUE_RANK` in schnapsen/state/constants.js gained "9":"0", display only; the one change
under schnapsen/). A 0 has no pips, only its corner index, and shows its paper without the centre fade. Six won-card
piles when the deck has 24. Tests: house.test.mjs takes `24` (19765/0), mp.test adds a house24 run (14/14 audited);
fit check at 412x750 and 360x640 with six piles and six-card hands: no scroll, zero shifts.

## Best-of sun prints (build 2026-10-24.17)

Seth's second Archive.zip (20 scans, Cooper Hewitt and NMAH) was cut into 18 candidates (`tools/candidates.py`), each
sun-printed in all four inks and judged with the current 24 on: a motif that reads at card size, full tonal range
(p95-p5 luminance), quality of the original drawing, clean crop (no torn edges, folds, text, or crops under ~250px
enlarged), and calm enough behind pips. Rejected outright: torn #1/#12, the quilt photo, the album quilt (cluttered),
the cross-stitch sampler (138px, boxed), the lily-of-the-valley bouquet (text, reversed values), the gold rose swag
(weak range, border strip), the NMAH design drawings (paper edge, grid). Ten new papers replaced the ten weakest sun
prints (`CYANO_PICKS` in tools/prints.py; the wallpaper set keeps `CUTS`): 10H rose vine, JS chintz medallion,
9S chintz florals, QD/KC feathered floral stripe (lower/upper), JD trellis chintz, 9D scattered chintz,
JC chintz florals (lower), 10C flower and lattice, 9C flower sprays. Build .18: the wallpaper set takes the same ten papers (tinted 12% like the rest), so both sets
match card for card again. Ochre ink deepened (138,92,6) → (112,72,0):
the diamond row's tonal range rose about 15 points (now 133-156). Rebuild: python3 tools/prints.py <archive1> app/prints <archive2>.

## Final gate run (build 2026-10-24.18)

rules 27/27, variant24 21/21, guest clean, house 16939/0 (20 cards) and 18633/0 (with 0s), cheat all caught,
mp 84/84 audited deals across six runs (classic, 24, classic at 15% loss, house, house at 15% loss, house with 0s),
relay.test 14/14, browser flows green with no page errors, one-screen fit at 412x750 and 360x640: no scroll, zero shifts.
Not re-run this round: browser relays.py (passed 1 of 3 at build .3; see the "stepped away" note above).

## High visibility (builds 2026-10-24.19 to .21)

For Jamie. A per-phone switch, `prefs.big` → class `big` on `<html>` (ident.js), so the stylesheet does the work and
the other phone is unaffected. Turned on from: Menu → "High visibility" (table and solo), the name sheet (tap your
name in the lobby), the first-visit name screen, or any link with `?big` (`?big=0` turns it off) — so a link can
be sent ready-made.
- Faces (`BigFace` in ui/cards.js, class `.hv`): no pips, no courts, no corner indices; one rank over one suit,
  centred, with a soft ivory halo, over the card's paper (wallpaper or sun print,
  still chosen in the menu; Seth asked to keep both). Face base tinted toward the suit. Deeper red #a3150f and
  amber #7a5200 in this mode (6:1 or better on the tints).
- Even ranks (build .20, Seth's ask): at one font size Josefin Sans Bold draws digits 68 tall, K/Q/J 74, A 77
  (per 100px), and the J hangs 16 below the line; the "10" was also set smaller. Now `RankGlyph` (ui/cards.js)
  draws each rank as SVG text with its viewBox cropped to that glyph's own ink box, so every rank (A K Q J 10 9 0
  2 3 4) fills one height box: .52w on the faces, also used for the won-card pile labels. Ink boxes are measured
  on the phone with canvas `measureText` (re-measured on `document.fonts` ready/loadingdone; table `INK0` holds
  the Josefin values until then), so a fallback face is cropped right too. Wide ranks squeeze (max .86w), never
  shrink. Checked from pixels with Josefin loaded through the stylesheet: every rank 50–52px tall at w=100 (the
  rest is anti-aliasing on round tops); with no web font, all 52. Suit .52w, gap .07w.
- Build .21 fix (Seth's phone, 412x744 with Josefin): when the stock is under 160px tall the container query hides
  "N left", but the stock's rows were fixed (1fr 28px 30px), so the hidden label kept its row and the stock cards,
  sized as if it were gone, rose 13px above their cell over the opponent's won-card row. Rows are now
  `1fr auto auto` (labels keep fixed heights; a hidden one takes no row) and the short formula is cqh - 34.
  The old fit check compared scrollHeight, which can't see an upward spill. New gate `tests/browser/fit.cjs`
  checks every card and label inside its cell on all four sides after every move of whole deals. It caught the
  bug on build .20 and passes on .21 at 23 sizes (360x600 to 412x915, 20 and 24 cards), and with the mode off.
- Hand: every card whole, side by side, no overlap. Width from the deal's hand size `--n`, not the cards held,
  so a card never resizes during a deal: min(124px, (avail - gaps)/n, 20svh/1.4).
- Won cards (house tables): `Piles big` renders each rank as a big rank over four fixed suit slots
  (spades, hearts / diamonds, clubs), filled with a suit chip once won. Same place every time.
- Table: rows 44 | well | 44 | 36 | 56 | hand; stock column 42% (bigger turned card); larger status, captions,
  stats, buttons; opponent's tiny hand-count backs hidden. Under 700px tall: rows 40/34/54 and tighter felt; a
  container query drops the "N left" label when the stock is under 160px tall, so the stock cards keep their size.
- Lobby and sheets: base text 22px, small labels 18–20px.
Checked: one-screen fit at 360x640, 390x844, 412x750, 412x915, 20 and 24 cards: no scroll, no overflow in any band.
Browser flows green with the mode off and on (?big on every page), no page errors; rules 27/27, variant24 21/21,
guest clean. Engine and net untouched, so mp/cheat/relay/house were not re-run.

## Floral deck faces, Bicycle layout, four-square won cards (build 2026-10-25.2)

The faces now take the floral deck's papers (59 Cooper Hewitt cutouts, Smithsonian Open Access CC0; picks in the
deck's CREDITS.txt): A, 10, K, Q, J, 9 and the house 0 per suit, 250x350 WebP in app/prints (tinted 12%) and
app/cyano (sun print in the suit's ink). The 0 has its own paper (0S.webp etc.), shown whole; before, it borrowed the 9's.
- Papers stronger: .9 opacity (print) / .88 (cyano) through `wp-fade` (centre fade #6a6a6a → white by 78%), plus
  `wp-c1`/`wp-c2` radial fades behind both corner indices; the 0 uses `wp-corners` (corner fades only).
- Bicycle geometry (`PIPS` in ui/cards.js, now in whole-card fractions): side columns 27% / 73%, centre 50%; top and
  bottom rows 16% / 84% on every number card; 9 and 10 in four even rows; 7 and 8 as 3+1(+1)+3 halfway between
  rows; the 9's odd pip dead centre. Pips .25w boxes; Ace .44w, Ace of spades .56w.
- Bicycle index: rank .18w, suit .105w under it, at 5% / 4.5% from the corner (was .29w / .2w).
- Bicycle court panels: 56% of the card's width (was 46%), nearly full height; the 200px court art is shown ~1.4x.
- Won cards: `Piles` in ui/game.js always draws the High visibility display (rank over four suit slots, filled with
  a suit chip once won), with the mode on or off; the fanned mini-card piles are gone (their .mini CSS is unused).
- History: build 2026-10-25.1 carried the deck changes but was built on .19, so it lost .20 (even ranks) and .21
  (stock row fix). .2 is .21 plus the deck changes plus the won-card display.
Checked: tests/browser/fit.cjs (every card and label inside its cell after every move) at 16 sizes from 360x600
to 412x915, mode on and off, 20 and 24 cards; screenshots at 412x744 both modes; no page errors. Engine and net untouched.

## Marriages you can't miss (build 2026-10-25.3)

Seth kept missing the bot's marriages (it declares and leads in one go, so only "Fritzl led" showed). In ui/game.js:
- `useMeldPop` watches the count of meld entries in the deal log; a new one shows `MeldPop` for 3 s: the K and Q of the
  suit as cards and "Fritzl declared 20" / "You declare 40 in trumps". It is an absolutely placed grid item in the
  felt's row (`.mpop`, grid-row 2 / 3 of `.game`, which is now position: relative), pointer-events none, so play
  goes on under it and nothing moves. aria-live assertive.
- `meldNow` (plays aren't logged, so the log ends with the meld until the trick completes): while a declaration is
  waiting for its lead, or its K/Q is on the table, the trick caption is `MeldRibbon` (gold, "Marriage 20 ♥", pulses
  3 times) and the led card glows (`.tslot.meld`).
- Badges by each name (`.mchips`): suit + points for every marriage declared this deal. Not shown for the opponent
  when their points are hidden (face-down piles, memory mode).
Checked: solo deals played until the bot declared (mode on and off) and until Seth's seat declared, at 412x744 and
360x640; fit.cjs at 6 sizes, mode on/off, 20 and 24 cards; no page errors.

## The back room (build 2026-10-25.4)

Seth's ask: a classic backroom card table, premium felt, gold linework. Static by his choice: no smoke, no haze,
nothing that moves by itself (the lobby marquee's bulb chase is gone; "Opening the table…" no longer pulses). Avatars
stay squares (no poker chips, his call). Paint only: every size, padding and border width the fixed table reads is
as it was in .3, so the geometry notes above all still hold.
- Cloth: `app/room/felt.webp` (320px tile, billiard green with a combed nap, 8 KB) on every screen, under a warm lamp
  pool (`--lamp`, upper middle) and shade falling to near-black at the edges (`--shade`). Together `--cloth`. Type
  gets a soft dark text-shadow to lift it off the nap. Measured on screenshots: ivory 7.9:1 at the brightest spot
  of the play area, 11:1 in the lobby; High visibility turns the lamp down and the cloth darker (12:1).
- Rails: `app/room/wood.webp` (640x160, mahogany, tiles left to right, 3 KB) with a lacquer sheen. The header is the
  far rail, the in-game chat drawer the near rail; each keeps its gold double inlay (the 3px double border it had)
  and casts a shadow onto the cloth. Bottom sheets are trays of the same cloth with a mahogany lip.
- Gold linework: the play area is the old 5px double rule, now with rounded corners (14px) and four flourished corners
  (`--orn-tl/tr/bl/br`, inline SVG in app.css, on `.felt::before` behind the cards). List rows (tables, seats, bots,
  menu) are ruled with gold hairlines that fade at both ends (`--hair` border-image). The lobby name sits over a
  diamond rule (`--orn-rule`). Empty card places are a gold double outline printed on the cloth; empty won-card
  slots are solid dark recesses (so the corner flourishes never show through them).
- Controls: plain buttons are a gold rule with a hairline laid inside; primary buttons, selected segments, the pot,
  badges, marriage chips and the ribbon are gold leaf (`--metal`, deeper fold) with the label stamped in dark brown.
  A disabled primary shows a dashed outline instead of a half-faded gold.
- Type: Playfair Display SC (700/900) replaces Limelight for the wordmark and headings; the italic Playfair for the
  tagline and "Nothing said yet." Josefin Sans everywhere else, unchanged (the rank ink boxes are measured on it).
- Cards: unchanged, apart from softer, deeper shadows on the cloth and a gold glow on the selected card.
- Wide screens: the column is the table, edged in mahogany and gold, in a dark room.
- The marriage pop-up, ribbon pulse and glow (build .3) still animate: they are signals, not decoration.
- Build 2026-10-26.1: Limelight is loaded again. .4 dropped it with the headings, but the "66" cartouche on the card
  backs (ui/cards.js `Back`) is set in it, so the backs fell back to Georgia.
- `tools/room.py app/room` redraws both textures (numpy, frequency-domain noise, seamless).
Checked: tests/browser/fit.cjs at 16 sizes (360x600 to 430x932), mode on and off, 20 and 24 cards: 64/64 all inside;
browser flows green, no page errors; rules 27/27, variant24 21/21, guest clean. Engine and net untouched, so
mp/cheat/relay/house were not re-run.

## Courts without inner pips (build 2026-10-26.2)

On top of 2026-10-26.1 (the back room, Limelight back for the "66"). Seth asked for the suit pips inside the court
panels to go (the corner index already says the suit). The 12 images in app/courts/ were cleaned: in each panel's
top-left and bottom-right corner, the largest blob of the suit's colour (the pip) plus its anti-aliased rim (pixels on
the line from the pip colour to white) was painted white, then tiny leftover specks nearby that touch no larger shape.
Nothing attached to the figures' line work changes. Re-encoded as WebP q92 (375 KB for all 12, was 306 KB). The floral
decks' 24 court cards were re-rendered the same way. (A parallel session also numbered a build 2026-10-26.1 with only
this change; this .2 supersedes both.)

## Self-contained (build 2026-10-26.3)

Seth's ask: no CDNs, no fonts from other services, everything local. Audit of the shipped files (index.html, app/,
vendor/, schnapsen/): the only third-party load was the Google Fonts stylesheet in index.html (plus two preconnects).
Preact+htm and nostr.js were already self-hosted in vendor/; images, textures, courts, prints and ornaments are all
in app/; no `@import`, no remote `url()`, no dynamic `import()` of a URL, no workers, no analytics.
- `app/fonts/`: Josefin Sans 400/700, Playfair Display SC 700/900, Playfair Display italic 400, Limelight 400.
  woff2 from the Fontsource npm packages v5.3.0 (Google Fonts' own builds), split by unicode-range exactly as Google
  serves them (latin, latin-ext, vietnamese, cyrillic where the family has it), so a phone fetches only the subsets
  its text needs: normally the six latin files, about 120 KB. 356 KB on disk for all 24 files. `font-display: swap`.
  OFL licence per family alongside. `tools/fonts.py` rebuilds the folder (usage in its docstring).
- index.html: the Google links are gone; `app/fonts/fonts.css` loads before app.css, and the two Josefin latin
  files are preloaded (almost all text, and the rank ink boxes are measured on it).
- What still leaves the site, by design: the Nostr relays (app/net/relay.js: WebSockets, plus the NIP-11 info
  `fetch` to the same hosts). That is the multiplayer transport, not a resource load; `?local` and solo use none.
  The optional `config.js` 404s when absent (expected, same as before).
- `tests/browser/selfhosted.cjs` (new gate): walks name screen, lobby, a table, solo setup, a solo deal with play,
  Deal log / Score sheet / Rules, both card-face sets, High visibility and #/net, in `?local` and with the real
  transport; aborts and records everything off-site, closes relay sockets without dialling. Fails on any off-site
  request that isn't the relay pool, any font not from app/fonts/, any of the four families never loading, or a
  page error. On build .2 it fails (Google Fonts, no faces loaded); on .3 it passes.
- `tests/browser/fit.cjs` no longer stubs Google Fonts with hand-copied jf400/jf700 files: the real fonts load.
Checked: selfhosted.cjs PASS (0 off-site in both passes; relay pool only in pass 2; 6 faces loaded, 6 font files,
all from app/fonts/); fit.cjs at 13 size/mode/deck combinations from 360x600 to 430x932, all inside; flows.py green,
no page errors; rules 27/27, variant24 21/21, guest clean. Screenshots: wordmark in Playfair SC, body in Josefin,
italic Playfair, Limelight "66" on the backs. Engine and net untouched, so mp/cheat/relay/house were not re-run.

## Sturdier connections (build 2026-10-26.4)

All in app/net/relay.js (plus a wake-lock hook); engine, match, mesh and UI layout untouched.
- **Dead sockets that look open.** A phone that sleeps or hops wifi↔cell can keep a WebSocket that reads "open"
  while nothing passes, and `send()` into it never fails. Before: nothing noticed, ever — `tests/zombie.test.mjs`
  on the .3 transport delivers 0 of 5 messages and the table stalls for good. Now each connection is probed (a
  REQ with a random `#t` that must come back EOSE, then CLOSE) when the page comes back on screen, on `online`,
  on `navigator.connection` change, when a post has had no OK for 8 s (`ACK_MS`), and after 90 s of silence
  (`QUIET_MS`). No answer in 6 s (`PROBE_MS`) → `kill()`: handlers detached, reopened at once, subscriptions
  re-asked with `since`, and every post sent into the dead connection without an OK (`c.unacked`, kept 2 min, up
  to 200) goes out again (newest 30). A probe that passes clears older unanswered posts on that connection, so a
  relay that never sends OK can't make it probe in a loop. Test: 5/5 delivered in 15.6 s, no duplicates.
- **Connecting that never ends.** `CONNECT_MS` 10 s: a socket not open by then is dropped and retried. An `error`
  before open counts as the end too (Node's WebSocket never follows it with `close`; phones can hang in
  "connecting" for minutes). One `lost()` handles close, early error and timeout.
- **Relay restarts.** A relay that worked earlier this session (`everOpen`) gets 12 ordinary tries (backoff capped
  at 60 s, ~8 min) before the 10-minute slow retry; never-opened relays keep 4. Before, a relay down ~25 s was
  shunned for 10 min — relay.test's "relay 1 dies" left the good relay unused for the rest of the run (55 events vs
  ~245 on the lossy and rate-limited ones), which is most of its slow "caught up in 55 s". Failures while
  `navigator.onLine === false` don't count, and `online` / network change reset the count.
- **The goodbye.** `leave()` used to seal the `bye` (async WebCrypto) on the way out; and when it did get sealed it
  waited for send budget, which a deal's burst has usually spent. Traced in two browsers: Seth saw "stepped away"
  only after the 140 s timeout. Now the bye is sealed ahead of time (`prepBye`, re-sealed hourly; receivers hear
  h-1..h+1 tags) and sent synchronously from pagehide to every open, non-resting relay, budget or not (prio
  "force"). Seth sees it at once; Jamie's return clears the banner in 0.2 s (was 6 s, and 38.9 s in relays.py).
  This was the cause of the "Jamie closes the page" flake noted at build .3.
- **The lost first hello** (in .3 too). A page's first hello is made before any relay connection is open, so it
  went to the outbox with a copy count of 0 (`ok.length` at that moment) — and the outbox took it out and sent it
  nowhere. Every page load, reload and return was heard only at the second hello, 6 s later. Now a queued "all"
  goes to every relay once one opens. The 6 s second hello now goes out only if nobody has answered.
- **Hello replies.** The answer to a hello was a routine heartbeat (needs 4 tokens, else skipped), so right after a
  burst a returning page heard nobody until the next regular heartbeat (45 s). Now: one copy, 1 token, on a relay
  the newcomer said it uses (`heartbeat(false, false, peerId)`, prio "tip").
- **Ghost peers** (in .3 too). After a reload, the `since` replay handed each page stored events from pages that had
  already closed or reloaded (its own old page included: a new `selfId`). Each became a peer for 140 s, was greeted
  every 12 s on every relay (mesh `regreet`), and, knowing no relays, made `cover()` send every broadcast to all
  relays — draining the send budget everyone shares. Now a stored event (data events before the relay's EOSE on
  that subscription; 10 s fallback for relays that send none; control events are never stored) can't create a
  peer, and a peer that said goodbye (`gone`) can't come back. Judged by the relay protocol, not the sender's clock.
- Measured on two browsers through four local relays (normal, 20% lossy, web of trust, 30/min), whole sequence:
  deal, both reload, a watcher, Jamie closes and returns. Old: "stepped away" after the 140 s timeout; banner gone
  6–39 s after she's back. New: "stepped away" at once; banner gone in 2.1–2.6 s; watcher 6 s (same as .3).
  Deal times: same range as .3 (both 7.5–21 s on these relays, set by repairs on the lossy one).
- `pageshow` with `persisted` (restored from the back/forward cache after pagehide left every room) → reload.
- **Screen wake lock** (`useWakeLock` in ui/hooks.js, used by `Game`): the screen stays on while a game is showing
  (solo too), re-requested each time the page becomes visible; silently nothing where unsupported.
- `CANDIDATE_RELAYS` (the #/net checker only) adds relay.0xchat.com and nostrue.com.
- The transport object has `wake(net)` (what the DOM events call), used by zombie.test.
Checked (serially, nothing else running): zombie.test 13/13 (fails on .3: 0/5 delivered, table stalls); relay.test
14/14, "caught up after 20 s away" 18.5 s (was 55 s: the restarted relay is used again); browser relays.py 19/19 on
3 of 3 runs (was 1 of 3), "stepped away" at once, "comes back" 1.9 / 2.4 / 1.9 s (was 38.9 s); selfhosted.cjs PASS;
flows.py green, no page errors; rules 27/27, variant24 21/21, guest clean, house 16965/0, cheat all caught, mp 84/84
audited. Not checkable here: real public relays and real phones (sleep, wifi↔cell) — the first real test.

## Being a good guest (build 2026-10-26.5)

Seth's ask: read each relay's policies and make sure we never abuse them or get banned. Research (Oct 26, three
agents; relay hosts themselves weren't reachable from the sandbox, so mostly secondary sources and software
defaults):
- Almost no relay publishes terms. Limits come from software defaults and operator plugins:
  - strfry has no built-in rate limit. Its common plugin (strfry-policies) defaults to 10 events/min per IP.
  - Damus's noteguard plugin limits notes per minute per IP; the config jb55 quoted is 6/min. It bans the IP
    (default 1 h) after repeated violations. Another app got exactly that ban on relay.damus.io on 2026-10-15,
    and a third reports a ban after about three test runs.
  - khatru's "sane defaults": per IP, a burst of 10, then 2 events per 3 min.
  - nos.lol limits and refuses connections per IP; it shares a server (142.132.206.70) with nostr.mom.
  - relay.coinos.io blocks kinds it doesn't allow (unpublished list).
- Spec rules that applied to us:
  - NIP-40: "Clients SHOULD NOT send expiration events to relays that do not support this NIP"; relays may keep
    expired events indefinitely.
  - NIP-59: one-time keys defeat relays' per-key anti-spam. Trystero, the closest precedent, uses one key per
    page load and ephemeral kinds.
  - strfry's default maxEventSize is 64 KB (our 64 and 128 KB padding buckets would have exceeded it).
  - strfry refuses ephemeral events older than 60 s.
- Measured before (build .4, both phones, a move every ~4 s): 35–44 events/min on each relay during play, ~4 MB/h
  of stored data per relay, 2.5–5 events/min per relay with both pages idle.

What changed (app/net/relay.js unless noted):
- **Nothing stored.** Data moved to ephemeral kind 24748 with no expiration tag. Catch-up after a dropped
  connection is our own repair (want / re-send), which already existed. "mute:" (nobody listening) counts as OK.
  An event that waited over 40 s (for budget or a connection) is re-signed before it goes (`renew`, `specs`).
- **One key per page load** (`pageKey`), so operators can limit or block us per key, not per shared IP.
- **Budget:** token bucket 2 deep, +1 per 20 s per relay per page: at most 5 events in any minute and 3/min
  after. Two phones on one home IP: at most 10 and 6. nos.lol and nostr.mom share one bucket (`GROUP`).
  "rate-limited:" rests the relay 10 min, doubling to 2 h, so a relay never sees a quick second strike.
- **Fewer events:**
  - one copy per person; broadcasts to a covering set without a spare; unknown peers 2 relays (was all);
  - batching (`mb`) of messages to the same people within 25 ms, and of resends;
  - no routine heartbeat while alone in a room or after the page has been hidden 5 min; heartbeats every 60 s
    (was 45; `STALE_MS` 190 s);
  - a hello at most every 30 s on wake;
  - the tip heartbeat waits 10 s and is skipped if everyone has answered since;
  - the 6 s second hello only if nobody answered.
- **Two waste bugs found by counting every message of three deals** (`onPublish` hook in relayP2P's config, for
  tests):
  - heartbeats announced message numbers still waiting for budget, so the other side saw holes and asked for
    them (85 wants in three deals). Heartbeats now announce only what has gone out (`outQ`, `outD`).
  - The outbox wasn't first-in-first-out: a later message could overtake one waiting for budget (more false
    holes). And the match safety net (15 s) re-sent whole deals during ordinary budget waits. Now FIFO, and the
    safety net waits 30 s and never while our own messages are queued.
- **Size:** padding buckets stop at 32 KB (about 44 KB as an event).
- **Probes** after 45 s of silence (was 90): with fewer heartbeats a dead socket on the receiving side went
  unnoticed too long. A probe is a REQ, not an event, so it costs no budget.
- **Relay list** (DEFAULT_RELAYS): nos.lol, nostr.mom, relay.primal.net, relay.ditto.pub, relay.coinos.io,
  relay.nostr.net, relay.snort.social, nostr.oxtr.dev (operator: "free to read and write to"),
  nostr-pub.wellorder.net (nostr-rs-relay's author).
  - relay.damus.io is out: the flagship social relay, with hour-long IP bans after bursts.
  - Also out: offchain.pub and nostr.bitcoiner.social (web of trust), relay.mostr.pub (now only redirects to
    relay.ditto.pub), relay.nostr.band (down since mid 2026), relay.0xchat.com (one app's private-message relay;
    it was briefly added in .4).
  - The #/net checker also tries damus and nostrue.com.
- Known, not fixed:
  - relay.snort.social (memlay, in-memory) was reported keeping events past their expiry; moot now that nothing
    we send is stored.
  - Per-IP connection limits: each page holds one socket per relay; two phones make two per relay per IP.

Measured after (three deals, both phones, three local relays, a move every ~3 s, counting what reaches the
relays): ~43 events and ~112 KB per deal (was ~135 events, ~225 KB); 8 wants in three deals (was 85).
The busiest single minute on any one relay is bounded by the budget (2 phones × 5).
Where the rest goes: the protocol itself (4 shuffle passes, card-key gifts after each trick, 2 audits, next) plus
about one heartbeat a minute per room per phone. About half the bytes are the five 11 KB shuffle messages
(1024-bit SRA); an elliptic-curve shuffle (32-byte cards, noble secp256k1 already vendored) would take a deal to
roughly 15–20 KB. Not done.

### The house relay (same build)

Seth is putting up his own relay on Cloudflare, possibly more than one. Set them as `HOUSE_RELAY` in app/net/relay.js
or `house: "wss://…"` (or a list, best first) in config.js; both phones load the same config.js.
- **Redundancy advice:**
  - Cloudflare first, a relay on another provider second (Deno Deploy, or the Pi through a tunnel), public relays
    last.
  - Two Workers on one Cloudflare account share its free allowance and its outages.
  - Separate accounts just for quota are the kind of thing Cloudflare's terms frown on.
- **Budget:** 30 deep, +1 per second per page: 60/min, and both phones flat out all day would be ~170k messages,
  under 9% of the Workers free plan's ~2M incoming WebSocket messages a day.
- **Routing:** everything goes to the best house relay that is up and that everyone can reach: `cover()`,
  `dataTargets()` and heartbeats pick it via `houseFor()`; the next one on the list takes over. Someone whose own house connection is down says so in their heartbeat's relay list and gets public
  relays instead. Hellos and goodbyes go as two copies, since everyone listens on every relay (`everywhere()`): the best two house
  relays, or the house relay plus one public relay, or two public relays at random. A first hello queued before any
  connection opened goes to the first two relays to open, house relays first.
- **Never spills over:** a message meant for the house relay waits for its budget (at most a second) instead of
  going to a public relay (`alive()` in publish and the outbox). Public relays are used only while it is down,
  resting or refusing.
- **Quiet standby:** public relays stay connected for listening. Silence probes skip them unless we sent to them in
  the last 5 minutes.
- **Retries:** the house relay is retried briskly (backoff capped at 15 s, every 2 min after ~10 min down).
- **Test:** tests/house.relay.test.mjs, with houses A and B and two public relays.
  - A up: 2 deals in ~10 s at a move every 250 ms, 0 events on B or the public relays.
  - A killed mid-deal: B takes over (2 deals in 7 s, 0 on public).
  - B killed too: the public relays carry it (2 deals in ~100 s, at their budgets).
  - Both back: reconnected in ~6 s, and the next 2 deals are on A only.
- tests/browser/relays.py now runs with a house relay (7815) by default; `SX_PUBLIC_ONLY=1` runs the old
  public-only flow, which is slow at public budgets with only three usable test relays (relay.test covers that
  path).
  - Checks that the house relay carried the game and the public relays only spare hellos and goodbyes.
  - Checks one signing key per page load, replacing the old "a different key per event" check.

Checked, build .5 (serially):
- zombie.test 13/13, on three relays all going dead together. Worst-case recovery is now ~60 s, against ~16 s in
  .4: with fewer heartbeats the receiver notices silence later. On phones, network-change and back-on-screen events
  trigger an immediate check, so this is the fallback.
- house.relay.test 10/10.
- relay.test 14/14 at the public budgets; "caught up after 20 s away" 0.9–15 s.
- browser relays.py 20/20 on 3 of 3 runs, with a house relay: dealt in 0.4 s; "stepped away" at once; comes back
  0.9 s; house 140 events, public 24; 6 keys for 146 events.
- selfhosted.cjs PASS; flows.py green, no page errors.
- mp 84/84 audited; cheat all caught.
- rules 27/27, variant24 21/21, guest clean, house 17414/0.

**The relay itself (Oct 26):** separate repo `schnapsen-relay`, delivered as shnapsen-relay-site.tar.gz (Seth's name
for it, Oct 27; the workflow unpacks any .tar.gz in the repo root) plus `.github/workflows/deploy-relay.yml` (cloudflare/wrangler-action@v3, wrangler 4.153.0, secrets
CLOUDFLARE_API_TOKEN and CLOUDFLARE_ACCOUNT_ID). Setup steps are in its README; the project doc
claude/schnapsen-relay.md is a copy.
- **Design:** a Worker plus one SQLite-backed Durable Object ("hub", WebSocket Hibernation API; subscriptions and
  rate counters in each socket's 2 KB attachment).
- **Protocol:** a NIP-01 subset (EVENT/REQ/CLOSE → OK/EOSE/CLOSED/NOTICE) and NIP-11. Only kinds 24747 and 24748;
  id and Schnorr checked with the site's own vendor/nostr.js (`verifyEv(sig, id, pubkey)`, ~1.7 ms).
- **Limits:** created_at within ±120 s; 240 events/min per connection; 20 subscriptions; 500 connections.
- **Storage:** none.
- **Origins:** browsers only from ALLOWED_ORIGINS (https://szk5334.github.io).
- **Tested under wrangler dev:**
  - its relay.test 16/16;
  - the game's two-player test, 4 deals in 24 s;
  - browser relays.py with `SX_HOUSE_URL=ws://127.0.0.1:8787` 20/20 (dealt 0.4 s, comeback 0.4 s, public relays
    27 spare events). relays.py takes `SX_HOUSE_URL` to point the house relay at any URL.
- **Once deployed:** put its wss:// address in HOUSE_RELAY (app/net/relay.js) or config.js `house`.

**Live (Oct 27, 2026): https://schnapsen-relay.szk5334.workers.dev** (its page answers "Schnapsen house relay. It
carries sealed game messages and stores nothing."). Build 2026-10-27.1 builds it in: `HOUSE_RELAY =
["wss://schnapsen-relay.szk5334.workers.dev"]`. A config.js `house` setting now replaces the built-in list entirely
(`""` or `[]` = public relays only; a list adds a second relay). relay.test and zombie.test pass `house: []` so they
stay public-only. The sandbox can't open WebSockets to workers.dev (proxy 403), so the first live test of the
deployed relay is on the phones: #/net should list it as open on both.

Next on this thread: real phones. Leading option: a Cloudflare Worker + Durable Object (free plan:
100k requests/day, incoming WebSocket messages count 1/20, no duration charge while hibernating, SQLite-backed
objects only), accepting only kinds 24747/24748, storing nothing, used first with the public relays as fallback.
Second provider for a backup house relay (researched Oct 26):
- Render free web service: one instance, sleeps after 15 min without HTTP or WebSocket traffic, ~1 min to wake,
  5 GB a month. Good as a standby.
- Deno Deploy free: 1M requests, 20 GiB egress. It may run several copies, which then need BroadcastChannel; unverified.
- Google e2-micro always free: card required, 1 GB egress a month.
- The Pi at home behind Tailscale Funnel.
Oracle Always Free was cut on 2026-06-15 (A1: 2 OCPU / 12 GB) and reclaims instances idle 7 days (<20% CPU p95,
network, and memory on A1), which a quiet relay is. Fly.io has no free tier for new orgs (~$2.19/mo).

## Hand-size table cards, suit squares (build 2026-10-28.1)

Seth's ask: the stock, turned card and trick as close to the hand's card size as possible, to show off the art;
the won-card squares show their suits at every screen size; as little empty space as possible. Card faces unchanged.
- **One card width for the middle** (`--cw` on `.felt`): min(hand card width `--hw`, what fits across, what fits
  down). Across: stock 1.32 cards + trick 2 cards + 16px of gaps. Down: one card row + caption line (`--cap`) + both
  won-card rows at their minimum (`--pmin` 40px; 48 in High visibility). `--hw`, `--avail` and `--n` now live on
  `.game`, so the felt and the hand share them. High visibility caps the table's cards at 124px (`--wmax`), not at
  its smaller flat hand.
- **The stock lies under the turned card**: the turned card whole, the back showing 32% down its left with the
  count on it as a gold-leaf badge (`.cnt`; hidden once closed). The caption under it is "Trumps ♣", "Closed ♣" or
  "No trumps"; the old "N left" line is gone. The pot badge moved to the pile's bottom-left corner.
- **Felt grid**: four columns (1fr | stock | trick | 1fr), rows far piles | cards (auto) | near piles; the cards
  row takes its own height and the won-card rows share what's left. `.stock` and `.trick` are no longer size
  containers: everything in the middle is sized from the felt's cq units. Classic tables use the same grid with
  empty rows above and below.
- **Status and buttons share one band** (`.acts` holds `p.status` plus the buttons; `.has` left-aligns the status
  when there are buttons). Rows are now 40 | felt | 40 | 52 | hand (big: 44 | felt | 44 | 56 | hand). The 35px
  freed went to the felt. `.status` keeps its class, so the tests that read it are unchanged.
- **Won-card squares**: every square shows its suit, faint (suit tint, .62) on the dark recess until won, then the
  card's enamel pip (`PipIcon`) on its suit's ivory. Square size `--s` is the largest the row allows; on short rows
  the rank sits beside the 2x2, on tall rows above it (container query on the row's aspect ratio, `.np5` / `.np6`).
- Measured (normal mode, card widths hand / table, square px): 412x744 solo 94/94, 28; 412x688 (≈ online on that
  phone) 87/87, 21; 360x640 81/81, 17; 360x584 74/67, 16; 390x844 106/98, 31; 430x932 116/110, 35.
  Before, at 412x744: hand 94, trick 80, stock 54, squares 15.
- Checked: fit.cjs at 8 sizes (360x584 to 430x932) x mode on/off x 20/24 cards: 32/32 all inside; flows.py green, no
  page errors; selfhosted.cjs PASS; rules 27/27, variant24 21/21, guest clean. Engine and net untouched.

## The wallpapered wall (build 2026-10-28.2)

Seth's ask: replace the mahogany with the deck's colour florals, one clipping enlarged to cover the background, exposed
around the table and at the top, with a thin mahogany rail between the paper and the felt.
- `app/ui/papers.js` (`hangPapers()`, called from boot.js): picks one of the 28 papers in app/prints at random on each
  page load and sets `--wall` (its absolute URL: a relative url() inside a custom property resolves against the
  stylesheet, app/, and 404s). It also mirrors the paper into a 2 x 2 tile on a canvas (seamless in every direction)
  and sets `--wall-tile` as a blob: URL. Nothing new is fetched; `html[data-wall]` names the paper.
- `html` background: the paper, `cover`, top-centred, under a soft vignette. At 600px and wider: the mirrored tile at
  400 x 560, since one clipping can't stretch across a monitor.
- The table is a felt panel set `--inset` (6px) into the wall behind a rail: gold hairline, `--railw` (7px) mahogany,
  gold hairline on the felt side (`--panel-edge`). On the play screen `.game` itself is the panel (margin, border,
  `background-clip: padding-box`, overflow: clip). On every other screen it's a fixed `.screen::before`, from under
  the header to the bottom inset, so lists scroll over it.
- The header hangs on the wall: no background of its own, height `--bar-h` (62px; lobby clamp(110px, 24svh, 200px)).
  Every control or label is its own plaque (`--plate`: dark, gold edge, 2px backdrop blur); the wordmark's plaque is
  its `::before`, since its gold is clipped to the letters (the old drop-shadow filter had to go, it trapped the
  plaque above the text). The lobby centres the wordmark as a sign, with your name plaque in the top corner.
- The chat bar is on the wall below the table: the latest message and "Chat" on plaques (`.dmsg` wraps who + text).
  Opened, the drawer is mahogany-topped as before.
- Play-screen width: `--avail` is now 100vw - 38px (inset, rail, 6px padding), 10px less than before; the table's
  cards are unchanged where they were capped at hand size (412 wide), about 3px smaller on 390/430.
- Resolution: the papers are 250 x 350, so on a phone the wall is a ~5x enlargement and soft. Sharp would need the
  original scans; papers.js would then point at those (one file, loaded once per visit).
- Removed: the mahogany header/drawer rails, the lobby's diamond rule, the wide-screen mahogany frame.
- Checked: fit.cjs at 5 sizes x mode on/off x 20/24 cards all inside (one intermittent 19px sideways scroll of the
  table found and fixed with overflow: clip); flows.py green, no page errors; selfhosted.cjs PASS.

- Build 2026-10-28.3: the score screen (`.result`, shown in place of `.game`) gets the same felt panel and rail; it
  sat on the bare paper and its text was lost. The wall is now the paper repeated at its own size (250 x 350 css px),
  seams and all, on every screen width (Seth: "seams are fine"); sharper than the 5x enlargement. The canvas mirror
  tile and `--wall-tile` are gone.

## Two nines: the 22-card deck (build 2026-10-28.4)

Seth's variant: add only the **9♥ and 9♠**, worth 0, ranked **third** (house A 10 9 4 3 2; classic A 10 9 K Q J), printed
as 9 (not 0). Hearts and spades run six long, diamonds and clubs five; five cards each, 11 face down; the trump 2/J still
swaps; a turned Ace is no-trumps 4 deals in 22. Table option Deck: 20 | 22 | 24, for House and Classic.
- **Engine (the first change under schnapsen/engine since Aug 22; additive, the 20 and 24 decks play move for move as
  before, the gates say so):** core.js gains variant "22" (`RANK_SETS`, `HAND_SIZE` 5, `LOW_TRUMP` J), `NINE_SUITS`,
  `inDeck(rank, suit)`, `cards()` (the active pack), `normVariant(v)`, and a per-variant power table (`RANKVAL22`: the 9 at
  3.5, between K 3 and 10 4, so every other card keeps its number and the bot's trump costs are unchanged). `makeDeck`,
  `mp/deck.js canonicalDeck` and the bot's unseen-card enumeration all go through `inDeck`/`cards()`: **any new loop over
  SUITS x RANKS must too.** Variant parsing everywhere (reducer, match, session) goes through `ENG.normVariant`.
- **Bots:** they know the pack (sampled worlds never contain a ♦9/♣9) and the order (`ENG.power` drives follows, legal
  plays, the solver, adjacency). Four 9-specific knobs were added to `STYLE0` (`nineHold`, `nineLead`, `nineFear`,
  `nineTrump`) and **measured before shipping**: paired deals against the same bot with the knobs off, house rules,
  fritzl, 1000 pairs per seed, game points per deal:

  | Knob | Result | Seeds |
  |---|---|---|
  | hold a side 9 as a thief (2) | -0.007 | 5, 4 negative |
  | reluctance to lead the 9 (3) | -0.027 | 3, all negative |
  | fear leading a 4/3/2 into an unseen 9 (1) | +0.002 | 5, 3 positive |
  | trump 9 cheaper (-6) / dearer (+6) | +0.002 / 0.000 (no move changed) | 5 / 1 |
  | hold 2 + lead 2 + fear 1 | -0.024 | 5, all negative |

  So all four ship at **0**, which is move-for-move the plain bot: a 9 is already its favourite probe lead (worth 0)
  and the endgame is solved exactly. The knobs stay in the code for the next experiment. Harness was a scratch script
  (decide() with `style` overrides, `BOT.NINE0` = all off); not kept in the repo.
- **UI:** `displayRank` keeps "9" in the 22 deck (values mode still prints the 24 deck's 9 as 0); the card shows the 9's
  pips and its own print. Won cards: six columns 2 3 4 9 10 A; the 9 column has only the spade and heart squares (the
  diamond and club squares are `.chip.nil`, hidden, so the geometry doesn't change). Option note, lobby label
  ("house rules with two 9s" / "classic with two 9s") and both rules sheets describe it.
- **Faster gates (Seth: no rate limiting; relay is proven, so relay.test / zombie / house.relay are not part of the run):**
  - `tests/gates.sh`: every non-network gate, nproc at a time, one verdict line each.
  - mp.test: one process per run (the engine's deck setting is global, so runs can't share a process), nproc at once;
    no per-step sleeps (a bare `setImmediate` yield); fake-mesh delivery mostly `setImmediate`, a quarter 1 ms late so
    messages still arrive out of order; a 240 s wall-clock guard instead of a 40,000-step cap. 9 runs (adds 22, house22,
    house22 at 15% loss). 96% of its time is the SRA modpow (1024-bit BigInt), so that is the floor.
  - cheat.test used to exit 0 whatever happened; it now fails unless every honest deal passes and every renege and
    rigged deck is caught.
  - `?fast` (hidden, like `?local`): the solo bot moves at once instead of its 650 / 1600 ms human pace. fit.cjs and
    flows.py use it. fit.cjs waits for running transitions before measuring (at full speed it could catch the stock
    mid-move: a false "out of cell"), takes `DECK=22|24` (`D24=1` still works) and picks the deck by the segment's text.
    flows.py launches the pre-installed Chromium (`CHROME=` to override) and writes shots to `$SHOTS` (default /tmp/sx-shots).
- Checked: gates.sh all green in 181 s with everything sharing 2 cores (rules 27/27, variant24 21/21, **variant22
  35/35**, guest clean, house 17320/0, with 0s 18645/0, **two 9s 18511/0** (17.5% no-trump, only ♥9/♠9 ever played),
  cheat honest 6/6, reneges 5/5, rigged 6/6, **mp 126/126 audited** across 9 runs, no desync or leak). Baseline before
  the change: 152 s for the 7 gates that existed then (mp alone 152 s for 6 runs). fit.cjs 48/48 all inside (8 sizes
  360x584 to 430x932 x High visibility on/off x 20/22/24) in 178 s; flows.py green, no page errors (42 s);
  selfhosted.cjs PASS (41 s). Screenshots of a 22-card solo deal in both modes: 9 printed as 9, two-square 9 column.

## The curve shuffle (build 2026-10-29.1)

Seth's ask: a faster shuffle. The 1024-bit SRA arithmetic was 96% of the CPU in the two-device tests, and the shuffle
messages were half of every deal's bytes.
- **Scheme:** the same four passes and key gifts (deck.js API unchanged: pass1..4, open, audit). A lock is a scalar k
  mod n on secp256k1; a card is a point; locking is k·P, unlocking k⁻¹·C. Prime order (cofactor 1), so DDH hides which
  card a ciphertext is (the job SRA's quadratic residues did). Cards are **hashed to the curve** (RFC 9380 SSWU,
  DST `SCHNAPSEN-MENTAL-POKER-V1:secp256k1_XMD:SHA-256_SSWU_RO_`, message `card i`): no card has a known log relative
  to another. Never encode cards as i·G; that would let either player tell locked cards apart.
- **One multiplication where SRA did two:** re-locking a position is one multiply by a⁻¹·a[j], opening one multiply by
  a[j]⁻¹·b[j]⁻¹. Per 20-card deal: 80 multiplications for the four passes (40 per phone), up to 20 to open cards, 80
  for each phone's audit.
- **The multiply:** libsecp256k1 in wasm (vendor/secp256k1.wasm, 163 KB, from tiny-secp256k1 2.2.3, MIT; our own
  10-line loader in ec.js, no npm runtime). 0.36 ms in Node, 0.44 ms in Chromium; the JavaScript path (vendor/ec.js,
  noble-curves 2.0.1 `multiplyUnsafe`) is 2.5–3 ms and the old SRA unlock 4.2 ms. The wasm loads in the background
  (`ready`); until then, or if it can't load, the JS path runs. Both give the same bytes (ec.test checks).
- **Sizes:** a card is 66 hex (was 256). A 20-card pass is 1.4 KB of JSON (was 5.2 KB), so it pads to the 2 KB bucket
  instead of 8 KB: each shuffle message on the wire about 2.7 KB instead of 11 KB.
- **Measured:** one 14-deal two-device mp run 16 s (SRA) → 11 s (curve in JS) → 1.9 s (wasm); the full mp gate (9 runs,
  126 deals) 15.9 s. Per-deal crypto on this machine about 0.7 s (SRA) → 0.07 s.
- **Mixed builds:** shuffle messages carry `x: "ec1"`. A deal saved by the old build is re-dealt on load (score and deal
  number kept; the previous deal's own messages are dropped from the resend list). An untagged pass from a phone still
  on the old build is not applied; the table shows "Your opponent is on an older version of the game. Both of you
  reload the page." Both phones must update; #/net shows the build.
- app/mp/sra.js is gone. tests/house.test.mjs: the no-trump share is now checked against 4/deck size ± 4σ (the fixed
  14–26% band failed about one run in 300 with 24 cards, where the share is 1/6).
- Checked: ec.test 31/31; mp 126/126 audited, no desync or leak; cheat honest 5/5, reneges 5/5, rigged 5/5; flows.py
  green with wasm in Chromium, no page errors. Also green in the same gate run: house (3 decks), variant22/24, rules,
  guest. Not re-run: fit.cjs (no layout change) and the relay/zombie tests (transport untouched).

## The review, and staying on the score (build 2026-10-30.1)

Seth's ask: a post-deal analysis of both players' moves that both can see, explained in strategy terms (not game points);
and a player is never pulled off the last table or its score when the other presses Next deal.

- **Staying put.** `match.js` keeps the finished deal as `p.last = { n, s, audit }` when the next one starts (saved, so it
  survives a reload) and publishes it as `view.last`. `room.js` remembers which deal each player has on screen
  (`sx.look.CODE`, keyed to the game's matchId): while the live deal is newer, that player stays on the old table ("See
  the score") and then its score, where the button is "Back to the table" instead of "Next deal". The one who dealt sees
  "Jamie is still looking at the score" when it's Jamie's turn (the deal on screen rides in table presence as `look`;
  one presence event per player per deal). Header score, Deal log and Score sheet follow the deal on screen.
- **The record.** `auditDeal` now returns the deal face up as dealt (`d0`) and the moves; solo keeps the same
  (`sx.solo.rec`, written by `openSolo`'s dispatch). The Review button shows wherever a record exists.
- **The judging** (`app/review.js`, pure, generator). Every choice with an alternative is judged from what that player
  could see: 10 worlds dealt by the bot's own sampler (public facts only), every choice played out in each, same random
  stream per world for every choice. The rest of the open play is Greta's (no closing); a closed endgame is played by
  sampling from each side's own view (so a close isn't judged as if the closer could see the other hand); an exhausted
  stock is solved exactly. Anything that looks costly gets a second look over 60 worlds. Shown: choices costing 0.4
  game points or more, the 5 biggest, in order. A marriage and the card led with it are one choice.
  - Its own exact endgame (plain minimax with a memo; checked against a brute force in review.test): the engine solver
    caches alpha-beta values in a memo that ignores the window, and scores an exhausted deal "last trick wins" even
    under house rules. (The bot's solver was fixed in build 2026-11-01.1; see "The bot's endgame, fixed".)
  - Seeded from the deal (`seedOf(moves, hand ids, deal number)`), so both phones produce the same review.
  - Measured (16 fixed deals, Greta vs Poldi, two seeds): Greta flagged 7, Poldi 15; 68% of points identical across seeds
    (the rest sit near the bar). Settings and the alternatives tried are in the comment above `TUNE`.
- **The words** (`app/ui/review.js`). No numbers of game points. Each point: what was done, what was better, the hand
  with both cards marked, then
  - *what each choice is*: takes or gives the trick (card points), trumps, spends a top trump where a plain card wins,
    throws an ace or ten onto a lost trick, leads a ten while its ace is unseen, cashes an ace, breaks or skips a
    marriage, declares, swaps, closes (with the other's score frozen, double if under 33);
  - *how they played out differently* across the worlds (`note`/`contrast` in review.js): who wins the next trick, which
    of the player's aces or tens ends up in the other's tricks, whose marriages get shown, trumps left for the endgame;
  - *how it ends*: with every card known, both lines played out ("you take all 3 tricks and reach 66"); otherwise how
    often each wins the deal (or wins it double), in words ("most of the time", "about half the time").
  - Size in words (small / clear / big). Headline per player: the count of costly choices.
- **Speed.** About 2.5 s per deal on this machine in Node; in Chromium with the CPU slowed 4x, 17–22 s. It starts working
  in 25 ms slices the moment the score screen opens (`warm`), keeps going only while the score or review is on screen,
  and is kept for the session, so reopening is instant.
- **Tests.** `tests/review.test.mjs [deals] [deck] [house]` (in gates.sh, 12 deals): same seed same review; Poldi
  flagged more than Greta (from 10 deals up); every shown point over the bar; at most 5; exact endgame = brute force on
  ~40 positions. `tests/browser/review.py`: two tabs, one deals while the other is on the old table, the other's score
  offers Back to the table, survives a reload, "still looking at the score", both reviews finish, solo review, no page
  errors. flows.py now presses "Back to the table" for the second player.
- Checked: gates all green (mp 126/126 audited, cheat all caught, review 97/97); review.test on 22 (house) and 24
  (classic); review.py 11/11; flows.py green, no page errors; selfhosted.cjs PASS. fit.cjs not re-run (table layout
  untouched).

## The bot's endgame, fixed (build 2026-11-01.1)

The handoff for .30 flagged it: the bot used the engine solver (schnapsen/engine/solver.js), which (a) scored an
exhausted open deal "last trick wins 1" under house rules too, and (b) kept alpha-beta values in a memo that ignored
the window they came from. Both fixed in solver.js:
- **House rules:** the node carries `house` (from the deal: `d.house`, which the reducer state has), and an open deal
  that runs out with nobody on 66 is worth 0. The bot's close rollout (`worth()` in bot.js) scores the same way as
  app/house.js (a 66 not called is paid; otherwise 0).
- **The memo:** each value is stored as exact / at least / at most and reused only where valid (fail-soft). Every
  first move is searched with the full window, so the per-move values the bot AVERAGES over sampled worlds (closed
  stock) are exact; before, all but the first were cut-off bounds.
- **New gate** `schnapsen/tests/solver.test.mjs`: every first move's value against review.js's plain minimax (separate
  code), on strict positions from bot deals, 3 decks x house/classic, exhausted and closed, some no-trump.
  New: 8340/8340 exact on 1595 positions. Old solver: 213 wrong (all on moves it didn't pick; its picks were right).
- **Measured** (paired deals, same deal both ways round, new bot vs old, 1000 pairs per seed, game points per deal):

  | Bot, rules | Result | Seeds |
  |---|---|---|
  | fritzl, house | +0.006, +0.011, +0.017, +0.018, +0.026 (mean +0.016, se ~0.006 each) | 5/5 positive |
  | greta, house | +0.009, +0.015, +0.017 | 3/3 positive |
  | fritzl, classic | +0.000, +0.002, +0.004 | noise, as expected |

  Small and clean: a structural fix. 3–4% of pairs play differently (the solver only runs in strict play).
- Tests: cheat.test's fake mesh no longer waits 1 ms per message (next-tick delivery, a bare yield per step).

## Duplicate deals (build 2026-11-01.1)

Seth's ask: on the score screen, Next deal and **Duplicate deal**. A duplicate is the last deal again, the other way
round: each player gets the hand the other had, the same turned card, the same stock order. Both deals count on the
sheet as usual; the duplicate's score screen opens with a comparison: what each made in each deal and over the pair
(pots left out). Logic in `app/dup.js` (pure, used by solo and online):
- `dupDeal(base, d0, perm, prev)`: `base` is the next deal as the table deals it anyway (dealer alternated, score,
  sheet, deal number, house flags); the old cards are laid over it. The dealer alternates, so the hand that led still
  leads, in the other player's hands. Ids are the old deal's own cards (canonical positions online).
- **Suits renamed** at random (`dupPerm`), only among suits holding the same ranks (22 deck: ♥/♠ with each other), so
  the cards don't look the same at a glance; the trump suit is renamed with the rest, so the deal is the same deal
  (a turned Ace still means no trumps). The notice doesn't mention it (Seth's call).
- A duplicate can't be duplicated (`canDup`; `s.dup` marks one). The Bummerl's last deal can be duplicated: it
  becomes deal 1 of the next Bummerl. Sheet rows of duplicates carry `dup` (shown "4 (3 again)").
- `freshDeal` clears `dup`; the settle functions (reducer.js, house.js) tag the row.
- **Online** (app/mp/match.js): "next" may carry `dup: 1`. **Seat 0 decides** each new deal with its first message:
  "p1" (fresh shuffle) or "dup" (with the renaming); it sends "dup" when the "next" that ended the last deal asked
  for it (`p.wantDup`). If both press different buttons at the same moment, seat 0's own choice wins and seat 1
  follows whatever arrives: the devices can't diverge. No shuffle for a duplicate: both devices hold the last deal
  face up (`p.last.audit.d0`) and lay out the same cards. **So in a duplicate each device holds the opponent's hand
  and the stock face up in its state** (drawn as backs); a doctored client could show them. It's the last deal's
  cards renamed, which both players have seen (and the review shows). The "audit" of a duplicate is local
  (`{ ok, d0, moves, dup }`); no keys travel. A phone still on .30 never answers "dup": both must update.
- **UI** (ui/game.js): the score's buttons wrap to two rows (Review, Next deal / Duplicate deal). `DupPop` over the
  felt for 3.5 s at the start ("Deal 3 again: Jamie has your hand from deal 3, and you have theirs. Same turned
  card, same stock."), shown until the first trick completes even if the other side leads at once. `DupTally` on the
  duplicate's score, right under the game points. room.js: a duplicate request moves the presser on like Next deal;
  the other player stays on their score ("Back to the table") as before.
- Tests: `tests/dup.test.mjs` (in gates.sh): 240 deals across 3 decks x house/classic: exact layout, renaming only
  among same-rank suits, and the first deal's moves mirrored (other seat, renamed cards) replay move for move to the
  mirrored result; two devices x 4 configurations: either seat asks, identical layout on both, mirrored play,
  duplicate of a duplicate refused, both races, a reload mid-duplicate. `tests/browser/dup.py`: two tabs and solo,
  notice, held player, comparison on both, sheet mark, reload.

Checked (build 2026-11-01.1): gates all green in 141 s (mp 126/126 audited, cheat all caught, review 96/96, dup
4716/4716, solver 8340/8340, house x3, variants, rules, guest); flows.py green, review.py 11/11, dup.py 17/17 (3 runs),
selfhosted.cjs PASS, no page errors. fit.cjs not re-run (the table's layout is untouched; the notice is an overlay).

## Hidden connection page

`#/net` (linked from nowhere): the build (`app/version.js` — bump per tarball; both phones must match), each
relay's state (open / resting / off with the reason / unreachable), events sent and budget, who this page has
heard from per room, lobby presence, relay notes, and **Check relays**: test-posts one stored and one
passing-through event to every candidate relay from this phone, reports Yes/No with the reason, and offers a
`config.js` list of the ones that work.

## Known limits

- Relays see IP addresses and timing. Tor Browser / Orbot hides the address.
- The lobby key derives from the public app id; a table's from its 4-letter code (guessable). Cards stay
  safe regardless (mental poker); table chat is as private as the code.
- Kinds 4747/24747 mark the traffic as this app's (same kinds as Party Line).
- Relays publish almost nothing about their limits (none of the six original relays' NIP-11 documents list
  rate limits); the budget is a guess kept well under typical client traffic. A browser can't see why a
  connection failed, so a ban and an outage look the same ("unreachable").
- Throwaway keys mean web-of-trust relays will always refuse us; they're detected and dropped.
- Presence isn't signed: anyone with the room key could claim a name. Party Line's identity keys would fix it.
- Not verified here: the six public relays (unreachable from the build sandbox). First real test: two phones.

## Next

- Contracts system (Sept–Oct sessions) lives in a different tarball; wire it in once the table is final. The house
  rules doc lists contracts as experimental; not in this build.
- QOL list in the conversation; the cheap ones first: rematch, reactions, sound, unread on tab title.
- From the Nov 1 list (play-experience ideas): endgame puzzles from real deals (the review's exact solver finds the
  answer), table mode (a tablet shows the felt, phones are hands; the watcher view is most of it), a lifetime ledger
  with Jamie, handicaps, a scorekeeper for a real deck.

## Nov 10 2026: no more no-trumps, one deck, marriage scale
- House rules: a turned Ace now names trumps like any other card (the 2 of trumps swaps for it). No-trump deals
  were dropped as too luck-based. `houseDeal` and `dupDeal` always use the turn-up's suit; the engine still
  accepts `trump = null` (solver tests use it), and the "No trumps" UI branches are now dead code.
- The 22- and 24-card decks are gone: engine is 20 cards only, the Deck option, the 9/0 display, the bot's nine
  knobs, variant22/variant24 tests and the house 22/24 + mp 22/24 runs are removed. `setVariant`/`getVariant`/
  `normVariant` remain as shims (always "classic") so old saves, older peers and existing call sites keep working.
- HOUSE RULES PLAY 17/34 MARRIAGES (17 plain, 34 royal: the 3 and 4 of trumps); classic tables keep 20/40.
  `ENG.meldValue(suit, trump, d)` reads the deal: `d.marriages` if set (experiments), else 17/34 when `d.house`.
  The solver and review nodes carry `marriages`. The bot's "royal marriage" wording keys off the trump suit.
  Older builds score 20/40 at house tables, so both phones must run build 2026-11-10.1 or later.
- Measured (schnapsen/tests/marriages.mjs, house rules, trumps always): 17/34 vs 20/40, 5000 paired fritzl deals:
  closes 62.7% -> 59.5%, tricks per deal 6.56 -> 6.95, winners short of 66 on tricks 59.1% -> 54.9%, win rate when
  dealt the royal marriage 80.2% -> 72.8%, gp/deal unchanged (1.69). Skill (greta vs ignaz, 6000 paired deals over
  3 seeds): greta's edge grows by about +0.044 +/- 0.012 gp per deal (~+19%).


## Royal House (build 2026-11-11.1)

Seth's Extended House Rules (project doc claude/extended-house-rules.md) as a third rule set beside Classic and House.
Table/solo option Rules: Classic | House | Royal House = `{house:false}` | `{house:true, variant:"classic"}` |
`{house:true, variant:"royal"}` (`RULESETS` / `rulesetOf` in app/house.js). Royal House is a house table (pot, piles,
no 200 no score) with the 32-card pack. **Both phones must run this build**: an older build reads `variant:"royal"` as
the 20-card pack, so the two devices would deal different decks and the audit fails.

**Rules.** A 10 K Q J 4 3 2 per suit, worth 21 20 14 13 12 4 3 2 (356; courts are their 2/3/4 twin + 10). Five cards
each, turn-up, 21 face down. Free play while `stock.length > 11` (tricks 1-5), follow suit (no heading, no forced trump)
while the rest of the stock lasts (tricks 6-11), strict for the last five; closing jumps to strict. The 2 or J of trumps
swaps for the turn-up on lead (2 first if both held), once per deal, never when the turn-up is itself the 2 or J of
trumps. Royal marriage K+Q 40/80, common marriage 4+3 20/40. Out at 200, Schneider under 100. The double: on lead,
before playing or declaring, stock open, cube centred or yours; accept doubles the cube and passes ownership, decline
ends the deal paid at the pre-double value (no Schneider/Schwarz). Results are multiplied by the cube; a scoreless
doubled deal adds its cube to the pot; the pot itself is a flat bonus (never doubled).

**Engine** (additive; classic and house play move for move as before, the gates say so):
- core.js: `PACKS` (classic, royal) behind the old global `setVariant` (`normVariant`: only "royal" is royal; old
  "22"/"24" still mean 20 cards). `val`/`power`/`RANKS`/`cards()` read the active pack; `ENG.OUT`, `ENG.HALF`,
  `ENG.DECK_POINTS` are getters (66/33/120 or 200/100/356). `exchangeRanks()`. **Marriage keys**: "H" = K+Q of hearts
  (unchanged, so classic logs/saves/messages are identical), "H3" = the common 4+3. `meldKeyOf`, `partnerRank`,
  `meldRanks`, `isMeldCard`, `meldSuitOf`, `meldKindOf`; `legalLeads(hand, key)`; `meldValue(key, trump, d)`.
  `legalFollows(hand, led, trump, mode)` with mode false/"free" | "follow" | true/"strict".
- rules.js: `playMode(d)` (FOLLOW_AT 11), `exchangeCard`, `canDouble`/`canAnswer`, `double`/`take`/`drop`,
  deal fields `cube`, `cubeOwner`, `offer` (absent on 20-card deals: `cubeOf(d)` defaults 1). While an offer waits,
  nothing but TAKE/DROP is legal. `finish` multiplies by the cube (result `cube`, `base`); reason "drop".
  `RULES.OUT`/`RULES.HALF` getters. Meld log entries for the common marriage carry `kind:"34", key`.
- solver.js: thresholds from the pack, cube on the node, melds via `meldKeyOf`. reducer.js: DOUBLE/TAKE/DROP;
  `freshDeal` drops the previous deal's cube fields (bug found by royal.house.test).
- bot.js: royal side-card costs (A 12, 10 7, K 3, Q 2, J 1); marriage protection for both kinds; exchange only when it
  upgrades (the 2 always, the J for a higher trump or a card that completes a marriage); close gate at OUT/3; reads
  (profiles) off in Royal House (they were measured on 20 cards). **The double** (`cubeStudy`): N belief-free worlds
  played out under the rollout policy, E = mean signed result per cube point. Offer when 0.35 <= E < 0.95 and (lead
  >= 25 or me >= 100); accept when E > -0.5. poldi never doubles and always accepts. Rollouts never close or double.
- Measured (Node, paired deals, royal, vs poldi): fritzl +0.58 gp/deal (300 pairs, 55% wins; with the double turned off +0.39 over 100 pairs),
  greta +0.23 (100 pairs) — **greta is not stronger than fritzl in Royal House** (her style knobs one by one on fritzl
  don't explain it; noise is large with the cube). Not tuned. Decision time: median 0 ms, p95 25 ms, max 83 ms.
  Bots double in more than half their deals with each other, and the doubled side declines more often than not.

**App:** house.js (cube in settle, `add` on scoreless rows, potOf sums them); match.js (DOUBLE/TAKE/DROP moves and
audit legality, meld/exchange reveals by key / `exchangeCard`, variant set in `act`); session.js (records the new
moves for the review, sets the pack on a saved solo game); review.js (thresholds from the pack, cube, melds by key,
DOUBLE/TAKE/DROP replayed but not judged; Royal House uses 6 worlds per choice and 24 on a second look:
`TUNE.ROYAL_FIRST/SECOND`, ~3 s per deal in Node); redact.js log lines.

**UI** (ui/game.js): Royal House prints every rank as itself (`useRanks`: values only for 20-card house). Won cards in
eight columns (`np8`, CSS container query at 95/10). The stock caption reads Free / Follow / Strict (gold for follow
and strict) instead of "Trumps"; a phase pop-up when the first pile runs out and when the stock does (not after a
close). The cube rides on the pile as a badge (`.cube`, top right; dashed "×2?" while an offer waits) and a pop-up says
each double and acceptance. Actions: Double (tap twice, "Sure? ×2"), Accept / Decline when asked (status "X doubles");
marriage buttons show KQ or 43 and drop "Declare" when more than two buttons; Swap names the card given. Result:
"The double was declined" + who declined; "Doubled ×N" in the tally; "No 200, into the pot (2)" rows. Rules sheet:
three tabs (Classic | House | Royal House). Room/solo options: three-way Rules, "Reaching 200", a note. Lobby rows say
"Royal House".

**Card papers:** the 2, 3 and 4 of each suit (both sets) come from the Floral Deck repo's own card map
(`manifest.json` deck), same treatment as the rest (250x350 WebP, wallpaper set tinted 12%, sun prints as the deck
made them). `python3 tools/floral_papers.py <Floral-Deck clone> app` rebuilds them; checked by rebuilding seven
existing faces the same way (mean pixel difference 2-4/255, i.e. WebP noise).

**Also fixed:** app/ui/rules.js in 2026-11-10.1 was cut off at the end (no closing backtick), a syntax error that
kept the whole site from loading.

**Tests:** schnapsen/tests/royal.test.mjs (pack, phases, follow obligations, marriages, exchange, the double,
scoring, 100 bot deals with conservation checks, solver vs plain minimax on closed royal endgames);
tests/royal.house.test.mjs (Bummerls through the reducer layer: marriage values by kind, cube on the sheet, declines,
scoreless deals add their cube, sheet sums); mp.test adds houseroyal at 0% and 15% loss (random doubles, takes and
drops online, all audited); dup.test adds royal (mirrored deals incl. common-marriage keys, two devices);
review.test runs `4 royal 1` in gates. tests/browser/royal.py: solo at 390x844, 360x640, 412x744, High visibility on
and off, whole deals with doubles, accepts, declines and marriages, every card/label/badge inside its cell after
every move; two tabs with a Royal House table, a double accepted online, a reload. (tests/browser/fit.cjs still clicks
the Deck option removed on Nov 10; it needs updating before it can run again.)

Checked (build 2026-11-11.1): gates all green in 61 s (mp 84/84 audited across 6 runs, house 19980/0, cheat all
caught, review 94 ok + royal 56 ok, royal.house 2591/0, royal 21/21, dup 2337/2337, solver 2792/2792, rules 28/28,
guest clean); royal.py all green (0 layout problems, 0 page errors); flows.py green, review.py 11/11, dup.py 17/17
(one earlier run timed out waiting for the solo duplicate notice, passed on rerun; it passes on 11-10.1 too).

## Nov 12 2026: the double taken out; no opponent hand row (build 2026-11-12.1)
- Seth's call: Royal House has no doubling. Removed everywhere: engine (`canDouble`/`canAnswer`, `double`/`take`/
  `drop`, the "drop" result, `cube`/`cubeOwner`/`offer`, cube multiplication in rules/solver/review/house, the pot's
  `add`), bot (`cubeStudy`, offer and answer), reducer actions, match legality, the UI (Double / Accept / Decline,
  the ×N badge, the pop-up, result and log lines), the rules sheet and the option note. Everything in the Royal House
  section above about the double is history. Royal House scoring is now exactly house scoring with 200 / 100.
- The opponent's hand-count card backs (the row of small rectangles by their name) are gone from every rule set.
  Their `.backs` CSS went with them; tests/browser/royal.py fails if they come back.
- Checked: gates all green in 59 s (mp 84/84 audited incl. houseroyal, house 18662/0, royal.house 5558/0, royal 17/17,
  review 96 + royal 60, dup 2337/2337, solver 2792/2792, rules 28/28, cheat, ec, guest); royal.py all green at
  390x844, 360x640, 412x744, High visibility on and off (0 layout problems, 0 page errors; online table 8 won-card
  columns on both, after a reload too); flows.py green, no page errors.
