# Schnapsen — serverless rebuild (handoff)

Lobby-first, phone-first, no backend. Everything multiplayer travels sealed through public Nostr relays;
phones never connect to each other (Oct 23: the WebRTC/Trystero transport is gone — direct links failed
between real phones without a TURN server). Relays see throwaway keys, hourly tags and padded ciphertext.
(This file is stripped by the deploy workflow.)

## What runs where

| Concern | How |
|---|---|
| Transport | `app/net/relay.js`: each room (lobby, `table-CODE`) is an AES-256-GCM key + HMAC tag key from HKDF(app id, room). Every event: new secp256k1 key, one tag = HMAC(room, hour), body padded to 256…131072. Data kind 4747 (relays keep 6 h, NIP-40), control kind 24747 (heartbeats, wants). |
| Delivery | Sequence numbers: one stream to everyone, one per recipient. Heartbeats (25 s, plus "tips" 2, 6 and 14 s after a burst) carry the latest numbers and the sender's relays (4-hex fingerprints). Holes → "want" after 1.5 s, asked again every 2–6 s while the sender is present; sender re-sends or says "gone". Reconnect asks each relay for what it missed (`since`). Routing: private → 2 shared relays; to everyone → covering set + spare; unknown → all. A relay answering OK=false is skipped 10 min and the event goes elsewhere. |
| Relay rules (build .2) | Public relays defend against spam: per-IP rate limits that become bans (relay.damus.io is reported to IP-ban), web-of-trust write filters (offchain.pub's operator runs one), logins/payment. So: NIP-11 read first (auth/payment/restricted_writes/PoW → never written to); per-relay token bucket 10 deep, +1 per 3 s; low budgets → 1 copy instead of 2, then another relay, then an outbox; routine heartbeats skipped first. Replies read by NIP-01 prefix: `rate-limited:` rests the relay 1→30 min; `blocked:`/`restricted:`/`auth-required:`/`pow:` (or "web of trust", "paid"...) retire it for 24 h, remembered in localStorage; CLOSED/AUTH the same. 4 failed connects in a row → retry every 10 min (an IP ban looks like this). Pool: damus, nos.lol, primal, ditto, coinos, nostr.mom, relay.nostr.net, snort. |
| Lobby presence, open tables | Room `lobby`. A table is advertised in its owner's presence, so it is listed exactly while the owner is here. No database. Presence carries a version so a late copy can't undo a newer one. Gone = `bye` on page close, or 80 s unheard. |
| Lobby + table chat | Same rooms. New arrivals get the last 50 messages from whoever is present; each device keeps 120 locally. |
| Seats and options before the deal | The table owner's device (presence carries `{seats, opts, status, matchId}`). |
| The game | **Lockstep, no host.** Both devices run the unmodified engine on their own view of the deal. |
| Shuffling | **Mental poker** (SRA commutative encryption, RFC 2409 1024-bit safe prime, cards as quadratic residues). Four passes; neither device knows the order. |
| Seeing a card | The other device sends its per-position key for that one card. Plays, marriages and the trump swap carry the mover's key. |
| Stuck deals | `match.js` safety net: waiting on the other device 15 s with nothing arriving → re-send all of ours from this deal. Receiving such a re-send means they're stuck → echo ours once (tagged so echoes never echo). |
| Honesty | End of every deal: both publish all keys; each device re-checks every shuffle pass and replays the deal face-up through the real engine. Silent by design: nothing about it is shown; "Next deal" simply enables once both sides have settled. The verdict is in `view.audit` if a UI for it is ever wanted. |
| Watchers | Seated devices broadcast `publicView` (scores, turn, log). Never a hand. |
| Solo vs bot | Entirely local (`openSolo`), bots as before. Online tables are two humans: a bot seat can't be hidden from the device running it. |
| House rules (build .3) | `app/house.js`, a layer over the untouched engine; the default for new tables and solo. Table option `house` (Rules: House / Classic / With nines) and `piles` ("up"/"down"). Turned Ace → `trump = null` (the engine needs nothing else: no card is ever a trump, no swap, every marriage 20). Exhausted with nobody on 66 → no score, sheet row `{scoreless:true}`; the **pot is the run of scoreless rows at the foot of the sheet**, so it rides the sheet through deals, reloads and the lockstep ctx. Next scorer gets `gp + pot` (row `.pot`). Engine `result` is left as is, so the audit still compares engine-to-engine. House tables show values (2/3/4) via `setRankMode`, and face-up won cards as five rank piles inside the felt (both scores public; "Face down" hides the opponent's). |

## Files

```
index.html            loads config.js (optional, repo root, NOT in the tarball) then app/boot.js
config.example.js     custom relays, app id
app/boot.js           picks transport: relays, or ?local = BroadcastChannel stand-in for 2-tab testing
app/hub.js            lobby mesh: who's here, tables, lobby chat
app/session.js        solo; table seats/options; opens the match once dealt
app/house.js          house rules: reducer wrapper, no-trump deal, pot, won-card list
app/chat.js           chat over a mesh (backlog sync, typing, local copy)
app/net/mesh.js       presence + topics over one Trystero room
app/net/relay.js      the relay transport (pool, sealing, routing, repair)     app/net/local.js   same surface over BroadcastChannel
app/mp/sra.js         BigInt SRA arithmetic     app/mp/deck.js     the four passes, open(), audit()
app/mp/match.js       the lockstep match: per-deal message log, key gifts, moves, audit, resume
app/ui/*.js           Preact + htm, no build step
vendor/               esbuild bundles of preact+htm and nostr.js (noble-curves schnorr + sha256), self-hosted
schnapsen/engine, state   the engine, byte-identical to the Aug 22 build
```

## Invariants

- Engine untouched. Online play builds deals with `match.buildDeal` (mirrors `rules.newDeal`), because
  `newDeal` uses `Math.random` and a global id counter. Card ids online are canonical positions 1..N.
- A back is `{id: -(pos+1), back:true, pos}`; turning it over replaces it in place.
- Every match message is `{t, n (deal), s (sender seq), from (seat)}`; peers apply in seq order and
  de-duplicate. On (re)join each side resends its whole current-deal log plus the previous deal's.
- "Next deal" stays disabled until the audit has run (normally well under a second).
- No player-facing text mentions devices, keys, servers, shuffling or checks.
- `?as=NAME` namespaces localStorage so one browser can be two people (with `?local`).

## Tests

```
cd schnapsen/tests && node rules.test.mjs && node variant24.mjs && node guest.test.mjs   # engine gates
cd tests && node house.test.mjs   # house rules with bots: 150 Bummerls, no-trump share, pot, sheet sums
cd tests && node mp.test.mjs      # 2 simulated devices, 14 deals x (20-card, 24-card, 15% loss, house, house + 15% loss)
cd tests && node cheat.test.mjs   # audit catches reneges and rigged decks
cd tests && node relay.test.mjs   # the real transport through 3 local relays (one lossy, one refusing):
                                  # presence, messages, deals, a relay dying, a reload, a player away
python3 tests/browser/relays.py   # two separate browsers over local relays (writes config.js; delete it after)
# relay tests need `ws` (npm i ws) resolvable from tests/, e.g. a node_modules symlink
tests/browser/*.py                # Playwright, two tabs with ?local: lobby, chat, seats, deal, reloads,
                                  # dropout, watcher, audited deals, solo (edit the chromium path)
```

Last run (Oct 23, build .2): rules 27/27, variant24 21/21, guest clean, mp 42/42 audited, 0 desyncs/leaks;
cheat: every renege and rigged deck caught; relay.test 14/14 at a brisk human pace (1.2 s/move) with a
web-of-trust relay (got 2 events, then dropped), a login-only relay by NIP-11 (got 0), a 30/min rate-limited
relay (0 refusals, never banned), a 30%-lossy relay and a relay dying mid-deal; browser relays.py 19/19
(next deal dealt in ~5 s; checker reads Yes/No with reasons); ?local flows all green.
The match re-sends only what the other side hasn't applied ("ak" on the wire), at low priority, backing off
15→60 s; re-sends answering a "want" go out only with budget in hand and at most every 8 s per message
(an earlier version queued them and fed back on itself: 417 waiting, 800 events per relay).

Build .3 (Oct 23, house rules + restyle): rules 27/27, variant24 21/21, guest clean, house 16692/0 (756 deals,
21.6% no-trump, 19 scoreless, pot paid), mp 70/70 audited incl. house runs (no-trump deals and a pot paid under
15% loss), cheat all caught, relay.test 14/14, browser flows green (house is now the default).
Browser relays.py: 19/19 on 1 of 3 runs. The other 2 failed at "Jamie closes the page: Seth sees 'stepped away'"
(90 s window): the banner does appear, just after the window, so Jamie's `bye` on pagehide didn't get out and the
80 s fallback fired. The .2 build passed that step 3 of 3 runs; per-run relay traffic is not higher on .3. Cause not
found: `bye` is best-effort (signed + sealed inside pagehide, behind any queued message). Watch for it on two phones.
Also in .3: the Google Fonts stylesheet loads non-blocking (it used to hold up config.js and the first render).

## Look (build .3)

"The green room": casino baize `#0e3a2b` with a 1px gold pinstripe every 14px on every surface, square corners,
gold double rules on the header, felt, sheets and chat. Limelight for the wordmark, headings, scores and card
indices; Josefin Sans for everything else (names and table codes too: Limelight's G reads as C). Primary buttons
and selected segments are a metallic gold gradient. The lobby header is a marquee with a slow bulb chase (the only
self-moving thing; off under reduced motion). Card backs: green, gold pinstripe, double gold frame. Suits are the
house deck's: spades #16307e, hearts #c8231c, diamonds #d29e00 (darkened from #e9b300 for legibility), clubs #1d7a3b.
Fonts come from Google Fonts; everything else is self-hosted.

## Large print (build 2026-10-24.1)

Refocused on large type and high contrast, same green-and-gold room. Base text 20px; ivory #fffbef on #0a2f22
(about 14:1), secondary text #dde4d3 (about 11:1), 2px gold rules on controls, 56px buttons, 50px segments.
Limelight only for the wordmark and headings; scores, card indices and everything read in play are bold Josefin.
Suit colours deepened to 4.5:1 or better on the card face (diamonds a dark amber #946500).
Cards sit square: no tilted or offset trick cards. The trick has two fixed slots (theirs left, yours right, an
empty dashed slot until a card lands); the turned card stands upright beside the stock. The hand sizes itself to
fit one row, up to 100px a card (`--n` on `.hand`). Suits are drawn SVG (`SuitIcon` in ui/cards.js), not font
glyphs: no text face has them, and phones filled the heart from a different, larger symbol font. The heart path
is scaled .92 to balance its solid mass. Also fixed: the stock's "Trumps" label shared the class `trump` with
trump cards, which washed out the trump cards' ink (old bug).

## Fixed table geometry (build 2026-10-24.1, later)

Every band of the table has one height for the whole game (opponent row 44, felt flexes with the screen only,
won-card rows 96 each, middle row 150+, status 32, actions 56 single row, hand = card height + lift). The
"stepped away" banner overlays instead of pushing. Checked by playing whole deals at 390x844, 412x915 and
360x780 and measuring every band after each move: zero shifts, no scrolling, including a four-card pile.

## One screen (build 2026-10-24.8)

The play screen is `height: 100svh` (small viewport: browser bars showing), so it is laid out once and never moves
when Chrome's bars slide. `.game` is a grid: 40 | well (minmax(0,1fr)) | 40 | 30 | 52 | hand. The well is a size
container; pile rows are min(96px, 25%) of it, minis are sized from their row (cqh), stock and trick cards from
their cells. Hand cards are min(116px, 12.6svh) wide and overlap only as much as the cards held need to fit
(`--c`), square and in line, corner index always visible. Corner index enlarged (rank .29w, suit .2w); pips .15w
on columns 40%/62%. Checked: whole deals at 412x750, 360x640, 390x844, 412x915: no scrolling, nothing past the
bottom edge, zero shifts during play.
Build .9: `.card { isolation: isolate }`, so a card's raised index and pips (z-index 1, above its ornament) stay
inside that card; an overlapping card now covers them.
Build .10: unplayable cards are greyed but opaque (grayscale + darken filter and a tinted ::after layer, no
opacity); in the hand, playable cards (z 2) come in front of unplayable ones (z 1), the selected card in front of all (z 3).

## The deck (build 2026-10-24.2)

- Pips: standard French layouts (2, 3, 4, 9, 10, Ace) in a field between the corner indices; lower half
  inverted; indices top-left and, inverted, bottom-right (`PIPS` in ui/cards.js). Suits are drawn SVG.
- Ornament (`tools/ornament.py` generates `app/ui/ornament.js`; symbols injected once, drawn with `<use>`):
  faint gold lace ground, gold double frame, illuminated index corner (gold bracket, ultramarine rule,
  vermilion dots, rosette), a flower bouquet in the free corners, top crest of filigree, a flowered vine
  garland down the free edge, all drawn for the top half and turned 180 degrees for the bottom. The Ace gets
  a lace rosette and flower wreath; the 2 and 4 a smaller medallion in their empty middle.
  References (PySolFC cardsets): Nicu's Ornamental corners, Ovale Salon ace rosettes, Dondorf and Hamburg 1864
  floral cartouches.
- Classic courts: the traditional double-headed K, Q, J from Seth's vector "Poker cards" set, cropped at the
  frame, in-frame suit marks recoloured to the house four colours, 200px WebP in app/courts/ (320 KB total).
  `tools/courts.py` rebuilds them (paths point at the session's unpacked copy). The set's licence wasn't in
  the zip; worth confirming if the site goes beyond friends.
- Back: after PySolFC tksol back101 (scroll-chain border, mirrored scroll band, mirrored "66") in deep gold on a
  powder blue and powder indigo wash, smoothed into one continuous gradient (build .3): a diagonal gradient
  #cfe2f6 → #b3c6f0 → #9c9fe2 under three heavily blurred layers of the old blotches (12, 35, 48), each layer
  one group under one filter; no tide lines, no grain. The hand-count backs are two radial blots of the same colours.
  Build .4: a soft white glow (blurred ellipse) behind each "66" so it reads off the wash.
  Build .7: elaborated, drawn as one half turned 180 degrees: blooms on the outer chain's corners, a gold lace
  ground over the inner panel, gold curls and a bouquet in each inner corner, flowering vines down both sides,
  and a centre medallion (ring of filigree curls, pale disc with a tick ring, a wreath of eight small flowers).
- Enamel pips (build .4, `PipIcon` in ui/cards.js): card pips are filled with a per-suit radial gradient (dark core
  → suit colour), get a near-white fade just inside the edge from the `pip-edge` filter (alpha eroded, blurred,
  subtracted, so it follows the real shape), and a stroke a shade darker than the middle (`PIP_LINE`).
  Build .6: the corner suit marks (cards and won-card piles) use `PipIcon` too; the corner numbers stay plain
  bold text, by Seth's choice. (`RankMark` and the `rk-edge` filter, the enamel number tried in .5, are still
  in the code, unused.) Tokens in logs and labels stay flat.

## Grandma prints and the 70s back (build 2026-10-24.11)

Replaces the face ornament (lace, bouquets, garland, crest, Ace wreath, 2/4 medallion) and the watercolour back.
`tools/wallpaper.py` (imported by `tools/ornament.py`) draws twenty SVG pattern tiles, one per card, in four suit
palettes, laid at .34 opacity behind each face through a radial fade mask (weaker in the middle), under the gold
frame (`orn-frame`). Nines borrow the ten's print.
  ♥ Ace chintz roses · K rose-and-ribbon stripe · Q strawberries · J polka dots + rosebuds · 10 doily lace
  ♠ Ace wisteria · K damask · Q violets · J forget-me-nots · 10 gingham
  ♦ Ace 70s daisies · K tulips · Q rose trellis · J calico · 10 sunflowers
  ♣ Ace hydrangea · K sweet peas · Q pansies · J feedsack · 10 toile sprigs
Back: 70s flower-power daisies in tomato red, denim blue, avocado green and mustard (one per suit) on cream, a
brown-and-mustard band, the gold frame, "66" in a brown pill cartouche. Hand-count backs: four colour dots.
Old ornament code (half/ace/mid symbols, watercolour filters) is still in ornament.py, unused.

## Cooper Hewitt prints (build 2026-10-24.12)

The face backgrounds are now cutouts from 20 Cooper Hewitt, Smithsonian Design Museum wallpaper scans (Seth's
Archive.zip, 25 scans, 5 unused). `tools/prints.py <scans> app/prints` crops a 5:7 piece per card (the `CUTS`
table: file, centre, width), tints it 32% toward the suit colour, and writes 250x350 WebP (about 300 KB for all
20). Build .13: tint lowered to 12%, shown at .62 opacity. A second set, app/cyano/, renders each cutout as a
one-colour sun print (contrast-stretched, shadows in the suit's ink, highlights to cream, faint wash and grain),
shown at .55; Menu → "Card faces" switches per phone (`prefs.faces`: print | cyano). Earlier: each face showed its print at .42 opacity through the `wp-fade` centre-fade mask, under the gold frame; nines
use the ten's. The drawn grandma prints in tools/wallpaper.py are no longer used on faces (the 70s back still is).
Licence: Cooper Hewitt images are often Smithsonian Open Access (CC0), but each object should be checked for the
CC0 badge on its si.edu page; not verified here.

## Lily backs (build 2026-10-24.14)

The back is the lily wallpaper Seth linked first (CHSDM-154584), cut by `back_images()` in tools/prints.py into
app/backs/: `back-print.webp` (the paper as is) and `back-cyano.webp` (Prussian-blue cyanotype, positive: pale
ground, blue lilies; Seth preferred it to the negative). It follows the "Card faces" menu choice. Gold frame and a "66" pill cartouche on top; the
hand-count backs are flat washes of the same colours. The 70s flower-power back (tools/wallpaper.py) is retired.

## Nines, zeros, and house rules with 0s (build 2026-10-24.16)

The 9s have their own prints (both sets): 9♥ poppy bouquet, 9♠ pansies (sampler), 9♦ beige trellis, 9♣ pastel
watercolour, from papers not used elsewhere. House rules no longer force 20 cards: the table options are now
Rules (House | Classic) and Deck (20 cards | 24). House + 24 is "house rules with 0s": the engine's 24-card deck,
with the 9 printed as 0 (`VALUE_RANK` in schnapsen/state/constants.js gained "9":"0", display only; the one change
under schnapsen/). A 0 has no pips, only its corner index, and shows its paper without the centre fade. Six won-card
piles when the deck has 24. Tests: house.test.mjs takes `24` (19765/0), mp.test adds a house24 run (14/14 audited);
fit check at 412x750 and 360x640 with six piles and six-card hands: no scroll, zero shifts.

## Best-of sun prints (build 2026-10-24.17)

Seth's second Archive.zip (20 scans, Cooper Hewitt and NMAH) was cut into 18 candidates (`tools/candidates.py`), each
sun-printed in all four inks and judged with the current 24 on: a motif that reads at card size, full tonal range
(p95-p5 luminance), quality of the original drawing, clean crop (no torn edges, folds, text, or crops under ~250px
enlarged), and calm enough behind pips. Rejected outright: torn #1/#12, the quilt photo, the album quilt (cluttered),
the cross-stitch sampler (138px, boxed), the lily-of-the-valley bouquet (text, reversed values), the gold rose swag
(weak range, border strip), the NMAH design drawings (paper edge, grid). Ten new papers replaced the ten weakest sun
prints (`CYANO_PICKS` in tools/prints.py; the wallpaper set keeps `CUTS`): 10H rose vine, JS chintz medallion,
9S chintz florals, QD/KC feathered floral stripe (lower/upper), JD trellis chintz, 9D scattered chintz,
JC chintz florals (lower), 10C flower and lattice, 9C flower sprays. Build .18: the wallpaper set takes the same ten papers (tinted 12% like the rest), so both sets
match card for card again. Ochre ink deepened (138,92,6) → (112,72,0):
the diamond row's tonal range rose about 15 points (now 133-156). Rebuild: python3 tools/prints.py <archive1> app/prints <archive2>.

## Final gate run (build 2026-10-24.18)

rules 27/27, variant24 21/21, guest clean, house 16939/0 (20 cards) and 18633/0 (with 0s), cheat all caught,
mp 84/84 audited deals across six runs (classic, 24, classic at 15% loss, house, house at 15% loss, house with 0s),
relay.test 14/14, browser flows green with no page errors, one-screen fit at 412x750 and 360x640: no scroll, zero shifts.
Not re-run this round: browser relays.py (passed 1 of 3 at build .3; see the "stepped away" note above).

## High visibility (build 2026-10-24.19)

For Jamie. A per-phone switch, `prefs.big` → class `big` on `<html>` (ident.js), so the stylesheet does the work and
the other phone is unaffected. Turned on from: Menu → "High visibility" (table and solo), the name sheet (tap your
name in the lobby), the first-visit name screen, or any link with `?big` (`?big=0` turns it off) — so a link can
be sent ready-made.
- Faces (`BigFace` in ui/cards.js, class `.hv`): no pips, no courts, no corner indices; one rank .72w (two-character
  "10" at .56w) over one suit .6w, centred, with a soft ivory halo, over the card's paper (wallpaper or sun print,
  still chosen in the menu; Seth asked to keep both). Face base tinted toward the suit. Deeper red #a3150f and
  amber #7a5200 in this mode (6:1 or better on the tints).
- Hand: every card whole, side by side, no overlap. Width from the deal's hand size `--n`, not the cards held,
  so a card never resizes during a deal: min(124px, (avail - gaps)/n, 20svh/1.4).
- Won cards (house tables): `Piles big` renders each rank as a big rank over four fixed suit slots
  (spades, hearts / diamonds, clubs), filled with a suit chip once won. Same place every time.
- Table: rows 44 | well | 44 | 36 | 56 | hand; stock column 42% (bigger turned card); larger status, captions,
  stats, buttons; opponent's tiny hand-count backs hidden. Under 700px tall: rows 40/34/54 and tighter felt; a
  container query drops the "N left" label when the stock is under 160px tall, so the stock cards keep their size.
- Lobby and sheets: base text 22px, small labels 18–20px.
Checked: one-screen fit at 360x640, 390x844, 412x750, 412x915, 20 and 24 cards: no scroll, no overflow in any band.
Browser flows green with the mode off and on (?big on every page), no page errors; rules 27/27, variant24 21/21,
guest clean. Engine and net untouched, so mp/cheat/relay/house were not re-run.

## Floral deck faces, Bicycle layout (build 2026-10-25.1)

The faces now take the floral deck's papers (59 Cooper Hewitt cutouts, Smithsonian Open Access CC0; picks in the
deck's CREDITS.txt): A, 10, K, Q, J, 9 and the house 0 per suit, 250x350 WebP in app/prints (tinted 12%) and
app/cyano (sun print in the suit's ink). The 0 has its own paper (0S.webp etc.), shown whole; before, it borrowed the 9's.
- Papers stronger: .9 opacity (print) / .88 (cyano) through `wp-fade` (centre fade #6a6a6a → white by 78%), plus
  `wp-c1`/`wp-c2` radial fades behind both corner indices; the 0 uses `wp-corners` (corner fades only).
- Bicycle geometry (`PIPS` in ui/cards.js, now in whole-card fractions): side columns 27% / 73%, centre 50%; top and
  bottom rows 16% / 84% on every number card; 9 and 10 in four even rows; 7 and 8 as 3+1(+1)+3 halfway between
  rows; the 9's odd pip dead centre. Pips .25w boxes; Ace .44w, Ace of spades .56w.
- Bicycle index: rank .18w, suit .105w under it, at 5% / 4.5% from the corner (was .29w / .2w).
- Bicycle court panels: 56% of the card's width (was 46%), nearly full height; the 200px court art is shown ~1.4x.
Checked at 390x844 and 360x640: classic 20 and 24, house with 0s, both face sets, high visibility; no page errors.
Engine and net untouched.

## Hidden connection page

`#/net` (linked from nowhere): the build (`app/version.js` — bump per tarball; both phones must match), each
relay's state (open / resting / off with the reason / unreachable), events sent and budget, who this page has
heard from per room, lobby presence, relay notes, and **Check relays**: test-posts one stored and one
passing-through event to every candidate relay from this phone, reports Yes/No with the reason, and offers a
`config.js` list of the ones that work.

## Known limits

- Relays see IP addresses and timing. Tor Browser / Orbot hides the address.
- The lobby key derives from the public app id; a table's from its 4-letter code (guessable). Cards stay
  safe regardless (mental poker); table chat is as private as the code.
- Kinds 4747/24747 mark the traffic as this app's (same kinds as Party Line).
- Relays publish almost nothing about their limits (none of the six original relays' NIP-11 documents list
  rate limits); the budget is a guess kept well under typical client traffic. A browser can't see why a
  connection failed, so a ban and an outage look the same ("unreachable").
- Throwaway keys mean web-of-trust relays will always refuse us; they're detected and dropped.
- Presence isn't signed: anyone with the room key could claim a name. Party Line's identity keys would fix it.
- Not verified here: the six public relays (unreachable from the build sandbox). First real test: two phones.

## Next

- Contracts system (Sept–Oct sessions) lives in a different tarball; wire it in once the table is final. The house
  rules doc lists contracts as experimental; not in this build.
- QOL list in the conversation; the cheap ones first: rematch, reactions, sound, unread on tab title.
