# Schnapsen — serverless rebuild (handoff)

Lobby-first, phone-first, no backend. Everything multiplayer travels sealed through public Nostr relays;
phones never connect to each other (Oct 23: the WebRTC/Trystero transport is gone — direct links failed
between real phones without a TURN server). Relays see throwaway keys, hourly tags and padded ciphertext.
(This file is stripped by the deploy workflow.)

## What runs where

| Concern | How |
|---|---|
| Transport | `app/net/relay.js`: each room (lobby, `table-CODE`) is an AES-256-GCM key + HMAC tag key from HKDF(app id, room). Every event: new secp256k1 key, one tag = HMAC(room, hour), body padded to 256…131072. Data kind 4747 (relays keep 6 h, NIP-40), control kind 24747 (heartbeats, wants). |
| Delivery | Sequence numbers: one stream to everyone, one per recipient. Heartbeats (25 s, plus "tips" 2, 6 and 14 s after a burst) carry the latest numbers and the sender's relays (4-hex fingerprints). Holes → "want" after 1.5 s, asked again every 2–6 s while the sender is present; sender re-sends or says "gone". Reconnect asks each relay for what it missed (`since`). Routing: private → 2 shared relays; to everyone → covering set + spare; unknown → all. A relay answering OK=false is skipped 10 min and the event goes elsewhere. |
| Relay rules (build .2) | Public relays defend against spam: per-IP rate limits that become bans (relay.damus.io is reported to IP-ban), web-of-trust write filters (offchain.pub's operator runs one), logins/payment. So: NIP-11 read first (auth/payment/restricted_writes/PoW → never written to); per-relay token bucket 10 deep, +1 per 3 s; low budgets → 1 copy instead of 2, then another relay, then an outbox; routine heartbeats skipped first. Replies read by NIP-01 prefix: `rate-limited:` rests the relay 1→30 min; `blocked:`/`restricted:`/`auth-required:`/`pow:` (or "web of trust", "paid"...) retire it for 24 h, remembered in localStorage; CLOSED/AUTH the same. 4 failed connects in a row → retry every 10 min (an IP ban looks like this). Pool: damus, nos.lol, primal, ditto, coinos, nostr.mom, relay.nostr.net, snort. |
| Lobby presence, open tables | Room `lobby`. A table is advertised in its owner's presence, so it is listed exactly while the owner is here. No database. Presence carries a version so a late copy can't undo a newer one. Gone = `bye` on page close, or 80 s unheard. |
| Lobby + table chat | Same rooms. New arrivals get the last 50 messages from whoever is present; each device keeps 120 locally. |
| Seats and options before the deal | The table owner's device (presence carries `{seats, opts, status, matchId}`). |
| The game | **Lockstep, no host.** Both devices run the unmodified engine on their own view of the deal. |
| Shuffling | **Mental poker** (SRA commutative encryption, RFC 2409 1024-bit safe prime, cards as quadratic residues). Four passes; neither device knows the order. |
| Seeing a card | The other device sends its per-position key for that one card. Plays, marriages and the trump swap carry the mover's key. |
| Stuck deals | `match.js` safety net: waiting on the other device 15 s with nothing arriving → re-send all of ours from this deal. Receiving such a re-send means they're stuck → echo ours once (tagged so echoes never echo). |
| Honesty | End of every deal: both publish all keys; each device re-checks every shuffle pass and replays the deal face-up through the real engine. Silent by design: nothing about it is shown; "Next deal" simply enables once both sides have settled. The verdict is in `view.audit` if a UI for it is ever wanted. |
| Watchers | Seated devices broadcast `publicView` (scores, turn, log). Never a hand. |
| Solo vs bot | Entirely local (`openSolo`), bots as before. Online tables are two humans: a bot seat can't be hidden from the device running it. |
| House rules (build .3) | `app/house.js`, a layer over the untouched engine; the default for new tables and solo. Table option `house` (Rules: House / Classic / With nines) and `piles` ("up"/"down"). Turned Ace → `trump = null` (the engine needs nothing else: no card is ever a trump, no swap, every marriage 20). Exhausted with nobody on 66 → no score, sheet row `{scoreless:true}`; the **pot is the run of scoreless rows at the foot of the sheet**, so it rides the sheet through deals, reloads and the lockstep ctx. Next scorer gets `gp + pot` (row `.pot`). Engine `result` is left as is, so the audit still compares engine-to-engine. House tables show values (2/3/4) via `setRankMode`, and face-up won cards as five rank piles inside the felt (both scores public; "Face down" hides the opponent's). |

## Files

```
index.html            loads config.js (optional, repo root, NOT in the tarball) then app/boot.js
config.example.js     custom relays, app id
app/boot.js           picks transport: relays, or ?local = BroadcastChannel stand-in for 2-tab testing
app/hub.js            lobby mesh: who's here, tables, lobby chat
app/session.js        solo; table seats/options; opens the match once dealt
app/house.js          house rules: reducer wrapper, no-trump deal, pot, won-card list
app/chat.js           chat over a mesh (backlog sync, typing, local copy)
app/net/mesh.js       presence + topics over one Trystero room
app/net/relay.js      the relay transport (pool, sealing, routing, repair)     app/net/local.js   same surface over BroadcastChannel
app/mp/sra.js         BigInt SRA arithmetic     app/mp/deck.js     the four passes, open(), audit()
app/mp/match.js       the lockstep match: per-deal message log, key gifts, moves, audit, resume
app/ui/*.js           Preact + htm, no build step
vendor/               esbuild bundles of preact+htm and nostr.js (noble-curves schnorr + sha256), self-hosted
schnapsen/engine, state   the engine, byte-identical to the Aug 22 build
```

## Invariants

- Engine untouched. Online play builds deals with `match.buildDeal` (mirrors `rules.newDeal`), because
  `newDeal` uses `Math.random` and a global id counter. Card ids online are canonical positions 1..N.
- A back is `{id: -(pos+1), back:true, pos}`; turning it over replaces it in place.
- Every match message is `{t, n (deal), s (sender seq), from (seat)}`; peers apply in seq order and
  de-duplicate. On (re)join each side resends its whole current-deal log plus the previous deal's.
- "Next deal" stays disabled until the audit has run (normally well under a second).
- No player-facing text mentions devices, keys, servers, shuffling or checks.
- `?as=NAME` namespaces localStorage so one browser can be two people (with `?local`).

## Tests

```
cd schnapsen/tests && node rules.test.mjs && node variant24.mjs && node guest.test.mjs   # engine gates
cd tests && node house.test.mjs   # house rules with bots: 150 Bummerls, no-trump share, pot, sheet sums
cd tests && node mp.test.mjs      # 2 simulated devices, 14 deals x (20-card, 24-card, 15% loss, house, house + 15% loss)
cd tests && node cheat.test.mjs   # audit catches reneges and rigged decks
cd tests && node relay.test.mjs   # the real transport through 3 local relays (one lossy, one refusing):
                                  # presence, messages, deals, a relay dying, a reload, a player away
python3 tests/browser/relays.py   # two separate browsers over local relays (writes config.js; delete it after)
# relay tests need `ws` (npm i ws) resolvable from tests/, e.g. a node_modules symlink
tests/browser/*.py                # Playwright, two tabs with ?local: lobby, chat, seats, deal, reloads,
                                  # dropout, watcher, audited deals, solo (edit the chromium path)
```

Last run (Oct 23, build .2): rules 27/27, variant24 21/21, guest clean, mp 42/42 audited, 0 desyncs/leaks;
cheat: every renege and rigged deck caught; relay.test 14/14 at a brisk human pace (1.2 s/move) with a
web-of-trust relay (got 2 events, then dropped), a login-only relay by NIP-11 (got 0), a 30/min rate-limited
relay (0 refusals, never banned), a 30%-lossy relay and a relay dying mid-deal; browser relays.py 19/19
(next deal dealt in ~5 s; checker reads Yes/No with reasons); ?local flows all green.
The match re-sends only what the other side hasn't applied ("ak" on the wire), at low priority, backing off
15→60 s; re-sends answering a "want" go out only with budget in hand and at most every 8 s per message
(an earlier version queued them and fed back on itself: 417 waiting, 800 events per relay).

Build .3 (Oct 23, house rules + restyle): rules 27/27, variant24 21/21, guest clean, house 16692/0 (756 deals,
21.6% no-trump, 19 scoreless, pot paid), mp 70/70 audited incl. house runs (no-trump deals and a pot paid under
15% loss), cheat all caught, relay.test 14/14, browser flows green (house is now the default).
Browser relays.py: 19/19 on 1 of 3 runs. The other 2 failed at "Jamie closes the page: Seth sees 'stepped away'"
(90 s window): the banner does appear, just after the window, so Jamie's `bye` on pagehide didn't get out and the
80 s fallback fired. The .2 build passed that step 3 of 3 runs; per-run relay traffic is not higher on .3. Cause not
found: `bye` is best-effort (signed + sealed inside pagehide, behind any queued message). Watch for it on two phones.
Also in .3: the Google Fonts stylesheet loads non-blocking (it used to hold up config.js and the first render).

## Look (build .3)

"The green room": casino baize `#0e3a2b` with a 1px gold pinstripe every 14px on every surface, square corners,
gold double rules on the header, felt, sheets and chat. Limelight for the wordmark, headings, scores and card
indices; Josefin Sans for everything else (names and table codes too: Limelight's G reads as C). Primary buttons
and selected segments are a metallic gold gradient. The lobby header is a marquee with a slow bulb chase (the only
self-moving thing; off under reduced motion). Card backs: green, gold pinstripe, double gold frame. Suits are the
house deck's: spades #16307e, hearts #c8231c, diamonds #d29e00 (darkened from #e9b300 for legibility), clubs #1d7a3b.
Fonts come from Google Fonts; everything else is self-hosted.

## Large print (build 2026-10-24.1)

Refocused on large type and high contrast, same green-and-gold room. Base text 20px; ivory #fffbef on #0a2f22
(about 14:1), secondary text #dde4d3 (about 11:1), 2px gold rules on controls, 56px buttons, 50px segments.
Limelight only for the wordmark and headings; scores, card indices and everything read in play are bold Josefin.
Suit colours deepened to 4.5:1 or better on the card face (diamonds a dark amber #946500).
Cards sit square: no tilted or offset trick cards. The trick has two fixed slots (theirs left, yours right, an
empty dashed slot until a card lands); the turned card stands upright beside the stock. The hand sizes itself to
fit one row, up to 100px a card (`--n` on `.hand`). Suits are drawn SVG (`SuitIcon` in ui/cards.js), not font
glyphs: no text face has them, and phones filled the heart from a different, larger symbol font. The heart path
is scaled .92 to balance its solid mass. Also fixed: the stock's "Trumps" label shared the class `trump` with
trump cards, which washed out the trump cards' ink (old bug).

## Fixed table geometry (build 2026-10-24.1, later)

Every band of the table has one height for the whole game (opponent row 44, felt flexes with the screen only,
won-card rows 96 each, middle row 150+, status 32, actions 56 single row, hand = card height + lift). The
"stepped away" banner overlays instead of pushing. Checked by playing whole deals at 390x844, 412x915 and
360x780 and measuring every band after each move: zero shifts, no scrolling, including a four-card pile.

## The deck (build 2026-10-24.2)

- Pips: standard French layouts (2, 3, 4, 9, 10, Ace) in a field between the corner indices; lower half
  inverted; indices top-left and, inverted, bottom-right (`PIPS` in ui/cards.js). Suits are drawn SVG.
- Ornament (`tools/ornament.py` generates `app/ui/ornament.js`; symbols injected once, drawn with `<use>`):
  faint gold lace ground, gold double frame, illuminated index corner (gold bracket, ultramarine rule,
  vermilion dots, rosette), a flower bouquet in the free corners, top crest of filigree, a flowered vine
  garland down the free edge, all drawn for the top half and turned 180 degrees for the bottom. The Ace gets
  a lace rosette and flower wreath; the 2 and 4 a smaller medallion in their empty middle.
  References (PySolFC cardsets): Nicu's Ornamental corners, Ovale Salon ace rosettes, Dondorf and Hamburg 1864
  floral cartouches.
- Classic courts: the traditional double-headed K, Q, J from Seth's vector "Poker cards" set, cropped at the
  frame, in-frame suit marks recoloured to the house four colours, 200px WebP in app/courts/ (320 KB total).
  `tools/courts.py` rebuilds them (paths point at the session's unpacked copy). The set's licence wasn't in
  the zip; worth confirming if the site goes beyond friends.
- Back: after PySolFC tksol back101 (scroll-chain border, mirrored scroll band, mirrored "66") in deep gold on a
  powder blue and powder indigo wash, smoothed into one continuous gradient (build .3): a diagonal gradient
  #cfe2f6 → #b3c6f0 → #9c9fe2 under three heavily blurred layers of the old blotches (12, 35, 48), each layer
  one group under one filter; no tide lines, no grain. The hand-count backs are two radial blots of the same colours.
  Build .4: a soft white glow (blurred ellipse) behind each "66" so it reads off the wash.
  Build .7: elaborated, drawn as one half turned 180 degrees: blooms on the outer chain's corners, a gold lace
  ground over the inner panel, gold curls and a bouquet in each inner corner, flowering vines down both sides,
  and a centre medallion (ring of filigree curls, pale disc with a tick ring, a wreath of eight small flowers).
- Enamel pips (build .4, `PipIcon` in ui/cards.js): card pips are filled with a per-suit radial gradient (dark core
  → suit colour), get a near-white fade just inside the edge from the `pip-edge` filter (alpha eroded, blurred,
  subtracted, so it follows the real shape), and a stroke a shade darker than the middle (`PIP_LINE`).
  Build .6: the corner suit marks (cards and won-card piles) use `PipIcon` too; the corner numbers stay plain
  bold text, by Seth's choice. (`RankMark` and the `rk-edge` filter, the enamel number tried in .5, are still
  in the code, unused.) Tokens in logs and labels stay flat.

## Hidden connection page

`#/net` (linked from nowhere): the build (`app/version.js` — bump per tarball; both phones must match), each
relay's state (open / resting / off with the reason / unreachable), events sent and budget, who this page has
heard from per room, lobby presence, relay notes, and **Check relays**: test-posts one stored and one
passing-through event to every candidate relay from this phone, reports Yes/No with the reason, and offers a
`config.js` list of the ones that work.

## Known limits

- Relays see IP addresses and timing. Tor Browser / Orbot hides the address.
- The lobby key derives from the public app id; a table's from its 4-letter code (guessable). Cards stay
  safe regardless (mental poker); table chat is as private as the code.
- Kinds 4747/24747 mark the traffic as this app's (same kinds as Party Line).
- Relays publish almost nothing about their limits (none of the six original relays' NIP-11 documents list
  rate limits); the budget is a guess kept well under typical client traffic. A browser can't see why a
  connection failed, so a ban and an outage look the same ("unreachable").
- Throwaway keys mean web-of-trust relays will always refuse us; they're detected and dropped.
- Presence isn't signed: anyone with the room key could claim a name. Party Line's identity keys would fix it.
- Not verified here: the six public relays (unreachable from the build sandbox). First real test: two phones.

## Next

- Contracts system (Sept–Oct sessions) lives in a different tarball; wire it in once the table is final. The house
  rules doc lists contracts as experimental; not in this build.
- QOL list in the conversation; the cheap ones first: rematch, reactions, sound, unread on tab title.
