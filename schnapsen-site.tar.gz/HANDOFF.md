# Schnapsen — serverless rebuild (handoff)

Lobby-first, phone-first, no backend. Everything multiplayer travels sealed through public Nostr relays;
phones never connect to each other (Oct 23: the WebRTC/Trystero transport is gone — direct links failed
between real phones without a TURN server). Relays see throwaway keys, hourly tags and padded ciphertext.
(This file is stripped by the deploy workflow.)

## What runs where

| Concern | How |
|---|---|
| Transport | `app/net/relay.js`: each room (lobby, `table-CODE`) is an AES-256-GCM key + HMAC tag key from HKDF(app id, room). Every event: new secp256k1 key, one tag = HMAC(room, hour), body padded to 256…131072. Data kind 4747 (relays keep 6 h, NIP-40), control kind 24747 (heartbeats, wants). |
| Delivery | Sequence numbers: one stream to everyone, one per recipient. Heartbeats (25 s, plus "tips" 2, 6 and 14 s after a burst) carry the latest numbers and the sender's relays (4-hex fingerprints). Holes → "want" after 1.5 s, asked again every 2–6 s while the sender is present; sender re-sends or says "gone". Reconnect asks each relay for what it missed (`since`). Routing: private → 2 shared relays; to everyone → covering set + spare; unknown → all. A relay answering OK=false is skipped 10 min and the event goes elsewhere. |
| Lobby presence, open tables | Room `lobby`. A table is advertised in its owner's presence, so it is listed exactly while the owner is here. No database. Presence carries a version so a late copy can't undo a newer one. Gone = `bye` on page close, or 80 s unheard. |
| Lobby + table chat | Same rooms. New arrivals get the last 50 messages from whoever is present; each device keeps 120 locally. |
| Seats and options before the deal | The table owner's device (presence carries `{seats, opts, status, matchId}`). |
| The game | **Lockstep, no host.** Both devices run the unmodified engine on their own view of the deal. |
| Shuffling | **Mental poker** (SRA commutative encryption, RFC 2409 1024-bit safe prime, cards as quadratic residues). Four passes; neither device knows the order. |
| Seeing a card | The other device sends its per-position key for that one card. Plays, marriages and the trump swap carry the mover's key. |
| Stuck deals | `match.js` safety net: waiting on the other device 15 s with nothing arriving → re-send all of ours from this deal. Receiving such a re-send means they're stuck → echo ours once (tagged so echoes never echo). |
| Honesty | End of every deal: both publish all keys; each device re-checks every shuffle pass and replays the deal face-up through the real engine. Silent by design: nothing about it is shown; "Next deal" simply enables once both sides have settled. The verdict is in `view.audit` if a UI for it is ever wanted. |
| Watchers | Seated devices broadcast `publicView` (scores, turn, log). Never a hand. |
| Solo vs bot | Entirely local (`openSolo`), bots as before. Online tables are two humans: a bot seat can't be hidden from the device running it. |

## Files

```
index.html            loads config.js (optional, repo root, NOT in the tarball) then app/boot.js
config.example.js     custom relays, app id
app/boot.js           picks transport: relays, or ?local = BroadcastChannel stand-in for 2-tab testing
app/hub.js            lobby mesh: who's here, tables, lobby chat
app/session.js        solo; table seats/options; opens the match once dealt
app/chat.js           chat over a mesh (backlog sync, typing, local copy)
app/net/mesh.js       presence + topics over one Trystero room
app/net/relay.js      the relay transport (pool, sealing, routing, repair)     app/net/local.js   same surface over BroadcastChannel
app/mp/sra.js         BigInt SRA arithmetic     app/mp/deck.js     the four passes, open(), audit()
app/mp/match.js       the lockstep match: per-deal message log, key gifts, moves, audit, resume
app/ui/*.js           Preact + htm, no build step
vendor/               esbuild bundles of preact+htm and nostr.js (noble-curves schnorr + sha256), self-hosted
schnapsen/engine, state   the engine, byte-identical to the Aug 22 build
```

## Invariants

- Engine untouched. Online play builds deals with `match.buildDeal` (mirrors `rules.newDeal`), because
  `newDeal` uses `Math.random` and a global id counter. Card ids online are canonical positions 1..N.
- A back is `{id: -(pos+1), back:true, pos}`; turning it over replaces it in place.
- Every match message is `{t, n (deal), s (sender seq), from (seat)}`; peers apply in seq order and
  de-duplicate. On (re)join each side resends its whole current-deal log plus the previous deal's.
- "Next deal" stays disabled until the audit has run (normally well under a second).
- No player-facing text mentions devices, keys, servers, shuffling or checks.
- `?as=NAME` namespaces localStorage so one browser can be two people (with `?local`).

## Tests

```
cd schnapsen/tests && node rules.test.mjs && node variant24.mjs && node guest.test.mjs   # engine gates
cd tests && node mp.test.mjs      # 2 simulated devices, 14 deals x (20-card, 24-card, 15% packet loss)
cd tests && node cheat.test.mjs   # audit catches reneges and rigged decks
cd tests && node relay.test.mjs   # the real transport through 3 local relays (one lossy, one refusing):
                                  # presence, messages, deals, a relay dying, a reload, a player away
python3 tests/browser/relays.py   # two separate browsers over local relays (writes config.js; delete it after)
# relay tests need `ws` (npm i ws) resolvable from tests/, e.g. a node_modules symlink
tests/browser/*.py                # Playwright, two tabs with ?local: lobby, chat, seats, deal, reloads,
                                  # dropout, watcher, audited deals, solo (edit the chromium path)
```

Last run (Oct 23): rules 27/27, variant24 21/21, guest clean, mp 42/42 deals audited, 0 desyncs, 0 leaks;
cheat: every renege and rigged deck caught; relay.test 9/9 (a relay dropping 30%: median 22 ms between moves,
90th 14 s; relay death, reload and 20 s away all recover); browser relays.py 13/13 (relays saw no names, words,
rooms or codes; every event a different key); browser flows.py (?local) all green.
Traffic on healthy relays: about 95 KB per phone per deal, mostly the four shuffle passes.

## Hidden connection page

`#/net` (linked from nowhere): each relay open/closed, KB sent, who this page has heard from in each room and
on which relays, lobby presence, and relay notes (refusals, repairs still outstanding).

## Known limits

- Relays see IP addresses and timing. Tor Browser / Orbot hides the address.
- The lobby key derives from the public app id; a table's from its 4-letter code (guessable). Cards stay
  safe regardless (mental poker); table chat is as private as the code.
- Kinds 4747/24747 mark the traffic as this app's (same kinds as Party Line).
- Presence isn't signed: anyone with the room key could claim a name. Party Line's identity keys would fix it.
- Not verified here: the six public relays (unreachable from the build sandbox). First real test: two phones.

## Next

- Contracts system (Sept–Oct sessions) lives in a different tarball; wire it in once the table is final.
- QOL list in the conversation; the cheap ones first: rematch, reactions, sound, unread on tab title.
