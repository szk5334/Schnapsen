# Schnapsen — serverless rebuild (handoff)

Lobby-first, phone-first, no backend. Everything multiplayer travels sealed through public Nostr relays;
phones never connect to each other (Oct 23: the WebRTC/Trystero transport is gone — direct links failed
between real phones without a TURN server). Relays see throwaway keys, hourly tags and padded ciphertext.
(This file is stripped by the deploy workflow.)

## What runs where

| Concern | How |
|---|---|
| Transport | `app/net/relay.js`: each room (lobby, `table-CODE`) is an AES-256-GCM key + HMAC tag key from HKDF(app id, room). Every event: one secp256k1 key per page load (since .5; was one per event), one tag = HMAC(room, hour), body padded to 256…32768. Data kind 24748, control kind 24747: both ephemeral, nothing stored (since .5; data was stored kind 4747 with a 6 h NIP-40 expiry). |
| Delivery | Sequence numbers: one stream to everyone, one per recipient. Heartbeats (25 s, plus "tips" 2, 6 and 14 s after a burst) carry the latest numbers and the sender's relays (4-hex fingerprints). Holes → "want" after 1.5 s, asked again every 2–6 s while the sender is present; sender re-sends or says "gone". Reconnect asks each relay for what it missed (`since`). Routing (since .5): private → 1 shared relay; to everyone → covering set, no spare; unknown → 2 at random. Messages to the same people within 25 ms go as one batch event (`mb`); resends answering a want go as one batch. A relay answering OK=false is skipped 10 min and the event goes elsewhere. |
| Relay rules (build .2; budgets since .5, see "Being a good guest") | Public relays defend against spam: per-IP rate limits that become bans (relay.damus.io is reported to IP-ban), web-of-trust write filters (offchain.pub's operator runs one), logins/payment. So: NIP-11 read first (auth/payment/restricted_writes/PoW → never written to); per-relay token bucket (now 2 deep, +1 per 20 s, shared by nos.lol + nostr.mom); low budgets → 1 copy instead of 2, then another relay, then an outbox; routine heartbeats skipped first. Replies read by NIP-01 prefix: `rate-limited:` rests the relay 1→30 min; `blocked:`/`restricted:`/`auth-required:`/`pow:` (or "web of trust", "paid"...) retire it for 24 h, remembered in localStorage; CLOSED/AUTH the same. 4 failed connects in a row → retry every 10 min (an IP ban looks like this). Pool: damus, nos.lol, primal, ditto, coinos, nostr.mom, relay.nostr.net, snort. |
| Lobby presence, open tables | Room `lobby`. A table is advertised in its owner's presence, so it is listed exactly while the owner is here. No database. Presence carries a version so a late copy can't undo a newer one. Gone = `bye` on page close (pre-sealed, sent synchronously, since build 2026-10-26.4), or 140 s unheard (`STALE_MS`). |
| Lobby + table chat | Same rooms. New arrivals get the last 50 messages from whoever is present; each device keeps 120 locally. |
| Seats and options before the deal | The table owner's device (presence carries `{seats, opts, status, matchId}`). |
| The game | **Lockstep, no host.** Both devices run the unmodified engine on their own view of the deal. |
| Shuffling | **Mental poker** (SRA commutative encryption, RFC 2409 1024-bit safe prime, cards as quadratic residues). Four passes; neither device knows the order. |
| Seeing a card | The other device sends its per-position key for that one card. Plays, marriages and the trump swap carry the mover's key. |
| Stuck deals | `match.js` safety net: waiting on the other device 30 s (15 s before .5) with nothing arriving, and nothing of ours still queued for budget (`mesh.backlog()`) → re-send all of ours from this deal. Receiving such a re-send means they're stuck → echo ours once (tagged so echoes never echo). |
| Honesty | End of every deal: both publish all keys; each device re-checks every shuffle pass and replays the deal face-up through the real engine. Silent by design: nothing about it is shown; "Next deal" simply enables once both sides have settled. The verdict is in `view.audit` if a UI for it is ever wanted. |
| Watchers | Seated devices broadcast `publicView` (scores, turn, log). Never a hand. |
| Solo vs bot | Entirely local (`openSolo`), bots as before. Online tables are two humans: a bot seat can't be hidden from the device running it. |
| House rules (build .3) | `app/house.js`, a layer over the untouched engine; the default for new tables and solo. Table option `house` (Rules: House / Classic / With nines) and `piles` ("up"/"down"). Turned Ace → `trump = null` (the engine needs nothing else: no card is ever a trump, no swap, every marriage 20). Exhausted with nobody on 66 → no score, sheet row `{scoreless:true}`; the **pot is the run of scoreless rows at the foot of the sheet**, so it rides the sheet through deals, reloads and the lockstep ctx. Next scorer gets `gp + pot` (row `.pot`). Engine `result` is left as is, so the audit still compares engine-to-engine. House tables show values (2/3/4) via `setRankMode`, and face-up won cards as five rank piles inside the felt (both scores public; "Face down" hides the opponent's). |

## Files

```
index.html            loads config.js (optional, repo root, NOT in the tarball) then app/boot.js
config.example.js     custom relays, app id
app/boot.js           picks transport: relays, or ?local = BroadcastChannel stand-in for 2-tab testing
app/hub.js            lobby mesh: who's here, tables, lobby chat
app/session.js        solo; table seats/options; opens the match once dealt
app/house.js          house rules: reducer wrapper, no-trump deal, pot, won-card list
app/chat.js           chat over a mesh (backlog sync, typing, local copy)
app/net/mesh.js       presence + topics over one Trystero room
app/net/relay.js      the relay transport (pool, sealing, routing, repair)     app/net/local.js   same surface over BroadcastChannel
app/mp/sra.js         BigInt SRA arithmetic     app/mp/deck.js     the four passes, open(), audit()
app/mp/match.js       the lockstep match: per-deal message log, key gifts, moves, audit, resume
app/ui/*.js           Preact + htm, no build step
vendor/               esbuild bundles of preact+htm and nostr.js (noble-curves schnorr + sha256), self-hosted
app/fonts/            the web fonts, self-hosted (fonts.css + woff2 subsets + OFL licences; tools/fonts.py rebuilds)
schnapsen/engine, state   the engine, byte-identical to the Aug 22 build
```

## Invariants

- Engine untouched. Online play builds deals with `match.buildDeal` (mirrors `rules.newDeal`), because
  `newDeal` uses `Math.random` and a global id counter. Card ids online are canonical positions 1..N.
- A back is `{id: -(pos+1), back:true, pos}`; turning it over replaces it in place.
- Every match message is `{t, n (deal), s (sender seq), from (seat)}`; peers apply in seq order and
  de-duplicate. On (re)join each side resends its whole current-deal log plus the previous deal's.
- "Next deal" stays disabled until the audit has run (normally well under a second).
- No player-facing text mentions devices, keys, servers, shuffling or checks.
- `?as=NAME` namespaces localStorage so one browser can be two people (with `?local`).

## Tests

```
cd schnapsen/tests && node rules.test.mjs && node variant24.mjs && node guest.test.mjs   # engine gates
cd tests && node house.test.mjs   # house rules with bots: 150 Bummerls, no-trump share, pot, sheet sums
cd tests && node mp.test.mjs      # 2 simulated devices, 14 deals x (20-card, 24-card, 15% loss, house, house + 15% loss)
cd tests && node cheat.test.mjs   # audit catches reneges and rigged decks
cd tests && node house.relay.test.mjs  # own relay first, public fallback when it dies, back when it returns (~5 min)
cd tests && node zombie.test.mjs  # dead-but-open sockets, a relay restart, network back, goodbye on the wire (~3 min)
cd tests && node relay.test.mjs   # the real transport through 3 local relays (one lossy, one refusing):
                                  # presence, messages, deals, a relay dying, a reload, a player away
python3 tests/browser/relays.py   # two separate browsers over local relays (writes config.js; delete it after)
# relay tests need `ws` (npm i ws) resolvable from tests/, e.g. a node_modules symlink
node tests/browser/selfhosted.cjs # every screen, both transports: no request leaves the site except to the relay
                                  # pool; all six font faces load, and only from app/fonts/
tests/browser/*.py                # Playwright, two tabs with ?local: lobby, chat, seats, deal, reloads,
                                  # dropout, watcher, audited deals, solo (edit the chromium path)
```

Last run (Oct 23, build .2): rules 27/27, variant24 21/21, guest clean, mp 42/42 audited, 0 desyncs/leaks;
cheat: every renege and rigged deck caught; relay.test 14/14 at a brisk human pace (1.2 s/move) with a
web-of-trust relay (got 2 events, then dropped), a login-only relay by NIP-11 (got 0), a 30/min rate-limited
relay (0 refusals, never banned), a 30%-lossy relay and a relay dying mid-deal; browser relays.py 19/19
(next deal dealt in ~5 s; checker reads Yes/No with reasons); ?local flows all green.
The match re-sends only what the other side hasn't applied ("ak" on the wire), at low priority, backing off
15→60 s; re-sends answering a "want" go out only with budget in hand and at most every 8 s per message
(an earlier version queued them and fed back on itself: 417 waiting, 800 events per relay).

Build .3 (Oct 23, house rules + restyle): rules 27/27, variant24 21/21, guest clean, house 16692/0 (756 deals,
21.6% no-trump, 19 scoreless, pot paid), mp 70/70 audited incl. house runs (no-trump deals and a pot paid under
15% loss), cheat all caught, relay.test 14/14, browser flows green (house is now the default).
Browser relays.py: 19/19 on 1 of 3 runs. The other 2 failed at "Jamie closes the page: Seth sees 'stepped away'"
(90 s window): the banner does appear, just after the window, so Jamie's `bye` on pagehide didn't get out and the
80 s fallback fired. The .2 build passed that step 3 of 3 runs; per-run relay traffic is not higher on .3. Cause not
found: `bye` is best-effort (signed + sealed inside pagehide, behind any queued message). Watch for it on two phones.
Also in .3: the Google Fonts stylesheet loads non-blocking (it used to hold up config.js and the first render).
(Superseded by build 2026-10-26.3: fonts are self-hosted, see "Self-contained" below.)

## Look (build .3)

"The green room": casino baize `#0e3a2b` with a 1px gold pinstripe every 14px on every surface, square corners,
gold double rules on the header, felt, sheets and chat. Limelight for the wordmark, headings, scores and card
indices; Josefin Sans for everything else (names and table codes too: Limelight's G reads as C). Primary buttons
and selected segments are a metallic gold gradient. The lobby header is a marquee with a slow bulb chase (the only
self-moving thing; off under reduced motion). Card backs: green, gold pinstripe, double gold frame. Suits are the
house deck's: spades #16307e, hearts #c8231c, diamonds #d29e00 (darkened from #e9b300 for legibility), clubs #1d7a3b.
Fonts are self-hosted in app/fonts/ (since build 2026-10-26.3); nothing loads from another site.

## Large print (build 2026-10-24.1)

Refocused on large type and high contrast, same green-and-gold room. Base text 20px; ivory #fffbef on #0a2f22
(about 14:1), secondary text #dde4d3 (about 11:1), 2px gold rules on controls, 56px buttons, 50px segments.
Limelight only for the wordmark and headings; scores, card indices and everything read in play are bold Josefin.
Suit colours deepened to 4.5:1 or better on the card face (diamonds a dark amber #946500).
Cards sit square: no tilted or offset trick cards. The trick has two fixed slots (theirs left, yours right, an
empty dashed slot until a card lands); the turned card stands upright beside the stock. The hand sizes itself to
fit one row, up to 100px a card (`--n` on `.hand`). Suits are drawn SVG (`SuitIcon` in ui/cards.js), not font
glyphs: no text face has them, and phones filled the heart from a different, larger symbol font. The heart path
is scaled .92 to balance its solid mass. Also fixed: the stock's "Trumps" label shared the class `trump` with
trump cards, which washed out the trump cards' ink (old bug).

## Fixed table geometry (build 2026-10-24.1, later)

Every band of the table has one height for the whole game (opponent row 44, felt flexes with the screen only,
won-card rows 96 each, middle row 150+, status 32, actions 56 single row, hand = card height + lift). The
"stepped away" banner overlays instead of pushing. Checked by playing whole deals at 390x844, 412x915 and
360x780 and measuring every band after each move: zero shifts, no scrolling, including a four-card pile.

## One screen (build 2026-10-24.8)

The play screen is `height: 100svh` (small viewport: browser bars showing), so it is laid out once and never moves
when Chrome's bars slide. `.game` is a grid: 40 | well (minmax(0,1fr)) | 40 | 30 | 52 | hand. The well is a size
container; pile rows are min(96px, 25%) of it, minis are sized from their row (cqh), stock and trick cards from
their cells. Hand cards are min(116px, 12.6svh) wide and overlap only as much as the cards held need to fit
(`--c`), square and in line, corner index always visible. Corner index enlarged (rank .29w, suit .2w); pips .15w
on columns 40%/62%. Checked: whole deals at 412x750, 360x640, 390x844, 412x915: no scrolling, nothing past the
bottom edge, zero shifts during play.
Build .9: `.card { isolation: isolate }`, so a card's raised index and pips (z-index 1, above its ornament) stay
inside that card; an overlapping card now covers them.
Build .10: unplayable cards are greyed but opaque (grayscale + darken filter and a tinted ::after layer, no
opacity); in the hand, playable cards (z 2) come in front of unplayable ones (z 1), the selected card in front of all (z 3).

## The deck (build 2026-10-24.2)

- Pips: standard French layouts (2, 3, 4, 9, 10, Ace) in a field between the corner indices; lower half
  inverted; indices top-left and, inverted, bottom-right (`PIPS` in ui/cards.js). Suits are drawn SVG.
- Ornament (`tools/ornament.py` generates `app/ui/ornament.js`; symbols injected once, drawn with `<use>`):
  faint gold lace ground, gold double frame, illuminated index corner (gold bracket, ultramarine rule,
  vermilion dots, rosette), a flower bouquet in the free corners, top crest of filigree, a flowered vine
  garland down the free edge, all drawn for the top half and turned 180 degrees for the bottom. The Ace gets
  a lace rosette and flower wreath; the 2 and 4 a smaller medallion in their empty middle.
  References (PySolFC cardsets): Nicu's Ornamental corners, Ovale Salon ace rosettes, Dondorf and Hamburg 1864
  floral cartouches.
- Classic courts: the traditional double-headed K, Q, J from Seth's vector "Poker cards" set, cropped at the
  frame, in-frame suit marks recoloured to the house four colours, 200px WebP in app/courts/ (320 KB total).
  `tools/courts.py` rebuilds them (paths point at the session's unpacked copy). The set's licence wasn't in
  the zip; worth confirming if the site goes beyond friends.
- Back: after PySolFC tksol back101 (scroll-chain border, mirrored scroll band, mirrored "66") in deep gold on a
  powder blue and powder indigo wash, smoothed into one continuous gradient (build .3): a diagonal gradient
  #cfe2f6 → #b3c6f0 → #9c9fe2 under three heavily blurred layers of the old blotches (12, 35, 48), each layer
  one group under one filter; no tide lines, no grain. The hand-count backs are two radial blots of the same colours.
  Build .4: a soft white glow (blurred ellipse) behind each "66" so it reads off the wash.
  Build .7: elaborated, drawn as one half turned 180 degrees: blooms on the outer chain's corners, a gold lace
  ground over the inner panel, gold curls and a bouquet in each inner corner, flowering vines down both sides,
  and a centre medallion (ring of filigree curls, pale disc with a tick ring, a wreath of eight small flowers).
- Enamel pips (build .4, `PipIcon` in ui/cards.js): card pips are filled with a per-suit radial gradient (dark core
  → suit colour), get a near-white fade just inside the edge from the `pip-edge` filter (alpha eroded, blurred,
  subtracted, so it follows the real shape), and a stroke a shade darker than the middle (`PIP_LINE`).
  Build .6: the corner suit marks (cards and won-card piles) use `PipIcon` too; the corner numbers stay plain
  bold text, by Seth's choice. (`RankMark` and the `rk-edge` filter, the enamel number tried in .5, are still
  in the code, unused.) Tokens in logs and labels stay flat.

## Grandma prints and the 70s back (build 2026-10-24.11)

Replaces the face ornament (lace, bouquets, garland, crest, Ace wreath, 2/4 medallion) and the watercolour back.
`tools/wallpaper.py` (imported by `tools/ornament.py`) draws twenty SVG pattern tiles, one per card, in four suit
palettes, laid at .34 opacity behind each face through a radial fade mask (weaker in the middle), under the gold
frame (`orn-frame`). Nines borrow the ten's print.
  ♥ Ace chintz roses · K rose-and-ribbon stripe · Q strawberries · J polka dots + rosebuds · 10 doily lace
  ♠ Ace wisteria · K damask · Q violets · J forget-me-nots · 10 gingham
  ♦ Ace 70s daisies · K tulips · Q rose trellis · J calico · 10 sunflowers
  ♣ Ace hydrangea · K sweet peas · Q pansies · J feedsack · 10 toile sprigs
Back: 70s flower-power daisies in tomato red, denim blue, avocado green and mustard (one per suit) on cream, a
brown-and-mustard band, the gold frame, "66" in a brown pill cartouche. Hand-count backs: four colour dots.
Old ornament code (half/ace/mid symbols, watercolour filters) is still in ornament.py, unused.

## Cooper Hewitt prints (build 2026-10-24.12)

The face backgrounds are now cutouts from 20 Cooper Hewitt, Smithsonian Design Museum wallpaper scans (Seth's
Archive.zip, 25 scans, 5 unused). `tools/prints.py <scans> app/prints` crops a 5:7 piece per card (the `CUTS`
table: file, centre, width), tints it 32% toward the suit colour, and writes 250x350 WebP (about 300 KB for all
20). Build .13: tint lowered to 12%, shown at .62 opacity. A second set, app/cyano/, renders each cutout as a
one-colour sun print (contrast-stretched, shadows in the suit's ink, highlights to cream, faint wash and grain),
shown at .55; Menu → "Card faces" switches per phone (`prefs.faces`: print | cyano). Earlier: each face showed its print at .42 opacity through the `wp-fade` centre-fade mask, under the gold frame; nines
use the ten's. The drawn grandma prints in tools/wallpaper.py are no longer used on faces (the 70s back still is).
Licence: Cooper Hewitt images are often Smithsonian Open Access (CC0), but each object should be checked for the
CC0 badge on its si.edu page; not verified here.

## Lily backs (build 2026-10-24.14)

The back is the lily wallpaper Seth linked first (CHSDM-154584), cut by `back_images()` in tools/prints.py into
app/backs/: `back-print.webp` (the paper as is) and `back-cyano.webp` (Prussian-blue cyanotype, positive: pale
ground, blue lilies; Seth preferred it to the negative). It follows the "Card faces" menu choice. Gold frame and a "66" pill cartouche on top; the
hand-count backs are flat washes of the same colours. The 70s flower-power back (tools/wallpaper.py) is retired.

## Nines, zeros, and house rules with 0s (build 2026-10-24.16)

The 9s have their own prints (both sets): 9♥ poppy bouquet, 9♠ pansies (sampler), 9♦ beige trellis, 9♣ pastel
watercolour, from papers not used elsewhere. House rules no longer force 20 cards: the table options are now
Rules (House | Classic) and Deck (20 cards | 24). House + 24 is "house rules with 0s": the engine's 24-card deck,
with the 9 printed as 0 (`VALUE_RANK` in schnapsen/state/constants.js gained "9":"0", display only; the one change
under schnapsen/). A 0 has no pips, only its corner index, and shows its paper without the centre fade. Six won-card
piles when the deck has 24. Tests: house.test.mjs takes `24` (19765/0), mp.test adds a house24 run (14/14 audited);
fit check at 412x750 and 360x640 with six piles and six-card hands: no scroll, zero shifts.

## Best-of sun prints (build 2026-10-24.17)

Seth's second Archive.zip (20 scans, Cooper Hewitt and NMAH) was cut into 18 candidates (`tools/candidates.py`), each
sun-printed in all four inks and judged with the current 24 on: a motif that reads at card size, full tonal range
(p95-p5 luminance), quality of the original drawing, clean crop (no torn edges, folds, text, or crops under ~250px
enlarged), and calm enough behind pips. Rejected outright: torn #1/#12, the quilt photo, the album quilt (cluttered),
the cross-stitch sampler (138px, boxed), the lily-of-the-valley bouquet (text, reversed values), the gold rose swag
(weak range, border strip), the NMAH design drawings (paper edge, grid). Ten new papers replaced the ten weakest sun
prints (`CYANO_PICKS` in tools/prints.py; the wallpaper set keeps `CUTS`): 10H rose vine, JS chintz medallion,
9S chintz florals, QD/KC feathered floral stripe (lower/upper), JD trellis chintz, 9D scattered chintz,
JC chintz florals (lower), 10C flower and lattice, 9C flower sprays. Build .18: the wallpaper set takes the same ten papers (tinted 12% like the rest), so both sets
match card for card again. Ochre ink deepened (138,92,6) → (112,72,0):
the diamond row's tonal range rose about 15 points (now 133-156). Rebuild: python3 tools/prints.py <archive1> app/prints <archive2>.

## Final gate run (build 2026-10-24.18)

rules 27/27, variant24 21/21, guest clean, house 16939/0 (20 cards) and 18633/0 (with 0s), cheat all caught,
mp 84/84 audited deals across six runs (classic, 24, classic at 15% loss, house, house at 15% loss, house with 0s),
relay.test 14/14, browser flows green with no page errors, one-screen fit at 412x750 and 360x640: no scroll, zero shifts.
Not re-run this round: browser relays.py (passed 1 of 3 at build .3; see the "stepped away" note above).

## High visibility (builds 2026-10-24.19 to .21)

For Jamie. A per-phone switch, `prefs.big` → class `big` on `<html>` (ident.js), so the stylesheet does the work and
the other phone is unaffected. Turned on from: Menu → "High visibility" (table and solo), the name sheet (tap your
name in the lobby), the first-visit name screen, or any link with `?big` (`?big=0` turns it off) — so a link can
be sent ready-made.
- Faces (`BigFace` in ui/cards.js, class `.hv`): no pips, no courts, no corner indices; one rank over one suit,
  centred, with a soft ivory halo, over the card's paper (wallpaper or sun print,
  still chosen in the menu; Seth asked to keep both). Face base tinted toward the suit. Deeper red #a3150f and
  amber #7a5200 in this mode (6:1 or better on the tints).
- Even ranks (build .20, Seth's ask): at one font size Josefin Sans Bold draws digits 68 tall, K/Q/J 74, A 77
  (per 100px), and the J hangs 16 below the line; the "10" was also set smaller. Now `RankGlyph` (ui/cards.js)
  draws each rank as SVG text with its viewBox cropped to that glyph's own ink box, so every rank (A K Q J 10 9 0
  2 3 4) fills one height box: .52w on the faces, also used for the won-card pile labels. Ink boxes are measured
  on the phone with canvas `measureText` (re-measured on `document.fonts` ready/loadingdone; table `INK0` holds
  the Josefin values until then), so a fallback face is cropped right too. Wide ranks squeeze (max .86w), never
  shrink. Checked from pixels with Josefin loaded through the stylesheet: every rank 50–52px tall at w=100 (the
  rest is anti-aliasing on round tops); with no web font, all 52. Suit .52w, gap .07w.
- Build .21 fix (Seth's phone, 412x744 with Josefin): when the stock is under 160px tall the container query hides
  "N left", but the stock's rows were fixed (1fr 28px 30px), so the hidden label kept its row and the stock cards,
  sized as if it were gone, rose 13px above their cell over the opponent's won-card row. Rows are now
  `1fr auto auto` (labels keep fixed heights; a hidden one takes no row) and the short formula is cqh - 34.
  The old fit check compared scrollHeight, which can't see an upward spill. New gate `tests/browser/fit.cjs`
  checks every card and label inside its cell on all four sides after every move of whole deals. It caught the
  bug on build .20 and passes on .21 at 23 sizes (360x600 to 412x915, 20 and 24 cards), and with the mode off.
- Hand: every card whole, side by side, no overlap. Width from the deal's hand size `--n`, not the cards held,
  so a card never resizes during a deal: min(124px, (avail - gaps)/n, 20svh/1.4).
- Won cards (house tables): `Piles big` renders each rank as a big rank over four fixed suit slots
  (spades, hearts / diamonds, clubs), filled with a suit chip once won. Same place every time.
- Table: rows 44 | well | 44 | 36 | 56 | hand; stock column 42% (bigger turned card); larger status, captions,
  stats, buttons; opponent's tiny hand-count backs hidden. Under 700px tall: rows 40/34/54 and tighter felt; a
  container query drops the "N left" label when the stock is under 160px tall, so the stock cards keep their size.
- Lobby and sheets: base text 22px, small labels 18–20px.
Checked: one-screen fit at 360x640, 390x844, 412x750, 412x915, 20 and 24 cards: no scroll, no overflow in any band.
Browser flows green with the mode off and on (?big on every page), no page errors; rules 27/27, variant24 21/21,
guest clean. Engine and net untouched, so mp/cheat/relay/house were not re-run.

## Floral deck faces, Bicycle layout, four-square won cards (build 2026-10-25.2)

The faces now take the floral deck's papers (59 Cooper Hewitt cutouts, Smithsonian Open Access CC0; picks in the
deck's CREDITS.txt): A, 10, K, Q, J, 9 and the house 0 per suit, 250x350 WebP in app/prints (tinted 12%) and
app/cyano (sun print in the suit's ink). The 0 has its own paper (0S.webp etc.), shown whole; before, it borrowed the 9's.
- Papers stronger: .9 opacity (print) / .88 (cyano) through `wp-fade` (centre fade #6a6a6a → white by 78%), plus
  `wp-c1`/`wp-c2` radial fades behind both corner indices; the 0 uses `wp-corners` (corner fades only).
- Bicycle geometry (`PIPS` in ui/cards.js, now in whole-card fractions): side columns 27% / 73%, centre 50%; top and
  bottom rows 16% / 84% on every number card; 9 and 10 in four even rows; 7 and 8 as 3+1(+1)+3 halfway between
  rows; the 9's odd pip dead centre. Pips .25w boxes; Ace .44w, Ace of spades .56w.
- Bicycle index: rank .18w, suit .105w under it, at 5% / 4.5% from the corner (was .29w / .2w).
- Bicycle court panels: 56% of the card's width (was 46%), nearly full height; the 200px court art is shown ~1.4x.
- Won cards: `Piles` in ui/game.js always draws the High visibility display (rank over four suit slots, filled with
  a suit chip once won), with the mode on or off; the fanned mini-card piles are gone (their .mini CSS is unused).
- History: build 2026-10-25.1 carried the deck changes but was built on .19, so it lost .20 (even ranks) and .21
  (stock row fix). .2 is .21 plus the deck changes plus the won-card display.
Checked: tests/browser/fit.cjs (every card and label inside its cell after every move) at 16 sizes from 360x600
to 412x915, mode on and off, 20 and 24 cards; screenshots at 412x744 both modes; no page errors. Engine and net untouched.

## Marriages you can't miss (build 2026-10-25.3)

Seth kept missing the bot's marriages (it declares and leads in one go, so only "Fritzl led" showed). In ui/game.js:
- `useMeldPop` watches the count of meld entries in the deal log; a new one shows `MeldPop` for 3 s: the K and Q of the
  suit as cards and "Fritzl declared 20" / "You declare 40 in trumps". It is an absolutely placed grid item in the
  felt's row (`.mpop`, grid-row 2 / 3 of `.game`, which is now position: relative), pointer-events none, so play
  goes on under it and nothing moves. aria-live assertive.
- `meldNow` (plays aren't logged, so the log ends with the meld until the trick completes): while a declaration is
  waiting for its lead, or its K/Q is on the table, the trick caption is `MeldRibbon` (gold, "Marriage 20 ♥", pulses
  3 times) and the led card glows (`.tslot.meld`).
- Badges by each name (`.mchips`): suit + points for every marriage declared this deal. Not shown for the opponent
  when their points are hidden (face-down piles, memory mode).
Checked: solo deals played until the bot declared (mode on and off) and until Seth's seat declared, at 412x744 and
360x640; fit.cjs at 6 sizes, mode on/off, 20 and 24 cards; no page errors.

## The back room (build 2026-10-25.4)

Seth's ask: a classic backroom card table, premium felt, gold linework. Static by his choice: no smoke, no haze,
nothing that moves by itself (the lobby marquee's bulb chase is gone; "Opening the table…" no longer pulses). Avatars
stay squares (no poker chips, his call). Paint only: every size, padding and border width the fixed table reads is
as it was in .3, so the geometry notes above all still hold.
- Cloth: `app/room/felt.webp` (320px tile, billiard green with a combed nap, 8 KB) on every screen, under a warm lamp
  pool (`--lamp`, upper middle) and shade falling to near-black at the edges (`--shade`). Together `--cloth`. Type
  gets a soft dark text-shadow to lift it off the nap. Measured on screenshots: ivory 7.9:1 at the brightest spot
  of the play area, 11:1 in the lobby; High visibility turns the lamp down and the cloth darker (12:1).
- Rails: `app/room/wood.webp` (640x160, mahogany, tiles left to right, 3 KB) with a lacquer sheen. The header is the
  far rail, the in-game chat drawer the near rail; each keeps its gold double inlay (the 3px double border it had)
  and casts a shadow onto the cloth. Bottom sheets are trays of the same cloth with a mahogany lip.
- Gold linework: the play area is the old 5px double rule, now with rounded corners (14px) and four flourished corners
  (`--orn-tl/tr/bl/br`, inline SVG in app.css, on `.felt::before` behind the cards). List rows (tables, seats, bots,
  menu) are ruled with gold hairlines that fade at both ends (`--hair` border-image). The lobby name sits over a
  diamond rule (`--orn-rule`). Empty card places are a gold double outline printed on the cloth; empty won-card
  slots are solid dark recesses (so the corner flourishes never show through them).
- Controls: plain buttons are a gold rule with a hairline laid inside; primary buttons, selected segments, the pot,
  badges, marriage chips and the ribbon are gold leaf (`--metal`, deeper fold) with the label stamped in dark brown.
  A disabled primary shows a dashed outline instead of a half-faded gold.
- Type: Playfair Display SC (700/900) replaces Limelight for the wordmark and headings; the italic Playfair for the
  tagline and "Nothing said yet." Josefin Sans everywhere else, unchanged (the rank ink boxes are measured on it).
- Cards: unchanged, apart from softer, deeper shadows on the cloth and a gold glow on the selected card.
- Wide screens: the column is the table, edged in mahogany and gold, in a dark room.
- The marriage pop-up, ribbon pulse and glow (build .3) still animate: they are signals, not decoration.
- Build 2026-10-26.1: Limelight is loaded again. .4 dropped it with the headings, but the "66" cartouche on the card
  backs (ui/cards.js `Back`) is set in it, so the backs fell back to Georgia.
- `tools/room.py app/room` redraws both textures (numpy, frequency-domain noise, seamless).
Checked: tests/browser/fit.cjs at 16 sizes (360x600 to 430x932), mode on and off, 20 and 24 cards: 64/64 all inside;
browser flows green, no page errors; rules 27/27, variant24 21/21, guest clean. Engine and net untouched, so
mp/cheat/relay/house were not re-run.

## Courts without inner pips (build 2026-10-26.2)

On top of 2026-10-26.1 (the back room, Limelight back for the "66"). Seth asked for the suit pips inside the court
panels to go (the corner index already says the suit). The 12 images in app/courts/ were cleaned: in each panel's
top-left and bottom-right corner, the largest blob of the suit's colour (the pip) plus its anti-aliased rim (pixels on
the line from the pip colour to white) was painted white, then tiny leftover specks nearby that touch no larger shape.
Nothing attached to the figures' line work changes. Re-encoded as WebP q92 (375 KB for all 12, was 306 KB). The floral
decks' 24 court cards were re-rendered the same way. (A parallel session also numbered a build 2026-10-26.1 with only
this change; this .2 supersedes both.)

## Self-contained (build 2026-10-26.3)

Seth's ask: no CDNs, no fonts from other services, everything local. Audit of the shipped files (index.html, app/,
vendor/, schnapsen/): the only third-party load was the Google Fonts stylesheet in index.html (plus two preconnects).
Preact+htm and nostr.js were already self-hosted in vendor/; images, textures, courts, prints and ornaments are all
in app/; no `@import`, no remote `url()`, no dynamic `import()` of a URL, no workers, no analytics.
- `app/fonts/`: Josefin Sans 400/700, Playfair Display SC 700/900, Playfair Display italic 400, Limelight 400.
  woff2 from the Fontsource npm packages v5.3.0 (Google Fonts' own builds), split by unicode-range exactly as Google
  serves them (latin, latin-ext, vietnamese, cyrillic where the family has it), so a phone fetches only the subsets
  its text needs: normally the six latin files, about 120 KB. 356 KB on disk for all 24 files. `font-display: swap`.
  OFL licence per family alongside. `tools/fonts.py` rebuilds the folder (usage in its docstring).
- index.html: the Google links are gone; `app/fonts/fonts.css` loads before app.css, and the two Josefin latin
  files are preloaded (almost all text, and the rank ink boxes are measured on it).
- What still leaves the site, by design: the Nostr relays (app/net/relay.js: WebSockets, plus the NIP-11 info
  `fetch` to the same hosts). That is the multiplayer transport, not a resource load; `?local` and solo use none.
  The optional `config.js` 404s when absent (expected, same as before).
- `tests/browser/selfhosted.cjs` (new gate): walks name screen, lobby, a table, solo setup, a solo deal with play,
  Deal log / Score sheet / Rules, both card-face sets, High visibility and #/net, in `?local` and with the real
  transport; aborts and records everything off-site, closes relay sockets without dialling. Fails on any off-site
  request that isn't the relay pool, any font not from app/fonts/, any of the four families never loading, or a
  page error. On build .2 it fails (Google Fonts, no faces loaded); on .3 it passes.
- `tests/browser/fit.cjs` no longer stubs Google Fonts with hand-copied jf400/jf700 files: the real fonts load.
Checked: selfhosted.cjs PASS (0 off-site in both passes; relay pool only in pass 2; 6 faces loaded, 6 font files,
all from app/fonts/); fit.cjs at 13 size/mode/deck combinations from 360x600 to 430x932, all inside; flows.py green,
no page errors; rules 27/27, variant24 21/21, guest clean. Screenshots: wordmark in Playfair SC, body in Josefin,
italic Playfair, Limelight "66" on the backs. Engine and net untouched, so mp/cheat/relay/house were not re-run.

## Sturdier connections (build 2026-10-26.4)

All in app/net/relay.js (plus a wake-lock hook); engine, match, mesh and UI layout untouched.
- **Dead sockets that look open.** A phone that sleeps or hops wifi↔cell can keep a WebSocket that reads "open"
  while nothing passes, and `send()` into it never fails. Before: nothing noticed, ever — `tests/zombie.test.mjs`
  on the .3 transport delivers 0 of 5 messages and the table stalls for good. Now each connection is probed (a
  REQ with a random `#t` that must come back EOSE, then CLOSE) when the page comes back on screen, on `online`,
  on `navigator.connection` change, when a post has had no OK for 8 s (`ACK_MS`), and after 90 s of silence
  (`QUIET_MS`). No answer in 6 s (`PROBE_MS`) → `kill()`: handlers detached, reopened at once, subscriptions
  re-asked with `since`, and every post sent into the dead connection without an OK (`c.unacked`, kept 2 min, up
  to 200) goes out again (newest 30). A probe that passes clears older unanswered posts on that connection, so a
  relay that never sends OK can't make it probe in a loop. Test: 5/5 delivered in 15.6 s, no duplicates.
- **Connecting that never ends.** `CONNECT_MS` 10 s: a socket not open by then is dropped and retried. An `error`
  before open counts as the end too (Node's WebSocket never follows it with `close`; phones can hang in
  "connecting" for minutes). One `lost()` handles close, early error and timeout.
- **Relay restarts.** A relay that worked earlier this session (`everOpen`) gets 12 ordinary tries (backoff capped
  at 60 s, ~8 min) before the 10-minute slow retry; never-opened relays keep 4. Before, a relay down ~25 s was
  shunned for 10 min — relay.test's "relay 1 dies" left the good relay unused for the rest of the run (55 events vs
  ~245 on the lossy and rate-limited ones), which is most of its slow "caught up in 55 s". Failures while
  `navigator.onLine === false` don't count, and `online` / network change reset the count.
- **The goodbye.** `leave()` used to seal the `bye` (async WebCrypto) on the way out; and when it did get sealed it
  waited for send budget, which a deal's burst has usually spent. Traced in two browsers: Seth saw "stepped away"
  only after the 140 s timeout. Now the bye is sealed ahead of time (`prepBye`, re-sealed hourly; receivers hear
  h-1..h+1 tags) and sent synchronously from pagehide to every open, non-resting relay, budget or not (prio
  "force"). Seth sees it at once; Jamie's return clears the banner in 0.2 s (was 6 s, and 38.9 s in relays.py).
  This was the cause of the "Jamie closes the page" flake noted at build .3.
- **The lost first hello** (in .3 too). A page's first hello is made before any relay connection is open, so it
  went to the outbox with a copy count of 0 (`ok.length` at that moment) — and the outbox took it out and sent it
  nowhere. Every page load, reload and return was heard only at the second hello, 6 s later. Now a queued "all"
  goes to every relay once one opens. The 6 s second hello now goes out only if nobody has answered.
- **Hello replies.** The answer to a hello was a routine heartbeat (needs 4 tokens, else skipped), so right after a
  burst a returning page heard nobody until the next regular heartbeat (45 s). Now: one copy, 1 token, on a relay
  the newcomer said it uses (`heartbeat(false, false, peerId)`, prio "tip").
- **Ghost peers** (in .3 too). After a reload, the `since` replay handed each page stored events from pages that had
  already closed or reloaded (its own old page included: a new `selfId`). Each became a peer for 140 s, was greeted
  every 12 s on every relay (mesh `regreet`), and, knowing no relays, made `cover()` send every broadcast to all
  relays — draining the send budget everyone shares. Now a stored event (data events before the relay's EOSE on
  that subscription; 10 s fallback for relays that send none; control events are never stored) can't create a
  peer, and a peer that said goodbye (`gone`) can't come back. Judged by the relay protocol, not the sender's clock.
- Measured on two browsers through four local relays (normal, 20% lossy, web of trust, 30/min), whole sequence:
  deal, both reload, a watcher, Jamie closes and returns. Old: "stepped away" after the 140 s timeout; banner gone
  6–39 s after she's back. New: "stepped away" at once; banner gone in 2.1–2.6 s; watcher 6 s (same as .3).
  Deal times: same range as .3 (both 7.5–21 s on these relays, set by repairs on the lossy one).
- `pageshow` with `persisted` (restored from the back/forward cache after pagehide left every room) → reload.
- **Screen wake lock** (`useWakeLock` in ui/hooks.js, used by `Game`): the screen stays on while a game is showing
  (solo too), re-requested each time the page becomes visible; silently nothing where unsupported.
- `CANDIDATE_RELAYS` (the #/net checker only) adds relay.0xchat.com and nostrue.com.
- The transport object has `wake(net)` (what the DOM events call), used by zombie.test.
Checked (serially, nothing else running): zombie.test 13/13 (fails on .3: 0/5 delivered, table stalls); relay.test
14/14, "caught up after 20 s away" 18.5 s (was 55 s: the restarted relay is used again); browser relays.py 19/19 on
3 of 3 runs (was 1 of 3), "stepped away" at once, "comes back" 1.9 / 2.4 / 1.9 s (was 38.9 s); selfhosted.cjs PASS;
flows.py green, no page errors; rules 27/27, variant24 21/21, guest clean, house 16965/0, cheat all caught, mp 84/84
audited. Not checkable here: real public relays and real phones (sleep, wifi↔cell) — the first real test.

## Being a good guest (build 2026-10-26.5)

Seth's ask: read each relay's policies and make sure we never abuse them or get banned. Research (Oct 26, three
agents; relay hosts themselves weren't reachable from the sandbox, so mostly secondary sources and software
defaults):
- Almost no relay publishes terms. Limits come from software defaults and operator plugins:
  - strfry has no built-in rate limit. Its common plugin (strfry-policies) defaults to 10 events/min per IP.
  - Damus's noteguard plugin limits notes per minute per IP; the config jb55 quoted is 6/min. It bans the IP
    (default 1 h) after repeated violations. Another app got exactly that ban on relay.damus.io on 2026-10-15,
    and a third reports a ban after about three test runs.
  - khatru's "sane defaults": per IP, a burst of 10, then 2 events per 3 min.
  - nos.lol limits and refuses connections per IP; it shares a server (142.132.206.70) with nostr.mom.
  - relay.coinos.io blocks kinds it doesn't allow (unpublished list).
- Spec rules that applied to us:
  - NIP-40: "Clients SHOULD NOT send expiration events to relays that do not support this NIP"; relays may keep
    expired events indefinitely.
  - NIP-59: one-time keys defeat relays' per-key anti-spam. Trystero, the closest precedent, uses one key per
    page load and ephemeral kinds.
  - strfry's default maxEventSize is 64 KB (our 64 and 128 KB padding buckets would have exceeded it).
  - strfry refuses ephemeral events older than 60 s.
- Measured before (build .4, both phones, a move every ~4 s): 35–44 events/min on each relay during play, ~4 MB/h
  of stored data per relay, 2.5–5 events/min per relay with both pages idle.

What changed (app/net/relay.js unless noted):
- **Nothing stored.** Data moved to ephemeral kind 24748 with no expiration tag. Catch-up after a dropped
  connection is our own repair (want / re-send), which already existed. "mute:" (nobody listening) counts as OK.
  An event that waited over 40 s (for budget or a connection) is re-signed before it goes (`renew`, `specs`).
- **One key per page load** (`pageKey`), so operators can limit or block us per key, not per shared IP.
- **Budget:** token bucket 2 deep, +1 per 20 s per relay per page: at most 5 events in any minute and 3/min
  after. Two phones on one home IP: at most 10 and 6. nos.lol and nostr.mom share one bucket (`GROUP`).
  "rate-limited:" rests the relay 10 min, doubling to 2 h, so a relay never sees a quick second strike.
- **Fewer events:**
  - one copy per person; broadcasts to a covering set without a spare; unknown peers 2 relays (was all);
  - batching (`mb`) of messages to the same people within 25 ms, and of resends;
  - no routine heartbeat while alone in a room or after the page has been hidden 5 min; heartbeats every 60 s
    (was 45; `STALE_MS` 190 s);
  - a hello at most every 30 s on wake;
  - the tip heartbeat waits 10 s and is skipped if everyone has answered since;
  - the 6 s second hello only if nobody answered.
- **Two waste bugs found by counting every message of three deals** (`onPublish` hook in relayP2P's config, for
  tests):
  - heartbeats announced message numbers still waiting for budget, so the other side saw holes and asked for
    them (85 wants in three deals). Heartbeats now announce only what has gone out (`outQ`, `outD`).
  - The outbox wasn't first-in-first-out: a later message could overtake one waiting for budget (more false
    holes). And the match safety net (15 s) re-sent whole deals during ordinary budget waits. Now FIFO, and the
    safety net waits 30 s and never while our own messages are queued.
- **Size:** padding buckets stop at 32 KB (about 44 KB as an event).
- **Probes** after 45 s of silence (was 90): with fewer heartbeats a dead socket on the receiving side went
  unnoticed too long. A probe is a REQ, not an event, so it costs no budget.
- **Relay list** (DEFAULT_RELAYS): nos.lol, nostr.mom, relay.primal.net, relay.ditto.pub, relay.coinos.io,
  relay.nostr.net, relay.snort.social, nostr.oxtr.dev (operator: "free to read and write to"),
  nostr-pub.wellorder.net (nostr-rs-relay's author).
  - relay.damus.io is out: the flagship social relay, with hour-long IP bans after bursts.
  - Also out: offchain.pub and nostr.bitcoiner.social (web of trust), relay.mostr.pub (now only redirects to
    relay.ditto.pub), relay.nostr.band (down since mid 2026), relay.0xchat.com (one app's private-message relay;
    it was briefly added in .4).
  - The #/net checker also tries damus and nostrue.com.
- Known, not fixed:
  - relay.snort.social (memlay, in-memory) was reported keeping events past their expiry; moot now that nothing
    we send is stored.
  - Per-IP connection limits: each page holds one socket per relay; two phones make two per relay per IP.

Measured after (three deals, both phones, three local relays, a move every ~3 s, counting what reaches the
relays): ~43 events and ~112 KB per deal (was ~135 events, ~225 KB); 8 wants in three deals (was 85).
The busiest single minute on any one relay is bounded by the budget (2 phones × 5).
Where the rest goes: the protocol itself (4 shuffle passes, card-key gifts after each trick, 2 audits, next) plus
about one heartbeat a minute per room per phone. About half the bytes are the five 11 KB shuffle messages
(1024-bit SRA); an elliptic-curve shuffle (32-byte cards, noble secp256k1 already vendored) would take a deal to
roughly 15–20 KB. Not done.

### The house relay (same build)

Seth is putting up his own relay on Cloudflare, possibly more than one. Set them as `HOUSE_RELAY` in app/net/relay.js
or `house: "wss://…"` (or a list, best first) in config.js; both phones load the same config.js.
- **Redundancy advice:**
  - Cloudflare first, a relay on another provider second (Deno Deploy, or the Pi through a tunnel), public relays
    last.
  - Two Workers on one Cloudflare account share its free allowance and its outages.
  - Separate accounts just for quota are the kind of thing Cloudflare's terms frown on.
- **Budget:** 30 deep, +1 per second per page: 60/min, and both phones flat out all day would be ~170k messages,
  under 9% of the Workers free plan's ~2M incoming WebSocket messages a day.
- **Routing:** everything goes to the best house relay that is up and that everyone can reach: `cover()`,
  `dataTargets()` and heartbeats pick it via `houseFor()`; the next one on the list takes over. Someone whose own house connection is down says so in their heartbeat's relay list and gets public
  relays instead. Hellos and goodbyes go as two copies, since everyone listens on every relay (`everywhere()`): the best two house
  relays, or the house relay plus one public relay, or two public relays at random. A first hello queued before any
  connection opened goes to the first two relays to open, house relays first.
- **Never spills over:** a message meant for the house relay waits for its budget (at most a second) instead of
  going to a public relay (`alive()` in publish and the outbox). Public relays are used only while it is down,
  resting or refusing.
- **Quiet standby:** public relays stay connected for listening. Silence probes skip them unless we sent to them in
  the last 5 minutes.
- **Retries:** the house relay is retried briskly (backoff capped at 15 s, every 2 min after ~10 min down).
- **Test:** tests/house.relay.test.mjs, with houses A and B and two public relays.
  - A up: 2 deals in ~10 s at a move every 250 ms, 0 events on B or the public relays.
  - A killed mid-deal: B takes over (2 deals in 7 s, 0 on public).
  - B killed too: the public relays carry it (2 deals in ~100 s, at their budgets).
  - Both back: reconnected in ~6 s, and the next 2 deals are on A only.
- tests/browser/relays.py now runs with a house relay (7815) by default; `SX_PUBLIC_ONLY=1` runs the old
  public-only flow, which is slow at public budgets with only three usable test relays (relay.test covers that
  path).
  - Checks that the house relay carried the game and the public relays only spare hellos and goodbyes.
  - Checks one signing key per page load, replacing the old "a different key per event" check.

Checked, build .5 (serially):
- zombie.test 13/13, on three relays all going dead together. Worst-case recovery is now ~60 s, against ~16 s in
  .4: with fewer heartbeats the receiver notices silence later. On phones, network-change and back-on-screen events
  trigger an immediate check, so this is the fallback.
- house.relay.test 10/10.
- relay.test 14/14 at the public budgets; "caught up after 20 s away" 0.9–15 s.
- browser relays.py 20/20 on 3 of 3 runs, with a house relay: dealt in 0.4 s; "stepped away" at once; comes back
  0.9 s; house 140 events, public 24; 6 keys for 146 events.
- selfhosted.cjs PASS; flows.py green, no page errors.
- mp 84/84 audited; cheat all caught.
- rules 27/27, variant24 21/21, guest clean, house 17414/0.

**The relay itself (Oct 26):** separate repo `schnapsen-relay`, delivered as shnapsen-relay-site.tar.gz (Seth's name
for it, Oct 27; the workflow unpacks any .tar.gz in the repo root) plus `.github/workflows/deploy-relay.yml` (cloudflare/wrangler-action@v3, wrangler 4.153.0, secrets
CLOUDFLARE_API_TOKEN and CLOUDFLARE_ACCOUNT_ID). Setup steps are in its README; the project doc
claude/schnapsen-relay.md is a copy.
- **Design:** a Worker plus one SQLite-backed Durable Object ("hub", WebSocket Hibernation API; subscriptions and
  rate counters in each socket's 2 KB attachment).
- **Protocol:** a NIP-01 subset (EVENT/REQ/CLOSE → OK/EOSE/CLOSED/NOTICE) and NIP-11. Only kinds 24747 and 24748;
  id and Schnorr checked with the site's own vendor/nostr.js (`verifyEv(sig, id, pubkey)`, ~1.7 ms).
- **Limits:** created_at within ±120 s; 240 events/min per connection; 20 subscriptions; 500 connections.
- **Storage:** none.
- **Origins:** browsers only from ALLOWED_ORIGINS (https://szk5334.github.io).
- **Tested under wrangler dev:**
  - its relay.test 16/16;
  - the game's two-player test, 4 deals in 24 s;
  - browser relays.py with `SX_HOUSE_URL=ws://127.0.0.1:8787` 20/20 (dealt 0.4 s, comeback 0.4 s, public relays
    27 spare events). relays.py takes `SX_HOUSE_URL` to point the house relay at any URL.
- **Once deployed:** put its wss:// address in HOUSE_RELAY (app/net/relay.js) or config.js `house`.

**Live (Oct 27, 2026): https://schnapsen-relay.szk5334.workers.dev** (its page answers "Schnapsen house relay. It
carries sealed game messages and stores nothing."). Build 2026-10-27.1 builds it in: `HOUSE_RELAY =
["wss://schnapsen-relay.szk5334.workers.dev"]`. A config.js `house` setting now replaces the built-in list entirely
(`""` or `[]` = public relays only; a list adds a second relay). relay.test and zombie.test pass `house: []` so they
stay public-only. The sandbox can't open WebSockets to workers.dev (proxy 403), so the first live test of the
deployed relay is on the phones: #/net should list it as open on both.

Next on this thread: real phones. Leading option: a Cloudflare Worker + Durable Object (free plan:
100k requests/day, incoming WebSocket messages count 1/20, no duration charge while hibernating, SQLite-backed
objects only), accepting only kinds 24747/24748, storing nothing, used first with the public relays as fallback.
Second provider for a backup house relay (researched Oct 26):
- Render free web service: one instance, sleeps after 15 min without HTTP or WebSocket traffic, ~1 min to wake,
  5 GB a month. Good as a standby.
- Deno Deploy free: 1M requests, 20 GiB egress. It may run several copies, which then need BroadcastChannel; unverified.
- Google e2-micro always free: card required, 1 GB egress a month.
- The Pi at home behind Tailscale Funnel.
Oracle Always Free was cut on 2026-06-15 (A1: 2 OCPU / 12 GB) and reclaims instances idle 7 days (<20% CPU p95,
network, and memory on A1), which a quiet relay is. Fly.io has no free tier for new orgs (~$2.19/mo).

## Hidden connection page

`#/net` (linked from nowhere): the build (`app/version.js` — bump per tarball; both phones must match), each
relay's state (open / resting / off with the reason / unreachable), events sent and budget, who this page has
heard from per room, lobby presence, relay notes, and **Check relays**: test-posts one stored and one
passing-through event to every candidate relay from this phone, reports Yes/No with the reason, and offers a
`config.js` list of the ones that work.

## Known limits

- Relays see IP addresses and timing. Tor Browser / Orbot hides the address.
- The lobby key derives from the public app id; a table's from its 4-letter code (guessable). Cards stay
  safe regardless (mental poker); table chat is as private as the code.
- Kinds 4747/24747 mark the traffic as this app's (same kinds as Party Line).
- Relays publish almost nothing about their limits (none of the six original relays' NIP-11 documents list
  rate limits); the budget is a guess kept well under typical client traffic. A browser can't see why a
  connection failed, so a ban and an outage look the same ("unreachable").
- Throwaway keys mean web-of-trust relays will always refuse us; they're detected and dropped.
- Presence isn't signed: anyone with the room key could claim a name. Party Line's identity keys would fix it.
- Not verified here: the six public relays (unreachable from the build sandbox). First real test: two phones.

## Next

- Contracts system (Sept–Oct sessions) lives in a different tarball; wire it in once the table is final. The house
  rules doc lists contracts as experimental; not in this build.
- QOL list in the conversation; the cheap ones first: rematch, reactions, sound, unread on tab title.
