/* The review sheet: the turning points of the deal just played, for both players, judged from what each could see.
 * The work runs a slice at a time (it takes a few seconds on a phone) and is kept, so reopening the sheet is instant. */
import { html, useState, useEffect } from "../../vendor/preact.js";
import { reviewSteps, seedOf, TUNE } from "../review.js";
import { ENG } from "../../schnapsen/engine/core.js";
import { Tok, Suit } from "./cards.js";
import { useRanks } from "./game.js";

const jobs = new Map();          // seed -> { it, progress, result, subs }

function job(rec, s) {
  const seed = seedOf(JSON.stringify(rec.moves) + "|" + rec.d0.hands[0].map(c => c.id) + "|" + (s.bummerlNo || 0) + "." + (s.dealNo || 0));
  let j = jobs.get(seed);
  if (!j) {
    j = { it: null, progress: { done: 0, total: 0 }, result: null, subs: new Set(), timer: null, error: null };
    j.variant = s.variant || "classic";
    j.it = reviewSteps(JSON.parse(JSON.stringify(rec.d0)), rec.moves, { house: !!s.house, variant: s.variant || "classic", seed });
    jobs.set(seed, j);
  }
  return j;
}
/* Run while someone is watching; a slice is ~25 ms so the page stays responsive. */
function pump(j) {
  if (j.result || j.error || j.timer || !j.subs.size) return;
  j.timer = setTimeout(() => {
    j.timer = null;
    const end = performance.now() + 25;
    const variant = ENG.getVariant();
    ENG.setVariant(j.variant);                  // judge in the deal's own deck, whatever the page set meanwhile
    try {
      while (performance.now() < end) {
        const r = j.it.next();
        if (r.done) { j.result = r.value; break; }
        if (r.value) j.progress = r.value;
      }
    } catch (e) { j.error = e.message || String(e); }
    ENG.setVariant(variant);                    // the review sets the deck it judges; put the table's back
    j.subs.forEach(f => f());
    pump(j);
  }, 0);
}

/* Start working it out in the background (the score screen calls this, so the review is usually ready when asked for). */
export function warm(rec, s) {
  const j = job(rec, s);
  const f = () => {};
  j.subs.add(f); pump(j);
  return () => j.subs.delete(f);
}

export function Review({ rec, s, seat, name }) {
  useRanks(s);
  const j = job(rec, s);
  const [, tick] = useState(0);
  useEffect(() => {
    const f = () => tick(x => x + 1);
    j.subs.add(f); pump(j);
    return () => j.subs.delete(f);
  }, [j]);

  if (j.error) return html`<p class="pad">The review couldn't be worked out for this deal.</p>`;
  if (!j.result) {
    const { done, total } = j.progress;
    return html`<div class="rv-wait" role="status">
      <p>Going over the deal${total ? `: ${done} of ${total} choices` : "…"}</p>
      <div class="rv-bar"><span style=${`width:${total ? Math.round(100 * done / total) : 4}%`}></span></div>
    </div>`;
  }
  const r = j.result;
  const order = [seat, 1 - seat];
  return html`<div class="rv">
    ${r.points.length
      ? html`<ul class="rv-head">${order.map(i => html`<li key=${i}><b>${name(i)}</b>: ${r.bySeat[i].count
          ? `${r.bySeat[i].count} costly ${r.bySeat[i].count === 1 ? "choice" : "choices"}`
          : "nothing costly"}</li>`)}</ul>`
      : html`<p class="rv-clean">A clean deal. No choice by either of you cost as much as ${TUNE.FLAG.toFixed(1)} of a game point.</p>`}
    ${r.bySeat[0].count + r.bySeat[1].count > r.points.length && html`<p class="muted">The ${r.points.length} that cost the most:</p>`}
    <ol class="rv-list">${r.points.map(p => html`<${Point} key=${p.i} p=${p} name=${name}/>`)}</ol>
    <p class="muted rv-foot">Each choice is judged from what that player could see at the time: the hidden cards are dealt many
      ways, and every choice is played out in each of them. Nobody is blamed for a card they couldn't know about.</p>
  </div>`;
}

const T = c => html`<${Tok} c=${c}/>`;
function did(o, p) {                 // past tense: what they did
  if (o.type === "CLOSE") return html`closed the stock`;
  if (o.type === "EXCHANGE") return html`swapped for the turn-up ${T(p.up)}`;
  if (o.type === "MELD") return html`declared ${o.meld} and led ${T(o.card)}`;
  return p.lead ? html`led ${T(o.card)}` : html`played ${T(o.card)} on ${T(p.led)}`;
}
function todo(o, p) {                // what would have been better
  if (o.type === "CLOSE") return html`close the stock`;
  if (o.type === "EXCHANGE") return html`swap for the turn-up ${T(p.up)}`;
  if (o.type === "MELD") return html`declare ${o.meld} and lead ${T(o.card)}`;
  return p.lead ? html`lead ${T(o.card)}` : html`play ${T(o.card)}`;
}
/* How a choice is named inside a sentence. */
const it = o => o.type === "CLOSE" ? "closing" : o.type === "EXCHANGE" ? "swapping" : o.type === "MELD" ? html`declaring with ${T(o.card)}` : T(o.card);
const freq = x => x >= 0.85 ? "almost always" : x >= 0.6 ? "most of the time" : x >= 0.4 ? "about half the time" : x >= 0.15 ? "now and then" : "hardly ever";
const SUITW = { S: "spades", H: "hearts", D: "diamonds", C: "clubs" };

/* What the choice is, in table talk. W = the mover ("you" or a name), pos = "your"/"Jamie's", opp = the other. */
function said(o, p, W, pos, opp) {
  const parts = [];
  const X = it(o);
  for (const f of o.facts) {
    if (f.k === "trump") parts.push(html`${X} trumps the ${T(f.led)} and takes ${f.pts} points`);
    else if (f.k === "take") parts.push(html`${X} takes the trick (${f.pts} points) and the lead`);
    else if (f.k === "dear") parts.push(html`but it spends ${X} where ${T(f.cheaper)} takes it just as well`);
    else if (f.k === "wasteTrump") parts.push(html`but it spends ${f.top ? "one of " + pos + " best trumps" : "a trump"} where ${T(f.alt)} takes it without one`);
    else if (f.k === "give") parts.push(f.could ? html`${X} lets ${opp} have the trick (${f.pts} points) when ${W} could take it` : html`${X} lets ${opp} have the trick (${f.pts} points)`);
    else if (f.k === "throw") parts.push(html`and throws ${T(o.card)}'s ${o.card.rank === "A" ? 11 : 10} points onto it`);
    else if (f.k === "leadTrump") parts.push(html`leading the trump ${X} draws one of ${opp}'s trumps`);
    else if (f.k === "leadAce") parts.push(html`leading ${X} cashes the ace now, while only a trump can take it`);
    else if (f.k === "bareTen") parts.push(html`${X} goes out while the ace of ${SUITW[o.card.suit]} is still unseen, so ${opp} can take it`);
    else if (f.k === "cheapLead") parts.push(html`${X} is a cheap lead: it costs little whoever takes it`);
    else if (f.k === "noDeclare") parts.push(html`leading it without declaring throws away the ${f.value} for the marriage`);
    else if (f.k === "breaks") parts.push(html`and it breaks up ${pos} marriage in ${SUITW[o.card.suit]}, worth ${f.value}`);
    else if (f.k === "declare") parts.push(html`declaring banks ${f.value}${f.counts ? "" : " (it counts once a trick is won)"} and still leads ${T(o.card)}`);
    else if (f.k === "swap") parts.push(html`swapping takes the ${T(f.up)} for ${pos} lowest trump`);
    else if (f.k === "close") parts.push(html`closing stops the drawing with ${opp} on ${f.them}${f.them < 33
      ? html`: if ${W} ${W === "you" ? "make" : "makes"} 66, ${opp} is caught under 33 and the win counts double${f.shut ? " (triple, with no trick yet)" : ""}` : ""}, and from here every card must follow suit`);
  }
  return parts.length ? html`${parts.map((x, i) => html`${i ? " " : ""}${x}`)}.` : null;
}

/* How the two played out differently, across all the ways the hidden cards could lie. */
function differ(w, p, W, pos, opp) {
  const B = it(p.best), C = it(p.chosen);
  if (w.k === "lead") return html`After ${B}, ${W} ${W === "you" ? "win" : "wins"} the next trick ${freq(w.pb)} (and lead${W === "you" ? "" : "s"}, and draw${W === "you" ? "" : "s"} first); after ${C}, ${freq(w.pc)}.`;
  if (w.k === "exposed") return html`After ${C}, ${pos} ${T(w.card)} ends up in ${opp}'s tricks ${freq(w.pc)}; after ${B}, ${freq(w.pb)}.`;
  if (w.k === "marriage") return html`${W === "you" ? "You get" : `${W} gets`} to declare the ${w.value} in ${SUITW[w.suit]} ${freq(w.pb)} after ${B}, but ${freq(w.pc)} after ${C}.`;
  if (w.k === "oppMarriage") return html`After ${C}, ${opp} gets to show a marriage more often.`;
  if (w.k === "trumps") return html`After ${B}, ${W} ${W === "you" ? "come" : "comes"} into the endgame with more trumps.`;
  if (w.k === "oppTrumps") return html`After ${B}, ${opp} is left with fewer trumps for the endgame.`;
  return null;
}

/* With every card known, how it goes from here (both sides at their best). */
function story(o, p, nm) {
  const l = o.line;
  if (!l || !l.end) return null;
  const n = l.tricks.length, mine = l.tricks.filter(x => x.winner === p.seat).length;
  const W = nm(p.seat), O = nm(1 - p.seat), e = l.end;
  const share = !n ? "" : mine === n ? `${W} ${W === "you" ? "take" : "takes"} ${n === 1 ? "the trick" : `all ${n} tricks`}` : mine === 0 ? `${O} ${O === "you" ? "takes" : "takes"} ${n === 1 ? "the trick" : `all ${n} tricks`}`.replace("you takes", "you take")
    : `${W} ${W === "you" ? "take" : "takes"} ${mine} of the ${n} tricks`;
  const how = e.reason === "claim" ? `${nm(e.winner)} ${nm(e.winner) === "you" ? "reach" : "reaches"} 66`
    : e.scoreless ? "nobody reaches 66"
    : e.reason === "closedOut" ? (e.winner === p.seat ? "the close comes home" : "the close fails")
    : `${nm(e.winner)} ${nm(e.winner) === "you" ? "take" : "takes"} the last trick and the deal`;
  return html`After ${it(o)}, ${share}${share ? " and " : ""}${how}.`;
}

function odds(p, nm) {
  const b = p.best, c = p.chosen, W = nm(p.seat), O = nm(1 - p.seat);
  const B = it(b), C = it(c);
  if (Math.abs(b.win - c.win) >= 0.1)
    return html`All told, ${W} ${W === "you" ? "win" : "wins"} the deal ${freq(b.win)} after ${B}, and ${freq(c.win)} after ${C}.`;
  if (b.big - c.big >= 0.15)
    return html`Both usually end the same way, but after ${B} ${W} ${W === "you" ? "win" : "wins"} it with ${O} under 33 (a double) ${freq(b.big)}, after ${C} only ${freq(c.big)}.`;
  if (c.bigLoss - b.bigLoss >= 0.15)
    return html`After ${C}, ${W} ${W === "you" ? "lose" : "loses"} it heavily ${freq(c.bigLoss)}; after ${B}, ${freq(b.bigLoss)}.`;
  return null;
}

function Point({ p, name }) {
  const nm = i => (name(i) === "You" ? "you" : name(i));
  const who = name(p.seat), W = nm(p.seat), O = nm(1 - p.seat);
  const pos = W === "you" ? "your" : `${W}'s`;
  const b = p.best, c = p.chosen;
  const marks = id => (c.card && c.card.id === id ? " rv-chose" : "") + (b.card && b.card.id === id ? " rv-best" : "");
  const sb = said(b, p, W, pos, O), sc = said(c, p, W, pos, O);
  const diffs = p.why.map(w => differ(w, p, W, pos, O)).filter(Boolean);
  const end = p.certain ? [story(b, p, nm), story(c, p, nm)].filter(Boolean) : [odds(p, nm)].filter(Boolean);
  const size = p.loss >= 1 ? "A big one" : p.loss >= 0.6 ? "A clear one" : "A small one";
  return html`<li class="rv-pt">
    <p class="rv-when">${`Trick ${p.trick} · ${who} ${p.lead ? "on lead" : "to follow"} · ${W} on ${p.me}, ${O} on ${p.them} · `}${p.trump ? html`trumps <${Suit} s=${p.trump}/>` : "no trumps"}${p.closed ? " · closed" : p.stock ? ` · ${p.stock} left to draw` : ""}</p>
    <p class="rv-what">${who} ${did(c, p)}. <span class="nw">Better: ${todo(b, p)}.</span></p>
    <div class="rv-hand" aria-label=${`${who === "You" ? "Your" : who + "'s"} hand`}>${p.hand.map(x => html`<span key=${x.id} class=${"rv-c" + marks(x.id)}>${T(x)}</span>`)}</div>
    ${sb && html`<p class="rv-why"><b class="rv-k">Better</b> ${sb}</p>`}
    ${sc && html`<p class="rv-why"><b class="rv-k">Instead</b> ${sc}</p>`}
    ${diffs.map((x, i) => html`<p key=${i} class="rv-why">${x}</p>`)}
    ${end.map((x, i) => html`<p key=${"e" + i} class="rv-why">${x}</p>`)}
    <p class="rv-cost">${size}${p.certain ? ", and a sure thing: every card was known by then." : "."}</p>
  </li>`;
}
