import { html, useState } from "../../vendor/preact.js";
import { Seg } from "./bits.js";

/* The rules sheet opens on the rules the table is playing; the other set is one tap away. */
export function Rules({ house = true }) {
  const [which, setWhich] = useState(house ? "house" : "classic");
  return html`<div class="rules">
    <${Seg} label="Which rules" value=${which} opts=${[{ v: "house", l: "House" }, { v: "classic", l: "Classic" }]} onPick=${setWhich}/>
    ${which === "house" ? html`<${House}/>` : html`<${Classic}/>`}
  </div>`;
}

function House() {
  return html`
    <p>Two players, twenty cards: A, 10, 4, 3 and 2 of each suit. Every card is worth what it says, and an Ace is 11, which makes 120 in the pack. First to <b>66</b> in a deal goes out.</p>
    <h3>The deal</h3>
    <p>Five cards to the player who isn't dealing, then five to the dealer. The next card is turned up, and the rest of the stock lies across it. The deal alternates.</p>
    <h3>Trumps</h3>
    <p>The turned card names trumps. The turned card is the last card drawn.</p>
    <p>On your lead, while the stock is open, you may swap the 2 of trumps for the turned card.</p>
    <h3>Playing</h3>
    <p>While the stock is open you may play any card. Once it's empty or closed, you must follow suit, beat the card led if you can, and trump if you can't follow.</p>
    <h3>Marriages</h3>
    <p>The 4 and 3 of one suit. Declare them when you lead one: 17 points, or 34 in trumps (the 3 and 4 of trumps make 34). They count once you've won a trick, and you may still declare after closing.</p>
    <h3>Won cards</h3>
    <p>Each player sorts what they win into five face-up piles, one per rank, fanned so every card shows. Both scores are public all game. A table can agree to keep won cards face down instead.</p>
    <h3>Closing</h3>
    <p>On your lead you may close the stock: no more drawing, strict rules from now on, and you must reach 66 yourself. Made, you score by where your opponent stood when you closed. Failed, they score 2, or 3 if they had no tricks then.</p>
    <h3>Scoring</h3>
    <p>Going out pays <b>1</b> if the loser has 33 or more, <b>2</b> if they have less but took a trick, <b>3</b> if they took none. Calling 66 without it pays your opponent 2, or 3 if they had no trick.</p>
    <p><b>No 66, no score.</b> If the cards run out and nobody went out, nobody scores. That deal adds 1 to the pot. Pots stack, and whoever scores the next deal takes the whole pot on top of their points.</p>
    <p>Count up from 0. First to 7, or whatever you agreed, wins the Bummerl.</p>`;
}

function Classic() {
  return html`
    <p>Two players, twenty cards: A, 10, K, Q and J of each suit. They're worth 11, 10, 4, 3 and 2, which makes 120 in the deck. First to <b>66</b> in a deal wins it.</p>
    <h3>Playing</h3>
    <p>You hold five cards. The next card turned up sets trumps and sits under the stock. The winner of each trick draws first, then the loser.</p>
    <p>While the stock is open you may play any card. Once it's empty or closed, you must follow suit, beat the card led if you can, and trump if you can't follow.</p>
    <h3>Marriages</h3>
    <p>Holding the K and Q of a suit, declare them when you lead one: 20 points, or 40 in trumps. They only count once you've won a trick.</p>
    <h3>The turn-up and closing</h3>
    <p>On your lead you may swap the trump jack for the turn-up. You may also <b>close</b> the stock: no more drawing, strict rules from now on, and you must reach 66 yourself.</p>
    <h3>Scoring a deal</h3>
    <p>3 game points if the loser took no tricks, 2 if they have under 33, otherwise 1. A failed close pays the other side 2, or 3 if they had no tricks when you closed. If the cards run out with nobody on 66, the last trick takes the deal for 1. The first to 7 game points wins the <b>Bummerl</b>.</p>
}
