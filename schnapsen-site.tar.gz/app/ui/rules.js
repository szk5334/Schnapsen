import { html } from "../../vendor/preact.js";

export function Rules() {
  return html`<div class="rules">
    <p>Two players, twenty cards: A, 10, K, Q and J of each suit. They're worth 11, 10, 4, 3 and 2, which makes 120 in the deck. First to <b>66</b> in a deal wins it.</p>
    <h3>Playing</h3>
    <p>You hold five cards. The next card turned up sets trumps and sits under the stock. The winner of each trick draws first, then the loser.</p>
    <p>While the stock is open you may play any card. Once it's empty or closed, you must follow suit, beat the card led if you can, and trump if you can't follow.</p>
    <h3>Marriages</h3>
    <p>Holding the K and Q of a suit, declare them when you lead one: 20 points, or 40 in trumps. They only count once you've won a trick.</p>
    <h3>The turn-up and closing</h3>
    <p>On your lead you may swap the trump jack for the turn-up. You may also <b>close</b> the stock: no more drawing, strict rules from now on, and you must reach 66 yourself.</p>
    <h3>Scoring a deal</h3>
    <p>3 game points if the loser took no tricks, 2 if they have under 33, otherwise 1. A failed close pays the other side 2, or 3 if they had no tricks when you closed. The first to 7 game points wins the <b>Bummerl</b>.</p>
    <p class="muted">With 24 cards, the four nines are added, worth nothing, and the trump nine swaps for the turn-up.</p>
  </div>`;
}
