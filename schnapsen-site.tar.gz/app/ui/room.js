import { html, useState, useEffect, useMemo } from "../../vendor/preact.js";
import { useCell, go } from "./hooks.js";
import { ChatPanel, ChatDrawer } from "./chat.js";
import { Avatar, Sheet, Seg } from "./bits.js";
import { Game, Watch, DealLog, ScoreLine } from "./game.js";
import { Rules } from "./rules.js";
import { PROFILES, ALL_BRAINS, who } from "../../schnapsen/state/personas.js";
import { openTable, openSolo } from "../session.js";
import { me, prefs } from "../ident.js";
import { BigToggle } from "./bits.js";
import { LS } from "../util.js";
import { RULESETS, rulesetOf } from "../house.js";

/* ================================================================== a table (online) */
export function TableScreen({ hub, code }) {
  const sess = useMemo(() => openTable(hub, code), [code]);
  useEffect(() => () => sess.leave(), [sess]);
  const st = useCell(sess.state);
  const chat = useCell(sess.chat);
  const w = useCell(me);
  const [menu, setMenu] = useState(false);
  const [sheet, setSheet] = useState(null);
  /* The deal this player has on screen (remembered across a reload). */
  const lookKey = "sx.look." + code, mid = st.table && st.table.matchId;
  const [lookS, setLookS] = useState(() => LS.get(lookKey));
  const look = lookS && lookS.m === mid ? lookS.n : null;          // only for this game at this table
  const setLook = n => { const x = { m: mid, n }; LS.set(lookKey, x); setLookS(x); };
  const vv = st.view;
  useEffect(() => {
    if (!vv) return;
    const held = vv.last && look != null && vv.last.n === look && vv.n > look;
    if (!held && look !== vv.n) setLook(vv.n);              // first visit, a new game, or more than a deal behind
  }, [vv && vv.n, vv && vv.last && vv.last.n, look]);
  useEffect(() => { if (look != null) sess.look(look); }, [look]);

  const leave = () => go("/");
  const share = async () => {
    const url = location.origin + location.pathname + "#/t/" + code;
    try { if (navigator.share) { await navigator.share({ title: "Schnapsen", text: `Join my table: ${code}`, url }); return; } } catch { return; }
    try { await navigator.clipboard.writeText(url); setSheet("copied"); setTimeout(() => setSheet(null), 1400); } catch {}
  };

  if (st.closed || st.kicked) return html`<div class="screen center"><p>${st.kicked ? "The table's owner gave your seat to someone else." : st.closed}</p><button class="btn primary" onClick=${leave}>Back to the lobby</button></div>`;
  if (!st.found) return html`<div class="screen center">
    ${st.lost
      ? html`<p>Couldn't find table <b>${code}</b>. Whoever opened it may have left, or the code is wrong.</p>`
      : html`<p class="pulse">Looking for table <b>${code}</b>…</p>`}
    <button class="btn" onClick=${leave}>Back to the lobby</button></div>`;

  const t = st.table;
  const owner = sess.owner;
  const seated = st.seat >= 0;
  const playing = t.status === "playing";
  const v = st.view;
  const opp = seated ? t.seats[1 - st.seat] : null;
  /* A player stays on the deal they're looking at until they choose to move on: the other pressing "Next deal"
   * doesn't pull them off the table or the score. `held` = the live deal is newer than the one on screen. */
  const held = !!(v && v.last && look != null && v.last.n === look && v.n > look);

  const s = held ? v.last.s : v && v.s;
  const head = html`<header class="bar">
    <button class="nav-back" onClick=${leave} aria-label="Back to the lobby">Lobby</button>
    <span class="tcode" aria-label="Table code">${code}</span>
    ${!playing && html`<button class="btn ghost" onClick=${share}>Invite</button>`}
    ${playing && s && html`<span class="score" aria-label="Game points">${s.gp[st.seat]}–${s.gp[1 - st.seat]} <small>of ${s.target}</small></span>`}
    <button class="btn ghost" onClick=${() => setMenu(true)} aria-label="Menu">Menu</button>
  </header>`;

  const menuSheet = menu && html`<${Sheet} title="Table" onClose=${() => setMenu(false)}>
    <div class="menu">
      ${s && html`<button class="row" onClick=${() => { setMenu(false); setSheet("log"); }}>Deal log</button>`}
      ${s && html`<button class="row" onClick=${() => { setMenu(false); setSheet("score"); }}>Score sheet</button>`}
      <button class="row" onClick=${() => { setMenu(false); setSheet("rules"); }}>Rules</button>
      <${BigToggle}/>
      <${FacesToggle}/>
      ${!t.opts.house && html`<${MemoryToggle}/>`}
      ${owner && playing && html`<button class="row" onClick=${() => { setMenu(false); sess.toSeats(); }}>End the game, back to the seats</button>`}
      ${!owner && seated && !playing && html`<button class="row" onClick=${() => { setMenu(false); sess.stand(); }}>Give up my seat</button>`}
      ${owner && html`<button class="row danger" onClick=${() => { sess.close(); go("/"); }}>Close the table</button>`}
    </div><//>`;
  const extra = sheet === "log" && s ? html`<${Sheet} title="This deal" onClose=${() => setSheet(null)}><${DealLog} s=${s}/><//>`
    : sheet === "score" && s ? html`<${Sheet} title="Score sheet" onClose=${() => setSheet(null)}><${ScoreLine} s=${s} seat=${st.seat} name=${i => (i === st.seat ? "You" : who(s, i))}/><//>`
    : sheet === "rules" ? html`<${Sheet} title="Rules" onClose=${() => setSheet(null)}><${Rules} which=${rulesetOf(t.opts)}/><//>`
    : sheet === "copied" ? html`<div class="toast" role="status">Invite link copied</div>` : null;

  if (playing && seated) {
    const wait = held ? null
      : v && v.error ? (/older version/.test(v.error) ? v.error : "This deal can't continue. End the game from the menu and deal again.")
      : !v || v.shuffling || v.waitingCards ? "Dealing…"
      : null;
    const gs = s;
    const au = held ? v.last.audit : v && v.audit;
    const record = au && au.ok && au.d0 ? { d0: au.d0, moves: au.moves } : null;
    const act = a => {
      if ((a.type === "NEXT_DEAL" || a.type === "NEW_BUMMERL" || a.type === "DUPLICATE_DEAL") && v) setLook(v.n + 1);
      sess.act(a);
    };
    const lingering = !held && v && st.oppLook != null && st.oppLook < v.n ? [1 - st.seat] : [];
    return html`<div class="screen play">
      ${head}
      ${!st.oppHere && html`<p class="banner">${opp.name} stepped away.</p>`}
      ${gs ? html`<${Game} s=${gs} seat=${st.seat} act=${act} seats=${t.seats} down=${st.oppHere ? [] : [1 - st.seat]} canDeal=${true} wait=${wait}
                    audit=${au} rejoin=${held ? () => setLook(v.n) : null} lingering=${lingering} record=${record}/>`
          : html`<div class="game"><p class="status pulse pad">${wait}</p></div>`}
      <${ChatDrawer} chat=${chat}/>
      ${menuSheet}${extra}
    </div>`;
  }

  const both = t.seats.every(Boolean);
  return html`<div class="screen room">
    ${head}
    ${!st.ownerHere && !owner && html`<p class="banner">${(t.seats[0] || {}).name || "The host"} stepped away.</p>`}
    <section class="seatsbox" aria-label="Seats">
      ${t.seats.map((x, i) => html`<div key=${i} class=${"seat" + (x && x.cid === w.cid ? " you" : "")}>
        ${x ? html`<${Avatar} p=${x}/><b>${x.cid === w.cid ? "You" : x.name}</b>
                 ${x.cid === t.ownerCid ? html`<small>Opened the table</small>` : owner && !playing && html`<button class="link" onClick=${() => sess.kick(x.cid)}>Remove</button>`}`
            : html`<span class="av empty"></span><span class="muted">Empty seat</span>
                 ${!seated && !owner && !playing && html`<button class="btn primary" onClick=${() => sess.sit(i)}>Sit here</button>`}`}
      </div>`)}
    </section>

    ${playing
      ? html`<${Watch} pub=${st.pub} seats=${t.seats}/>`
      : owner ? html`<${HostOptions} t=${t} sess=${sess} ready=${both}/>`
      : html`<p class="muted pad">${seated ? `Waiting for ${(t.seats[0] || {}).name || "the other player"} to deal.` : "Take the empty seat to play, or stay and watch."}</p>`}

    <${ChatPanel} chat=${chat} placeholder="Message the table" empty="Nothing said yet."/>
    ${menuSheet}${extra}
  </div>`;
}

/* The rules a table plays by: Classic (20 cards), House (20 cards, Seth's rules) or Royal House (32 cards). */
const NOTES = {
  classic: "Schnapsen as the coffee houses play it.",
  house: "Marriages 17, or 34 in trumps. No 66, no score: the deal goes into the pot.",
  royal: "32 cards, race to 200. Free play, then follow suit, then strict. Two marriages a suit, and the double.",
};
function GameOpts({ o, set }) {
  const rs = rulesetOf(o);
  return html`
    <div class="opt"><span>Rules</span><${Seg} label="Rules" value=${rs} opts=${[{ v: "classic", l: "Classic" }, { v: "house", l: "House" }, { v: "royal", l: "Royal House" }]} onPick=${v => set({ ...RULESETS[v] })}/></div>
    ${o.house && html`<div class="opt"><span>Won cards</span><${Seg} label="Won cards" value=${o.piles === "down" ? "down" : "up"} opts=${[{ v: "up", l: "Face up" }, { v: "down", l: "Face down" }]} onPick=${v => set({ piles: v })}/></div>`}
    <div class="opt"><span>Play to</span><${Seg} label="Play to" value=${o.target} opts=${[{ v: 7, l: "7" }, { v: 11, l: "11" }]} onPick=${v => set({ target: v })}/></div>
    <div class="opt"><span>Reaching ${rs === "royal" ? 200 : 66}</span><${Seg} label="Claiming" value=${!!o.strict} opts=${[{ v: false, l: "Automatic" }, { v: true, l: "You declare" }]} onPick=${v => set({ strict: v })}/></div>
    <p class="optnote">${NOTES[rs]}</p>`;
}

function HostOptions({ t, sess, ready }) {
  const o = t.opts;
  return html`<section class="opts" aria-label="Game options">
    <${GameOpts} o=${o} set=${p => sess.setOpts(p)}/>
    <div class="opt"><span>Listed in the lobby</span><${Seg} label="Listed" value=${!o.private} opts=${[{ v: true, l: "Yes" }, { v: false, l: "Invite only" }]} onPick=${v => sess.setOpts({ private: !v })}/></div>
    <button class="btn primary wide" disabled=${!ready} onClick=${() => sess.start()}>${ready ? "Deal" : "Waiting for a second player"}</button>
  </section>`;
}

function FacesToggle() {
  const p = useCell(prefs);
  const cyano = p.faces === "cyano";
  return html`<button class="row" onClick=${() => prefs.set(v => ({ ...v, faces: cyano ? "print" : "cyano" }))}>
    Card faces<span class="sw">${cyano ? "Sun print" : "Wallpaper"}</span></button>`;
}

function MemoryToggle() {
  const p = useCell(prefs);
  return html`<button class="row" role="switch" aria-checked=${p.memory} onClick=${() => prefs.set(v => ({ ...v, memory: !v.memory }))}>
    Hide their running score<span class="sw">${p.memory ? "On" : "Off"}</span></button>`;
}

/* ================================================================== you vs a bot */
export function SoloScreen() {
  const saved = LS.get("sx.solo");
  const fresh = bot => ({ bot, ...(LS.get("sx.soloOpts") || { house: true, piles: "up", variant: "classic", target: 7, strict: false }) });
  const [opts, setOpts] = useState(saved && saved.mode === "play" ? null : fresh("fritzl"));
  if (opts && !opts.go) return html`<${SoloSetup} o=${opts} set=${setOpts}/>`;
  return html`<${SoloGame} opts=${opts} onNew=${() => setOpts(fresh((saved && saved.brains && saved.brains[1]) || "fritzl"))}/>`;
}

function SoloSetup({ o, set }) {
  return html`<div class="screen room">
    <header class="bar"><button class="nav-back" onClick=${() => go("/")}>Lobby</button><span class="tcode">Against a bot</span></header>
    <section class="bots" aria-label="Opponent">
      ${ALL_BRAINS.map(b => html`<button key=${b} class=${"bot" + (o.bot === b ? " on" : "")} aria-pressed=${o.bot === b} onClick=${() => set({ ...o, bot: b })}>
        <b>${PROFILES[b].name}</b><span>${PROFILES[b].blurb}</span></button>`)}
    </section>
    <section class="opts">
      <${GameOpts} o=${o} set=${p => set({ ...o, ...p })}/>
      <button class="btn primary wide" onClick=${() => { const { bot, go, ...keep } = o; LS.set("sx.soloOpts", keep); set({ ...o, go: true }); }}>Deal</button>
    </section>
  </div>`;
}

function SoloGame({ opts, onNew }) {
  const sess = useMemo(() => openSolo(opts ? { ...opts, fresh: true } : {}), []);
  useEffect(() => () => sess.leave(), [sess]);
  const st = useCell(sess.state);
  const [menu, setMenu] = useState(false);
  const [sheet, setSheet] = useState(null);
  const s = st.s;
  if (!s) return null;
  const name = i => (i === 0 ? "You" : who(s, i));
  return html`<div class="screen play">
    <header class="bar">
      <button class="nav-back" onClick=${() => go("/")}>Lobby</button>
      <span class="tcode">${who(s, 1)}</span>
      <span class="score" aria-label="Game points">${s.gp[0]}–${s.gp[1]} <small>of ${s.target}</small></span>
      <button class="btn ghost" onClick=${() => setMenu(true)}>Menu</button>
    </header>
    <${Game} s=${s} seat=${0} act=${sess.act} canDeal=${true} record=${st.rec}/>
    ${menu && html`<${Sheet} title="Game" onClose=${() => setMenu(false)}><div class="menu">
      <button class="row" onClick=${() => { setMenu(false); setSheet("log"); }}>Deal log</button>
      <button class="row" onClick=${() => { setMenu(false); setSheet("score"); }}>Score sheet</button>
      <button class="row" onClick=${() => { setMenu(false); setSheet("rules"); }}>Rules</button>
      <${BigToggle}/>
      <${FacesToggle}/>
      ${!s.house && html`<${MemoryToggle}/>`}
      <button class="row" onClick=${() => { setMenu(false); LS.del("sx.solo"); onNew(); }}>New game</button>
    </div><//>`}
    ${sheet === "log" && html`<${Sheet} title="This deal" onClose=${() => setSheet(null)}><${DealLog} s=${s}/><//>`}
    ${sheet === "score" && html`<${Sheet} title="Score sheet" onClose=${() => setSheet(null)}><${ScoreLine} s=${s} seat=${0} name=${name}/><//>`}
    ${sheet === "rules" && html`<${Sheet} title="Rules" onClose=${() => setSheet(null)}><${Rules} which=${rulesetOf(s)}/><//>`}
  </div>`;
}
