import { useState, useEffect } from "../../vendor/preact.js";

/* Subscribe a component to a cell (see util.js). */
export function useCell(c) {
  const [v, setV] = useState(() => (c ? c.get() : null));
  useEffect(() => { if (!c) { setV(null); return; } setV(c.get()); return c.sub(setV); }, [c]);
  return v;
}

/* Re-render on a timer — for relative times and typing indicators. */
export function useTick(ms) {
  const [, set] = useState(0);
  useEffect(() => { const t = setInterval(() => set(n => n + 1), ms); return () => clearInterval(t); }, [ms]);
}

/* #/            lobby
 * #/t/ABCD      a table
 * #/solo        you against a bot */
export function parseHash() {
  const h = (location.hash || "").replace(/^#\/?/, "");
  const m = h.match(/^t\/([A-Za-z]{3,6})/);
  if (m) return { view: "table", code: m[1].toUpperCase() };
  if (h.startsWith("solo")) return { view: "solo" };
  if (h.startsWith("net")) return { view: "net" };
  return { view: "lobby" };
}
export function useRoute() {
  const [r, setR] = useState(parseHash);
  useEffect(() => { const f = () => setR(parseHash()); addEventListener("hashchange", f); return () => removeEventListener("hashchange", f); }, []);
  return r;
}
export const go = path => { location.hash = path; };

/* Keep the screen on while a game is showing. A phone that dims and sleeps mid-deal drops its relay
 * connections; this asks the browser to hold the screen on. The browser lets go whenever the page is hidden,
 * so it is asked again each time the page comes back. Silently does nothing where unsupported or refused. */
export function useWakeLock(on = true) {
  useEffect(() => {
    if (!on || typeof navigator === "undefined" || !navigator.wakeLock) return;
    let lock = null, done = false;
    const grab = async () => {
      if (done || document.visibilityState !== "visible" || (lock && !lock.released)) return;
      try { lock = await navigator.wakeLock.request("screen"); if (done) lock.release().catch(() => {}); } catch {}
    };
    const vis = () => { if (document.visibilityState === "visible") grab(); };
    grab();
    document.addEventListener("visibilitychange", vis);
    return () => { done = true; document.removeEventListener("visibilitychange", vis); if (lock) lock.release().catch(() => {}); };
  }, [on]);
}
