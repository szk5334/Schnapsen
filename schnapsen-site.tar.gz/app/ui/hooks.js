import { useState, useEffect } from "../../vendor/preact.js";

/* Subscribe a component to a cell (see util.js). */
export function useCell(c) {
  const [v, setV] = useState(() => (c ? c.get() : null));
  useEffect(() => { if (!c) { setV(null); return; } setV(c.get()); return c.sub(setV); }, [c]);
  return v;
}

/* Re-render on a timer — for relative times and typing indicators. */
export function useTick(ms) {
  const [, set] = useState(0);
  useEffect(() => { const t = setInterval(() => set(n => n + 1), ms); return () => clearInterval(t); }, [ms]);
}

/* #/            lobby
 * #/t/ABCD      a table
 * #/solo        you against a bot */
export function parseHash() {
  const h = (location.hash || "").replace(/^#\/?/, "");
  const m = h.match(/^t\/([A-Za-z]{3,6})/);
  if (m) return { view: "table", code: m[1].toUpperCase() };
  if (h.startsWith("solo")) return { view: "solo" };
  return { view: "lobby" };
}
export function useRoute() {
  const [r, setR] = useState(parseHash);
  useEffect(() => { const f = () => setR(parseHash()); addEventListener("hashchange", f); return () => removeEventListener("hashchange", f); }, []);
  return r;
}
export const go = path => { location.hash = path; };
