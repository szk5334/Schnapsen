import { html } from "../../vendor/preact.js";
import { useCell, useRoute } from "./hooks.js";
import { NameSheet } from "./bits.js";
import { Lobby } from "./lobby.js";
import { TableScreen, SoloScreen } from "./room.js";
import { NetPage } from "./net.js";
import { me } from "../ident.js";

export function App({ hub }) {
  const w = useCell(me);
  const r = useRoute();
  if (!w.name) return html`<${NameSheet} first/>`;
  if (r.view === "table") return html`<${TableScreen} key=${r.code} hub=${hub} code=${r.code}/>`;
  if (r.view === "solo") return html`<${SoloScreen}/>`;
  if (r.view === "net") return html`<${NetPage} hub=${hub}/>`;
  return html`<${Lobby} hub=${hub}/>`;
}
