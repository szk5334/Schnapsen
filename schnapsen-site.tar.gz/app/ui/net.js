import { html } from "../../vendor/preact.js";
import { useCell, useTick, go } from "./hooks.js";

/* Hidden connection page — #/net. Not linked from anywhere; open it on both phones to see which relays
 * each can reach, who each has heard from in each room, and anything a relay refused. */
export function NetPage({ hub }) {
  useTick(1000);
  const here = useCell(hub.here) || [];
  const d = hub.p2p.diag ? hub.p2p.diag() : null;
  const dot = st => html`<span class=${"nd " + st}>${st}</span>`;
  return html`<div class="screen netpage">
    <header class="bar"><button class="nav-back" onClick=${() => go("/")}>Lobby</button><span class="tcode">Connection</span></header>
    ${!d ? html`<p class="pad">Local test mode.</p>` : html`
      <section class="pad">
        <p>This page: <code>${d.selfId}</code>${d.sentKB != null ? html`<br/>Sent so far: ${d.sentKB} KB` : ""}</p>
        ${Object.entries(d.sockets).map(([k, socks]) => html`<h3>${k}</h3>
          <ul class="nl">${Object.keys(socks).length ? Object.entries(socks).map(([u, st]) => html`<li>${dot(st)} ${u.replace("wss://", "")}</li>`) : html`<li class="muted">no sockets yet</li>`}</ul>`)}
        <h3>Rooms</h3>
        <ul class="nl">${Object.entries(d.rooms).map(([r, peers]) => html`<li><b>${r}</b>: ${peers.length ? peers.map(p => `${p.peer.slice(0, 6)}${p.via.length ? " via " + p.via.join(", ") : ""}`).join("; ") : "nobody else"}</li>`)}</ul>
        <h3>People in the lobby</h3>
        <ul class="nl">${here.map(p => html`<li>${p.self ? "you" : p.name}${p.hosting ? ` (table ${p.hosting.code})` : ""}</li>`)}</ul>
        <h3>Relay notes</h3>
        <ul class="nl">${d.errors.length ? d.errors.slice().reverse().map(e => html`<li>${new Date(e.at).toLocaleTimeString()} ${e.via} ${e.room}: ${e.error}${e.n > 1 ? ` (×${e.n})` : ""}</li>`) : html`<li class="muted">none</li>`}</ul>
      </section>`}
  </div>`;
}
