import { html, useState } from "../../vendor/preact.js";
import { useCell, useTick, go } from "./hooks.js";
import { BUILD } from "../version.js";
import { CANDIDATE_RELAYS, checkRelay, verdict } from "../net/relay.js";

/* Hidden connection page — #/net. Not linked from anywhere. Open it on both phones: the build line must
 * match, and each phone shows which relays it is using, which ones it has set aside and why, and who it
 * has heard from. "Check relays" test-posts to every candidate relay from this phone. */
export function NetPage({ hub }) {
  useTick(1000);
  const here = useCell(hub.here) || [];
  const d = hub.p2p.diag ? hub.p2p.diag() : null;
  const dot = st => html`<span class=${"nd " + st}>${st}</span>`;
  return html`<div class="screen netpage">
    <header class="bar"><button class="nav-back" onClick=${() => go("/")}>Lobby</button><span class="tcode">Connection</span></header>
    <section class="pad">
      <p>Build <b>${BUILD}</b><br/><small class="muted">Both phones should show the same build. If not, reload the older one (pull down, or clear the site's data).</small></p>
      ${!d ? html`<p>Local test mode (?local): no relays.</p>` : html`
        <p>This page: <code>${d.selfId}</code><br/>Sent so far: ${d.sentKB} KB${d.queued ? html` · <b>${d.queued}</b> waiting for a relay with budget` : ""}</p>
        <h3>Relays</h3>
        <ul class="nl">${(d.relays || []).map(r => html`<li>${dot(r.state)} ${r.url.replace(/^wss?:\/\//, "")}${r.name && r.name !== r.url.replace(/^wss?:\/\//, "") ? html` <small class="muted">${r.name}</small>` : ""}
          <small class="muted"> · ${r.events} sent · budget ${r.budget}/10</small>${r.why ? html`<br/><small>${r.why}</small>` : ""}</li>`)}</ul>
        <h3>Rooms</h3>
        <ul class="nl">${Object.entries(d.rooms).map(([r, peers]) => html`<li><b>${r}</b>: ${peers.length ? peers.map(p => `${p.peer.slice(0, 6)}${p.via.length ? " via " + p.via.join(", ") : ""}`).join("; ") : "nobody else"}</li>`)}</ul>
        <h3>People in the lobby</h3>
        <ul class="nl">${here.map(p => html`<li>${p.self ? "you" : p.name}${p.hosting ? ` (table ${p.hosting.code})` : ""}</li>`)}</ul>
        <h3>Relay notes</h3>
        <ul class="nl">${d.errors.length ? d.errors.slice().reverse().map(e => html`<li>${new Date(e.at).toLocaleTimeString()} ${e.room.replace(/^wss?:\/\//, "")}: ${e.error}${e.n > 1 ? ` (×${e.n})` : ""}</li>`) : html`<li class="muted">none</li>`}</ul>
        <${Checker} current=${(d.relays || []).map(r => r.url)}/>`}
    </section>
  </div>`;
}

/* Test every candidate relay from this phone, three at a time, and offer the ones that work as a list. */
function Checker({ current }) {
  const [rows, setRows] = useState(null);
  const [busy, setBusy] = useState(false);
  const list = [...new Set(current.concat(CANDIDATE_RELAYS))];
  const run = async () => {
    setBusy(true);
    const res = {}; setRows({});
    let i = 0;
    const worker = async () => { while (i < list.length) { const u = list[i++]; res[u] = { url: u, pending: true }; setRows({ ...res }); const r = await checkRelay(u); res[u] = { ...r, v: verdict(r) }; setRows({ ...res }); } };
    await Promise.all([worker(), worker(), worker()]);
    setBusy(false);
  };
  const good = rows ? list.filter(u => rows[u] && rows[u].v && rows[u].v.ok) : [];
  const snippet = `window.SX_CONFIG = { relays: ${JSON.stringify(good.slice(0, 8), null, 1).replace(/\n\s*/g, " ")} };`;
  return html`<h3>Check relays</h3>
    <p><small class="muted">Posts two test events to each relay from this phone and checks they come back. Run it on both phones; use relays that say Yes on both.</small></p>
    <button class="btn" disabled=${busy} onClick=${run}>${busy ? "Checking…" : rows ? "Check again" : "Check relays"}</button>
    ${rows && html`<ul class="nl chk">${list.map(u => { const r = rows[u]; return html`<li>
      <b>${u.replace(/^wss?:\/\//, "")}</b> ${!r ? html`<small class="muted">waiting</small>` : r.pending ? html`<small class="muted">checking…</small>` : html`<span class=${r.v.ok ? "yes" : "no"}>${r.v.text}</span>`}
      ${r && r.rules && r.rules.software ? html`<br/><small class="muted">${r.rules.software.replace(/^.*\//, "")}${Object.keys(r.rules.limitation || {}).length ? " · " + Object.entries(r.rules.limitation).map(([k, v]) => k + " " + v).join(", ") : ""}</small>` : ""}</li>`; })}</ul>`}
    ${rows && !busy && html`<p><small>${good.length} of ${list.length} work from this phone.${good.length ? " For config.js (repo root), if you want both phones on exactly these:" : ""}</small></p>
      ${good.length ? html`<textarea class="snip" readonly rows="4" onFocus=${e => e.currentTarget.select()}>${snippet}</textarea>` : ""}`}`;
}
