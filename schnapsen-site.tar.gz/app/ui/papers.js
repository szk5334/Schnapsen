/* THE WALL (build 2026-10-28.2). Behind everything hangs one of the deck's colour papers (app/prints, the files the
 * card faces use, so usually cached already), picked at random on each page load and enlarged to cover the screen.
 * The table is a felt panel set into it. On wide screens one clipping can't be stretched that far, so the same paper
 * is mirrored into a 2 x 2 tile on a canvas (seamless in every direction) and repeated instead.
 * Nothing new is fetched: the stylesheet gets --wall (the paper's own URL) and --wall-tile (a blob: URL). Until they
 * are set, or without a canvas, the dark room shows. */
const RANKS = ["A", "K", "Q", "J", "10", "9", "0"], SUITS = ["S", "H", "D", "C"];
const ALL = RANKS.flatMap(r => SUITS.map(s => r + s));

function tile(img) {
  const w = img.naturalWidth, h = img.naturalHeight;
  const c = document.createElement("canvas");
  c.width = w * 2; c.height = h * 2;
  const g = c.getContext("2d");
  for (const [fx, fy] of [[1, 1], [-1, 1], [1, -1], [-1, -1]]) {
    g.setTransform(fx, 0, 0, fy, fx < 0 ? w * 2 : 0, fy < 0 ? h * 2 : 0);
    g.drawImage(img, 0, 0);
  }
  return new Promise(ok => c.toBlob(b => ok(b && URL.createObjectURL(b)), "image/webp", .92));
}

export function hangPapers() {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  const pick = ALL[Math.floor(Math.random() * ALL.length)];
  const src = new URL(`app/prints/${pick}.webp`, document.baseURI).href;   /* absolute: a relative url() in a custom property resolves against the stylesheet */
  const img = new Image();
  img.decoding = "async";
  img.onload = async () => {
    root.style.setProperty("--wall", `url("${src}")`);
    root.dataset.wall = pick;
    try { const url = await tile(img); if (url) root.style.setProperty("--wall-tile", `url("${url}")`); } catch {}
  };
  img.src = src;
}
