/* THE WALL (build 2026-10-28.2, tiled since .3). Behind everything hangs one of the deck's colour papers (app/prints,
 * the files the card faces use, so usually cached already), picked at random on each page load and repeated at its
 * own size, seams and all. The table is a felt panel set into it. Nothing new is fetched: the stylesheet gets --wall
 * (the paper's own URL). Until it is set, the dark room shows. */
const RANKS = ["A", "K", "Q", "J", "10", "9", "0"], SUITS = ["S", "H", "D", "C"];
const ALL = RANKS.flatMap(r => SUITS.map(s => r + s));

export function hangPapers() {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  const pick = ALL[Math.floor(Math.random() * ALL.length)];
  const src = new URL(`app/prints/${pick}.webp`, document.baseURI).href;   /* absolute: a relative url() in a custom property resolves against the stylesheet */
  const img = new Image();
  img.decoding = "async";
  img.onload = async () => {
    root.style.setProperty("--wall", `url("${src}")`);
    root.dataset.wall = pick;
  };
  img.src = src;
}
