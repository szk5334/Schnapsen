import { html, useState, useEffect, useRef } from "../../vendor/preact.js";
import { RULES, effPts, stockLeft, other } from "../../schnapsen/engine/rules.js";
import { ENG } from "../../schnapsen/engine/core.js";
import { publicView } from "../../schnapsen/engine/redact.js";
import { who, PROFILES } from "../../schnapsen/state/personas.js";
import { SUIT_GLYPH, SUIT_NAME, sortHandDisplay, displayRank, setRankMode } from "../../schnapsen/state/constants.js";
import { potOf, wonCards } from "../house.js";
import { Card, Back, Tok, Suit, SuitIcon, PipIcon, RankGlyph } from "./cards.js";
import { Avatar, Sheet } from "./bits.js";
import { Review, warm } from "./review.js";
import { useCell, useWakeLock } from "./hooks.js";
import { prefs } from "../ident.js";
import { canDup, dupTally } from "../dup.js";

const OUT = 66;
/* House tables print the values on the cards (4, 3, 2); classic tables keep K, Q, J. */
export const useRanks = s => setRankMode(s && s.house ? "values" : "faces");
const openPiles = s => !!(s.house && s.piles !== "down");

/* THE TABLE. Opponent on top, the stock and the trick in the middle, you and your hand at the bottom —
 * the way the two of you actually sit. */
/* rejoin: this player is still on a deal the other has moved on from; the button takes them to the live one.
 * lingering: seats still looking at the last deal's score (so "waiting" can say so). record: { d0, moves } for the review. */
export function Game({ s, seat, act, seats = [], down = [], canDeal, wait, audit, rejoin, lingering = [], record }) {
  const p = useCell(prefs);
  useWakeLock(true);
  const [sel, setSel] = useState(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => { setSel(null); }, [s.turn, s.phase, (s.trick || []).length]);
  useEffect(() => { if (s.phase !== "scored") setSeen(false); }, [s.phase]);
  ENG.setVariant(s.variant || "classic");
  useRanks(s);

  const opp = other(seat);
  const myTurn = s.mode === "play" && s.phase === "play" && s.turn === seat && !wait;
  const legal = myTurn ? new Set(RULES.legalCards(s, seat).map(c => c.id)) : null;
  const name = i => (i === seat ? "You" : who(s, i));
  const person = i => seats[i] || (s.brains[i] !== "human" ? { name: PROFILES[s.brains[i]] ? PROFILES[s.brains[i]].name : "Bot", color: "#a9b3a5" } : { name: who(s, i), color: "#a9b3a5" });

  const pick = c => {
    if (!myTurn || !legal.has(c.id)) return;
    if (sel === c.id) { setSel(null); act({ type: "PLAY", seat, cardId: c.id }); }
    else setSel(c.id);
  };

  const status = wait ? wait : s.phase === "scored"
    ? (s.result ? `${name(s.result.winner)} ${s.result.winner === seat ? "take" : "takes"} the deal` : "Deal over")
    : myTurn
      ? (sel ? "Tap it again to play" : s.meldSuit ? (s.house ? `Lead the 4 or 3 of ${SUIT_NAME[s.meldSuit]}` : `Lead the king or queen of ${SUIT_NAME[s.meldSuit]}`) : s.trick.length ? "Your turn to follow" : "Your lead")
      : down.includes(s.turn) ? `Waiting for ${name(s.turn)} to come back`
      : lingering.includes(s.turn) ? `${name(s.turn)} is still looking at the score` : `${name(s.turn)} to play`;

  const pop = useMeldPop(s);
  const dpop = useDupPop(s);
  if (s.phase === "scored" && seen) return html`<${Result} s=${s} seat=${seat} name=${name} act=${act} canDeal=${canDeal} audit=${audit} rejoin=${rejoin} record=${record}/>`;

  const nb = s.phase === "scored" ? 1 : actionCount(s, seat, myTurn);
  return html`
    <div class="game" style=${`--n:${ENG.handSize()}`}>
      ${pop && html`<${MeldPop} key=${pop.n} m=${pop.m} who=${pop.m.seat === seat ? "You" : name(pop.m.seat)} trump=${s.trump}/>`}
      ${!pop && dpop && html`<${DupPop} key=${dpop} s=${s} seat=${seat} name=${name}/>`}
      <${Side} s=${s} i=${opp} p=${person(opp)} label=${name(opp)} hidden=${s.house ? s.piles === "down" : p.memory} away=${down.includes(opp)} turn=${s.turn === opp && s.phase === "play"}>
        <span class="backs" aria-label=${`${(s.hands[opp] || []).length} cards`}>${(s.hands[opp] || []).map((_, k) => html`<${Back} key=${k} size="xs"/>`)}</span>
      <//>

      <div class=${"felt" + (openPiles(s) ? " piled" : "")}>
        ${openPiles(s) && html`<${Piles} cards=${wonCards(s, opp)} who=${name(opp)} side="far"/>`}
        <${Stock} s=${s}/>
        <${Trick} s=${s} seat=${seat} name=${name}/>
        ${openPiles(s) && html`<${Piles} cards=${wonCards(s, seat)} who="You" side="near"/>`}
      </div>

      <${Side} s=${s} i=${seat} p=${person(seat)} label="You" turn=${myTurn} mine/>

      <div class=${"acts" + (nb ? " has" : "")}>
        <p class=${"status" + (myTurn ? " go" : "")} role="status">${status}</p>
        ${s.phase === "scored"
          ? html`<button class="btn primary" onClick=${() => setSeen(true)}>See the score</button>`
          : html`<${Actions} s=${s} seat=${seat} act=${act} on=${myTurn}/>`}
      </div>

      <div class="hand" role="group" aria-label="Your hand" style=${`--c:${Math.max(1, (s.hands[seat] || []).length)}`}>
        ${sortHandDisplay(s.hands[seat] || [], s.trump).map(c => html`<${Card} key=${c.id} c=${c} size="lg"
          sel=${sel === c.id} dim=${myTurn && !legal.has(c.id)} legal=${myTurn && legal.has(c.id)} trump=${!!s.trump && c.suit === s.trump}
          onClick=${() => pick(c)} label=${`${displayRank(c.rank)} of ${SUIT_NAME[c.suit]}${sel === c.id ? ", tap again to play" : ""}`}/>`)}
      </div>
    </div>`;
}

function Side({ s, i, p, label, hidden, away, turn, mine, children }) {
  const pts = effPts(s, i);
  const waiting = s.meldPts[i] > 0 && s.tricksWon[i] === 0;
  return html`
    <div class=${"side" + (turn ? " turn" : "") + (mine ? " mine" : "")}>
      <${Avatar} p=${p}/>
      <span class="sname">${label}${away ? html` <em>away</em>` : ""}</span>
      ${children}
      ${(mine || !hidden) && (s.meldedSuits[i] || []).length > 0 && html`<span class="mchips" aria-label=${`Marriages declared: ${s.meldedSuits[i].map(su => ENG.meldValue(su, s.trump) + " in " + SUIT_NAME[su]).join(", ")}`}>
        ${s.meldedSuits[i].map(su => html`<span key=${su} class="mchip"><i class=${"msuit s-" + su}><${SuitIcon} s=${su}/></i>${ENG.meldValue(su, s.trump)}</span>`)}</span>`}
      <span class="stat"><b>${s.tricksWon[i]}</b> ${s.tricksWon[i] === 1 ? "trick" : "tricks"}</span>
      <span class="stat pts">${hidden && !mine ? html`<b>?</b>` : html`<b>${pts}</b>`} pts${waiting ? html`<i title="Marriage points count once a trick is won"> +${s.meldPts[i]}</i>` : ""}</span>
    </div>`;
}

/* THE STOCK, tucked behind the turned card the way it lies on a real table: the turned card whole, the stock's back
 * showing down its left side with the count on it. (Build 2026-10-28.1: both at the hand's card size.) */
function Stock({ s }) {
  const left = stockLeft(s);
  const pot = s.house ? potOf(s.sheet) : 0;
  const has = s.stock.length > 0;
  return html`
    <div class="stock" aria-label=${`Stock: ${s.closed ? "closed" : left + " cards"}. ${s.trump ? `Trumps are ${SUIT_NAME[s.trump]}` : "No trumps"}.`}>
      <div class="pile">
        ${has ? html`<${Back} size="sm" struck=${s.closed}/>` : html`<span class=${"card z-sm gone" + (s.up ? "" : " hide")}></span>`}
        ${s.up ? html`<${Card} c=${s.up} size="sm" label=${`Turned card: ${displayRank(s.up.rank)} of ${SUIT_NAME[s.up.suit]}`}/>` : html`<span class="card z-sm gone"></span>`}
        ${has && !s.closed && html`<span class="cnt" aria-hidden="true">${left}</span>`}
        ${pot > 0 && html`<span class="pot" title="Scoreless deals waiting for the next winner">Pot <b>${pot}</b></span>`}
      </div>
      ${s.trump ? html`<span class="trump">${s.closed ? "Closed" : "Trumps"} <${Suit} s=${s.trump}/></span>`
        : html`<span class="trump nt">No trumps</span>`}
    </div>`;
}

/* WON CARDS, house style: one column per rank, lowest on the left, the aces on the right, the way the points climb.
 * Each is the rank over four fixed suit slots (spades, hearts / diamonds, clubs), filled with a suit mark once that
 * card is won. Same place every time, so it reads at a glance. (Build 2026-10-25.2: every layout, not only High
 * visibility; the old fanned mini-card piles are gone.) */
const pileOrder = () => (ENG.getVariant() === "24" ? ["9", "J", "Q", "K", "10", "A"] : ENG.getVariant() === "22" ? ["J", "Q", "K", "9", "10", "A"] : ["J", "Q", "K", "10", "A"]);
const SUIT_ORDER = ["S", "H", "D", "C"];
/* Every square carries its suit: faint until that card is won, then the card's own enamel pip on ivory.
 * (Build 2026-10-28.1: the squares are as large as the row allows; the rank sits beside them on a short row and
 * above them on a tall one.) */
function Piles({ cards, who, side }) {
  const pts = cards.reduce((a, c) => a + ENG.val(c), 0);
  const order = pileOrder();
  return html`<div class=${"piles hv " + side + " np" + order.length} style=${"--np:" + order.length} role="group" aria-label=${`${who === "You" ? "Your" : who + "'s"} won cards: ${cards.length ? cards.length + " cards, " + pts + " points" : "none yet"}`}>
    ${order.map(r => {
      const got = new Set(cards.filter(c => c.rank === r).map(c => c.suit));
      return html`<span key=${r} class=${"rchips" + (got.size ? "" : " none")}>
        <span class="rl"><${RankGlyph} r=${displayRank(r)}/></span>
        <span class="chips">${SUIT_ORDER.map(su => !ENG.inDeck(r, su)
          ? html`<i key=${su} class="chip nil" aria-hidden="true"></i>`
          : got.has(su)
          ? html`<i key=${su} class=${"chip s-" + su}><${PipIcon} s=${su}/></i>`
          : html`<i key=${su} class=${"chip off s-" + su}><${SuitIcon} s=${su}/></i>`)}</span>
      </span>`;
    })}
  </div>`;
}

/* MARRIAGES, made hard to miss (build 2026-10-25.3, Seth kept missing the bot's). A declaration shows three ways:
 *  - a pop-up over the table for 3 s: both cards of the marriage, "Fritzl declared 20" (taps pass through it);
 *  - the trick caption becomes a gold ribbon, and the led card of the marriage glows, until the trick is taken;
 *  - gold badges by the declarer's name (suit and points), for the rest of the deal. Hidden for the opponent when
 *    their points are hidden (face-down piles, memory mode): the pop-up and ribbon are the spoken declaration.
 * Plays aren't logged, so after a declaration the log ends with the meld until the trick completes. */
function meldNow(s) {
  const log = s.log || [], last = log[log.length - 1];
  if (!last || last.k !== "meld" || s.phase !== "play") return null;
  if (s.meldSuit) return last;                                          // declared, card not led yet
  if (s.trick.length && s.trick[0].seat === last.seat) return last;     // its king or queen is on the table
  return null;
}
function useMeldPop(s) {
  const count = (s.log || []).filter(e => e.k === "meld").length;
  const seen = useRef(count), [pop, setPop] = useState(null);
  useEffect(() => {
    if (count > seen.current) {
      const melds = (s.log || []).filter(e => e.k === "meld");
      setPop({ n: count, m: melds[melds.length - 1] });
      const t = setTimeout(() => setPop(null), 3000);
      seen.current = count;
      return () => clearTimeout(t);
    }
    seen.current = count;                                               // a new deal starts the count again
  }, [count]);
  return pop;
}
/* The start of a duplicate deal: say so for a few seconds, over the felt, without moving anything. */
function useDupPop(s) {
  /* Early in the deal: no trick finished yet (the opponent may already have led, or the bot swapped). */
  const fresh = !!(s.dup && s.phase === "play" && !(s.log || []).some(e => e.k === "trick"));
  const id = s.dup ? `${s.bummerlNo}.${s.dealNo}` : null;
  const [pop, setPop] = useState(null), shown = useRef(null);
  useEffect(() => {
    if (!fresh || shown.current === id) return;
    shown.current = id; setPop(id);
    const t = setTimeout(() => setPop(null), 3500);
    return () => clearTimeout(t);
  }, [fresh, id]);
  return pop;
}
function DupPop({ s, seat, name }) {
  return html`<div class="mpop dpop" role="status" aria-live="assertive">
    <div class="mpop-in">
      <p class="mpop-t"><b class="mpop-v">Deal ${s.dup.of} again</b></p>
      <p class="dpop-t">${name(other(seat))} has your hand from deal ${s.dup.of}, and you have theirs. Same turned card, same stock.</p>
    </div>
  </div>`;
}
function MeldPop({ m, who, trump }) {
  const pts = m.value, inTrumps = !!trump && m.suit === trump;
  return html`<div class="mpop" role="status" aria-live="assertive">
    <div class="mpop-in">
      <div class="mpop-cards">
        <${Card} c=${{ id: -901, rank: "K", suit: m.suit }}/><${Card} c=${{ id: -902, rank: "Q", suit: m.suit }}/>
      </div>
      <p class="mpop-t"><b>${who}</b> ${who === "You" ? "declare" : "declared"} <b class="mpop-v">${pts}</b>${inTrumps ? " in trumps" : ""}</p>
    </div>
  </div>`;
}
function MeldRibbon({ m, mine }) {
  return html`<span class="tcap mribbon">${mine ? "Your marriage" : "Marriage"} <b>${m.value}</b> <i class=${"msuit s-" + m.suit}><${SuitIcon} s=${m.suit}/></i></span>`;
}

/* The trick sits in two fixed slots, lined up side by side: theirs on the left, yours on the right. A card
 * always lands in its owner's slot, so nothing on the table moves when the lead changes hands. */
function Trick({ s, seat, name }) {
  const opp = other(seat);
  const m = meldNow(s);
  const slots = (cards, winner) => [opp, seat].map(i => {
    const x = cards.find(y => y.seat === i);
    const glow = m && x && i === m.seat && x.card.suit === m.suit && winner === -1;
    return html`<span key=${i} class=${"tslot" + (winner === i ? " won" : "") + (glow ? " meld" : "")}>${x ? html`<${Card} c=${x.card}/>` : html`<span class="card z-md gone" aria-hidden="true"></span>`}</span>`;
  });
  if (s.trick.length) {
    const t = s.trick[0];
    return html`<div class="trick">
      ${slots(s.trick, -1)}
      ${m ? html`<${MeldRibbon} m=${m} mine=${m.seat === seat}/>`
        : html`<span class="tcap">${t.seat === seat ? "You led" : `${name(t.seat)} led`}</span>`}
    </div>`;
  }
  if (s.lastTrick) {
    const lt = s.lastTrick;
    return html`<div class="trick last">
      ${slots(lt.trick, lt.winner)}
      ${m ? html`<${MeldRibbon} m=${m} mine=${m.seat === seat}/>`
        : html`<span class="tcap">${lt.winner === seat ? "You" : name(lt.winner)} took ${lt.pts}</span>`}
    </div>`;
  }
  return html`<div class="trick">
    ${slots([], -1)}
    ${m ? html`<${MeldRibbon} m=${m} mine=${m.seat === seat}/>`
      : html`<span class="tcap">${s.turn === seat ? "Lead any card" : `${name(s.turn)} leads`}</span>`}
  </div>`;
}

/* How many buttons the action row will show (the status line gives them room). */
function actionCount(s, seat, on) {
  if (!on) return 0;
  return RULES.meldOptions(s, seat).length + (RULES.canExchange(s, seat) ? 1 : 0) + (RULES.canClose(s, seat) ? 1 : 0) + (s.strictClaim && RULES.canClaim(s, seat) ? 1 : 0);
}
function Actions({ s, seat, act, on }) {
  const [arm, setArm] = useState(false);
  useEffect(() => setArm(false), [s.turn, (s.log || []).length]);
  if (!on) return null;
  const ex = RULES.canExchange(s, seat);
  const cl = RULES.canClose(s, seat);
  const melds = RULES.meldOptions(s, seat);
  const claim = s.strictClaim && RULES.canClaim(s, seat);
  const low = ENG.exchangeRank();
  return html`
    ${melds.map(m => html`<button key=${m.suit} class="btn meld" onClick=${() => act({ type: "MELD", seat, suit: m.suit })}>Declare ${m.value} <${Suit} s=${m.suit}/></button>`)}
    ${ex && html`<button class="btn" onClick=${() => act({ type: "EXCHANGE", seat })}>Swap ${displayRank(low)}<${Suit} s=${s.trump}/></button>`}
    ${cl && (arm
      ? html`<button class="btn warn" aria-label="Tap again to close the stock" onClick=${() => act({ type: "CLOSE", seat })}>Sure? Close</button>`
      : html`<button class="btn" aria-label="Close the stock" onClick=${() => setArm(true)}>Close</button>`)}
    ${claim && html`<button class="btn" onClick=${() => act({ type: "CLAIM", seat })}>Declare 66</button>`}`;
}

function Result({ s, seat, name, act, canDeal, audit, rejoin, record }) {
  const ready = audit !== null;                       // online: the next deal opens once both sides are settled
  const [rv, setRv] = useState(false);
  useEffect(() => (record ? warm(record, s) : undefined), [record]);   // work the review out while the score is read
  const dt = html`<${DupTally} s=${s} seat=${seat} name=${name}/>`;   // a duplicate's comparison comes first after the score
  const next = html`<${Next} s=${s} act=${act} canDeal=${canDeal} ready=${ready} rejoin=${rejoin} review=${record ? () => setRv(true) : null} dup=${canDup(s, record && record.d0)}/>
    ${rv && record && html`<${Sheet} title="The deal, looked back" onClose=${() => setRv(false)}><${Review} rec=${record} s=${s} seat=${seat} name=${name}/><//>`}`;
  const r = s.result;
  const o = other(seat);
  const hr = s.house && s.houseResult;
  if (hr && hr.scoreless) return html`
    <div class="result">
      <h2 class="lost">No 66, no score</h2>
      <p class="gp"><b>+0</b> to either side</p>
      ${dt}
      <p>Neither side reached 66. The deal goes into the pot, which now holds <b>${hr.pot}</b> for whoever scores next.</p>
      <dl class="tally">
        <dt>Card points</dt><dd>${r.pts[seat]} – ${r.pts[o]}</dd>
        <dt>Tricks</dt><dd>${r.tricks[seat]} – ${r.tricks[o]}</dd>
      </dl>
      <${ScoreLine} s=${s} seat=${seat} name=${name}/>
      <p class="muted">${Math.max(0, s.target - s.gp[seat])} more and the Bummerl is yours.</p>
      ${next}
    </div>`;
  const winner = hr ? hr.winner : r.winner;
  const gp = hr ? hr.gp : r.gp;
  const won = winner === seat;
  const head = hr && r.reason === "exhausted" ? "66, counted at the end" : r.head;
  return html`
    <div class="result">
      <h2 class=${won ? "won" : "lost"}>${head}</h2>
      <p class="gp"><b>+${gp}</b> ${won ? "to you" : `to ${name(winner)}`}${hr && hr.pot ? html`<span class="potwin"> and the pot, <b>+${hr.pot}</b></span>` : ""}</p>
      ${dt}
      <p>${hr && r.reason === "exhausted" ? `${r.pts[winner]} card points when the cards ran out.` : r.why}</p>
      <dl class="tally">
        <dt>Card points</dt><dd>${r.pts[seat]} – ${r.pts[o]}</dd>
        <dt>Tricks</dt><dd>${r.tricks[seat]} – ${r.tricks[o]}</dd>
        ${r.closedBy != null && html`<dt>Closed by</dt><dd>${name(r.closedBy)}, with ${name(other(r.closedBy))} on ${r.closeSnap ? r.closeSnap.pts : 0}</dd>`}
      </dl>
      ${r.tricks[other(winner)] === 0 && html`<p class="note">${name(other(winner))} didn't take a single trick.</p>`}
      <${ScoreLine} s=${s} seat=${seat} name=${name}/>
      ${s.bummerlDone
        ? html`<p class="bummerl">${name(s.bummerlWinner)} ${s.bummerlWinner === seat ? "win" : "wins"} the Bummerl ${s.gp[s.bummerlWinner]}–${s.gp[other(s.bummerlWinner)]}${s.schneiderBummerl ? ", Schneider" : ""}.</p>`
        : html`<p class="muted">${Math.max(0, s.target - s.gp[seat])} more and the Bummerl is yours.</p>`}
      ${next}
    </div>`;
}

function Next({ s, act, canDeal, ready, rejoin, review, dup }) {
  return html`<div class="acts">
    ${review && html`<button class="btn" onClick=${review}>Review</button>`}
    ${rejoin
      ? html`<button class="btn primary" onClick=${rejoin}>Back to the table</button>`
      : canDeal
      ? html`${s.bummerlDone
        ? html`<button class="btn primary" disabled=${!ready} onClick=${() => act({ type: "NEW_BUMMERL" })}>New Bummerl</button>`
        : html`<button class="btn primary" disabled=${!ready} onClick=${() => act({ type: "NEXT_DEAL" })}>Next deal</button>`}
        ${dup && html`<button class="btn" disabled=${!ready} onClick=${() => act({ type: "DUPLICATE_DEAL" })}
          aria-label="Duplicate deal: the same cards again, with the hands swapped">Duplicate deal</button>`}`
      : html`<p class="muted">Waiting for the next deal</p>`}
  </div>`;
}

/* After a duplicate: what each of you made from the same cards, deal by deal and over the pair (pots aside). */
const signed = v => (v > 0 ? "+" + v : v < 0 ? "\u2212" + -v : "0");
function DupTally({ s, seat, name }) {
  const t = dupTally(s);
  if (!t) return null;
  const o = other(seat), me = t.sum[seat];
  const verdict = me === 0 ? "Dead even: you both made the same from the same cards."
    : me > 0 ? `Over the pair you came out ${me} ahead.` : `Over the pair ${name(o)} came out ${-me} ahead.`;
  return html`<section class="duptally" aria-label="Duplicate">
    <h3>The same cards, both ways</h3>
    <table class="sheet-t">
      <thead><tr><th></th><th>Deal ${t.of}</th><th>Deal ${s.dealNo}</th><th>Both</th></tr></thead>
      <tbody>${[seat, o].map(i => html`<tr key=${i}><td>${name(i)}</td><td>${signed(t.prev[i])}</td><td>${signed(t.now[i])}</td><td><b>${signed(t.sum[i])}</b></td></tr>`)}</tbody>
    </table>
    <p class=${me > 0 ? "note" : ""}>${verdict}</p>
    <p class="muted">${t.lead === seat ? "You" : name(t.lead)} led with these cards in deal ${t.of}, ${t.lead === seat ? name(o) : "you"} in deal ${s.dealNo}.${s.house ? " Pots aren't counted here." : ""}</p>
  </section>`;
}

export function ScoreLine({ s, seat, name }) {
  const o = other(seat);
  return html`<table class="sheet-t">
    <thead><tr><th>Deal</th><th>${name(seat)}</th><th>${name(o)}</th></tr></thead>
    <tbody>${(s.sheet || []).map(r => r.scoreless
      ? html`<tr key=${r.dealNo} class="nil"><td>${r.dealNo}${r.dup ? html`<small class="dupm"> (${r.dup} again)</small>` : ""}</td><td colspan="2">No 66, into the pot</td></tr>`
      : html`<tr key=${r.dealNo}><td>${r.dealNo}${r.dup ? html`<small class="dupm"> (${r.dup} again)</small>` : ""}</td><td>${r.winner === seat ? "+" + r.gp : ""}</td><td>${r.winner === o ? "+" + r.gp : ""}</td></tr>`)}</tbody>
    <tfoot><tr><td>Total</td><td>${s.gp[seat]}</td><td>${s.gp[o]}</td></tr></tfoot>
  </table>`;
}

/* The public record of the deal, newest first. */
export function DealLog({ s }) {
  useRanks(s);
  const nm = i => who(s, i);
  const T = c => html`<${Tok} c=${c}/>`;
  const lines = (s.log || []).slice().reverse().map(e =>
    e.k === "trick" ? html`${nm(e.winner)} took ${T(e.led)} / ${T(e.fol)} (${e.pts})`
    : e.k === "meld" ? html`${nm(e.seat)} declared ${e.value} in <${Suit} s=${e.suit}/>`
    : e.k === "close" ? `${nm(e.seat)} closed the stock`
    : e.k === "exchange" ? html`${nm(e.seat)} swapped the ${T(e.gave)} for the turn-up`
    : e.k === "tookup" ? html`${nm(e.seat)} drew the turn-up, ${T(e.card)}` : "").filter(Boolean);
  return lines.length ? html`<ol class="log">${lines.map((l, i) => html`<li key=${i}>${l}</li>`)}</ol>`
    : html`<p class="muted">Nothing played yet this deal.</p>`;
}

/* What a watcher sees: the public view the host shares — scores, whose turn, the last few plays. */
export function Watch({ pub, seats }) {
  if (!pub) return html`<p class="muted pad">The game hasn't started.</p>`;
  return html`<div class="watch">
    <p class="status">${pub.status}</p>
    <ul class="wseats">${pub.seats.map((x, i) => html`<li key=${i}><${Avatar} p=${seats[i] || { name: x.name }}/><b>${x.name}</b><span>${x.score} of ${pub.target}</span><small>${x.note}</small></li>`)}</ul>
    <p class="muted">${pub.stockCount ? `${pub.stockCount} cards in the stock` : "Stock is out"}${pub.pileTop ? `, ${pub.pileTop} on the table` : ""}</p>
    <ol class="log">${(pub.log || []).map((l, i) => html`<li key=${i}>${l}</li>`)}</ol>
  </div>`;
}
