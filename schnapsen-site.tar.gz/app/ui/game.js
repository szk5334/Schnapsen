import { html, useState, useEffect } from "../../vendor/preact.js";
import { RULES, effPts, stockLeft, other } from "../../schnapsen/engine/rules.js";
import { ENG } from "../../schnapsen/engine/core.js";
import { publicView } from "../../schnapsen/engine/redact.js";
import { who, PROFILES } from "../../schnapsen/state/personas.js";
import { SUIT_GLYPH, SUIT_NAME, sortHandDisplay, displayRank, setRankMode } from "../../schnapsen/state/constants.js";
import { potOf, wonCards } from "../house.js";
import { Card, Back, Tok, Suit, SuitIcon, PipIcon, RankGlyph } from "./cards.js";
import { Avatar, Sheet } from "./bits.js";
import { useCell } from "./hooks.js";
import { prefs } from "../ident.js";

const OUT = 66;
/* House tables print the values on the cards (4, 3, 2); classic tables keep K, Q, J. */
export const useRanks = s => setRankMode(s && s.house ? "values" : "faces");
const openPiles = s => !!(s.house && s.piles !== "down");

/* THE TABLE. Opponent on top, the stock and the trick in the middle, you and your hand at the bottom —
 * the way the two of you actually sit. */
export function Game({ s, seat, act, seats = [], down = [], canDeal, wait, audit }) {
  const p = useCell(prefs);
  const [sel, setSel] = useState(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => { setSel(null); }, [s.turn, s.phase, (s.trick || []).length]);
  useEffect(() => { if (s.phase !== "scored") setSeen(false); }, [s.phase]);
  ENG.setVariant(s.variant || "classic");
  useRanks(s);

  const opp = other(seat);
  const myTurn = s.mode === "play" && s.phase === "play" && s.turn === seat && !wait;
  const legal = myTurn ? new Set(RULES.legalCards(s, seat).map(c => c.id)) : null;
  const name = i => (i === seat ? "You" : who(s, i));
  const person = i => seats[i] || (s.brains[i] !== "human" ? { name: PROFILES[s.brains[i]] ? PROFILES[s.brains[i]].name : "Bot", color: "#a9b3a5" } : { name: who(s, i), color: "#a9b3a5" });

  const pick = c => {
    if (!myTurn || !legal.has(c.id)) return;
    if (sel === c.id) { setSel(null); act({ type: "PLAY", seat, cardId: c.id }); }
    else setSel(c.id);
  };

  const status = wait ? wait : s.phase === "scored"
    ? (s.result ? `${name(s.result.winner)} ${s.result.winner === seat ? "take" : "takes"} the deal` : "Deal over")
    : myTurn
      ? (sel ? "Tap it again to play" : s.meldSuit ? (s.house ? `Lead the 4 or 3 of ${SUIT_NAME[s.meldSuit]}` : `Lead the king or queen of ${SUIT_NAME[s.meldSuit]}`) : s.trick.length ? "Your turn to follow" : "Your lead")
      : down.includes(s.turn) ? `Waiting for ${name(s.turn)} to come back` : `${name(s.turn)} to play`;

  if (s.phase === "scored" && seen) return html`<${Result} s=${s} seat=${seat} name=${name} act=${act} canDeal=${canDeal} audit=${audit}/>`;

  return html`
    <div class="game">
      <${Side} s=${s} i=${opp} p=${person(opp)} label=${name(opp)} hidden=${s.house ? s.piles === "down" : p.memory} away=${down.includes(opp)} turn=${s.turn === opp && s.phase === "play"}>
        <span class="backs" aria-label=${`${(s.hands[opp] || []).length} cards`}>${(s.hands[opp] || []).map((_, k) => html`<${Back} key=${k} size="xs"/>`)}</span>
      <//>

      <div class=${"felt" + (openPiles(s) ? " piled" : "")}>
        ${openPiles(s) && html`<${Piles} cards=${wonCards(s, opp)} who=${name(opp)} side="far"/>`}
        <${Stock} s=${s}/>
        <${Trick} s=${s} seat=${seat} name=${name}/>
        ${openPiles(s) && html`<${Piles} cards=${wonCards(s, seat)} who="You" side="near"/>`}
      </div>

      <${Side} s=${s} i=${seat} p=${person(seat)} label="You" turn=${myTurn} mine/>

      <p class=${"status" + (myTurn ? " go" : "")} role="status">${status}</p>

      ${s.phase === "scored"
        ? html`<div class="acts"><button class="btn primary" onClick=${() => setSeen(true)}>See the score</button></div>`
        : html`<${Actions} s=${s} seat=${seat} act=${act} on=${myTurn}/>`}

      <div class="hand" role="group" aria-label="Your hand" style=${`--n:${ENG.handSize()};--c:${Math.max(1, (s.hands[seat] || []).length)}`}>
        ${sortHandDisplay(s.hands[seat] || [], s.trump).map(c => html`<${Card} key=${c.id} c=${c} size="lg"
          sel=${sel === c.id} dim=${myTurn && !legal.has(c.id)} legal=${myTurn && legal.has(c.id)} trump=${!!s.trump && c.suit === s.trump}
          onClick=${() => pick(c)} label=${`${displayRank(c.rank)} of ${SUIT_NAME[c.suit]}${sel === c.id ? ", tap again to play" : ""}`}/>`)}
      </div>
    </div>`;
}

function Side({ s, i, p, label, hidden, away, turn, mine, children }) {
  const pts = effPts(s, i);
  const waiting = s.meldPts[i] > 0 && s.tricksWon[i] === 0;
  return html`
    <div class=${"side" + (turn ? " turn" : "") + (mine ? " mine" : "")}>
      <${Avatar} p=${p}/>
      <span class="sname">${label}${away ? html` <em>away</em>` : ""}</span>
      ${children}
      <span class="stat"><b>${s.tricksWon[i]}</b> ${s.tricksWon[i] === 1 ? "trick" : "tricks"}</span>
      <span class="stat pts">${hidden && !mine ? html`<b>?</b>` : html`<b>${pts}</b>`} pts${waiting ? html`<i title="Marriage points count once a trick is won"> +${s.meldPts[i]}</i>` : ""}</span>
    </div>`;
}

function Stock({ s }) {
  const left = stockLeft(s);
  const pot = s.house ? potOf(s.sheet) : 0;
  return html`
    <div class="stock" aria-label=${`Stock: ${left} cards. ${s.trump ? `Trumps are ${SUIT_NAME[s.trump]}` : "No trumps"}.`}>
      <div class="pile">
        ${pot > 0 && html`<span class="pot" title="Scoreless deals waiting for the next winner">Pot <b>${pot}</b></span>`}
        ${s.stock.length > 0 ? html`<${Back} size="sm" struck=${s.closed}/>` : html`<span class="card z-sm gone"></span>`}
        ${s.up ? html`<${Card} c=${s.up} size="sm" label=${`Turned card: ${displayRank(s.up.rank)} of ${SUIT_NAME[s.up.suit]}`}/>` : html`<span class="card z-sm gone"></span>`}
      </div>
      <span class="slabel">${s.closed ? "Closed" : left ? `${left} left` : "Empty"}</span>
      ${s.trump ? html`<span class="trump">Trumps <${Suit} s=${s.trump}/></span>` : html`<span class="trump nt">No trumps</span>`}
    </div>`;
}

/* WON CARDS, house style: one column per rank, lowest on the left, the aces on the right, the way the points climb.
 * Each is the rank over four fixed suit slots (spades, hearts / diamonds, clubs), filled with a suit mark once that
 * card is won. Same place every time, so it reads at a glance. (Build 2026-10-25.2: every layout, not only High
 * visibility; the old fanned mini-card piles are gone.) */
const pileOrder = () => (ENG.getVariant() === "24" ? ["9", "J", "Q", "K", "10", "A"] : ["J", "Q", "K", "10", "A"]);
const SUIT_ORDER = ["S", "H", "D", "C"];
function Piles({ cards, who, side }) {
  const pts = cards.reduce((a, c) => a + ENG.val(c), 0);
  return html`<div class=${"piles hv " + side} style=${"--np:" + pileOrder().length} role="group" aria-label=${`${who === "You" ? "Your" : who + "'s"} won cards: ${cards.length ? cards.length + " cards, " + pts + " points" : "none yet"}`}>
    ${pileOrder().map(r => {
      const got = new Set(cards.filter(c => c.rank === r).map(c => c.suit));
      return html`<span key=${r} class=${"rchips" + (got.size ? "" : " none")}>
        <${RankGlyph} r=${displayRank(r)}/>
        <span class="chips">${SUIT_ORDER.map(su => got.has(su)
          ? html`<i key=${su} class=${"chip s-" + su}><${SuitIcon} s=${su}/></i>`
          : html`<i key=${su} class="chip off"></i>`)}</span>
      </span>`;
    })}
  </div>`;
}

/* The trick sits in two fixed slots, lined up side by side: theirs on the left, yours on the right. A card
 * always lands in its owner's slot, so nothing on the table moves when the lead changes hands. */
function Trick({ s, seat, name }) {
  const opp = other(seat);
  const slots = (cards, winner) => [opp, seat].map(i => {
    const x = cards.find(y => y.seat === i);
    return html`<span key=${i} class=${"tslot" + (winner === i ? " won" : "")}>${x ? html`<${Card} c=${x.card}/>` : html`<span class="card z-md gone" aria-hidden="true"></span>`}</span>`;
  });
  if (s.trick.length) {
    const t = s.trick[0];
    return html`<div class="trick">
      ${slots(s.trick, -1)}
      <span class="tcap">${t.seat === seat ? "You led" : `${name(t.seat)} led`}</span>
    </div>`;
  }
  if (s.lastTrick) {
    const lt = s.lastTrick;
    return html`<div class="trick last">
      ${slots(lt.trick, lt.winner)}
      <span class="tcap">${lt.winner === seat ? "You" : name(lt.winner)} took ${lt.pts}</span>
    </div>`;
  }
  return html`<div class="trick">
    ${slots([], -1)}
    <span class="tcap">${s.turn === seat ? "Lead any card" : `${name(s.turn)} leads`}</span>
  </div>`;
}

function Actions({ s, seat, act, on }) {
  const [arm, setArm] = useState(false);
  useEffect(() => setArm(false), [s.turn, (s.log || []).length]);
  if (!on) return html`<div class="acts"></div>`;
  const ex = RULES.canExchange(s, seat);
  const cl = RULES.canClose(s, seat);
  const melds = RULES.meldOptions(s, seat);
  const claim = s.strictClaim && RULES.canClaim(s, seat);
  const low = ENG.exchangeRank();
  return html`<div class="acts">
    ${melds.map(m => html`<button key=${m.suit} class="btn meld" onClick=${() => act({ type: "MELD", seat, suit: m.suit })}>Declare ${m.value} <${Suit} s=${m.suit}/></button>`)}
    ${ex && html`<button class="btn" onClick=${() => act({ type: "EXCHANGE", seat })}>Swap ${displayRank(low)}<${Suit} s=${s.trump}/></button>`}
    ${cl && (arm
      ? html`<button class="btn warn" aria-label="Tap again to close the stock" onClick=${() => act({ type: "CLOSE", seat })}>Sure? Close</button>`
      : html`<button class="btn" aria-label="Close the stock" onClick=${() => setArm(true)}>Close</button>`)}
    ${claim && html`<button class="btn" onClick=${() => act({ type: "CLAIM", seat })}>Declare 66</button>`}
  </div>`;
}

function Result({ s, seat, name, act, canDeal, audit }) {
  const ready = audit !== null;                       // online: the next deal opens once both sides are settled
  const r = s.result;
  const o = other(seat);
  const hr = s.house && s.houseResult;
  if (hr && hr.scoreless) return html`
    <div class="result">
      <h2 class="lost">No 66, no score</h2>
      <p class="gp"><b>+0</b> to either side</p>
      <p>Neither side reached 66. The deal goes into the pot, which now holds <b>${hr.pot}</b> for whoever scores next.</p>
      <dl class="tally">
        <dt>Card points</dt><dd>${r.pts[seat]} – ${r.pts[o]}</dd>
        <dt>Tricks</dt><dd>${r.tricks[seat]} – ${r.tricks[o]}</dd>
      </dl>
      <${ScoreLine} s=${s} seat=${seat} name=${name}/>
      <p class="muted">${Math.max(0, s.target - s.gp[seat])} more and the Bummerl is yours.</p>
      <${Next} s=${s} act=${act} canDeal=${canDeal} ready=${ready}/>
    </div>`;
  const winner = hr ? hr.winner : r.winner;
  const gp = hr ? hr.gp : r.gp;
  const won = winner === seat;
  const head = hr && r.reason === "exhausted" ? "66, counted at the end" : r.head;
  return html`
    <div class="result">
      <h2 class=${won ? "won" : "lost"}>${head}</h2>
      <p class="gp"><b>+${gp}</b> ${won ? "to you" : `to ${name(winner)}`}${hr && hr.pot ? html`<span class="potwin"> and the pot, <b>+${hr.pot}</b></span>` : ""}</p>
      <p>${hr && r.reason === "exhausted" ? `${r.pts[winner]} card points when the cards ran out.` : r.why}</p>
      <dl class="tally">
        <dt>Card points</dt><dd>${r.pts[seat]} – ${r.pts[o]}</dd>
        <dt>Tricks</dt><dd>${r.tricks[seat]} – ${r.tricks[o]}</dd>
        ${r.closedBy != null && html`<dt>Closed by</dt><dd>${name(r.closedBy)}, with ${name(other(r.closedBy))} on ${r.closeSnap ? r.closeSnap.pts : 0}</dd>`}
      </dl>
      ${r.tricks[other(winner)] === 0 && html`<p class="note">${name(other(winner))} didn't take a single trick.</p>`}
      <${ScoreLine} s=${s} seat=${seat} name=${name}/>
      ${s.bummerlDone
        ? html`<p class="bummerl">${name(s.bummerlWinner)} ${s.bummerlWinner === seat ? "win" : "wins"} the Bummerl ${s.gp[s.bummerlWinner]}–${s.gp[other(s.bummerlWinner)]}${s.schneiderBummerl ? ", Schneider" : ""}.</p>`
        : html`<p class="muted">${Math.max(0, s.target - s.gp[seat])} more and the Bummerl is yours.</p>`}
      <${Next} s=${s} act=${act} canDeal=${canDeal} ready=${ready}/>
    </div>`;
}

function Next({ s, act, canDeal, ready }) {
  return html`<div class="acts">
    ${canDeal
      ? (s.bummerlDone
        ? html`<button class="btn primary" disabled=${!ready} onClick=${() => act({ type: "NEW_BUMMERL" })}>New Bummerl</button>`
        : html`<button class="btn primary" disabled=${!ready} onClick=${() => act({ type: "NEXT_DEAL" })}>Next deal</button>`)
      : html`<p class="muted">Waiting for the next deal</p>`}
  </div>`;
}

export function ScoreLine({ s, seat, name }) {
  const o = other(seat);
  return html`<table class="sheet-t">
    <thead><tr><th>Deal</th><th>${name(seat)}</th><th>${name(o)}</th></tr></thead>
    <tbody>${(s.sheet || []).map(r => r.scoreless
      ? html`<tr key=${r.dealNo} class="nil"><td>${r.dealNo}</td><td colspan="2">No 66, into the pot</td></tr>`
      : html`<tr key=${r.dealNo}><td>${r.dealNo}</td><td>${r.winner === seat ? "+" + r.gp : ""}</td><td>${r.winner === o ? "+" + r.gp : ""}</td></tr>`)}</tbody>
    <tfoot><tr><td>Total</td><td>${s.gp[seat]}</td><td>${s.gp[o]}</td></tr></tfoot>
  </table>`;
}

/* The public record of the deal, newest first. */
export function DealLog({ s }) {
  useRanks(s);
  const nm = i => who(s, i);
  const T = c => html`<${Tok} c=${c}/>`;
  const lines = (s.log || []).slice().reverse().map(e =>
    e.k === "trick" ? html`${nm(e.winner)} took ${T(e.led)} / ${T(e.fol)} (${e.pts})`
    : e.k === "meld" ? html`${nm(e.seat)} declared ${e.value} in <${Suit} s=${e.suit}/>`
    : e.k === "close" ? `${nm(e.seat)} closed the stock`
    : e.k === "exchange" ? html`${nm(e.seat)} swapped the ${T(e.gave)} for the turn-up`
    : e.k === "tookup" ? html`${nm(e.seat)} drew the turn-up, ${T(e.card)}` : "").filter(Boolean);
  return lines.length ? html`<ol class="log">${lines.map((l, i) => html`<li key=${i}>${l}</li>`)}</ol>`
    : html`<p class="muted">Nothing played yet this deal.</p>`;
}

/* What a watcher sees: the public view the host shares — scores, whose turn, the last few plays. */
export function Watch({ pub, seats }) {
  if (!pub) return html`<p class="muted pad">The game hasn't started.</p>`;
  return html`<div class="watch">
    <p class="status">${pub.status}</p>
    <ul class="wseats">${pub.seats.map((x, i) => html`<li key=${i}><${Avatar} p=${seats[i] || { name: x.name }}/><b>${x.name}</b><span>${x.score} of ${pub.target}</span><small>${x.note}</small></li>`)}</ul>
    <p class="muted">${pub.stockCount ? `${pub.stockCount} cards in the stock` : "Stock is out"}${pub.pileTop ? `, ${pub.pileTop} on the table` : ""}</p>
    <ol class="log">${(pub.log || []).map((l, i) => html`<li key=${i}>${l}</li>`)}</ol>
  </div>`;
}
