import { html, useState, useEffect } from "../../vendor/preact.js";
import { RULES, effPts, stockLeft, other } from "../../schnapsen/engine/rules.js";
import { ENG } from "../../schnapsen/engine/core.js";
import { publicView } from "../../schnapsen/engine/redact.js";
import { who, PROFILES } from "../../schnapsen/state/personas.js";
import { SUIT_GLYPH, SUIT_NAME, sortHandDisplay, displayRank } from "../../schnapsen/state/constants.js";
import { Card, Back, Tok, Suit } from "./cards.js";
import { Avatar, Sheet } from "./bits.js";
import { useCell } from "./hooks.js";
import { prefs } from "../ident.js";

const OUT = 66;

/* THE TABLE. Opponent on top, the stock and the trick in the middle, you and your hand at the bottom —
 * the way the two of you actually sit. */
export function Game({ s, seat, act, seats = [], down = [], canDeal, wait, audit }) {
  const p = useCell(prefs);
  const [sel, setSel] = useState(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => { setSel(null); }, [s.turn, s.phase, (s.trick || []).length]);
  useEffect(() => { if (s.phase !== "scored") setSeen(false); }, [s.phase]);
  ENG.setVariant(s.variant || "classic");

  const opp = other(seat);
  const myTurn = s.mode === "play" && s.phase === "play" && s.turn === seat && !wait;
  const legal = myTurn ? new Set(RULES.legalCards(s, seat).map(c => c.id)) : null;
  const name = i => (i === seat ? "You" : who(s, i));
  const person = i => seats[i] || (s.brains[i] !== "human" ? { name: PROFILES[s.brains[i]] ? PROFILES[s.brains[i]].name : "Bot", color: "#a9b3a5" } : { name: who(s, i), color: "#a9b3a5" });

  const pick = c => {
    if (!myTurn || !legal.has(c.id)) return;
    if (sel === c.id) { setSel(null); act({ type: "PLAY", seat, cardId: c.id }); }
    else setSel(c.id);
  };

  const status = wait ? wait : s.phase === "scored"
    ? (s.result ? `${name(s.result.winner)} ${s.result.winner === seat ? "take" : "takes"} the deal` : "Deal over")
    : myTurn
      ? (s.meldSuit ? `Lead the king or queen of ${SUIT_NAME[s.meldSuit]}` : s.trick.length ? "Your turn to follow" : "Your lead")
      : down.includes(s.turn) ? `Waiting for ${name(s.turn)} to come back` : `${name(s.turn)} to play`;

  if (s.phase === "scored" && seen) return html`<${Result} s=${s} seat=${seat} name=${name} act=${act} canDeal=${canDeal} audit=${audit}/>`;

  return html`
    <div class="game">
      <${Side} s=${s} i=${opp} p=${person(opp)} label=${name(opp)} hidden=${p.memory} away=${down.includes(opp)} turn=${s.turn === opp && s.phase === "play"}>
        <span class="backs" aria-label=${`${(s.hands[opp] || []).length} cards`}>${(s.hands[opp] || []).map((_, k) => html`<${Back} key=${k} size="xs"/>`)}</span>
      <//>

      <div class="felt">
        <${Stock} s=${s}/>
        <${Trick} s=${s} seat=${seat} name=${name}/>
      </div>

      <${Side} s=${s} i=${seat} p=${person(seat)} label="You" turn=${myTurn} mine/>

      <p class=${"status" + (myTurn ? " go" : "")} role="status">${status}</p>

      ${s.phase === "scored"
        ? html`<div class="acts"><button class="btn primary" onClick=${() => setSeen(true)}>See the score</button></div>`
        : html`<${Actions} s=${s} seat=${seat} act=${act} on=${myTurn}/>`}

      <div class="hand" role="group" aria-label="Your hand">
        ${sortHandDisplay(s.hands[seat] || [], s.trump).map(c => html`<${Card} key=${c.id} c=${c} size="lg"
          sel=${sel === c.id} dim=${myTurn && !legal.has(c.id)} legal=${myTurn && legal.has(c.id)} trump=${c.suit === s.trump}
          onClick=${() => pick(c)} label=${`${displayRank(c.rank)} of ${SUIT_NAME[c.suit]}${sel === c.id ? ", tap again to play" : ""}`}/>`)}
      </div>
      <p class="hint">${myTurn ? (sel ? "Tap it again to play" : "Tap a card, then tap again to play") : " "}</p>
    </div>`;
}

function Side({ s, i, p, label, hidden, away, turn, mine, children }) {
  const pts = effPts(s, i);
  const waiting = s.meldPts[i] > 0 && s.tricksWon[i] === 0;
  return html`
    <div class=${"side" + (turn ? " turn" : "") + (mine ? " mine" : "")}>
      <${Avatar} p=${p}/>
      <span class="sname">${label}${away ? html` <em>away</em>` : ""}</span>
      ${children}
      <span class="stat"><b>${s.tricksWon[i]}</b> ${s.tricksWon[i] === 1 ? "trick" : "tricks"}</span>
      <span class="stat pts">${hidden && !mine ? html`<b>?</b>` : html`<b>${pts}</b>`} pts${waiting ? html`<i title="Marriage points count once a trick is won"> +${s.meldPts[i]}</i>` : ""}</span>
    </div>`;
}

function Stock({ s }) {
  const left = stockLeft(s);
  return html`
    <div class="stock" aria-label=${`Stock: ${left} cards. Trumps are ${SUIT_NAME[s.trump]}.`}>
      <div class="pile">
        ${s.up && html`<span class="upcard"><${Card} c=${s.up} size="sm"/></span>`}
        ${s.stock.length > 0 ? html`<${Back} size="sm" struck=${s.closed}/>` : !s.up && html`<span class="card z-sm gone"></span>`}
      </div>
      <span class="slabel">${s.closed ? "Closed" : left ? `${left} left` : "Empty"}</span>
      <span class="trump">Trumps <${Suit} s=${s.trump}/></span>
    </div>`;
}

function Trick({ s, seat, name }) {
  if (s.trick.length) {
    const t = s.trick[0];
    return html`<div class="trick">
      <span class=${"tslot " + (t.seat === seat ? "me" : "them")}><${Card} c=${t.card}/></span>
      <span class="tcap">${t.seat === seat ? "You led" : `${name(t.seat)} led`}</span>
    </div>`;
  }
  if (s.lastTrick) {
    const lt = s.lastTrick;
    return html`<div class="trick last">
      ${lt.trick.map(x => html`<span key=${x.card.id} class=${"tslot " + (x.seat === seat ? "me" : "them") + (x.seat === lt.winner ? " won" : "")}><${Card} c=${x.card}/></span>`)}
      <span class="tcap">${lt.winner === seat ? "You" : name(lt.winner)} took ${lt.pts}</span>
    </div>`;
  }
  return html`<div class="trick"><span class="tcap">${s.turn === seat ? "Lead any card" : `${name(s.turn)} leads`}</span></div>`;
}

function Actions({ s, seat, act, on }) {
  const [arm, setArm] = useState(false);
  useEffect(() => setArm(false), [s.turn, (s.log || []).length]);
  if (!on) return html`<div class="acts"></div>`;
  const ex = RULES.canExchange(s, seat);
  const cl = RULES.canClose(s, seat);
  const melds = RULES.meldOptions(s, seat);
  const claim = s.strictClaim && RULES.canClaim(s, seat);
  const low = ENG.exchangeRank();
  return html`<div class="acts">
    ${melds.map(m => html`<button key=${m.suit} class="btn meld" onClick=${() => act({ type: "MELD", seat, suit: m.suit })}>Declare ${m.value} <${Suit} s=${m.suit}/></button>`)}
    ${ex && html`<button class="btn" onClick=${() => act({ type: "EXCHANGE", seat })}>Swap ${displayRank(low)}<${Suit} s=${s.trump}/> for the turn-up</button>`}
    ${cl && (arm
      ? html`<button class="btn warn" onClick=${() => act({ type: "CLOSE", seat })}>Tap again to close</button>`
      : html`<button class="btn" onClick=${() => setArm(true)}>Close the stock</button>`)}
    ${claim && html`<button class="btn" onClick=${() => act({ type: "CLAIM", seat })}>Declare 66</button>`}
  </div>`;
}

function Result({ s, seat, name, act, canDeal, audit }) {
  const ready = audit !== null;                       // online: the next deal opens once both sides are settled
  const r = s.result; const won = r.winner === seat;
  const o = other(seat);
  return html`
    <div class="result">
      <h2 class=${won ? "won" : "lost"}>${r.head}</h2>
      <p class="gp"><b>+${r.gp}</b> ${r.winner === seat ? "to you" : `to ${name(r.winner)}`}</p>
      <p>${r.why}</p>
      <dl class="tally">
        <dt>Card points</dt><dd>${r.pts[seat]} – ${r.pts[o]}</dd>
        <dt>Tricks</dt><dd>${r.tricks[seat]} – ${r.tricks[o]}</dd>
        ${r.closedBy != null && html`<dt>Closed by</dt><dd>${name(r.closedBy)}, with ${name(other(r.closedBy))} on ${r.closeSnap ? r.closeSnap.pts : 0}</dd>`}
      </dl>
      ${r.schwarz && html`<p class="note">${name(other(r.winner))} didn't take a single trick.</p>`}
      <${ScoreLine} s=${s} seat=${seat} name=${name}/>
      ${s.bummerlDone
        ? html`<p class="bummerl">${name(s.bummerlWinner)} ${s.bummerlWinner === seat ? "win" : "wins"} the Bummerl ${s.gp[s.bummerlWinner]}–${s.gp[other(s.bummerlWinner)]}${s.schneiderBummerl ? ", Schneider" : ""}.</p>`
        : html`<p class="muted">${Math.max(0, s.target - s.gp[seat])} more and the Bummerl is yours.</p>`}
      <div class="acts">
        ${canDeal
          ? (s.bummerlDone
            ? html`<button class="btn primary" disabled=${!ready} onClick=${() => act({ type: "NEW_BUMMERL" })}>New Bummerl</button>`
            : html`<button class="btn primary" disabled=${!ready} onClick=${() => act({ type: "NEXT_DEAL" })}>Next deal</button>`)
          : html`<p class="muted">Waiting for the next deal</p>`}
      </div>
    </div>`;
}

export function ScoreLine({ s, seat, name }) {
  const o = other(seat);
  return html`<table class="sheet-t">
    <thead><tr><th>Deal</th><th>${name(seat)}</th><th>${name(o)}</th></tr></thead>
    <tbody>${(s.sheet || []).map(r => html`<tr key=${r.dealNo}><td>${r.dealNo}</td><td>${r.winner === seat ? "+" + r.gp : ""}</td><td>${r.winner === o ? "+" + r.gp : ""}</td></tr>`)}</tbody>
    <tfoot><tr><td>Total</td><td>${s.gp[seat]}</td><td>${s.gp[o]}</td></tr></tfoot>
  </table>`;
}

/* The public record of the deal, newest first. */
export function DealLog({ s }) {
  const lines = publicView(s).log;
  return lines.length ? html`<ol class="log">${lines.map((l, i) => html`<li key=${i}>${l}</li>`)}</ol>`
    : html`<p class="muted">Nothing played yet this deal.</p>`;
}

/* What a watcher sees: the public view the host shares — scores, whose turn, the last few plays. */
export function Watch({ pub, seats }) {
  if (!pub) return html`<p class="muted pad">The game hasn't started.</p>`;
  return html`<div class="watch">
    <p class="status">${pub.status}</p>
    <ul class="wseats">${pub.seats.map((x, i) => html`<li key=${i}><${Avatar} p=${seats[i] || { name: x.name }}/><b>${x.name}</b><span>${x.score} of ${pub.target}</span><small>${x.note}</small></li>`)}</ul>
    <p class="muted">${pub.stockCount ? `${pub.stockCount} cards in the stock` : "Stock is out"}${pub.pileTop ? `, ${pub.pileTop} on the table` : ""}</p>
    <ol class="log">${(pub.log || []).map((l, i) => html`<li key=${i}>${l}</li>`)}</ol>
  </div>`;
}
