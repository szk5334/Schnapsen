import { html, useState, useEffect, useRef } from "../../vendor/preact.js";
import { initials, cleanName } from "../util.js";
import { me, setName } from "../ident.js";

export function Avatar({ p, ring, size }) {
  const name = (p && p.name) || "?";
  return html`<span class=${"av" + (ring ? " ring" : "") + (size ? " " + size : "")} style=${"--c:" + ((p && p.color) || "#888")} aria-hidden="true">${initials(name)}</span>`;
}

/* A bottom sheet. Closes on the backdrop and on Escape. */
export function Sheet({ title, onClose, children }) {
  useEffect(() => {
    const f = e => { if (e.key === "Escape") onClose && onClose(); };
    addEventListener("keydown", f); return () => removeEventListener("keydown", f);
  }, []);
  return html`
    <div class="scrim" onClick=${onClose}>
      <div class="sheet" role="dialog" aria-modal="true" aria-label=${title} onClick=${e => e.stopPropagation()}>
        <div class="sheet-head"><h2>${title}</h2>${onClose && html`<button class="x" onClick=${onClose} aria-label="Close">Close</button>`}</div>
        ${children}
      </div>
    </div>`;
}

/* Segmented choice. */
export function Seg({ value, opts, onPick, label }) {
  return html`<div class="seg" role="radiogroup" aria-label=${label}>
    ${opts.map(o => html`<button key=${o.v} role="radio" aria-checked=${value === o.v} class=${value === o.v ? "on" : ""}
      onClick=${() => onPick(o.v)}>${o.l}</button>`)}
  </div>`;
}

export function NameSheet({ onDone, first }) {
  const [v, setV] = useState(me.get().name || "");
  const ref = useRef(null);
  useEffect(() => { ref.current && ref.current.focus(); }, []);
  const ok = cleanName(v).length > 0;
  const save = e => { e.preventDefault(); if (!ok) return; setName(v); onDone && onDone(); };
  const body = html`
    <form class="name-form" onSubmit=${save}>
      <label for="nm">${first ? "Pick a name the table will see." : "Your name at the table"}</label>
      <input id="nm" ref=${ref} value=${v} maxlength="16" autocomplete="nickname" enterkeyhint="done"
        onInput=${e => setV(e.currentTarget.value)}/>
      <button class="btn primary" disabled=${!ok}>${first ? "Come in" : "Save"}</button>
    </form>`;
  if (first) return html`<div class="screen gate"><h1 class="mark big">Schnapsen</h1><p class="lede">A race to 66 for two, with whoever you like.</p>${body}</div>`;
  return html`<${Sheet} title="Your name" onClose=${onDone}>${body}<//>`;
}
