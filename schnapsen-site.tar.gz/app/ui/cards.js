import { html } from "../../vendor/preact.js";
import { useCell } from "./hooks.js";
import { prefs } from "../ident.js";
import { ORNAMENT_DEFS } from "./ornament.js";
import { SUIT_NAME, displayRank } from "../../schnapsen/state/constants.js";

/* THE FOUR SUITS, drawn rather than typed. No text font in the stack carries suit symbols, so a phone fills them
 * in from whatever symbol font it has, and the heart often comes from a different one than the other three,
 * a size larger. Drawn shapes are the same size everywhere. All four share one 100 x 100 box and are balanced
 * by eye: the heart and the diamond are a little narrower than the box because they are solid all the way out. */
const SUIT_PATH = {
  S: "M50 5C61 24 91 38 91 59C91 73 80 81 68 81C61 81 56 78 53 74C54 83 58 89 65 95H35C42 89 46 83 47 74C44 78 39 81 32 81C20 81 9 73 9 59C9 38 39 24 50 5Z",
  H: "M50 90C22 67 9 53 9 34C9 20 19 11 31 11C39 11 46 16 50 24C54 16 61 11 69 11C81 11 91 20 91 34C91 53 78 67 50 90Z",
  D: "M50 5L85 50L50 95L15 50Z",
  C: "M50 6A20 20 0 0 1 66 38A20 20 0 1 1 55 72C56 82 59 89 66 95H34C41 89 44 82 45 72A20 20 0 1 1 34 38A20 20 0 0 1 50 6Z",
};
const HEART_T = "translate(50 52) scale(.92) translate(-50 -52)";
export function SuitIcon({ s }) {
  return html`<svg class="sg" viewBox="0 0 100 100" aria-hidden="true" focusable="false"><path d=${SUIT_PATH[s] || ""} transform=${s === "H" ? HEART_T : null}/></svg>`;
}
/* A PIP on a card face: dark in the core, the suit colour through the middle, fading to near-white just inside
 * the edge, with an outline a shade darker than the middle (gradients and the edge filter are in ornament.js).
 * It is what makes the pips stand clear of the ornament. */
const PIP_LINE = { S: "#1a3489", H: "#a8180f", D: "#8a6200", C: "#15693a" };
/* The corner number, painted like a pip: same gradient, same fade inside the edge, same outline. Drawn as SVG
 * text in the page's bold face so it can take the gradient and the edge filter. */
export function RankMark({ r, s }) {
  const T = (extra) => html`<text x="50" y="74" text-anchor="middle" font-size="88" font-weight="700" letter-spacing=${r.length > 1 ? -9 : 0}
    font-family="Josefin Sans, Futura, Century Gothic, system-ui, sans-serif" ...${extra}>${r}</text>`;
  return html`<svg class="rk" viewBox="0 0 100 80" aria-hidden="true" focusable="false">
    ${T({ fill: `url(#pip-g-${s})`, filter: "url(#rk-edge)" })}
    ${T({ fill: "none", stroke: PIP_LINE[s], "stroke-width": 3.4, "stroke-linejoin": "round" })}</svg>`;
}
export function PipIcon({ s }) {
  const t = s === "H" ? HEART_T : null, d = SUIT_PATH[s] || "";
  return html`<svg class="sg pipg" viewBox="-4 -4 108 108" aria-hidden="true" focusable="false">
    <path d=${d} transform=${t} fill=${`url(#pip-g-${s})`} filter="url(#pip-edge)"/>
    <path d=${d} transform=${t} fill="none" stroke=${PIP_LINE[s]} stroke-width="4" stroke-linejoin="round"/></svg>`;
}

/* THE STANDARD FRENCH PIP LAYOUTS. Positions are in a pip field: x 0 (left column) to 1 (right), y 0 (top
 * row) to 1 (bottom row). Pips below the middle are printed upside down, as on any real deck.
 *   2, 3     one centre column        4        the four corners
 *   9        four down each side, one in the centre     10    four down each side, two in the centre column
 * House tables print the J, Q and K as 2, 3 and 4, so those cards get the 2, 3 and 4 patterns. On classic
 * tables they stay court cards: the traditional double-headed figures, cut from the vector poker deck (see
 * gen/courts.py; the suit marks inside each panel are recoloured to the house four colours). */
const T3 = [0, 1 / 3, 2 / 3, 1];
const PIPS = {
  "2": [[.5, 0], [.5, 1]],
  "3": [[.5, 0], [.5, .5], [.5, 1]],
  "4": [[0, 0], [1, 0], [0, 1], [1, 1]],
  "9": [...T3.map(y => [0, y]), ...T3.map(y => [1, y]), [.5, .5]],
  "10": [...T3.map(y => [0, y]), ...T3.map(y => [1, y]), [.5, 1 / 6], [.5, 5 / 6]],
};
function Face({ c }) {
  const r = displayRank(c.rank);
  if (r === "0") return null;                                       // the house 0: corner index only, no pips
  if (r === "A") return html`<span class="pp ace" aria-hidden="true"><${PipIcon} s=${c.suit}/></span>`;
  const pips = PIPS[r];
  if (!pips) return html`<span class="court" aria-hidden="true"><img src=${`app/courts/${c.rank}${c.suit}.webp`} alt="" decoding="async" draggable="false"/></span>`;
  return pips.map(([x, y], k) => html`<span key=${k} class=${"pp" + (y > .5 ? " inv" : "")} style=${`--x:${x};--y:${y}`} aria-hidden="true"><${PipIcon} s=${c.suit}/></span>`);
}

/* The ornament is defined once for the page and drawn on every face with <use>, so a full hand costs a few
 * small elements, not thousands of paths. */
if (typeof document !== "undefined" && !document.getElementById("orn-half")) document.body.insertAdjacentHTML("afterbegin", ORNAMENT_DEFS);
/* Behind each face: its own cutout from a Cooper Hewitt wallpaper (Smithsonian Open Access, CC0), tinted slightly
 * toward its suit and laid faintly, fading toward the middle so the pips stand clear, under the gold frame
 * (tools/prints.py makes app/prints/). Each 9 has its own paper; on house tables it is the 0. */
/* Two sets, picked per phone in the menu: the wallpaper in its own colours ("print"), or the same papers as
 * one-colour sun prints in the suit's ink ("cyano", app/cyano/). */
const FACE_SET = { print: { dir: "prints", op: ".62" }, cyano: { dir: "cyano", op: ".55" } };
const Ornament = ({ c }) => {
  const p = useCell(prefs) || {};
  const set = FACE_SET[p.faces] || FACE_SET.print;
  return html`<svg class="orn" viewBox="0 0 250 350" preserveAspectRatio="none" aria-hidden="true" focusable="false">
  <g opacity=${set.op}><image href=${`app/${set.dir}/${c.rank}${c.suit}.webp`} x="10" y="10" width="230" height="330" preserveAspectRatio="xMidYMid slice" mask=${displayRank(c.rank) === "0" ? null : "url(#wp-fade)"}/></g>
  <use href="#orn-frame"/></svg>`;
};

/* One card. Four-colour suits; corner indices top left and, upside down, bottom right. */
/* HIGH VISIBILITY FACE: no pips, no courts. The rank as large as the card is wide, the suit as large under it,
 * over the card's paper (wallpaper or sun print, per the menu), with a soft ivory halo so both stand clear of it. */
function BigFace({ c }) {
  const r = displayRank(c.rank);
  return html`<span class=${"bf" + (r.length > 1 ? " two" : "")} aria-hidden="true"><b>${r}</b><${SuitIcon} s=${c.suit}/></span>`;
}

export function Card({ c, size = "md", sel, dim, legal, trump, onClick, label }) {
  const p = useCell(prefs) || {};
  if (!c || c.back) return html`<${Back} size=${size}/>`;
  const cls = ["card", "s-" + c.suit, "z-" + size, sel && "sel", dim && "dim", legal && "legal", trump && "trump", p.big && "hv"].filter(Boolean).join(" ");
  const name = `${displayRank(c.rank)} of ${SUIT_NAME[c.suit]}`;
  const ix = cl => html`<span class=${cl} aria-hidden="true"><b>${displayRank(c.rank)}</b><i><${PipIcon} s=${c.suit}/></i></span>`;
  const face = p.big ? html`${size !== "xs" && html`<${Ornament} c=${c}/>`}<${BigFace} c=${c}/>`
    : html`${size !== "xs" && html`<${Ornament} c=${c}/>`}${ix("ix")}<${Face} c=${c}/>${ix("ix br")}`;
  return onClick
    ? html`<button class=${cls} onClick=${onClick} aria-label=${label || name} aria-pressed=${!!sel}>${face}</button>`
    : html`<span class=${cls} role="img" aria-label=${label || name}>${face}</span>`;
}

/* The back: one Cooper Hewitt paper for every card (the lilies, CHSDM-154584), in the same style as the faces:
 * the wallpaper as it is, or a Prussian-blue sun print (pale ground, blue lilies). A gold frame
 * and a "66" cartouche sit on top. The tiny backs that count the opponent's hand are a flat wash of the same. */
const BACK_SET = { print: { img: "app/backs/back-print.webp", pill: "#f6efdc", ink: "#6b3a52" }, cyano: { img: "app/backs/back-cyano.webp", pill: "#f6f0e2", ink: "#102e68" } };
export function Back({ size = "md", struck }) {
  const p = useCell(prefs) || {};
  const set = BACK_SET[p.faces] || BACK_SET.print;
  const cls = "card back z-" + size + (struck ? " struck" : "") + (p.faces === "cyano" ? " cy" : "");
  return html`<span class=${cls} aria-hidden="true">${size !== "xs" && html`<svg class="orn" viewBox="0 0 250 350" preserveAspectRatio="none" focusable="false">
    <image href=${set.img} x="0" y="0" width="250" height="350" preserveAspectRatio="xMidYMid slice"/>
    <use href="#orn-frame"/>
    <rect x="82" y="152" width="86" height="46" rx="23" fill=${set.pill} stroke="#c99a2e" stroke-width="3"/>
    <rect x="88" y="158" width="74" height="34" rx="17" fill="none" stroke="#7a5a14" stroke-width="1"/>
    <text x="125" y="186" text-anchor="middle" font-family="Limelight, Georgia, serif" font-size="28" fill=${set.ink}>66</text></svg>`}</span>`;
}

export function Tok({ c }) {
  if (!c || c.back) return html`<span class="tok">?</span>`;
  return html`<span class=${"tok s-" + c.suit} aria-label=${`${displayRank(c.rank)} of ${SUIT_NAME[c.suit]}`}>${displayRank(c.rank)}<${SuitIcon} s=${c.suit}/></span>`;
}
export function Suit({ s }) { return html`<span class=${"tok s-" + s} aria-label=${SUIT_NAME[s]}><${SuitIcon} s=${s}/></span>`; }
