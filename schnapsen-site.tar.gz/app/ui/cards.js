import { html } from "../../vendor/preact.js";
import { SUIT_GLYPH, SUIT_NAME, displayRank } from "../../schnapsen/state/constants.js";

/* One card. Four-colour suits; the index is the only type on the face. */
export function Card({ c, size = "md", sel, dim, legal, trump, onClick, label }) {
  if (!c || c.back) return html`<${Back} size=${size}/>`;
  const cls = ["card", "s-" + c.suit, "z-" + size, sel && "sel", dim && "dim", legal && "legal", trump && "trump"].filter(Boolean).join(" ");
  const name = `${displayRank(c.rank)} of ${SUIT_NAME[c.suit]}`;
  const face = html`
    <span class="ix"><b>${displayRank(c.rank)}</b><i>${SUIT_GLYPH[c.suit]}</i></span>
    <span class="pip" aria-hidden="true">${SUIT_GLYPH[c.suit]}</span>`;
  return onClick
    ? html`<button class=${cls} onClick=${onClick} aria-label=${label || name} aria-pressed=${!!sel}>${face}</button>`
    : html`<span class=${cls} role="img" aria-label=${label || name}>${face}</span>`;
}

export function Back({ size = "md", struck }) {
  return html`<span class=${"card back z-" + size + (struck ? " struck" : "")} aria-hidden="true"></span>`;
}

/* Inline token for logs and messages: K♥ in its suit colour. */
export function Tok({ c }) {
  if (!c || c.back) return html`<span class="tok">?</span>`;
  return html`<span class=${"tok s-" + c.suit}>${displayRank(c.rank)}${SUIT_GLYPH[c.suit]}</span>`;
}
export function Suit({ s }) { return html`<span class=${"tok s-" + s}>${SUIT_GLYPH[s]}</span>`; }
