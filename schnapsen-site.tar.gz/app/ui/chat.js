import { html, useState, useRef, useEffect, useLayoutEffect } from "../../vendor/preact.js";
import { useCell, useTick } from "./hooks.js";
import { clock } from "../util.js";
import { me } from "../ident.js";

/* The chat panel. Lines, not bubbles: name in the speaker's colour, text after it, consecutive lines
 * from one person folded together. */
export function ChatPanel({ chat, placeholder = "Say something", empty, onSent }) {
  const st = useCell(chat ? chat.state : null);
  const people = useCell(chat ? chat.mesh.people : null) || [];
  const w = useCell(me);
  const listRef = useRef(null);
  const stick = useRef(true);
  const [txt, setTxt] = useState("");
  useTick(2000);

  const msgs = (st && st.messages) || [];
  useLayoutEffect(() => {
    const el = listRef.current; if (el && stick.current) el.scrollTop = el.scrollHeight;
  }, [msgs.length]);
  const onScroll = e => { const el = e.currentTarget; stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 40; };

  const now = Date.now();
  const typers = st ? people.filter(p => !p.self && st.typing[p.cid] > now).map(p => p.name || "Someone") : [];

  const submit = e => {
    e && e.preventDefault();
    if (!txt.trim() || !chat) return;
    chat.send(txt); setTxt(""); stick.current = true;
    onSent && onSent();
  };

  let prev = null;
  return html`
    <section class="chat" aria-label="Chat">
      <ol class="msgs" ref=${listRef} onScroll=${onScroll} aria-live="polite">
        ${msgs.length === 0 && html`<li class="sys">${empty || "Nothing said yet."}</li>`}
        ${msgs.map(m => {
          const fold = prev && prev.cid === m.cid && m.ts - prev.ts < 5 * 60e3;
          prev = m;
          const mine = m.cid === w.cid;
          return html`<li key=${m.id} class=${"msg" + (fold ? " fold" : "") + (mine ? " mine" : "")}>
            ${!fold && html`<span class="who" style=${"color:" + (m.color || "inherit")}>${m.name || "Someone"}</span>`}
            <span class="txt">${m.text}</span>
            ${!fold && html`<time>${clock(m.ts)}</time>`}
          </li>`;
        })}
      </ol>
      <p class="chat-meta">
        ${typers.length ? `${typers.join(", ")} ${typers.length > 1 ? "are" : "is"} typing…` : ""}
      </p>
      <form class="composer" onSubmit=${submit}>
        <input value=${txt} placeholder=${placeholder} maxlength="500" enterkeyhint="send" autocomplete="off"
          aria-label="Message" onInput=${e => { setTxt(e.currentTarget.value); chat && chat.typing(); }}/>
        <button class="btn" disabled=${!txt.trim()}>Send</button>
      </form>
    </section>`;
}

/* The game's chat drawer: one line showing the latest message, tap to open the full panel. */
export function ChatDrawer({ chat }) {
  const st = useCell(chat ? chat.state : null);
  const [open, setOpen] = useState(false);
  const msgs = (st && st.messages) || [];
  const [seen, setSeen] = useState(msgs.length);
  const w = useCell(me);
  useEffect(() => { if (open) setSeen(msgs.length); }, [open, msgs.length]);
  if (!chat) return null;
  const unread = Math.max(0, msgs.slice(seen).filter(m => m.cid !== w.cid).length);
  const last = msgs[msgs.length - 1];
  return html`
    <div class=${"drawer" + (open ? " open" : "")}>
      <button class="drawer-bar" onClick=${() => setOpen(!open)} aria-expanded=${open}>
        ${last && !open ? html`<span class="who" style=${"color:" + last.color}>${last.name}</span><span class="txt">${last.text}</span>`
               : html`<span class="txt">Table chat</span>`}
        ${unread > 0 && !open ? html`<b class="badge">${unread}</b>` : html`<span class="chev">${open ? "Close" : "Chat"}</span>`}
      </button>
      ${open && html`<div class="drawer-body"><${ChatPanel} chat=${chat} placeholder="Message the table" empty="Talk to the table here."/></div>`}
    </div>`;
}
