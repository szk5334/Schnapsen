/* A TABLE SESSION — one game seen from this device.
 *
 *   solo    you against a bot, entirely on this device
 *   online  two people, two devices, no host. The person who opened the table arranges the seats and
 *           options; once the cards are dealt, both devices are equals. Each runs the same engine on its
 *           own view of the deal, the deck is shuffled by mental poker (mp/), and moves travel straight
 *           between the two devices. Nobody — not the other player, not a watcher, not a server — can
 *           see a card the rules haven't shown them.
 *
 * The table's arrangement lives in its OWNER's presence, so an unstarted table exists exactly while its
 * owner is here. A started game lives on both players' devices and survives either one reloading.
 */
import { freshBummerl, botAction, SETUP } from "../schnapsen/state/reducer.js";
import { reducer, withHouse, houseDeal } from "./house.js";
import { publicView } from "../schnapsen/engine/redact.js";
import { ENG } from "../schnapsen/engine/core.js";
import { LS, uid, cell, makeCode, nudge } from "./util.js";
import { me } from "./ident.js";
import { openMesh } from "./net/mesh.js";
import { openChat } from "./chat.js";
import { openMatch } from "./mp/match.js";

export const DEFAULT_OPTS = { target: 7, variant: "classic", house: true, piles: "up", strict: false, bot: "fritzl", private: false };
export const SESSION_KEY = "sx.session";

/* ------------------------------------------------------------------ the bot clock (solo) */
function botClock(get, dispatch) {
  let timer = null;
  return function tick() {
    clearTimeout(timer);
    const s = get();
    if (!s || s.mode !== "play" || s.phase !== "play" || s.brains[s.turn] === "human") return;
    /* The beat: when a trick has just resolved, both cards sit face-up while you add them up. Counting
     * to 66 is the game, so the bot waits before it leads to the next trick. */
    const justResolved = !(s.trick || []).length && !!s.lastTrick;
    timer = setTimeout(() => {
      if (get() !== s) return;
      const d = botAction(s, s.turn);
      if (d && d.action) dispatch(d.action);
    }, justResolved ? 1600 : 650);
  };
}

const startState = (o, brains, names) => {
  const variant = o.variant === "24" ? "24" : "classic";
  ENG.setVariant(variant);
  return houseDeal(withHouse(freshBummerl({ ...SETUP, variant, strictClaim: !!o.strict, bummerlNo: 0 }, brains, names, o.target, 0), o));
};

/* ------------------------------------------------------------------ solo */
export function openSolo(opts = {}) {
  const o = { ...DEFAULT_OPTS, ...opts };
  const st = cell({ role: "solo", seat: 0, s: null });
  const saved = opts.fresh ? null : LS.get("sx.solo");
  let s = saved && saved.mode === "play" ? saved : startState(o, ["human", o.bot], [me.get().name || "You", ""]);
  const commit = n => { s = n; LS.set("sx.solo", s); st.set(v => ({ ...v, s })); tick(); };
  const dispatch = a => commit(reducer(s, a));
  const tick = botClock(() => s, dispatch);
  commit(s);
  return { state: st, act: dispatch, leave() { LS.set("sx.solo", s); } };
}

/* ------------------------------------------------------------------ open a new table */
export function createTable(hub, opts = {}) {
  const code = makeCode(hub.tables.get().map(t => t.code));
  const w = me.get();
  const table = {
    code, ownerCid: w.cid,
    seats: [{ cid: w.cid, name: w.name, color: w.color }, null],
    opts: { ...DEFAULT_OPTS, ...opts },
    status: "open", matchId: null, createdAt: Date.now(),
  };
  LS.set("sx.own." + code, table);
  return code;
}

/* ------------------------------------------------------------------ join a table */
export function openTable(hub, code) {
  const who = () => me.get();
  const owned = LS.get("sx.own." + code);
  const owner = !!(owned && owned.ownerCid === who().cid);
  let table = owner ? owned : LS.get("sx.seen." + code);          // a joiner remembers the table it sat at
  const st = cell({ owner, code, table, seat: -1, view: null, people: [], found: owner || !!table, lost: false, closed: null, kicked: false, pub: null, oppHere: false });
  const mesh = openMesh(hub.p2p, "table-" + code, { presence: presence() });
  const chat = openChat(mesh, { me, persistKey: "t." + code });
  const offs = [];
  let match = null, matchOff = null, lastPub = null;

  function presence() {
    const w = who();
    return { cid: w.cid, name: w.name, color: w.color, ...(owner ? { owner: true, table } : {}) };
  }
  offs.push(me.sub(() => mesh.setPresence(presence())));
  const mySeat = () => (table ? table.seats.findIndex(x => x && x.cid === who().cid) : -1);
  const emit = () => st.set(x => ({ ...x, table, seat: mySeat() }));

  /* ---- the game itself: open (or resume) the match once the table says it's dealt ---- */
  function syncMatch() {
    const seat = mySeat();
    const want = table && table.status === "playing" && table.matchId && seat >= 0;
    if (want && (!match || match.matchId !== table.matchId)) {
      closeMatch();
      const config = { matchId: table.matchId, seats: table.seats, opts: table.opts };
      const opp = table.seats[1 - seat];
      match = openMatch({ mesh, code, config, seat, peerCid: opp.cid });
      match.matchId = table.matchId;
      let prevTurn = null;
      const onView = v => {
        st.set(x => ({ ...x, view: v }));
        const s = v && v.s;
        if (s && s.phase === "play" && s.turn === seat && prevTurn !== s.turn && !v.waitingCards) nudge("Your turn");
        prevTurn = s && s.turn;
        /* Watchers get the public view: scores, whose turn, what has been played. Never a hand. It is only
         * sent while somebody other than the two players is at the table (a newcomer gets the latest copy on
         * arrival), and the lobby listing only changes when the score does — relays count every message. */
        if (s) {
          const pub = publicView(s);
          if (s.phase === "play" && !s.trump) pub.status = pub.status.replace(/ · +trumps/, " · no trumps");
          const pv = JSON.stringify({ ...pub, gp: s.gp, target: s.target, house: !!s.house });
          if (pv !== lastPub) { lastPub = pv; if (watchers()) mesh.send("pub", JSON.parse(pv)); if (owner) advertise(s.gp); }
        }
      };
      matchOff = match.state.sub(onView);
      onView(match.state.get());
    } else if (!want && match) {
      closeMatch();
      st.set(x => ({ ...x, view: null }));
    }
  }
  function closeMatch() { if (matchOff) matchOff(); if (match) match.close(); match = null; matchOff = null; }

  const watchers = () => {
    const seated = new Set(((table && table.seats) || []).filter(Boolean).map(x => x.cid));
    return mesh.people.get().some(p => !p.self && p.cid && !seated.has(p.cid));
  };

  /* ---- owner: seats and options, until the deal ---- */
  let lastAd = "";
  const advertise = score => {
    const ad = JSON.stringify([table.status, table.opts, table.seats, score || null]);
    if (ad === lastAd) return;
    lastAd = ad;
    hub.setHosting({
      code, private: !!table.opts.private, status: table.status,
      seats: table.seats.map(x => (x ? { name: x.name, color: x.color } : null)),
      target: table.opts.target, variant: table.opts.variant, house: !!table.opts.house, score: score || null,
    });
  };
  const setTable = patch => {
    table = { ...table, ...patch };
    LS.set("sx.own." + code, table);
    emit(); mesh.setPresence(presence()); advertise(); syncMatch();
  };
  if (owner) {
    hub.setWhere("table:" + code);
    advertise();
    offs.push(mesh.on("sit", (d, from) => {
      if (!from.cid || !d || table.status !== "open") return;
      const seat = d.seat | 0;
      if (seat < 0 || seat >= table.seats.length || table.seats[seat]) return;
      if (table.seats.some(x => x && x.cid === from.cid)) return;
      const seats = table.seats.slice();
      seats[seat] = { cid: from.cid, name: String(from.name || "").slice(0, 16), color: from.color };
      setTable({ seats });
    }));
    offs.push(mesh.on("stand", (d, from) => {
      if (table.status !== "open") return;
      const seat = table.seats.findIndex(x => x && x.cid === from.cid);
      if (seat < 0 || from.cid === table.ownerCid) return;
      const seats = table.seats.slice(); seats[seat] = null; setTable({ seats });
    }));
  } else {
    hub.setWhere("table:" + code);
    offs.push(mesh.on("kick", (d, from) => { if (from.owner && d && d.cid === who().cid) st.set(x => ({ ...x, kicked: true })); }));
    offs.push(mesh.on("bye", (d, from) => { if (from.owner) st.set(x => ({ ...x, closed: "The table was closed." })); }));
    setTimeout(() => { if (!st.get().found) st.set(x => ({ ...x, lost: true })); }, 25000);
  }
  offs.push(mesh.onJoin(peerId => { if (match && lastPub) mesh.send("pub", JSON.parse(lastPub), peerId); }));   // a new watcher
  offs.push(mesh.on("pub", (d, from) => { if (from.cid && d && d.seats) st.set(x => ({ ...x, pub: d })); }));

  /* ---- everyone: follow the owner's presence and notice who's here ---- */
  offs.push(mesh.people.sub(list => {
    if (!owner) {
      const o = list.find(p => p.owner && p.table && p.table.code === code);
      if (o) { table = o.table; if (mySeat() >= 0) LS.set("sx.seen." + code, table); }
    }
    const seat = mySeat();
    const opp = table && seat >= 0 ? table.seats[1 - seat] : null;
    st.set(x => ({ ...x, people: list, table, seat, found: x.found || !!table, lost: x.lost && !table,
      ownerHere: owner || list.some(p => p.owner), oppHere: !!(opp && list.some(p => p.cid === opp.cid)) }));
    syncMatch();
  }));

  LS.set(SESSION_KEY, { code, at: Date.now() });
  emit(); syncMatch();

  return {
    state: st,
    chat: cell(chat),
    owner,
    mesh,
    act(a) { if (match) match.act(a); },
    sit(seat) { const o = mesh.people.get().find(p => p.owner); if (o) mesh.send("sit", { seat }, o.peerId); },
    stand() { const o = mesh.people.get().find(p => p.owner); if (o) mesh.send("stand", 1, o.peerId); },
    /* owner only */
    setOpts(patch) { if (owner && table.status === "open") setTable({ opts: { ...table.opts, ...patch } }); },
    start() { if (owner && table.seats.every(Boolean)) setTable({ status: "playing", matchId: uid() }); },
    toSeats() { if (owner && table.status === "playing") { if (match) match.forget(); setTable({ status: "open", matchId: null }); } },
    kick(cid) {
      if (!owner || table.status !== "open") return;
      setTable({ seats: table.seats.map(x => (x && x.cid === cid ? null : x)) });
      mesh.send("kick", { cid });
    },
    close() {
      if (!owner) return;
      mesh.send("bye", 1);
      if (match) match.forget();
      LS.del("sx.own." + code); LS.del(SESSION_KEY);
      hub.setHosting(null);
    },
    leave() {
      closeMatch();
      offs.forEach(f => { try { f(); } catch {} });
      chat.close(); mesh.leave();
      if (owner) hub.setHosting(null);
      hub.setWhere("lobby");
    },
  };
}
