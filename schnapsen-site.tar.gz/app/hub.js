/* THE HUB — the always-on part of the site: the lobby mesh (who is here, which tables are open) and
 * the lobby chat. One per page; screens read its cells.
 *
 * There is no table list stored anywhere. A host advertises its table in its own lobby presence, so a
 * table is listed exactly while its host is here, and vanishes the moment they leave. */
import { cell } from "./util.js";
import { me } from "./ident.js";
import { openMesh } from "./net/mesh.js";
import { openChat } from "./chat.js";

export function startHub(p2p) {
  const where = cell({ where: "lobby", hosting: null });
  const pres = () => ({ cid: me.get().cid, name: me.get().name, color: me.get().color, ...where.get() });
  const mesh = openMesh(p2p, "lobby", { presence: pres() });
  me.sub(() => mesh.setPresence(pres()));
  where.sub(() => mesh.setPresence(pres()));

  /* One row per person — a second tab of the same person adds nothing to the list. */
  const here = cell([]);
  const tables = cell([]);
  const fold = list => {
    const by = new Map();
    for (const x of list) {
      if (!x.cid) continue;
      const prev = by.get(x.cid);
      if (!prev || x.self || (x.hosting && !prev.hosting)) by.set(x.cid, { ...(prev || {}), ...x });
    }
    here.set([...by.values()]);
    tables.set([...by.values()].filter(x => x.hosting && !x.hosting.private)
      .map(x => ({ ...x.hosting, hostCid: x.cid, hostName: x.name, hostColor: x.color }))
      .sort((a, b) => (a.status === "open" ? 0 : 1) - (b.status === "open" ? 0 : 1)));
  };
  mesh.people.sub(fold);
  fold(mesh.people.get());

  const chat = openChat(mesh, { me, persistKey: "lobby" });

  return {
    p2p, mesh, here, tables, chat, where,
    setHosting(h) { where.set(w => ({ ...w, hosting: h })); },
    setWhere(w) { where.set(x => ({ ...x, where: w })); },
  };
}
