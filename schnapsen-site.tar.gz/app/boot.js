/* Boot: pick the transport, start the hub, mount the app.
 *
 *   default      Trystero (Nostr relays for introductions, WebRTC for everything else)
 *   ?local       the BroadcastChannel stand-in — try two-player on one device, in two tabs
 *
 * Optional settings come from /config.js (see config.example.js). The site works without it. */
import { html, render } from "../vendor/preact.js";
import { App } from "./ui/app.js";
import { startHub } from "./hub.js";
import { localP2P } from "./net/local.js";

const cfg = window.SX_CONFIG || {};
const local = new URLSearchParams(location.search).has("local");

async function iceServers() {
  if (cfg.iceServers && cfg.iceServers.length) return cfg.iceServers;
  if (!cfg.turnCredentialsUrl) return null;
  /* A TURN provider's credentials endpoint (e.g. Metered Open Relay). Give it four seconds; without TURN
   * most connections still work, so a slow answer must never hold up the page. */
  try {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 4000);
    const r = await fetch(cfg.turnCredentialsUrl, { signal: ctl.signal }); clearTimeout(t);
    const list = await r.json();
    return Array.isArray(list) ? list : null;
  } catch { return null; }
}

async function main() {
  let p2p;
  if (local) p2p = localP2P();
  else {
    const [{ trysteroP2P }, ice] = await Promise.all([import("./net/p2p.js"), iceServers()]);
    p2p = trysteroP2P({ ...cfg, turn: ice });
  }
  const hub = startHub(p2p);
  window.__sx = { hub };                       // handy in devtools
  render(html`<${App} hub=${hub}/>`, document.getElementById("app"));
}

main().catch(e => {
  console.error(e);
  document.getElementById("app").innerHTML = `<div class="screen center"><p>Something went wrong starting up.</p><pre class="err"></pre><button class="btn" onclick="location.reload()">Reload</button></div>`;
  document.querySelector(".err").textContent = String(e && e.message || e);
});
