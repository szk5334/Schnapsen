/* Boot: pick the transport, start the hub, mount the app.
 *
 *   default      sealed messages through public Nostr relays (net/relay.js); phones never connect directly
 *   ?local       the BroadcastChannel stand-in — try two-player on one device, in two tabs
 *
 * Optional settings come from /config.js (see config.example.js). The site works without it. */
import { html, render } from "../vendor/preact.js";
import { App } from "./ui/app.js";
import { startHub } from "./hub.js";
import { localP2P } from "./net/local.js";
import { relayP2P } from "./net/relay.js";
import { BUILD } from "./version.js";

const cfg = window.SX_CONFIG || {};
const local = new URLSearchParams(location.search).has("local");

function main() {
  const p2p = local ? localP2P() : relayP2P(cfg);
  const hub = startHub(p2p);
  window.__sx = { hub, BUILD };                // handy in devtools
  console.info("Schnapsen build", BUILD);
  render(html`<${App} hub=${hub}/>`, document.getElementById("app"));
}

try { main(); } catch (e) {
  console.error(e);
  document.getElementById("app").innerHTML = `<div class="screen center"><p>Something went wrong starting up.</p><pre class="err"></pre><button class="btn" onclick="location.reload()">Reload</button></div>`;
  document.querySelector(".err").textContent = String(e && e.message || e);
}
