/* Small shared helpers. No framework, no game knowledge. */

/* ?as=NAME gives a tab its own storage, so one device can play both seats (with ?local) while testing. */
const NS = (() => { try { const a = new URLSearchParams(location.search).get("as"); return a ? "as." + a + "." : ""; } catch { return ""; } })();
export const LS = {
  get(k, d = null) { try { const v = localStorage.getItem(NS + k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem(NS + k, JSON.stringify(v)); } catch {} },
  del(k) { try { localStorage.removeItem(NS + k); } catch {} },
};

export const uid = () =>
  (crypto.randomUUID ? crypto.randomUUID() : "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, c => {
    const r = (Math.random() * 16) | 0; return (c === "x" ? r : (r & 3) | 8).toString(16);
  }));

/* Table codes: four letters, no I or O, so they read aloud cleanly across a room. */
const CODE_ABC = "ABCDEFGHJKLMNPQRSTUVWXYZ";
export function makeCode(taken = []) {
  for (let n = 0; n < 50; n++) {
    let c = ""; for (let i = 0; i < 4; i++) c += CODE_ABC[(Math.random() * CODE_ABC.length) | 0];
    if (!taken.includes(c)) return c;
  }
  return "T" + Date.now().toString(36).slice(-3).toUpperCase();
}
export const cleanCode = s => (s || "").toUpperCase().replace(/[^A-Z]/g, "").slice(0, 4);

/* Every person gets a steady colour from their client id — chosen to read on the loden ground. */
const SWATCH = ["#d9a066", "#8fb8de", "#c48fbf", "#9fc98d", "#e0c35c", "#e48b7c", "#7fc9bd", "#b6a4e0"];
export function colorFor(id) {
  let h = 0; for (const ch of String(id || "")) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return SWATCH[h % SWATCH.length];
}
export function initials(name) {
  const p = String(name || "?").trim().split(/\s+/).filter(Boolean);
  if (!p.length) return "?";
  return (p.length === 1 ? p[0].slice(0, 2) : p[0][0] + p[1][0]).toUpperCase();
}
export const cleanName = s => String(s || "").replace(/\s+/g, " ").trim().slice(0, 16);

export function clock(ts) {
  const d = new Date(ts); return d.getHours() + ":" + String(d.getMinutes()).padStart(2, "0");
}

/* A tiny observable value. Components subscribe with useSignal() in ui/hooks.js. */
export function cell(v) {
  const subs = new Set();
  return {
    get: () => v,
    set(n) { if (typeof n === "function") n = n(v); if (n === v) return; v = n; subs.forEach(f => f(v)); },
    sub(f) { subs.add(f); return () => subs.delete(f); },
  };
}

export const sleep = ms => new Promise(r => setTimeout(r, ms));

/* Vibrate + flash the tab title when something needs you and the page is in the background. */
let titleTimer = null; const baseTitle = typeof document !== "undefined" ? document.title : "";
export function nudge(text) {
  try { if (navigator.vibrate && (!navigator.userActivation || navigator.userActivation.hasBeenActive)) navigator.vibrate(40); } catch {}
  if (typeof document === "undefined" || !document.hidden) return;
  clearInterval(titleTimer); let on = false;
  titleTimer = setInterval(() => { document.title = (on = !on) ? text : baseTitle; }, 900);
  const stop = () => { if (!document.hidden) { clearInterval(titleTimer); document.title = baseTitle; document.removeEventListener("visibilitychange", stop); } };
  document.addEventListener("visibilitychange", stop);
}
