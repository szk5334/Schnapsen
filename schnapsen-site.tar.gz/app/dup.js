/* DUPLICATE DEALS — the same cards again, the other way round.
 *
 * After a deal, either player can ask for it to be dealt again with the hands swapped: whoever held the leading
 * hand now holds the dealer's, and the other way round. The stock and the turned card come in the same order,
 * so each of you plays both sides of one deal and luck drops out of the comparison: add up what each of you
 * made over the pair.
 *
 *   The deal     The dealer alternates as always, so the hand that led still leads (now in the other player's
 *                hands). Same turned card, same stock order, same draws.
 *   Disguise     The suits are renamed at random so the cards don't look the same at a glance. Suits only
 *                swap with suits that hold the same ranks (in the 22 deck hearts and spades carry a 9, so they
 *                swap only with each other). The trump suit is renamed with the rest, so the deal plays out
 *                exactly as before.
 *   Once only    A duplicate can't be duplicated again (that would just be the first deal once more).
 *   Scoring      Both deals count on the sheet as usual (pot and all). The comparison leaves the pot out:
 *                it is what each deal paid on its own.
 *
 * Pure: solo (session.js) and online (mp/match.js) build the same deal from the same inputs. */
import { other } from "../schnapsen/engine/rules.js";

const cardsOf = d => [...d.hands[0], ...d.hands[1], ...(d.up ? [d.up] : []), ...d.stock];

/* A random renaming of the suits, only among suits holding the same ranks in this deal. */
export function dupPerm(d0, rnd = Math.random) {
  const sig = {};
  for (const c of cardsOf(d0)) (sig[c.suit] = sig[c.suit] || []).push(c.rank);
  const groups = {};
  for (const s of Object.keys(sig)) { const k = sig[s].sort().join(","); (groups[k] = groups[k] || []).push(s); }
  const perm = {};
  for (const g of Object.values(groups)) {
    const to = g.slice();
    for (let i = to.length - 1; i > 0; i--) { const j = (rnd() * (i + 1)) | 0; [to[i], to[j]] = [to[j], to[i]]; }
    g.forEach((s, i) => (perm[s] = to[i]));
  }
  return perm;
}

/* What a finished deal paid each seat, signed, without the pot. House rules: a deal nobody won is 0. */
export function dealValue(s, seat) {
  const hr = s.house && s.houseResult;
  if (hr) return hr.scoreless ? 0 : hr.winner === seat ? hr.gp : -hr.gp;
  const r = s.result;
  if (!r) return 0;
  return r.winner === seat ? r.gp : -r.gp;
}

/* Can this finished deal be dealt again? Not a duplicate itself, and we hold the deal as it was dealt. */
export const canDup = (s, d0) => !!(s && s.phase === "scored" && !s.dup && d0 && d0.hands);

/* The duplicate. `base` is the next deal as the table would deal it anyway (the dealer has alternated; score,
 * sheet and deal number are right); `d0` is the finished deal as it was dealt; `prev` the finished deal's
 * final state (for the comparison). Returns `base` with the old cards laid out the other way round. */
export function dupDeal(base, d0, perm, prev) {
  /* Every card of the old deal, by its NEW face: the renamed card is the old deal's own card of that rank and
   * suit, so ids stay ids of this pack (canonical positions online, the solo deck's ids in solo). */
  const byKey = {};
  for (const c of cardsOf(d0)) byKey[c.rank + "." + c.suit] = c;
  const map = c => {
    const n = byKey[c.rank + "." + (perm[c.suit] || c.suit)];
    if (!n) throw new Error("duplicate: no " + c.rank + " of " + perm[c.suit]);
    return { ...n };
  };
  const lead0 = other(d0.dealer), lead = other(base.dealer);
  const hands = { [lead]: d0.hands[lead0].map(map), [base.dealer]: d0.hands[d0.dealer].map(map) };
  const up = map(d0.up);
  const trump = up.suit;   // the turned card names trumps (house no-trumps dropped Nov 2026)
  return {
    ...base,
    hands, up, stock: d0.stock.map(map), trump,
    trick: [], turn: lead, lead,
    banner: `Deal ${base.dealNo || 1}: deal ${prev.dealNo || 1} again, the other way round.`,
    dup: {
      of: prev.dealNo || 1,
      bummerl: prev.bummerlNo || 1,
      lead: lead0,                                      // who held the leading hand the first time
      prev: [dealValue(prev, 0), dealValue(prev, 1)],   // what that deal paid each seat
    },
  };
}

/* The comparison, once the duplicate is over: per seat, the first deal, this one, and both together. */
export function dupTally(s) {
  if (!s.dup || s.phase !== "scored") return null;
  const now = [dealValue(s, 0), dealValue(s, 1)];
  const sum = [s.dup.prev[0] + now[0], s.dup.prev[1] + now[1]];
  return { of: s.dup.of, lead: s.dup.lead, prev: s.dup.prev, now, sum };
}

