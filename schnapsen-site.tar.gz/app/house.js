/* HOUSE RULES — Seth's Schnapsen, as a layer over the untouched engine.
 *
 *   The pack      20 cards shown by value: A, 10, 4, 3, 2 (the K, Q and J of the engine, relabelled).
 *   Trumps        The turned card always names trumps, an Ace included. (No-trump deals on a turned Ace were
 *                 dropped in Nov 2026: too luck-based. The engine still supports `trump = null`.)
 *   No 66, no score
 *                 A deal that runs out without anyone reaching 66 scores nothing (the engine would give the
 *                 last trick 1). It adds 1 to the pot instead; the pot stacks, and whoever scores the next
 *                 deal takes it on top of what they won.
 *   Open piles    Won cards lie face up, sorted into rank piles, so both scores are always public. A table
 *                 can agree to keep them face down instead (`piles: "down"`).
 *
 * The pot is never stored: it is the run of scoreless deals at the foot of the score sheet. That way it
 * travels with the sheet between deals, through reloads, and through the lockstep match, for free.
 */
import { reducer as baseReducer } from "../schnapsen/state/reducer.js";
import { other } from "../schnapsen/engine/rules.js";
import { ENG } from "../schnapsen/engine/core.js";

/* ROYAL HOUSE (Nov 2026) is a house table with the 32-card pack (`variant: "royal"`): 200 to go out, 100 the
 * Schneider line, three kinds of play and two marriages a suit. Everything below reads the pack's numbers from the engine, so it serves both. */
const DEALING = new Set(["START", "RESUME", "NEXT_DEAL", "NEW_BUMMERL"]);

/* The run of scoreless deals at the end of the sheet. */
export function potOf(sheet) {
  let n = 0;
  for (let i = (sheet || []).length - 1; i >= 0 && sheet[i].scoreless; i--) n++;
  return n;
}

/* Copy the table's house settings onto a state (freshBummerl rebuilds from scratch and drops them). */
export function withHouse(s, opts) {
  if (!opts || !opts.house) return s;
  return { ...s, house: true, piles: opts.piles === "down" ? "down" : "up", ...(ENG.normVariant(opts.variant) === "royal" ? { variant: "royal" } : {}) };
}
/* The three rule sets a table can play, as table options. */
export const RULESETS = {
  classic: { house: false, variant: "classic" },
  house:   { house: true,  variant: "classic" },
  royal:   { house: true,  variant: "royal" },
};
export const rulesetOf = o => !o || !o.house ? "classic" : ENG.normVariant(o.variant) === "royal" ? "royal" : "house";

/* A new deal under house rules: the turned card names trumps, as in the classic game. */
export function houseDeal(s) {
  if (!s || !s.house || !s.up || s.phase !== "play") return s;
  const lead = (s.names && s.names[other(s.dealer)]) || "";
  return { ...s, trump: s.up.suit, banner: s.banner || (lead ? `${lead} leads.` : "") };
}

/* Bank a finished deal the house way. `prev` is the state before the move that ended it. */
function houseSettle(prev, s) {
  const r = s.result;
  const sheet = (prev.sheet || []).slice();
  const gp = (prev.gp || [0, 0]).slice();
  const pot = potOf(sheet);
  const OUT = ENG.OUT, HALF = ENG.HALF;
  let winner = r.winner, won = r.gp, scoreless = false;
  if (r.reason === "exhausted") {
    /* Nobody went out. With "you declare" on, someone can finish over 66 without calling it: the cards are
     * public, so they are paid as if they had called. Otherwise the deal is scoreless and feeds the pot. */
    const p = r.pts[0] >= OUT ? 0 : r.pts[1] >= OUT ? 1 : -1;
    if (p < 0) scoreless = true;
    else { winner = p; const o = other(p); won = r.tricks[o] === 0 ? 3 : r.pts[o] < HALF ? 2 : 1; }
  }
  const row = { dealNo: s.dealNo, reason: r.reason, pts: [r.pts[0], r.pts[1]], closedBy: r.closedBy, trump: s.trump, ...(s.dup ? { dup: s.dup.of } : {}) };
  if (scoreless) {
    sheet.push({ ...row, winner: null, gp: 0, scoreless: true });
    return { ...s, gp, sheet, bummerlDone: false, bummerlWinner: null, schneiderBummerl: false,
      house: true, houseResult: { scoreless: true, pot: pot + 1 } };
  }
  gp[winner] += won + pot;
  sheet.push({ ...row, winner, gp: won + pot, pot });
  const done = s.target > 0 && gp[winner] >= s.target;
  return { ...s, gp, sheet, bummerlDone: done, bummerlWinner: done ? winner : null,
    schneiderBummerl: done && gp[other(winner)] === 0,
    houseResult: { winner, gp: won, pot, total: won + pot } };
}

/* The reducer every table uses. Classic tables pass straight through. */
export function reducer(state, a) {
  if (a && a.type === "__SYNC__") return a.state;
  const house = state && state.house;
  let next = baseReducer(state, a);
  if (!house || next === state) return next;
  if (!next.house) next = { ...next, house: true, piles: state.piles || "up", variant: state.variant || "classic" };
  if (DEALING.has(a.type) && next.mode === "play") next = houseDeal({ ...next, houseResult: null });
  if (next.phase === "scored" && next.roundEndedAt && !state.roundEndedAt && next.result) next = houseSettle(state, next);
  return next;
}

/* Every card a seat has won in tricks, from the public log. */
export function wonCards(s, seat) {
  const out = [];
  for (const e of s.log || []) if (e.k === "trick" && e.winner === seat) out.push(e.led, e.fol);
  return out;
}
