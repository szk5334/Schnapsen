/* HOUSE RULES — Seth's no-trump Schnapsen, as a layer over the untouched engine.
 *
 *   The pack      20 cards shown by value: A, 10, 4, 3, 2 (the K, Q and J of the engine, relabelled).
 *   No trumps     A turned-up Ace means the deal is played with no trump suit. Each of the five outcomes is
 *                 one in five. With no trumps there is nothing to swap for the turn-up and every marriage is 20.
 *                 The engine needs nothing for this: with `trump = null` no card is ever a trump.
 *   No 66, no score
 *                 A deal that runs out without anyone reaching 66 scores nothing (the engine would give the
 *                 last trick 1). It adds 1 to the pot instead; the pot stacks, and whoever scores the next
 *                 deal takes it on top of what they won.
 *   Open piles    Won cards lie face up, sorted into rank piles, so both scores are always public. A table
 *                 can agree to keep them face down instead (`piles: "down"`).
 *
 * The pot is never stored: it is the run of scoreless deals at the foot of the score sheet. That way it
 * travels with the sheet between deals, through reloads, and through the lockstep match, for free.
 */
import { reducer as baseReducer } from "../schnapsen/state/reducer.js";
import { other } from "../schnapsen/engine/rules.js";

const OUT = 66;
const DEALING = new Set(["START", "RESUME", "NEXT_DEAL", "NEW_BUMMERL"]);

/* The run of scoreless deals at the end of the sheet. */
export function potOf(sheet) {
  let n = 0;
  for (let i = (sheet || []).length - 1; i >= 0 && sheet[i].scoreless; i--) n++;
  return n;
}

/* Copy the table's house settings onto a state (freshBummerl rebuilds from scratch and drops them). */
export function withHouse(s, opts) {
  if (!opts || !opts.house) return s;
  return { ...s, house: true, piles: opts.piles === "down" ? "down" : "up" };
}

/* A new deal under house rules: the turn-up decides between four trump suits and none. */
export function houseDeal(s) {
  if (!s || !s.house || !s.up || s.phase !== "play") return s;
  const nt = s.up.rank === "A";
  const lead = (s.names && s.names[other(s.dealer)]) || "";
  return {
    ...s,
    trump: nt ? null : s.up.suit,
    banner: nt ? `Deal ${s.dealNo || 1}. An Ace is turned: no trumps.` : s.banner || (lead ? `${lead} leads.` : ""),
  };
}

/* Bank a finished deal the house way. `prev` is the state before the move that ended it. */
function houseSettle(prev, s) {
  const r = s.result;
  const sheet = (prev.sheet || []).slice();
  const gp = (prev.gp || [0, 0]).slice();
  const pot = potOf(sheet);
  let winner = r.winner, won = r.gp, scoreless = false;
  if (r.reason === "exhausted") {
    /* Nobody went out. With "you declare" on, someone can finish over 66 without calling it: the cards are
     * public, so they are paid as if they had called. Otherwise the deal is scoreless and feeds the pot. */
    const p = r.pts[0] >= OUT ? 0 : r.pts[1] >= OUT ? 1 : -1;
    if (p < 0) scoreless = true;
    else { winner = p; const o = other(p); won = r.tricks[o] === 0 ? 3 : r.pts[o] < 33 ? 2 : 1; }
  }
  const row = { dealNo: s.dealNo, reason: r.reason, pts: [r.pts[0], r.pts[1]], closedBy: r.closedBy, trump: s.trump, ...(s.dup ? { dup: s.dup.of } : {}) };
  if (scoreless) {
    sheet.push({ ...row, winner: null, gp: 0, scoreless: true });
    return { ...s, gp, sheet, bummerlDone: false, bummerlWinner: null, schneiderBummerl: false,
      house: true, houseResult: { scoreless: true, pot: pot + 1 } };
  }
  gp[winner] += won + pot;
  sheet.push({ ...row, winner, gp: won + pot, pot });
  const done = s.target > 0 && gp[winner] >= s.target;
  return { ...s, gp, sheet, bummerlDone: done, bummerlWinner: done ? winner : null,
    schneiderBummerl: done && gp[other(winner)] === 0,
    houseResult: { winner, gp: won, pot, total: won + pot } };
}

/* The reducer every table uses. Classic tables pass straight through. */
export function reducer(state, a) {
  if (a && a.type === "__SYNC__") return a.state;
  const house = state && state.house;
  let next = baseReducer(state, a);
  if (!house || next === state) return next;
  if (!next.house) next = { ...next, house: true, piles: state.piles || "up", variant: state.variant || "classic" };
  if (DEALING.has(a.type) && next.mode === "play") next = houseDeal({ ...next, houseResult: null });
  if (next.phase === "scored" && next.roundEndedAt && !state.roundEndedAt && next.result) next = houseSettle(state, next);
  return next;
}

/* Every card a seat has won in tricks, from the public log. */
export function wonCards(s, seat) {
  const out = [];
  for (const e of s.log || []) if (e.k === "trick" && e.winner === seat) out.push(e.led, e.fol);
  return out;
}
