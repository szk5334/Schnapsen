/* PEER-TO-PEER TRANSPORT (Trystero), with two independent ways of finding each other.
 *
 * Devices introduce themselves through public relays — Nostr relays AND WebTorrent trackers, at the same
 * time — and then talk directly over WebRTC. Either network alone is enough; running both means one flaky
 * relay can't keep two phones apart. A peer reachable both ways is still one peer: Trystero gives a device
 * the same id on both, and every message is sent exactly once, on one of them.
 */
import { nostr, torrent } from "../../vendor/trystero.js";

/* Large, long-lived Nostr relays that pass ephemeral events. Trystero's own default picks 5 of ~30 small
 * community relays from the app name, and for this app those 5 can all be dark at once. */
const NOSTR_RELAYS = [
  "wss://relay.damus.io",
  "wss://nos.lol",
  "wss://relay.primal.net",
  "wss://nostr.mom",
  "wss://relay.nostr.net",
  "wss://offchain.pub",
];

export function trysteroP2P(cfg) {
  const appId = cfg.p2pAppId || "szk5334-schnapsen";
  const rtc = cfg.turn && cfg.turn.length ? { turnConfig: cfg.turn } : {};
  const strategies = [
    { name: "nostr", mod: nostr, conf: { appId, ...rtc, relayConfig: { urls: (cfg.relays && cfg.relays.length) ? cfg.relays : NOSTR_RELAYS } } },
    { name: "torrent", mod: torrent, conf: { appId, ...rtc, ...(cfg.trackers && cfg.trackers.length ? { relayConfig: { urls: cfg.trackers } } : {}) } },
  ];
  const errors = [];
  const rooms = new Map();

  return {
    kind: "trystero",
    join(roomId, opts = {}) {
      const via = new Map();                 // peerId -> Set(strategy index)
      let onJoin = () => {}, onLeave = () => {};
      const subs = strategies.map((st, k) => {
        const conf = { ...st.conf, ...(opts.password ? { password: opts.password } : {}) };
        const r = st.mod.joinRoom(conf, roomId, {
          onJoinError: d => { errors.push({ at: Date.now(), via: st.name, room: roomId, error: String((d && d.error) || d) }); if (errors.length > 30) errors.shift(); },
        });
        r.onPeerJoin = id => {
          const had = via.has(id);
          if (!had) via.set(id, new Set());
          via.get(id).add(k);
          if (!had) onJoin(id);
        };
        r.onPeerLeave = id => {
          const set = via.get(id); if (!set) return;
          set.delete(k);
          if (!set.size) { via.delete(id); onLeave(id); }
        };
        return r;
      });
      const route = id => { const set = via.get(id); return set && set.size ? Math.min(...set) : -1; };
      rooms.set(roomId, { via, strategies: strategies.map(s => s.name) });

      return {
        selfId: nostr.selfId,
        set onPeerJoin(f) { onJoin = f; [...via.keys()].forEach(id => f(id)); },
        set onPeerLeave(f) { onLeave = f; },
        peers: () => [...via.keys()],
        action(name) {
          const acts = subs.map(r => r.makeAction(name));
          let handler = () => {};
          acts.forEach(a => { a.onMessage = (data, meta) => handler(data, meta && meta.peerId); });
          const sendTo = (data, id) => { const k = route(id); if (k >= 0) acts[k].send(data, { target: id }); };
          return {
            send(data, to) { if (to) sendTo(data, to); else [...via.keys()].forEach(id => sendTo(data, id)); },
            set onMessage(f) { handler = f; },
          };
        },
        leave() { subs.forEach(r => r.leave()); rooms.delete(roomId); },
      };
    },
    /* For the hidden #/net page. */
    diag() {
      const sockets = {};
      for (const st of strategies) {
        try {
          const s = st.mod.getRelaySockets();
          sockets[st.name] = Object.fromEntries(Object.entries(s).map(([u, ws]) => [u, ["connecting", "open", "closing", "closed"][ws.readyState] || "?"]));
        } catch { sockets[st.name] = {}; }
      }
      const rs = {};
      for (const [id, r] of rooms) rs[id] = [...r.via].map(([p, set]) => ({ peer: p, via: [...set].map(k => r.strategies[k]) }));
      return { selfId: nostr.selfId, turn: !!(cfg.turn && cfg.turn.length), sockets, rooms: rs, errors: errors.slice() };
    },
  };
}
