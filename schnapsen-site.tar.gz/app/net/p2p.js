/* PEER-TO-PEER TRANSPORT (Trystero).
 * Peers find each other through public Nostr relays, which only ever see an encrypted handshake. After
 * that, every chat message travels device-to-device over a WebRTC data channel (DTLS-encrypted).
 * Nothing said in a chat is sent to InstantDB or to any other server. */
import { joinRoom, selfId } from "../../vendor/trystero.js";

export function trysteroP2P(cfg) {
  const base = { appId: cfg.p2pAppId || "szk5334-schnapsen" };
  if (cfg.turn && cfg.turn.length) base.turnConfig = cfg.turn;
  if (cfg.relays && cfg.relays.length) base.relayConfig = { urls: cfg.relays };

  return {
    kind: "trystero",
    join(roomId, opts = {}) {
      const conf = { ...base };
      if (opts.password) conf.password = opts.password;
      const room = joinRoom(conf, roomId, {
        onJoinError: d => console.warn("[p2p] could not connect to a peer:", d && d.error),
      });
      let onJoin = () => {}, onLeave = () => {};
      room.onPeerJoin = id => onJoin(id);
      room.onPeerLeave = id => onLeave(id);
      return {
        selfId,
        set onPeerJoin(f) { onJoin = f; Object.keys(room.getPeers()).forEach(id => f(id)); },
        set onPeerLeave(f) { onLeave = f; },
        peers: () => Object.keys(room.getPeers()),
        action(name) {
          const a = room.makeAction(name);
          return {
            send(data, to) { return to ? a.send(data, { target: to }) : a.send(data); },
            set onMessage(f) { a.onMessage = (data, meta) => f(data, meta && meta.peerId); },
          };
        },
        leave() { room.leave(); },
      };
    },
  };
}
