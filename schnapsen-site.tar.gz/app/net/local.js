/* LOCAL BACKEND — the same surface as net/instant.js, carried between tabs of one browser by a
 * BroadcastChannel. It exists so the whole multiplayer flow can be tried (and tested) on a single device
 * with no account anywhere: open the site twice with ?local in the URL. */
import { uid } from "../util.js";

const TAB = uid();
const TABLES_KEY = "sx.local.tables";
const chan = new BroadcastChannel("sx-local");
const listeners = new Set();
chan.onmessage = e => listeners.forEach(f => f(e.data));
const post = m => chan.postMessage(m);

function readTables() { try { return JSON.parse(localStorage.getItem(TABLES_KEY) || "{}"); } catch { return {}; } }
function writeTables(t) { localStorage.setItem(TABLES_KEY, JSON.stringify(t)); }

export function localBackend() {
  return {
    kind: "local",
    onStatus(cb) { cb("online"); return () => {}; },
    tables: {
      subscribe(cb) {
        const emit = () => { const t = readTables(); cb(Object.keys(t).map(id => ({ id, ...t[id] }))); };
        const f = m => { if (m.k === "tables") emit(); };
        listeners.add(f); emit();
        return () => listeners.delete(f);
      },
      put(id, patch) {
        const t = readTables(); t[id] = { ...(t[id] || {}), ...patch }; writeTables(t);
        post({ k: "tables" }); listeners.forEach(f => f({ k: "tables" }));
      },
      remove(id) {
        const t = readTables(); delete t[id]; writeTables(t);
        post({ k: "tables" }); listeners.forEach(f => f({ k: "tables" }));
      },
    },
    room(type, id, presence) {
      const rk = type + ":" + id;
      const peerId = uid();
      let mine = { ...presence };
      const peers = new Map();          // peerId -> { p, seen }
      const presSubs = new Set();
      const topicSubs = new Map();
      const emitPresence = () => {
        const now = Date.now();
        for (const [k, v] of peers) if (now - v.seen > 5000) peers.delete(k);
        const list = [{ ...mine, peerId, self: true }, ...[...peers].map(([k, v]) => ({ ...v.p, peerId: k }))];
        presSubs.forEach(f => f(list));
      };
      const beat = () => post({ k: "pres", rk, peerId, p: mine });
      const f = m => {
        if (m.rk !== rk || m.peerId === peerId) return;
        if (m.k === "pres") {
          const had = peers.has(m.peerId);
          const prev = had ? JSON.stringify(peers.get(m.peerId).p) : "";
          peers.set(m.peerId, { p: m.p, seen: Date.now() });
          if (!had) beat();
          if (!had || prev !== JSON.stringify(m.p)) emitPresence();
        } else if (m.k === "bye") { peers.delete(m.peerId); emitPresence(); }
        else if (m.k === "topic") {
          const subs = topicSubs.get(m.topic); if (!subs) return;
          const from = peers.has(m.peerId) ? { ...peers.get(m.peerId).p, peerId: m.peerId } : { peerId: m.peerId };
          subs.forEach(cb => cb(m.data, from));
        }
      };
      listeners.add(f);
      const hb = setInterval(() => { beat(); emitPresence(); }, 1500);
      beat();
      const onUnload = () => post({ k: "bye", rk, peerId });
      addEventListener("pagehide", onUnload);
      return {
        setPresence(p) { mine = { ...mine, ...p }; beat(); emitPresence(); },
        onPresence(cb) { presSubs.add(cb); setTimeout(emitPresence, 0); return () => presSubs.delete(cb); },
        publish(topic, data) { post({ k: "topic", rk, peerId, topic, data }); },
        on(topic, cb) {
          if (!topicSubs.has(topic)) topicSubs.set(topic, new Set());
          topicSubs.get(topic).add(cb);
          return () => topicSubs.get(topic).delete(cb);
        },
        leave() { clearInterval(hb); listeners.delete(f); removeEventListener("pagehide", onUnload); post({ k: "bye", rk, peerId }); },
      };
    },
  };
}

/* The P2P stand-in: same shape as net/p2p.js's trystero transport. */
export function localP2P() {
  return {
    kind: "local",
    join(roomId) {
      const selfId = uid().slice(0, 8);
      const c = new BroadcastChannel("sx-p2p-" + roomId);
      const peers = new Set(); const seen = new Map();
      const actions = new Map();
      let onJoin = () => {}, onLeave = () => {};
      c.onmessage = e => {
        const m = e.data; if (m.from === selfId) return;
        if (m.k === "here" || m.k === "hello") {
          seen.set(m.from, Date.now());
          if (!peers.has(m.from)) { peers.add(m.from); if (m.k === "here") c.postMessage({ k: "hello", from: selfId }); onJoin(m.from); }
        } else if (m.k === "leave") { if (peers.delete(m.from)) onLeave(m.from); }
        else if (m.k === "act" && (!m.to || m.to === selfId)) { const a = actions.get(m.name); a && a.cb && a.cb(m.data, m.from); }
      };
      c.postMessage({ k: "here", from: selfId });
      const hb = setInterval(() => {
        c.postMessage({ k: "hello", from: selfId });
        const now = Date.now();
        for (const p of [...peers]) if (now - (seen.get(p) || 0) > 6000) { peers.delete(p); onLeave(p); }
      }, 2000);
      return {
        selfId,
        set onPeerJoin(f) { onJoin = f; peers.forEach(p => f(p)); },
        set onPeerLeave(f) { onLeave = f; },
        peers: () => [...peers],
        action(name) {
          const a = { cb: null };
          actions.set(name, a);
          return {
            send(data, to) { c.postMessage({ k: "act", from: selfId, name, data, to: to || null }); },
            set onMessage(f) { a.cb = f; },
          };
        },
        leave() { clearInterval(hb); c.postMessage({ k: "leave", from: selfId }); c.close(); },
      };
    },
  };
}
