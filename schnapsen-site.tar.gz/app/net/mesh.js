/* THE MESH — everything multiplayer rides on this, and there is no server behind it.
 *
 * A mesh is one Trystero room: every device in it holds a direct, encrypted WebRTC link to every other.
 * Public Nostr relays are used only to introduce devices to each other (an encrypted handshake), never to
 * carry what is said or played.
 *
 *   people        cell: everyone in the room, including you — each a presence object {cid, name, …}
 *   setPresence   merge into your own presence; every peer hears it
 *   send(t, d, to)  topic message to everyone, or to one peerId
 *   on(t, cb)     cb(data, fromPresence, fromPeerId)
 *   onJoin(cb)    a new peer finished its hello
 *   peerOf(cid)   the peerId a person is reachable at (newest link wins)
 */
import { cell } from "../util.js";

export function openMesh(p2p, roomId, { password, presence }) {
  const t = p2p.join(roomId, { password });
  const self = t.selfId;
  let mine = { ...presence };
  const others = new Map();                 // peerId -> presence (after their hello)
  const people = cell([{ ...mine, peerId: self, self: true }]);
  const topics = new Map();
  const joinSubs = new Set();

  const pres = t.action("p");
  const msg = t.action("m");

  const emit = () => people.set([{ ...mine, peerId: self, self: true }, ...[...others].map(([k, v]) => ({ ...v, peerId: k }))]);

  t.onPeerJoin = id => pres.send(mine, id);
  t.onPeerLeave = id => { if (others.delete(id)) emit(); };
  pres.onMessage = (d, id) => {
    if (!d || typeof d !== "object" || !d.cid) return;
    const fresh = !others.has(id);
    others.set(id, d);
    emit();
    if (fresh) { pres.send(mine, id); joinSubs.forEach(f => f(id, d)); }
  };
  msg.onMessage = (d, id) => {
    if (!d || !d.t) return;
    const subs = topics.get(d.t); if (!subs) return;
    const from = others.get(id) || {};
    subs.forEach(f => { try { f(d.d, from, id); } catch (e) { console.error(e); } });
  };

  return {
    selfId: self,
    people,
    setPresence(p) { mine = { ...mine, ...p }; emit(); pres.send(mine); },
    send(topic, data, to) { msg.send({ t: topic, d: data }, to); },
    on(topic, cb) {
      if (!topics.has(topic)) topics.set(topic, new Set());
      topics.get(topic).add(cb);
      return () => topics.get(topic).delete(cb);
    },
    onJoin(cb) { joinSubs.add(cb); return () => joinSubs.delete(cb); },
    peerOf(cid) { let p = null; for (const [k, v] of others) if (v.cid === cid) p = k; return p; },
    linked: () => others.size,
    leave() { t.leave(); },
  };
}
