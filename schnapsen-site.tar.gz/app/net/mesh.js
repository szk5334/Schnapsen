/* THE MESH — everything multiplayer rides on this, and there is no server of our own behind it.
 *
 * A mesh is one room on the transport (net/relay.js: sealed messages through public Nostr relays; or
 * net/local.js between tabs for testing). Everyone in the room hears everyone's presence and topics.
 *
 *   people        cell: everyone in the room, including you — each a presence object {cid, name, …}
 *   setPresence   merge into your own presence; every peer hears it
 *   send(t, d, to)  topic message to everyone, or to one peerId
 *   on(t, cb)     cb(data, fromPresence, fromPeerId)
 *   onJoin(cb)    a new peer finished its hello
 *   peerOf(cid)   the peerId a person is reachable at (newest link wins)
 */
import { cell } from "../util.js";

export function openMesh(p2p, roomId, { password, presence }) {
  const t = p2p.join(roomId, { password });
  const self = t.selfId;
  let mine = { ...presence, pv: 1 };
  const others = new Map();                 // peerId -> presence (after their hello)
  const presV = new Map();                  // peerId -> version of the newest presence applied
  const people = cell([{ ...mine, peerId: self, self: true }]);
  const topics = new Map();
  const joinSubs = new Set();

  const pres = t.action("p");
  const msg = t.action("m");

  const emit = () => people.set([{ ...mine, peerId: self, self: true }, ...[...others].map(([k, v]) => ({ ...v, peerId: k }))]);

  t.onPeerJoin = id => pres.send(mine, id);
  t.onPeerLeave = id => { presV.delete(id); if (others.delete(id)) emit(); };
  pres.onMessage = (d, id) => {
    if (!d || typeof d !== "object" || !d.cid) return;
    /* Relayed messages can arrive out of order: never let an older presence replace a newer one. */
    const v = +d.pv || 0;
    if ((presV.get(id) || 0) > v) return;
    presV.set(id, v);
    const fresh = !others.has(id);
    others.set(id, d);
    emit();
    if (fresh) { pres.send(mine, id); joinSubs.forEach(f => f(id, d)); }
  };
  msg.onMessage = (d, id) => {
    if (!d || !d.t) return;
    const subs = topics.get(d.t); if (!subs) return;
    const from = others.get(id) || {};
    subs.forEach(f => { try { f(d.d, from, id); } catch (e) { console.error(e); } });
  };

  /* A link whose hello never arrived (lost on the way): say hello again until it does. */
  const regreet = setInterval(() => {
    for (const id of (t.peers ? t.peers() : [])) if (!others.has(id)) pres.send(mine, id);
  }, 12000);

  return {
    selfId: self,
    people,
    setPresence(p) { mine = { ...mine, ...p, pv: mine.pv + 1 }; emit(); pres.send(mine); },
    /* prio "low": may be skipped when relays are busy (used for re-sends that will be tried again). */
    send(topic, data, to, prio) { msg.send({ t: topic, d: data }, to, prio); },
    on(topic, cb) {
      if (!topics.has(topic)) topics.set(topic, new Set());
      topics.get(topic).add(cb);
      return () => topics.get(topic).delete(cb);
    },
    onJoin(cb) { joinSubs.add(cb); return () => joinSubs.delete(cb); },
    /* The link a person was most recently heard on (a reload leaves a stale one behind for a while). */
    peerOf(cid) {
      let p = null, best = -1;
      for (const [k, v] of others) if (v.cid === cid) { const h = t.heard ? t.heard(k) : 0; if (h >= best) { best = h; p = k; } }
      return p;
    },
    linked: () => others.size,
    leave() { clearInterval(regreet); t.leave(); },
  };
}
