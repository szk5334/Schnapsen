/* RELAY TRANSPORT — every message rides public Nostr relays, sealed. Phones never connect to each other.
 *
 * Same surface as the old WebRTC transport (join → action → send/onMessage, onPeerJoin/onPeerLeave), so
 * the mesh, chat, table and lockstep match on top of it are unchanged.
 *
 * What a relay sees: events signed by a brand-new throwaway key each time, carrying one random-looking tag
 * that changes every hour, and a body of AES-256-GCM ciphertext padded to a fixed bucket size. Who is
 * talking, in which room, and what was said or played are all inside the seal. (A relay does see the IP
 * address that posted an event, and when.)
 *
 * Getting messages through relays that drop things:
 *   - every data message carries a sequence number: one counter for messages to everyone, and one per
 *     person for messages to just them (so a watcher never waits on a card key that wasn't for them);
 *   - heartbeats carry the sender's latest numbers and which relays it can reach;
 *   - a receiver that sees a hole (a q it never got, below someone's top) asks for it after a short settle
 *     ("want"), and the sender sends it again on relays they share;
 *   - a "tip" heartbeat follows every burst of messages, so a lost last message is noticed within seconds
 *     instead of waiting for the next regular heartbeat;
 *   - data events are stored by relays for a few hours, so a phone whose connection dropped asks each relay
 *     for what it missed when it reconnects.
 * Messages go to the relays both sides can reach (two of them for one person, a covering set plus a spare
 * for everyone), within each relay's rules and send budget — see the pool below.
 */
import { newKey, pubOf, signId, sha256hex } from "../../vendor/nostr.js";

/* Large general-purpose relays with no published login, payment or web-of-trust wall. Any that turns out
 * to block us, rate-limit us or be unreachable is set aside automatically (see the pool). offchain.pub is out:
 * its operator's other relay only takes writes from its web of trust. Check them all from #/net. */
export const DEFAULT_RELAYS = [
  "wss://relay.damus.io",
  "wss://nos.lol",
  "wss://relay.primal.net",
  "wss://relay.ditto.pub",
  "wss://relay.coinos.io",
  "wss://nostr.mom",
  "wss://relay.nostr.net",
  "wss://relay.snort.social",
];
/* Extra relays the #/net checker tries, so a better list can be chosen from real results. */
export const CANDIDATE_RELAYS = DEFAULT_RELAYS.concat([
  "wss://offchain.pub",
  "wss://relay.mostr.pub",
  "wss://nostr.oxtr.dev",
  "wss://nostr-pub.wellorder.net",
  "wss://nostr.bitcoiner.social",
  "wss://relay.nostr.band",
]);
export const KIND_DATA = 4747, KIND_CTRL = 24747;

const KEEP_S = 6 * 3600;            // relays keep data events this long (NIP-40 expiration)
const HB_MS = 45000;                // regular heartbeat
const STALE_MS = 140000;            // not heard from this long → gone
const TIPS = [3000];                // a heartbeat this long after the last message of a burst
const SETTLE_MS = 1500;             // wait this long for stragglers before asking for a hole
const ASK_MS = [2000, 4000, 8000, 12000];  // then ask again at this pace (the last one repeats) while they're here
const ASK_MAX = 16;                 // numbers per ask
const RESEND_GAP_MS = 8000;         // a message is re-sent at most this often, however often it's asked for
const OUTBOX_MAX = 150;             // data waiting for budget; beyond this the oldest go (repair brings them back)
const REFUSE_MS = 600000;           // skip a relay that refused a kind for this long
const BUFFER = 600;                 // sent messages kept for re-sending

const S = globalThis.crypto.subtle;
const te = new TextEncoder(), td = new TextDecoder();
const hasDOM = typeof document !== "undefined" && typeof addEventListener === "function";
const now = () => Date.now();
const rnd = n => globalThis.crypto.getRandomValues(new Uint8Array(n));
const hexOf = b => [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, "0")).join("");
function b64(u) { let s = ""; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); }
const unb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
const shuffle = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = rnd(1)[0] % (i + 1); [a[i], a[j]] = [a[j], a[i]]; } return a; };
/* A relay's 4-hex fingerprint (FNV-1a of its URL), so heartbeats can say "I can reach these" in a few bytes. */
export function fpOf(url) {
  let h = 0x811c9dc5;
  for (const ch of String(url).toLowerCase().replace(/\/+$/, "")) { h ^= ch.charCodeAt(0); h = Math.imul(h, 0x01000193) >>> 0; }
  return (h & 0xffff).toString(16).padStart(4, "0");
}

/* ------------------------------------------------------------------ sealing */
async function roomKeys(secret) {
  const base = await S.importKey("raw", te.encode(secret), "HKDF", false, ["deriveBits"]);
  const bits = info => S.deriveBits({ name: "HKDF", hash: "SHA-256", salt: te.encode("schnapsen/relay/v1"), info: te.encode(info) }, base, 256);
  const aes = await S.importKey("raw", await bits("body"), "AES-GCM", false, ["encrypt", "decrypt"]);
  const mac = await S.importKey("raw", await bits("tag"), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return { aes, mac };
}
const hourOf = ts => Math.floor(ts / 3600e3);
async function tagFor(keys, hour) { return hexOf(await S.sign("HMAC", keys.mac, te.encode("h:" + hour))).slice(0, 32); }
const BUCKETS = [256, 512, 1024, 2048, 4096, 8192, 16384, 32768, 65536, 131072];
function pad(bytes) {
  const size = BUCKETS.find(s => s >= bytes.length + 4) || bytes.length + 4;
  const out = new Uint8Array(size);
  new DataView(out.buffer).setUint32(0, bytes.length);
  out.set(bytes, 4);
  out.set(rnd(Math.min(65536, size - 4 - bytes.length)).subarray(0, size - 4 - bytes.length), 4 + bytes.length);
  return out;
}
async function seal(keys, obj) {
  const iv = rnd(12);
  const ct = new Uint8Array(await S.encrypt({ name: "AES-GCM", iv }, keys.aes, pad(te.encode(JSON.stringify(obj)))));
  const out = new Uint8Array(12 + ct.length); out.set(iv); out.set(ct, 12);
  return b64(out);
}
async function unseal(keys, box) {
  try {
    const raw = unb64(box);
    const pt = new Uint8Array(await S.decrypt({ name: "AES-GCM", iv: raw.subarray(0, 12) }, keys.aes, raw.subarray(12)));
    const n = new DataView(pt.buffer, pt.byteOffset).getUint32(0);
    return JSON.parse(td.decode(pt.subarray(4, 4 + n)));
  } catch { return null; }
}
function makeEvent(kind, tag, content) {
  const sk = newKey();
  const pubkey = pubOf(sk);
  const created_at = Math.floor(now() / 1000);
  const tags = [["t", tag]];
  if (kind === KIND_DATA) tags.push(["expiration", String(created_at + KEEP_S)]);
  const id = sha256hex(te.encode(JSON.stringify([0, pubkey, created_at, kind, tags, content])));
  return { id, pubkey, created_at, kind, tags, content, sig: signId(id, sk) };
}

/* ------------------------------------------------------------------ the relay pool
 *
 * Public relays are run by volunteers for social media, and they defend themselves: per-IP rate limits that
 * turn into bans, web-of-trust filters that refuse keys nobody follows, login or payment walls. So the pool
 * plays by their rules instead of pushing through them:
 *
 *   - each relay's NIP-11 rules are read first; one that needs a login, payment, proof-of-work or limits
 *     writes is never written to;
 *   - every relay has a send budget (a token bucket, 10 deep, one token back every 3 s — at most 30 events
 *     in any first minute and 20 a minute after, however busy); when budgets run low a message goes to one relay
 *     instead of two, then to another relay, then waits; routine heartbeats are skipped first;
 *   - replies are read by their standard prefixes: "rate-limited:" backs that relay off (1 min, doubling
 *     to 30); "blocked:", "restricted:", "auth-required:" and "pow:" retire it for a day (remembered across
 *     reloads); the event is re-sent elsewhere either way;
 *   - a relay whose connection keeps failing (often what an IP ban looks like) is retried only every 10 min.
 */
const BUCKET = 10, REFILL_MS = 3000;            // send budget per relay
const HB_RESERVE = 4;                           // heartbeats only go to relays with this much budget left
const OFF_MS = 24 * 3600e3;                     // a relay that blocked us sits out this long
const DEAD_TRIES = 4, DEAD_RETRY_MS = 600000;   // connection failures before the slow retry, and its pace
const lsGet = k => { try { const v = localStorage.getItem("sx.relay." + k); return v ? JSON.parse(v) : null; } catch { return null; } };
const lsSet = (k, v) => { try { localStorage.setItem("sx.relay." + k, JSON.stringify(v)); } catch {} };
export const httpOf = url => String(url).replace(/^ws/, "http");

/* A relay's published rules (NIP-11), cached for a day. Resolves to null when it publishes none. */
export async function relayRules(url, { fresh = false } = {}) {
  const key = "nip11." + url, hit = !fresh && lsGet(key);
  if (hit && now() - hit.at < OFF_MS) return hit.info;
  if (typeof fetch !== "function") return null;
  try {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 5000);
    const r = await fetch(httpOf(url), { headers: { Accept: "application/nostr+json" }, signal: ctl.signal });
    clearTimeout(t);
    const info = await r.json();
    lsSet(key, { at: now(), info });
    return info;
  } catch { return null; }
}
/* Why we can't write to a relay, from its rules — or null if nothing in them stops us. */
export function rulesBar(info) {
  const l = (info && info.limitation) || {};
  if (l.auth_required) return "needs a login (NIP-42)";
  if (l.payment_required) return "paid members only";
  if (l.restricted_writes) return "only accepts writes from approved people";
  if (l.min_pow_difficulty > 0) return `wants proof-of-work (${l.min_pow_difficulty} bits)`;
  return null;
}
/* What a refusal means, from NIP-01's standard prefixes. */
export function reading(msg) {
  const m = String(msg || "").toLowerCase();
  if (m.startsWith("duplicate:")) return "ok";
  if (m.startsWith("rate-limited:") || /rate.?limit|too (many|fast)|slow down/.test(m)) return "slow";
  if (/^(blocked|restricted|auth-required|pow):/.test(m) || /web of trust|\bwot\b|not allowed|whitelist|allowlist|paid|pay to/.test(m)) return "off";
  return "refused";
}

function relayPool(urls, report) {
  const conns = new Map();                 // url -> connection state
  const subs = new Map();                  // id -> { filters(since), cb, since }
  const seen = new Set();
  const pending = new Map();               // event id -> { ev, msg, sent:Set(url), at, prio }
  const outbox = [];                       // data events waiting for budget
  let n = 0, droppedNote = 0;

  const offInfo = url => { const o = lsGet("off." + url); return o && o.until > now() ? o : null; };
  function retire(c, why) {
    const until = now() + OFF_MS;
    c.off = { why, until }; lsSet("off." + c.url, c.off);
    report("relay", c.url, "stopped using it for a day: " + why);
    clearTimeout(c.timer);
    try { c.ws && c.ws.close(); } catch {}
  }
  function slowDown(c, why) {
    c.slowN = (c.slowN || 0) + 1;
    c.slowUntil = now() + Math.min(1800000, 60000 * 2 ** (c.slowN - 1));
    c.tokens = 0;
    report("relay", c.url, `asked us to slow down — resting it ${Math.round((c.slowUntil - now()) / 60000)} min` + (why ? ": " + String(why).slice(0, 100) : ""));
  }

  function make(url) {
    const c = { url, ws: null, open: false, queue: [], attempt: 0, fails: 0, lastAt: 0, refused: {}, timer: null,
      state: "connecting", bytesOut: 0, events: 0, tokens: BUCKET, refillAt: now(), slowN: 0, slowUntil: 0,
      off: offInfo(url), rules: null, maxLen: 0, everOpen: false };
    conns.set(url, c);
    return c;
  }
  async function start(c) {
    if (c.off) { c.state = "off"; return; }
    const info = await relayRules(c.url);
    c.rules = info;
    const bar = rulesBar(info);
    if (bar) { retire(c, "its published rules: " + bar); c.state = "off"; return; }
    const ml = info && info.limitation && +info.limitation.max_message_length;
    if (ml > 0) c.maxLen = ml;
    connect(c);
  }
  function connect(c) {
    if (c.off) { c.state = "off"; return; }
    let ws;
    c.state = "connecting";
    try { ws = new WebSocket(c.url); } catch (e) { c.state = "closed"; retry(c); return; }
    c.ws = ws;
    let opened = false;
    ws.onopen = () => {
      opened = true; c.open = true; c.everOpen = true; c.state = "open"; c.attempt = 0; c.fails = 0;
      for (const [id, s] of subs) ws.send(JSON.stringify(["REQ", id, ...s.filters(c.lastAt ? c.lastAt - 60 : s.since)]));
      for (const m of c.queue.splice(0)) { c.bytesOut += m.length; ws.send(m); }
    };
    ws.onmessage = e => {
      let m; try { m = JSON.parse(e.data); } catch { return; }
      if (m[0] === "EVENT") {
        const ev = m[2], s = subs.get(m[1]);
        if (!ev || typeof ev.id !== "string") return;
        if (ev.created_at > c.lastAt && ev.created_at <= now() / 1000 + 60) c.lastAt = ev.created_at;
        if (!s || seen.has(ev.id)) return;
        seen.add(ev.id); if (seen.size > 20000) seen.clear();
        s.cb(ev, c.url);
      } else if (m[0] === "OK") {
        if (m[2] !== false) return;
        const p = pending.get(m[1]);
        const r = reading(m[3]);
        if (r === "ok") return;
        if (r === "slow") slowDown(c, m[3]);
        else if (r === "off") retire(c, String(m[3] || "refused").slice(0, 120));
        else {
          const kind = p ? p.ev.kind : KIND_DATA;
          c.refused[kind] = now() + REFUSE_MS;
          report("relay", c.url, "refused an event" + (m[3] ? ": " + String(m[3]).slice(0, 120) : ""));
        }
        if (p && p.prio !== "low") {                 // send it somewhere that will take it
          const alt = usable(p.ev.kind).filter(x => !p.sent.has(x.url) && fits(x, p.msg));
          alt.slice(0, 1).forEach(x => { p.sent.add(x.url); spend(x); push(x, p.msg); });
        }
      } else if (m[0] === "CLOSED") {
        const r = reading(m[2]);
        if (r === "off" || /^(auth-required|restricted|blocked):/i.test(String(m[2] || ""))) retire(c, "won't let us read: " + String(m[2] || "").slice(0, 100));
        else if (r === "slow") slowDown(c, m[2]);
        else report("relay", c.url, "closed a subscription: " + String(m[2] || "").slice(0, 100));
      } else if (m[0] === "NOTICE") {
        if (reading(m[1]) === "slow") slowDown(c, m[1]);
        else report("relay", c.url, "notice: " + String(m[1] || "").slice(0, 120));
      } else if (m[0] === "AUTH") {
        retire(c, "asks for a login (NIP-42)");
      }
    };
    ws.onclose = () => {
      if (conns.get(c.url) !== c || c.ws !== ws) return;
      c.open = false; c.state = c.off ? "off" : "closed";
      if (!opened) c.fails++;
      if (!c.off) retry(c);
    };
    ws.onerror = () => {};
  }
  function retry(c) {
    clearTimeout(c.timer);
    let wait;
    if (c.fails >= DEAD_TRIES) {
      wait = DEAD_RETRY_MS;
      if (c.fails === DEAD_TRIES) report("relay", c.url, "can't connect (down, or it has banned this network) — trying again every 10 min");
      c.state = "unreachable";
    } else wait = Math.min(60000, 1500 * 2 ** c.attempt) + Math.random() * 1000;
    c.attempt++;
    c.timer = setTimeout(() => { if (conns.get(c.url) === c && !c.open && !c.off) connect(c); }, wait);
  }
  function push(c, m) {
    if (c.open) { try { c.bytesOut += m.length; c.events++; c.ws.send(m); } catch { c.queue.push(m); } }
    else if (c.queue.length < 100) c.queue.push(m);
  }
  function refill(c) {
    const t = now();
    if (t < c.slowUntil) { c.refillAt = t; return; }
    const add = Math.floor((t - c.refillAt) / REFILL_MS);
    if (add > 0) { c.tokens = Math.min(BUCKET, c.tokens + add); c.refillAt += add * REFILL_MS; }
    if (c.tokens >= BUCKET) c.refillAt = t;
  }
  const spend = c => { refill(c); c.tokens = Math.max(0, c.tokens - 1); };
  const budget = c => { refill(c); return now() < c.slowUntil ? 0 : c.tokens; };
  const fits = (c, msg) => !c.maxLen || msg.length <= c.maxLen;
  /* Relays that are open, not resting, not refusing this kind, and have budget for one more event. */
  function usable(kind, reserve = 1) {
    const t = now();
    return [...conns.values()].filter(c => c.open && !c.off && !((c.refused[kind] || 0) > t) && budget(c) >= reserve);
  }
  /* Data that found no relay with budget waits here and goes out as budget returns. */
  setInterval(() => {
    while (outbox.length) {
      const o = outbox[0];
      const ok = usable(o.ev.kind).filter(c => fits(c, o.msg));
      if (!ok.length) break;
      outbox.shift();
      const pick = (o.want.filter(c => ok.includes(c)).length ? o.want.filter(c => ok.includes(c)) : ok).slice(0, o.count);
      pick.forEach(c => { o.sent.add(c.url); spend(c); push(c, o.msg); });
    }
    const cut = now() - 120000; for (const [id, p] of pending) if (p.at < cut) pending.delete(id);
  }, 500);

  for (const u of urls) start(make(u));

  return {
    urls,
    usable,
    all: () => [...conns.values()],
    /* Publish to the wanted relays that have budget; top up from others; queue (data) or drop (low). */
    publish(kind, tag, content, targets, prio = "normal") {
      const ev = makeEvent(kind, tag, content);
      seen.add(ev.id);
      const msg = JSON.stringify(["EVENT", ev]);
      prio = prio || "normal";
      const reserve = prio === "low" ? HB_RESERVE : 1;
      const ok = usable(kind, reserve).filter(c => fits(c, msg));
      const want = (targets && targets.length ? targets : ok);
      /* Budgets running low everywhere: one copy instead of two (lost ones are repaired anyway). */
      const lean = prio === "tip" || prio === "now" || ok.every(c => budget(c) < BUCKET / 2);
      const count = prio === "all" ? ok.length : lean ? 1 : Math.max(1, Math.min(want.length, 3));
      let pick = want.filter(c => ok.includes(c));
      if (prio !== "all" && pick.length < Math.min(count, ok.length)) pick = pick.concat(ok.filter(c => !pick.includes(c)).slice(0, count - pick.length));
      const p = { ev, msg, sent: new Set(), at: now(), prio };
      pending.set(ev.id, p);
      if (!pick.length) {
        /* Only first sends wait for budget. Heartbeats, tips and re-sends are dropped instead: they're
         * repeated anyway, and a queue of stale re-sends is what starves everything else. */
        if (prio === "normal" || prio === "all") {
          outbox.push({ ev, msg, want, count, sent: p.sent });
          if (outbox.length > OUTBOX_MAX) { outbox.shift(); if (!droppedNote++) report("relay", "all", "too much waiting for relay budget; dropped the oldest (they'll be repaired)"); }
        }
        return ev;
      }
      pick.forEach(c => { p.sent.add(c.url); spend(c); push(c, msg); });
      return ev;
    },
    subscribe(filters, cb) {
      const id = "sx" + (++n) + hexOf(rnd(3));
      const s = { filters, cb, since: Math.floor(now() / 1000) - 15 };
      subs.set(id, s);
      for (const c of conns.values()) if (c.open) c.ws.send(JSON.stringify(["REQ", id, ...filters(s.since)]));
      return {
        refresh() {                                  // tags rotated: same id, new filter (replaces the old one)
          for (const c of conns.values()) if (c.open) c.ws.send(JSON.stringify(["REQ", id, ...filters(c.lastAt ? c.lastAt - 60 : s.since)]));
        },
        close() {
          subs.delete(id);
          for (const c of conns.values()) if (c.open) try { c.ws.send(JSON.stringify(["CLOSE", id])); } catch {}
        },
      };
    },
    /* The page came back to the foreground: reconnect anything closed right away (not banned or dead ones). */
    wake() { for (const c of conns.values()) if (!c.open && !c.off && c.fails < DEAD_TRIES && c.state !== "connecting") { clearTimeout(c.timer); c.attempt = 0; connect(c); } },
    status() {
      const t = now();
      return Object.fromEntries([...conns.values()].map(c => [c.url,
        c.off ? "off" : t < c.slowUntil ? "resting" : c.open && Object.values(c.refused).some(u => u > t) ? "refusing" : c.state]));
    },
    detail() {
      const t = now();
      return [...conns.values()].map(c => ({ url: c.url, state: c.off ? "off" : t < c.slowUntil ? "resting" : c.state,
        why: c.off ? c.off.why : t < c.slowUntil ? `resting ${Math.ceil((c.slowUntil - t) / 60000)} min more` : c.state === "unreachable" ? "can't connect" : "",
        budget: budget(c), events: c.events, kb: Math.round(c.bytesOut / 1024), name: c.rules && c.rules.name || "" }));
    },
    queued: () => outbox.length,
    bytesOut() { return [...conns.values()].reduce((a, c) => a + c.bytesOut, 0); },
  };
}

/* ------------------------------------------------------------------ checking a relay (for #/net)
 * Reads its rules, then does exactly what the game does, once: subscribe on one connection, post one
 * stored and one passing-through event (throwaway keys, random tag, sealed-size body) on another, and see
 * whether the relay accepts them and delivers them back. Costs the relay two events. */
export async function checkRelay(url, ms = 9000) {
  const t0 = now();
  const out = { url, rules: null, bar: null, connect: null, data: null, ctrl: null, echoData: false, echoCtrl: false, ms: 0 };
  const info = await relayRules(url, { fresh: true });
  out.rules = info ? { name: info.name || "", software: info.software || "", limitation: info.limitation || {} } : null;
  out.bar = rulesBar(info);
  const tag = hexOf(rnd(16));
  const body = b64(rnd(256));
  const evs = [makeEvent(KIND_DATA, tag, body), makeEvent(KIND_CTRL, tag, body)];
  const open = () => new Promise(res => {
    let ws; const t = setTimeout(() => { try { ws && ws.close(); } catch {} res(null); }, 6000);
    try { ws = new WebSocket(url); } catch { clearTimeout(t); res(null); return; }
    ws.onopen = () => { clearTimeout(t); res(ws); };
    ws.onerror = () => {}; ws.onclose = () => { clearTimeout(t); res(null); };
  });
  const [rx, tx] = await Promise.all([open(), open()]);
  out.connect = !!(rx && tx);
  if (!out.connect) { [rx, tx].forEach(w => { try { w && w.close(); } catch {} }); out.ms = now() - t0; return out; }
  out.connect = now() - t0;
  await new Promise(res => {
    const done = () => (out.data !== null && out.ctrl !== null && (out.echoData || out.data !== "ok") && (out.echoCtrl || out.ctrl !== "ok")) && res();
    const t = setTimeout(res, ms);
    rx.onmessage = e => {
      let m; try { m = JSON.parse(e.data); } catch { return; }
      if (m[0] === "EVENT" && m[2] && m[2].id === evs[0].id) out.echoData = true;
      if (m[0] === "EVENT" && m[2] && m[2].id === evs[1].id) out.echoCtrl = true;
      if (m[0] === "CLOSED") { out.readRefused = String(m[2] || "closed"); }
      if (m[0] === "EOSE" && !out.sent) { out.sent = true; evs.forEach(ev => tx.send(JSON.stringify(["EVENT", ev]))); }
      done() && clearTimeout(t);
    };
    tx.onmessage = e => {
      let m; try { m = JSON.parse(e.data); } catch { return; }
      if (m[0] === "OK") {
        const v = m[2] === false ? (String(m[3] || "refused") || "refused") : "ok";
        if (m[1] === evs[0].id) out.data = v;
        if (m[1] === evs[1].id) out.ctrl = v;
      } else if (m[0] === "AUTH") { out.auth = true; }
      done() && clearTimeout(t);
    };
    setTimeout(() => { if (!out.sent) { out.sent = true; evs.forEach(ev => tx.send(JSON.stringify(["EVENT", ev]))); } }, 2000);
    rx.send(JSON.stringify(["REQ", "chk" + tag.slice(0, 6), { kinds: [KIND_DATA, KIND_CTRL], "#t": [tag], since: Math.floor(now() / 1000) - 30 }]));
  });
  [rx, tx].forEach(w => { try { w.close(); } catch {} });
  out.ms = now() - t0;
  return out;
}
/* One line a person can read. */
export function verdict(r) {
  if (r.bar) return { ok: false, text: "No: " + r.bar };
  if (!r.connect) return { ok: false, text: "No: can't connect (down, or blocking this network)" };
  if (r.auth) return { ok: false, text: "No: asks for a login" };
  const bad = [r.data, r.ctrl].find(v => v && v !== "ok");
  if (bad) return { ok: false, text: "No: " + bad.slice(0, 90) };
  if (r.data === null || r.ctrl === null) return { ok: false, text: "No: never answered our test post" };
  if (!r.echoData || !r.echoCtrl) return { ok: false, text: `No: took our posts but never passed ${!r.echoData && !r.echoCtrl ? "them" : "one"} on` };
  return { ok: true, text: `Yes (${(r.ms / 1000).toFixed(1)} s)` };
}

/* ------------------------------------------------------------------ the transport */
export function relayP2P(cfg = {}) {
  const appId = cfg.p2pAppId || "szk5334-schnapsen";
  const urls = (cfg.relays && cfg.relays.length ? cfg.relays : DEFAULT_RELAYS).slice();
  const fpUrl = new Map(urls.map(u => [fpOf(u), u]));
  const errors = [];
  const report = (via, where, error) => {
    const last = errors[errors.length - 1];
    if (last && last.via === via && last.room === where && last.error === error) { last.n = (last.n || 1) + 1; last.at = now(); return; }
    errors.push({ at: now(), via, room: where, error }); if (errors.length > 40) errors.shift();
  };
  const pool = relayPool(urls, report);
  const selfId = hexOf(rnd(8));
  const rooms = new Map();
  const myFps = kind => pool.usable(kind).map(c => fpOf(c.url));

  /* Smallest set of my open relays that reaches every live peer, plus one spare. Unknown → all. */
  function cover(kind, peers) {
    const open = pool.usable(kind);
    if (!open.length) return [];
    if (!peers.length || peers.some(p => !p.relays || !p.relays.size)) return open;
    const left = new Set(peers.map((_, i) => i));
    const pick = [];
    while (left.size) {
      let best = null, bestHit = 0;
      for (const c of open) {
        if (pick.includes(c)) continue;
        const f = fpOf(c.url); let hit = 0;
        for (const i of left) if (peers[i].relays.has(f)) hit++;
        if (hit > bestHit) { best = c; bestHit = hit; }
      }
      if (!best) return open;                         // somebody shares no relay with me: everywhere
      pick.push(best);
      for (const i of [...left]) if (peers[i].relays.has(fpOf(best.url))) left.delete(i);
    }
    const spare = shuffle(open.filter(c => !pick.includes(c)))[0];
    if (spare) pick.push(spare);
    return pick;
  }

  function join(roomId, opts = {}) {
    const secret = `sx1|${appId}|${roomId}|${opts.password || ""}`;
    const peers = new Map();                 // peerId -> { heard, relays:Set, b:stream (to all), d:stream (to me), repair, tries }
    const handlers = new Map();              // action name -> fn
    const sent = new Map();                  // "q" or "peer:dq" -> envelope (for re-sending)
    const dseq = new Map();                  // peerId -> last private number sent to them
    const resentAt = new Map();              // sent-buffer key -> when it was last re-sent
    const waiting = [];                      // sends made before the keys are ready
    let keys = null, seq = 0, sub = null, hour = 0, left = false;
    let onJoin = () => {}, onLeave = () => {};
    let tipTimers = [], hbTimer = null, lastHiReply = 0;
    const timers = [];
    const stats = { sent: 0, got: 0, hb: 0, wantOut: 0, wantIn: 0, resent: 0, holes: 0 };

    const tags = async () => { const h = hourOf(now()); return Promise.all([h - 1, h, h + 1].map(x => tagFor(keys, x))); };
    async function publish(kind, env, targets, prio) {
      if (left && env.c !== "bye") return;
      const tag = await tagFor(keys, hourOf(now()));
      pool.publish(kind, tag, await seal(keys, env), targets, prio);
    }
    const live = () => [...peers.values()];

    /* ---- sending ---- */
    function dataTargets(to) {
      if (to) {
        const p = peers.get(to);
        const open = pool.usable(KIND_DATA);
        if (p && p.relays && p.relays.size) {
          const shared = open.filter(c => p.relays.has(fpOf(c.url)));
          if (shared.length) return shuffle(shared).slice(0, 2);
        }
        return open;
      }
      return cover(KIND_DATA, live());
    }
    function sendData(name, data, to, prio) {
      if (!keys) { waiting.push([name, data, to, prio]); return; }
      const env = { c: "m", f: selfId, a: name, d: data };
      if (to) { env.to = to; env.dq = (dseq.get(to) || 0) + 1; dseq.set(to, env.dq); sent.set(to + ":" + env.dq, env); }
      else { env.q = ++seq; sent.set(String(env.q), env); }
      if (sent.size > BUFFER) sent.delete(sent.keys().next().value);
      stats.sent++;
      publish(KIND_DATA, env, dataTargets(to), prio);
      tipTimers.forEach(clearTimeout);
      tipTimers = TIPS.map(ms => setTimeout(() => heartbeat(false, true), ms));
    }
    function heartbeat(hi, tip) {
      if (!keys || left) return;
      const env = { c: "hb", f: selfId, top: seq, r: myFps(KIND_DATA) };
      const d = {};
      for (const id of peers.keys()) if (dseq.get(id)) d[id.slice(0, 8)] = dseq.get(id);
      if (Object.keys(d).length) env.d = d;
      if (hi) env.hi = 1;
      stats.hb++;
      /* A hello goes everywhere (that's how people find each other); routine heartbeats go where the
       * people here can hear them, and only to relays with budget to spare. */
      if (hi) publish(KIND_CTRL, env, pool.usable(KIND_CTRL), "all");
      else publish(KIND_CTRL, env, cover(KIND_CTRL, live()), tip ? "tip" : "low");
    }
    function schedule() {
      clearTimeout(hbTimer);
      hbTimer = setTimeout(() => { heartbeat(false); schedule(); }, HB_MS + Math.random() * 5000);
    }

    /* ---- receiving ----
     * Two streams per sender: b (their messages to everyone) and d (their messages to me alone). Each
     * remembers which numbers arrived; anything missing below the highest number known is a hole. */
    const stream = floor => ({ floor, max: floor, seen: new Set() });
    function contact(env) {
      let p = peers.get(env.f);
      if (p) { p.heard = now(); return p; }
      const base = env.c === "m" && env.q ? env.q - 1 : (env.top | 0);
      p = { id: env.f, heard: now(), relays: new Set(), b: stream(base), d: stream(0), repair: null, tries: 0 };
      peers.set(env.f, p);
      onJoin(env.f);
      return p;
    }
    function missing(st) {
      const out = [];
      for (let q = Math.max(st.floor + 1, st.max - 400); q <= st.max && out.length < ASK_MAX; q++) if (!st.seen.has(q)) out.push(q);
      return out;
    }
    function checkHoles(p) {
      if (p.repair || (!missing(p.b).length && !missing(p.d).length)) return;
      p.repair = setTimeout(function again() {
        p.repair = null;
        if (!peers.has(p.id) || left) return;
        const qs = missing(p.b), dqs = missing(p.d);
        if (!qs.length && !dqs.length) { p.tries = 0; return; }
        p.tries++;
        if (p.tries === 6) report("repair", roomId, `still missing ${qs.length + dqs.length} message(s) from ${p.id.slice(0, 6)}`);
        stats.wantOut++; stats.holes = qs.length + dqs.length;
        publish(KIND_CTRL, { c: "want", f: selfId, of: p.id, qs, dqs }, dataTargets(p.id), "now");
        p.repair = setTimeout(again, ASK_MS[Math.min(p.tries - 1, ASK_MS.length - 1)]);
      }, SETTLE_MS);
    }
    function mark(st, q) {
      if (st.seen.has(q)) return false;
      st.seen.add(q);
      if (q > st.max) st.max = q;
      if (st.seen.size > 3000) { const cut = st.max - 2000; for (const x of st.seen) if (x < cut) st.seen.delete(x); st.floor = Math.max(st.floor, cut); }
      return true;
    }
    function deliver(p, env) {
      let fresh;
      if (env.to) { if (env.to !== selfId || typeof env.dq !== "number") return; fresh = mark(p.d, env.dq); }
      else { if (typeof env.q !== "number") return; fresh = mark(p.b, env.q); }
      if (fresh) {
        stats.got++;
        const h = handlers.get(env.a);
        if (h) try { h(env.d, env.f, { q: env.q, dq: env.dq }); } catch (e) { console.error(e); }
      }
      checkHoles(p);
    }
    async function receive(ev) {
      if (!keys || left) return;
      const env = await unseal(keys, ev.content);
      if (!env || typeof env.f !== "string" || env.f === selfId) return;
      if (env.c === "bye") { const p = peers.get(env.f); if (p) { clearTimeout(p.repair); peers.delete(env.f); onLeave(env.f); } return; }
      if (env.c === "m" && env.to && env.to !== selfId) { const p = peers.get(env.f); if (p) p.heard = now(); return; }
      const p = contact(env);
      if (env.c === "m") deliver(p, env);
      else if (env.c === "hb") {
        if (Array.isArray(env.r)) p.relays = new Set(env.r.map(String));
        let grew = false;
        if ((env.top | 0) > p.b.max) { p.b.max = env.top | 0; grew = true; }
        const mine = env.d && env.d[selfId.slice(0, 8)];
        if ((mine | 0) > p.d.max) { p.d.max = mine | 0; grew = true; }
        if (grew) checkHoles(p);
        if (env.hi && now() - lastHiReply > 3000) { lastHiReply = now(); setTimeout(() => heartbeat(false), 200 + Math.random() * 1200); }
      } else if (env.c === "want" && env.of === selfId) {
        const keys = [];
        for (const q of (Array.isArray(env.qs) ? env.qs : []).slice(0, ASK_MAX)) keys.push(String(q));
        for (const q of (Array.isArray(env.dqs) ? env.dqs : []).slice(0, ASK_MAX)) keys.push(env.f + ":" + q);
        stats.wantIn++;
        const t = now();
        for (const k of keys) {
          const m = sent.get(k);
          if (!m || t - (resentAt.get(k) || 0) < RESEND_GAP_MS) continue;
          resentAt.set(k, t); if (resentAt.size > 2000) resentAt.clear();
          stats.resent++; publish(KIND_DATA, m, dataTargets(env.f), "now");
        }
        /* Numbers we no longer hold (long gone from the buffer): say so, so they stop asking. */
        const gq = (env.qs || []).filter(q => !sent.has(String(q))), gd = (env.dqs || []).filter(q => !sent.has(env.f + ":" + q));
        if (gq.length || gd.length) publish(KIND_CTRL, { c: "gone", f: selfId, of: env.f, qs: gq, dqs: gd }, dataTargets(env.f), "now");
      } else if (env.c === "gone" && env.of === selfId) {
        (env.qs || []).forEach(q => mark(p.b, +q)); (env.dqs || []).forEach(q => mark(p.d, +q));
      }
    }

    /* ---- liveness ---- */
    timers.push(setInterval(() => {
      const cut = now() - STALE_MS;
      for (const [id, p] of peers) if (p.heard < cut) { clearTimeout(p.repair); peers.delete(id); onLeave(id); }
    }, 5000));
    timers.push(setInterval(async () => {                // the tag rolls over on the hour
      if (!keys || hourOf(now()) === hour) return;
      hour = hourOf(now()); const t = await tags(); sub.tagsNow = t; sub.h.refresh();
    }, 30000));

    (async () => {
      keys = await roomKeys(secret);
      if (left) return;
      hour = hourOf(now());
      sub = { tagsNow: await tags() };
      sub.h = pool.subscribe(since => [{ kinds: [KIND_DATA, KIND_CTRL], "#t": sub.tagsNow, since }], ev => receive(ev));
      heartbeat(true);
      timers.push(setTimeout(() => heartbeat(true), 6000));
      schedule();
      waiting.splice(0).forEach(([a, d, t, pr]) => sendData(a, d, t, pr));
    })();

    const room = {
      selfId,
      set onPeerJoin(f) { onJoin = f; [...peers.keys()].forEach(id => f(id)); },
      set onPeerLeave(f) { onLeave = f; },
      peers: () => [...peers.keys()],
      heard: id => (peers.get(id) || {}).heard || 0,
      action(name) {
        return {
          send(data, to, prio) { sendData(name, data, to, prio); },
          set onMessage(f) { handlers.set(name, f); },
        };
      },
      /* Back in the foreground: say hello so everyone answers, and repair anything missed meanwhile. */
      wake() { heartbeat(true); },
      leave() {
        if (left) return;
        if (keys) publish(KIND_CTRL, { c: "bye", f: selfId }, cover(KIND_CTRL, live()));
        left = true;
        tipTimers.forEach(clearTimeout); clearTimeout(hbTimer); timers.forEach(t => { clearInterval(t); clearTimeout(t); });
        for (const p of peers.values()) clearTimeout(p.repair);
        if (sub) sub.h.close();
        rooms.delete(roomId);
      },
      _stats: () => ({ ...stats, peers: [...peers.values()].map(p => ({ b: [p.b.floor, p.b.max, p.b.seen.size], d: [p.d.floor, p.d.max, p.d.seen.size], tries: p.tries })) }),
      _diag: () => [...peers.values()].map(p => ({ peer: p.id, via: [...p.relays].map(f => (fpUrl.get(f) || f).replace(/^wss?:\/\//, "")) })),
    };
    rooms.set(roomId, room);
    return room;
  }

  if (hasDOM) {
    addEventListener("pagehide", () => { for (const r of [...rooms.values()]) r.leave(); });
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState !== "visible") return;
      pool.wake();
      for (const r of rooms.values()) r.wake();
    });
  }

  return {
    kind: "relays",
    join,
    diag() {
      const rs = {};
      for (const [id, r] of rooms) rs[id] = r._diag();
      const st = {};
      for (const [id, r] of rooms) st[id] = r._stats();
      return { stats: st, selfId, sockets: { relays: pool.status() }, relays: pool.detail(), queued: pool.queued(), rooms: rs, errors: errors.slice(), sentKB: Math.round(pool.bytesOut() / 1024) };
    },
  };
}
