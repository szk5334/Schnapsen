/* RELAY TRANSPORT — every message rides public Nostr relays, sealed. Phones never connect to each other.
 *
 * Same surface as the old WebRTC transport (join → action → send/onMessage, onPeerJoin/onPeerLeave), so
 * the mesh, chat, table and lockstep match on top of it are unchanged.
 *
 * What a relay sees: events signed by a brand-new throwaway key each time, carrying one random-looking tag
 * that changes every hour, and a body of AES-256-GCM ciphertext padded to a fixed bucket size. Who is
 * talking, in which room, and what was said or played are all inside the seal. (A relay does see the IP
 * address that posted an event, and when.)
 *
 * Getting messages through relays that drop things:
 *   - every data message carries a sequence number: one counter for messages to everyone, and one per
 *     person for messages to just them (so a watcher never waits on a card key that wasn't for them);
 *   - heartbeats carry the sender's latest numbers and which relays it can reach;
 *   - a receiver that sees a hole (a q it never got, below someone's top) asks for it after a short settle
 *     ("want"), and the sender republishes it on every relay;
 *   - a short "tip" heartbeat follows every burst of messages, so a lost last message is noticed within
 *     seconds instead of waiting for the next regular heartbeat;
 *   - data events are stored by relays for a few hours, so a phone whose connection dropped asks each relay
 *     for what it missed when it reconnects.
 * Messages go to the relays both sides can reach (two of them for one person, a covering set plus a spare
 * for everyone); a relay that refuses an event is skipped for ten minutes and the event goes elsewhere.
 */
import { newKey, pubOf, signId, sha256hex } from "../../vendor/nostr.js";

export const DEFAULT_RELAYS = [
  "wss://relay.damus.io",
  "wss://nos.lol",
  "wss://relay.primal.net",
  "wss://nostr.mom",
  "wss://relay.nostr.net",
  "wss://offchain.pub",
];
export const KIND_DATA = 4747, KIND_CTRL = 24747;

const KEEP_S = 6 * 3600;            // relays keep data events this long (NIP-40 expiration)
const HB_MS = 25000;                // regular heartbeat
const STALE_MS = 80000;             // not heard from this long → gone
const TIPS = [2000, 6000, 14000];        // heartbeats this long after the last message of a burst
const SETTLE_MS = 1500;             // wait this long for stragglers before asking for a hole
const ASK_MS = [2000, 3000, 4000, 6000];   // then ask again at this pace (the last one repeats) while they're here
const REFUSE_MS = 600000;           // skip a relay that refused a kind for this long
const BUFFER = 600;                 // sent messages kept for re-sending

const S = globalThis.crypto.subtle;
const te = new TextEncoder(), td = new TextDecoder();
const hasDOM = typeof document !== "undefined" && typeof addEventListener === "function";
const now = () => Date.now();
const rnd = n => globalThis.crypto.getRandomValues(new Uint8Array(n));
const hexOf = b => [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, "0")).join("");
function b64(u) { let s = ""; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); }
const unb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
const shuffle = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = rnd(1)[0] % (i + 1); [a[i], a[j]] = [a[j], a[i]]; } return a; };
/* A relay's 4-hex fingerprint (FNV-1a of its URL), so heartbeats can say "I can reach these" in a few bytes. */
export function fpOf(url) {
  let h = 0x811c9dc5;
  for (const ch of String(url).toLowerCase().replace(/\/+$/, "")) { h ^= ch.charCodeAt(0); h = Math.imul(h, 0x01000193) >>> 0; }
  return (h & 0xffff).toString(16).padStart(4, "0");
}

/* ------------------------------------------------------------------ sealing */
async function roomKeys(secret) {
  const base = await S.importKey("raw", te.encode(secret), "HKDF", false, ["deriveBits"]);
  const bits = info => S.deriveBits({ name: "HKDF", hash: "SHA-256", salt: te.encode("schnapsen/relay/v1"), info: te.encode(info) }, base, 256);
  const aes = await S.importKey("raw", await bits("body"), "AES-GCM", false, ["encrypt", "decrypt"]);
  const mac = await S.importKey("raw", await bits("tag"), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return { aes, mac };
}
const hourOf = ts => Math.floor(ts / 3600e3);
async function tagFor(keys, hour) { return hexOf(await S.sign("HMAC", keys.mac, te.encode("h:" + hour))).slice(0, 32); }
const BUCKETS = [256, 512, 1024, 2048, 4096, 8192, 16384, 32768, 65536, 131072];
function pad(bytes) {
  const size = BUCKETS.find(s => s >= bytes.length + 4) || bytes.length + 4;
  const out = new Uint8Array(size);
  new DataView(out.buffer).setUint32(0, bytes.length);
  out.set(bytes, 4);
  out.set(rnd(Math.min(65536, size - 4 - bytes.length)).subarray(0, size - 4 - bytes.length), 4 + bytes.length);
  return out;
}
async function seal(keys, obj) {
  const iv = rnd(12);
  const ct = new Uint8Array(await S.encrypt({ name: "AES-GCM", iv }, keys.aes, pad(te.encode(JSON.stringify(obj)))));
  const out = new Uint8Array(12 + ct.length); out.set(iv); out.set(ct, 12);
  return b64(out);
}
async function unseal(keys, box) {
  try {
    const raw = unb64(box);
    const pt = new Uint8Array(await S.decrypt({ name: "AES-GCM", iv: raw.subarray(0, 12) }, keys.aes, raw.subarray(12)));
    const n = new DataView(pt.buffer, pt.byteOffset).getUint32(0);
    return JSON.parse(td.decode(pt.subarray(4, 4 + n)));
  } catch { return null; }
}
function makeEvent(kind, tag, content) {
  const sk = newKey();
  const pubkey = pubOf(sk);
  const created_at = Math.floor(now() / 1000);
  const tags = [["t", tag]];
  if (kind === KIND_DATA) tags.push(["expiration", String(created_at + KEEP_S)]);
  const id = sha256hex(te.encode(JSON.stringify([0, pubkey, created_at, kind, tags, content])));
  return { id, pubkey, created_at, kind, tags, content, sig: signId(id, sk) };
}

/* ------------------------------------------------------------------ the relay pool */
function relayPool(urls, report) {
  const conns = new Map();                 // url -> { ws, open, queue, attempt, lastAt, refused:{kind:until}, timer }
  const subs = new Map();                  // id -> { filters(sinceFor), cb, since }
  const seen = new Set();
  const pending = new Map();               // event id -> { ev, sent:Set(url), at }
  let n = 0;

  function connect(url) {
    const old = conns.get(url);
    const c = { url, ws: null, open: false, queue: [], attempt: old ? old.attempt : 0, lastAt: old ? old.lastAt : 0, refused: old ? old.refused : {}, timer: null, state: "connecting", bytesOut: old ? old.bytesOut : 0 };
    conns.set(url, c);
    let ws;
    try { ws = new WebSocket(url); } catch (e) { c.state = "closed"; report("relay", url, "could not open: " + (e && e.message || e)); retry(c); return; }
    c.ws = ws;
    ws.onopen = () => {
      c.open = true; c.state = "open"; c.attempt = 0;
      for (const [id, s] of subs) ws.send(JSON.stringify(["REQ", id, ...s.filters(c.lastAt ? c.lastAt - 60 : s.since)]));
      for (const m of c.queue.splice(0)) { c.bytesOut += m.length; ws.send(m); }
    };
    ws.onmessage = e => {
      let m; try { m = JSON.parse(e.data); } catch { return; }
      if (m[0] === "EVENT") {
        const ev = m[2], s = subs.get(m[1]);
        if (!ev || typeof ev.id !== "string") return;
        if (ev.created_at > c.lastAt && ev.created_at <= now() / 1000 + 60) c.lastAt = ev.created_at;
        if (!s || seen.has(ev.id)) return;
        seen.add(ev.id); if (seen.size > 20000) seen.clear();
        s.cb(ev, url);
      } else if (m[0] === "OK") {
        const p = pending.get(m[1]);
        if (m[2] === false) {
          const kind = p ? p.ev.kind : KIND_DATA;
          c.refused[kind] = now() + REFUSE_MS;
          report("relay", url, "refused an event" + (m[3] ? ": " + String(m[3]).slice(0, 120) : ""));
          if (p) {                                   // send it somewhere that will take it
            const alt = usable(kind).filter(x => !p.sent.has(x.url));
            const pick = alt.length ? alt : [...conns.values()].filter(x => !p.sent.has(x.url));
            pick.slice(0, 2).forEach(x => { p.sent.add(x.url); push(x, JSON.stringify(["EVENT", p.ev])); });
          }
        }
      } else if (m[0] === "CLOSED" || m[0] === "NOTICE") {
        report("relay", url, m[0].toLowerCase() + ": " + String(m[2] || m[1] || "").slice(0, 120));
      }
    };
    ws.onclose = () => { if (conns.get(url) !== c) return; c.open = false; c.state = "closed"; retry(c); };
    ws.onerror = () => {};
  }
  function retry(c) {
    clearTimeout(c.timer);
    const wait = Math.min(60000, 1500 * 2 ** c.attempt) + Math.random() * 1000;
    c.attempt++;
    c.timer = setTimeout(() => { if (conns.get(c.url) === c && !c.open) connect(c.url); }, wait);
  }
  function push(c, m) {
    if (c.open) { try { c.bytesOut += m.length; c.ws.send(m); } catch { c.queue.push(m); } }
    else if (c.queue.length < 400) c.queue.push(m);
  }
  /* Relays that are open and haven't refused this kind lately. */
  function usable(kind) {
    const t = now();
    return [...conns.values()].filter(c => c.open && !((c.refused[kind] || 0) > t));
  }
  urls.forEach(connect);
  setInterval(() => { const cut = now() - 120000; for (const [id, p] of pending) if (p.at < cut) pending.delete(id); }, 30000);

  return {
    urls,
    usable,
    all: () => [...conns.values()],
    /* Publish to the given connections (or all when none are usable). */
    publish(kind, tag, content, targets) {
      const ev = makeEvent(kind, tag, content);
      seen.add(ev.id);
      let list = targets && targets.length ? targets : usable(kind);
      if (!list.length) list = [...conns.values()];
      const m = JSON.stringify(["EVENT", ev]);
      pending.set(ev.id, { ev, sent: new Set(list.map(c => c.url)), at: now() });
      list.forEach(c => push(c, m));
      return ev;
    },
    subscribe(filters, cb) {
      const id = "sx" + (++n) + hexOf(rnd(3));
      const s = { filters, cb, since: Math.floor(now() / 1000) - 15 };
      subs.set(id, s);
      for (const c of conns.values()) if (c.open) c.ws.send(JSON.stringify(["REQ", id, ...filters(s.since)]));
      return {
        refresh() {                                  // tags rotated: same id, new filter (replaces the old one)
          for (const c of conns.values()) if (c.open) c.ws.send(JSON.stringify(["REQ", id, ...filters(c.lastAt ? c.lastAt - 60 : s.since)]));
        },
        close() {
          subs.delete(id);
          for (const c of conns.values()) if (c.open) try { c.ws.send(JSON.stringify(["CLOSE", id])); } catch {}
        },
      };
    },
    /* The page came back to the foreground: reconnect anything closed right away. */
    wake() { for (const c of conns.values()) if (!c.open) { clearTimeout(c.timer); c.attempt = 0; connect(c.url); } },
    status() {
      const t = now();
      return Object.fromEntries([...conns.values()].map(c => [c.url, c.open && Object.values(c.refused).some(u => u > t) ? "refusing" : c.state]));
    },
    bytesOut() { return [...conns.values()].reduce((a, c) => a + c.bytesOut, 0); },
  };
}

/* ------------------------------------------------------------------ the transport */
export function relayP2P(cfg = {}) {
  const appId = cfg.p2pAppId || "szk5334-schnapsen";
  const urls = (cfg.relays && cfg.relays.length ? cfg.relays : DEFAULT_RELAYS).slice();
  const fpUrl = new Map(urls.map(u => [fpOf(u), u]));
  const errors = [];
  const report = (via, where, error) => {
    const last = errors[errors.length - 1];
    if (last && last.via === via && last.room === where && last.error === error) { last.n = (last.n || 1) + 1; last.at = now(); return; }
    errors.push({ at: now(), via, room: where, error }); if (errors.length > 40) errors.shift();
  };
  const pool = relayPool(urls, report);
  const selfId = hexOf(rnd(8));
  const rooms = new Map();
  const myFps = kind => pool.usable(kind).map(c => fpOf(c.url));

  /* Smallest set of my open relays that reaches every live peer, plus one spare. Unknown → all. */
  function cover(kind, peers) {
    const open = pool.usable(kind);
    if (!open.length) return [];
    if (!peers.length || peers.some(p => !p.relays || !p.relays.size)) return open;
    const left = new Set(peers.map((_, i) => i));
    const pick = [];
    while (left.size) {
      let best = null, bestHit = 0;
      for (const c of open) {
        if (pick.includes(c)) continue;
        const f = fpOf(c.url); let hit = 0;
        for (const i of left) if (peers[i].relays.has(f)) hit++;
        if (hit > bestHit) { best = c; bestHit = hit; }
      }
      if (!best) return open;                         // somebody shares no relay with me: everywhere
      pick.push(best);
      for (const i of [...left]) if (peers[i].relays.has(fpOf(best.url))) left.delete(i);
    }
    const spare = shuffle(open.filter(c => !pick.includes(c)))[0];
    if (spare) pick.push(spare);
    return pick;
  }

  function join(roomId, opts = {}) {
    const secret = `sx1|${appId}|${roomId}|${opts.password || ""}`;
    const peers = new Map();                 // peerId -> { heard, relays:Set, b:stream (to all), d:stream (to me), repair, tries }
    const handlers = new Map();              // action name -> fn
    const sent = new Map();                  // "q" or "peer:dq" -> envelope (for re-sending)
    const dseq = new Map();                  // peerId -> last private number sent to them
    const waiting = [];                      // sends made before the keys are ready
    let keys = null, seq = 0, sub = null, hour = 0, left = false;
    let onJoin = () => {}, onLeave = () => {};
    let tipTimers = [], hbTimer = null, lastHiReply = 0;
    const timers = [];
    const stats = { sent: 0, got: 0, hb: 0, wantOut: 0, wantIn: 0, resent: 0, holes: 0 };

    const tags = async () => { const h = hourOf(now()); return Promise.all([h - 1, h, h + 1].map(x => tagFor(keys, x))); };
    async function publish(kind, env, targets) {
      if (left && env.c !== "bye") return;
      const tag = await tagFor(keys, hourOf(now()));
      pool.publish(kind, tag, await seal(keys, env), targets);
    }
    const live = () => [...peers.values()];

    /* ---- sending ---- */
    function dataTargets(to) {
      if (to) {
        const p = peers.get(to);
        const open = pool.usable(KIND_DATA);
        if (p && p.relays && p.relays.size) {
          const shared = open.filter(c => p.relays.has(fpOf(c.url)));
          if (shared.length) return shuffle(shared).slice(0, 2);
        }
        return open;
      }
      return cover(KIND_DATA, live());
    }
    function sendData(name, data, to) {
      if (!keys) { waiting.push([name, data, to]); return; }
      const env = { c: "m", f: selfId, a: name, d: data };
      if (to) { env.to = to; env.dq = (dseq.get(to) || 0) + 1; dseq.set(to, env.dq); sent.set(to + ":" + env.dq, env); }
      else { env.q = ++seq; sent.set(String(env.q), env); }
      if (sent.size > BUFFER) sent.delete(sent.keys().next().value);
      stats.sent++;
      publish(KIND_DATA, env, dataTargets(to));
      tipTimers.forEach(clearTimeout);
      tipTimers = TIPS.map(ms => setTimeout(() => heartbeat(false), ms));
    }
    function heartbeat(hi) {
      if (!keys || left) return;
      const env = { c: "hb", f: selfId, top: seq, r: myFps(KIND_DATA) };
      const d = {};
      for (const id of peers.keys()) if (dseq.get(id)) d[id.slice(0, 8)] = dseq.get(id);
      if (Object.keys(d).length) env.d = d;
      if (hi) env.hi = 1;
      stats.hb++;
      publish(KIND_CTRL, env, hi ? pool.usable(KIND_CTRL) : cover(KIND_CTRL, live()));
    }
    function schedule() {
      clearTimeout(hbTimer);
      hbTimer = setTimeout(() => { heartbeat(false); schedule(); }, HB_MS + Math.random() * 5000);
    }

    /* ---- receiving ----
     * Two streams per sender: b (their messages to everyone) and d (their messages to me alone). Each
     * remembers which numbers arrived; anything missing below the highest number known is a hole. */
    const stream = floor => ({ floor, max: floor, seen: new Set() });
    function contact(env) {
      let p = peers.get(env.f);
      if (p) { p.heard = now(); return p; }
      const base = env.c === "m" && env.q ? env.q - 1 : (env.top | 0);
      p = { id: env.f, heard: now(), relays: new Set(), b: stream(base), d: stream(0), repair: null, tries: 0 };
      peers.set(env.f, p);
      onJoin(env.f);
      return p;
    }
    function missing(st) {
      const out = [];
      for (let q = Math.max(st.floor + 1, st.max - 400); q <= st.max && out.length < 64; q++) if (!st.seen.has(q)) out.push(q);
      return out;
    }
    function checkHoles(p) {
      if (p.repair || (!missing(p.b).length && !missing(p.d).length)) return;
      p.repair = setTimeout(function again() {
        p.repair = null;
        if (!peers.has(p.id) || left) return;
        const qs = missing(p.b), dqs = missing(p.d);
        if (!qs.length && !dqs.length) { p.tries = 0; return; }
        p.tries++;
        if (p.tries === 6) report("repair", roomId, `still missing ${qs.length + dqs.length} message(s) from ${p.id.slice(0, 6)}`);
        stats.wantOut++; stats.holes = qs.length + dqs.length;
        publish(KIND_CTRL, { c: "want", f: selfId, of: p.id, qs, dqs }, pool.usable(KIND_CTRL));
        p.repair = setTimeout(again, ASK_MS[Math.min(p.tries - 1, ASK_MS.length - 1)]);
      }, SETTLE_MS);
    }
    function mark(st, q) {
      if (st.seen.has(q)) return false;
      st.seen.add(q);
      if (q > st.max) st.max = q;
      if (st.seen.size > 3000) { const cut = st.max - 2000; for (const x of st.seen) if (x < cut) st.seen.delete(x); st.floor = Math.max(st.floor, cut); }
      return true;
    }
    function deliver(p, env) {
      let fresh;
      if (env.to) { if (env.to !== selfId || typeof env.dq !== "number") return; fresh = mark(p.d, env.dq); }
      else { if (typeof env.q !== "number") return; fresh = mark(p.b, env.q); }
      if (fresh) {
        stats.got++;
        const h = handlers.get(env.a);
        if (h) try { h(env.d, env.f, { q: env.q, dq: env.dq }); } catch (e) { console.error(e); }
      }
      checkHoles(p);
    }
    async function receive(ev) {
      if (!keys || left) return;
      const env = await unseal(keys, ev.content);
      if (!env || typeof env.f !== "string" || env.f === selfId) return;
      if (env.c === "bye") { const p = peers.get(env.f); if (p) { clearTimeout(p.repair); peers.delete(env.f); onLeave(env.f); } return; }
      if (env.c === "m" && env.to && env.to !== selfId) { const p = peers.get(env.f); if (p) p.heard = now(); return; }
      const p = contact(env);
      if (env.c === "m") deliver(p, env);
      else if (env.c === "hb") {
        if (Array.isArray(env.r)) p.relays = new Set(env.r.map(String));
        let grew = false;
        if ((env.top | 0) > p.b.max) { p.b.max = env.top | 0; grew = true; }
        const mine = env.d && env.d[selfId.slice(0, 8)];
        if ((mine | 0) > p.d.max) { p.d.max = mine | 0; grew = true; }
        if (grew) checkHoles(p);
        if (env.hi && now() - lastHiReply > 3000) { lastHiReply = now(); setTimeout(() => heartbeat(false), 200 + Math.random() * 1200); }
      } else if (env.c === "want" && env.of === selfId) {
        const again = [];
        for (const q of (Array.isArray(env.qs) ? env.qs : []).slice(0, 64)) again.push(sent.get(String(q)));
        for (const q of (Array.isArray(env.dqs) ? env.dqs : []).slice(0, 64)) again.push(sent.get(env.f + ":" + q));
        stats.wantIn++;
        for (const m of again) if (m) { stats.resent++; publish(KIND_DATA, m, pool.usable(KIND_DATA)); }
        /* Numbers we no longer hold (long gone from the buffer): say so, so they stop asking. */
        const gq = (env.qs || []).filter(q => !sent.has(String(q))), gd = (env.dqs || []).filter(q => !sent.has(env.f + ":" + q));
        if (gq.length || gd.length) publish(KIND_CTRL, { c: "gone", f: selfId, of: env.f, qs: gq, dqs: gd }, pool.usable(KIND_CTRL));
      } else if (env.c === "gone" && env.of === selfId) {
        (env.qs || []).forEach(q => mark(p.b, +q)); (env.dqs || []).forEach(q => mark(p.d, +q));
      }
    }

    /* ---- liveness ---- */
    timers.push(setInterval(() => {
      const cut = now() - STALE_MS;
      for (const [id, p] of peers) if (p.heard < cut) { clearTimeout(p.repair); peers.delete(id); onLeave(id); }
    }, 5000));
    timers.push(setInterval(async () => {                // the tag rolls over on the hour
      if (!keys || hourOf(now()) === hour) return;
      hour = hourOf(now()); const t = await tags(); sub.tagsNow = t; sub.h.refresh();
    }, 30000));

    (async () => {
      keys = await roomKeys(secret);
      if (left) return;
      hour = hourOf(now());
      sub = { tagsNow: await tags() };
      sub.h = pool.subscribe(since => [{ kinds: [KIND_DATA, KIND_CTRL], "#t": sub.tagsNow, since }], ev => receive(ev));
      heartbeat(true);
      timers.push(setTimeout(() => heartbeat(true), 3000), setTimeout(() => heartbeat(true), 9000));
      schedule();
      waiting.splice(0).forEach(([a, d, t]) => sendData(a, d, t));
    })();

    const room = {
      selfId,
      set onPeerJoin(f) { onJoin = f; [...peers.keys()].forEach(id => f(id)); },
      set onPeerLeave(f) { onLeave = f; },
      peers: () => [...peers.keys()],
      heard: id => (peers.get(id) || {}).heard || 0,
      action(name) {
        return {
          send(data, to) { sendData(name, data, to); },
          set onMessage(f) { handlers.set(name, f); },
        };
      },
      /* Back in the foreground: say hello so everyone answers, and repair anything missed meanwhile. */
      wake() { heartbeat(true); },
      leave() {
        if (left) return;
        if (keys) publish(KIND_CTRL, { c: "bye", f: selfId }, pool.usable(KIND_CTRL));
        left = true;
        tipTimers.forEach(clearTimeout); clearTimeout(hbTimer); timers.forEach(t => { clearInterval(t); clearTimeout(t); });
        for (const p of peers.values()) clearTimeout(p.repair);
        if (sub) sub.h.close();
        rooms.delete(roomId);
      },
      _stats: () => ({ ...stats, peers: [...peers.values()].map(p => ({ b: [p.b.floor, p.b.max, p.b.seen.size], d: [p.d.floor, p.d.max, p.d.seen.size], tries: p.tries })) }),
      _diag: () => [...peers.values()].map(p => ({ peer: p.id, via: [...p.relays].map(f => (fpUrl.get(f) || f).replace(/^wss?:\/\//, "")) })),
    };
    rooms.set(roomId, room);
    return room;
  }

  if (hasDOM) {
    addEventListener("pagehide", () => { for (const r of [...rooms.values()]) r.leave(); });
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState !== "visible") return;
      pool.wake();
      for (const r of rooms.values()) r.wake();
    });
  }

  return {
    kind: "relays",
    join,
    diag() {
      const rs = {};
      for (const [id, r] of rooms) rs[id] = r._diag();
      const st = {};
      for (const [id, r] of rooms) st[id] = r._stats();
      return { stats: st, selfId, sockets: { relays: pool.status() }, rooms: rs, errors: errors.slice(), sentKB: Math.round(pool.bytesOut() / 1024) };
    },
  };
}
