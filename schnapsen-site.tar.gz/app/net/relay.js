/* RELAY TRANSPORT — every message rides public Nostr relays, sealed. Phones never connect to each other.
 *
 * Same surface as the old WebRTC transport (join → action → send/onMessage, onPeerJoin/onPeerLeave), so
 * the mesh, chat, table and lockstep match on top of it are unchanged.
 *
 * What a relay sees: ephemeral events (never stored) signed by one key per page load, carrying one
 * random-looking tag that changes every hour, and a body of AES-256-GCM ciphertext padded to a fixed bucket
 * size. Who is talking, in which room, and what was said or played are all inside the seal. (A relay does see
 * the IP address that posted an event, and when.)
 *
 * Being a good guest on relays run by volunteers for social media (see the pool, and HANDOFF.md):
 *   - nothing stored: both kinds are ephemeral; nothing of ours sits on anyone's disk;
 *   - few events: one copy per person, messages a moment apart batched into one event, no routine heartbeat
 *     when nobody else is here or the page has long been hidden, a hello at most every 30 s;
 *   - a hard budget per relay well under common per-IP limits, and long rests when a relay says slow down.
 *
 * Getting messages through relays that drop things:
 *   - every data message carries a sequence number: one counter for messages to everyone, and one per
 *     person for messages to just them (so a watcher never waits on a card key that wasn't for them);
 *   - heartbeats carry the sender's latest numbers and which relays it can reach;
 *   - a receiver that sees a hole (a q it never got, below someone's top) asks for it after a short settle
 *     ("want"), and the sender sends it again on a relay they share;
 *   - a "tip" heartbeat follows a burst of messages unless everyone has answered meanwhile, so a lost last
 *     message is noticed within seconds instead of at the next regular heartbeat;
 *   - a connection that has quietly died is found by probing and replaced (see the pool).
 * Messages go to the relays both sides can reach (one for one person, a covering set for everyone), within
 * each relay's rules and send budget.
 */
import { newKey, pubOf, signId, sha256hex } from "../../vendor/nostr.js";

/* General-purpose public relays with no published login, payment, web-of-trust or kind wall (reviewed Oct 2026;
 * see "Being a good guest" in HANDOFF.md). Any that blocks us, rate-limits us or is unreachable is set aside
 * automatically (see the pool). Left out on purpose:
 *   relay.damus.io       the flagship social relay; its anti-spam plugin bans an IP for an hour after repeated
 *                        rate-limit hits, and bursts have got other apps banned there (Oct 2026)
 *   offchain.pub, nostr.bitcoiner.social   web-of-trust filtered
 *   relay.mostr.pub      now only redirects to relay.ditto.pub
 *   relay.nostr.band     down since mid 2026
 *   relay.0xchat.com     one chat app's private-message inbox relay: not ours to use
 * Check them from #/net. */
export const DEFAULT_RELAYS = [
  "wss://nos.lol",
  "wss://nostr.mom",
  "wss://relay.primal.net",
  "wss://relay.ditto.pub",
  "wss://relay.coinos.io",
  "wss://relay.nostr.net",
  "wss://relay.snort.social",
  "wss://nostr.oxtr.dev",
  "wss://nostr-pub.wellorder.net",
];
/* Extra relays the #/net checker tries (two test posts each, only when someone presses the button). */
export const CANDIDATE_RELAYS = DEFAULT_RELAYS.concat([
  "wss://relay.damus.io",
  "wss://nostrue.com",
]);
/* Both kinds are EPHEMERAL (20000-29999): relays pass them on and store nothing. Nothing of ours sits on a
 * volunteer's disk; catching up after a dropped connection is done by our own repair (want / re-send). */
export const KIND_DATA = 24748, KIND_CTRL = 24747;

/* THE HOUSE RELAYS — Seth's own relays (a Cloudflare Worker first, ideally one on another provider second), set
 * here or in config.js as `house: "wss://…"` or a list in order of preference. Everything goes to the first one
 * that is up and that everyone can reach; the next takes over if it goes down.
 * When it is up, everything goes there and the public relays are only listened to; they carry our messages
 * only while the house relay is unreachable, resting or refusing. Its budget is generous but sustainable on
 * Cloudflare's free plan (incoming WebSocket messages count 1/20 against 100,000 requests a day, so about
 * 2 million messages): a burst of 30, then one a second per page. Two phones flat out all day would be
 * ~170,000 messages; a whole match is a few hundred. */
export const HOUSE_RELAY = ["wss://schnapsen-relay.szk5334.workers.dev"];   // live since Oct 27, 2026
const HOUSE_BUCKET = 30, HOUSE_REFILL_MS = 1000;

const HB_MS = 60000;                // regular heartbeat (only while someone else is here and the page isn't long hidden)
const STALE_MS = 190000;            // not heard from this long → gone
const HIDDEN_QUIET_MS = 300000;     // a page hidden this long stops its routine heartbeats
const HELLO_GAP_MS = 30000;         // a room says hello at most this often (coming back on screen, network back)
const TIP_MS = 10000;               // after a burst, a heartbeat this much later, unless everyone here has answered
const BATCH_MS = 25;                // messages sent within this long to the same people travel as one event
const SETTLE_MS = 1500;             // wait this long for stragglers before asking for a hole
const ASK_MS = [2000, 4000, 8000, 12000];  // then ask again at this pace (the last one repeats) while they're here
const ASK_MAX = 16;                 // numbers per ask
const RESEND_GAP_MS = 8000;         // a message is re-sent at most this often, however often it's asked for
const OUTBOX_MAX = 150;             // data waiting for budget; beyond this the oldest go (repair brings them back)
const REFUSE_MS = 600000;           // skip a relay that refused a kind for this long
const BUFFER = 600;                 // sent messages kept for re-sending

const S = globalThis.crypto.subtle;
const te = new TextEncoder(), td = new TextDecoder();
const hasDOM = typeof document !== "undefined" && typeof addEventListener === "function";
const now = () => Date.now();
const rnd = n => globalThis.crypto.getRandomValues(new Uint8Array(n));
const hexOf = b => [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, "0")).join("");
function b64(u) { let s = ""; for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); }
const unb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
const shuffle = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = rnd(1)[0] % (i + 1); [a[i], a[j]] = [a[j], a[i]]; } return a; };
/* A relay's 4-hex fingerprint (FNV-1a of its URL), so heartbeats can say "I can reach these" in a few bytes. */
export function fpOf(url) {
  let h = 0x811c9dc5;
  for (const ch of String(url).toLowerCase().replace(/\/+$/, "")) { h ^= ch.charCodeAt(0); h = Math.imul(h, 0x01000193) >>> 0; }
  return (h & 0xffff).toString(16).padStart(4, "0");
}

/* ------------------------------------------------------------------ sealing */
async function roomKeys(secret) {
  const base = await S.importKey("raw", te.encode(secret), "HKDF", false, ["deriveBits"]);
  const bits = info => S.deriveBits({ name: "HKDF", hash: "SHA-256", salt: te.encode("schnapsen/relay/v1"), info: te.encode(info) }, base, 256);
  const aes = await S.importKey("raw", await bits("body"), "AES-GCM", false, ["encrypt", "decrypt"]);
  const mac = await S.importKey("raw", await bits("tag"), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return { aes, mac };
}
const hourOf = ts => Math.floor(ts / 3600e3);
async function tagFor(keys, hour) { return hexOf(await S.sign("HMAC", keys.mac, te.encode("h:" + hour))).slice(0, 32); }
/* Padding sizes stop at 32 KB: sealed and base64'd that is about 44 KB of event, under strfry's default 64 KB
 * event limit. Anything larger (never seen in play) is padded only to the next 4 KB. */
const BUCKETS = [256, 512, 1024, 2048, 4096, 8192, 16384, 32768];
function pad(bytes) {
  const size = BUCKETS.find(s => s >= bytes.length + 4) || Math.ceil((bytes.length + 4) / 4096) * 4096;
  const out = new Uint8Array(size);
  new DataView(out.buffer).setUint32(0, bytes.length);
  out.set(bytes, 4);
  out.set(rnd(Math.min(65536, size - 4 - bytes.length)).subarray(0, size - 4 - bytes.length), 4 + bytes.length);
  return out;
}
async function seal(keys, obj) {
  const iv = rnd(12);
  const ct = new Uint8Array(await S.encrypt({ name: "AES-GCM", iv }, keys.aes, pad(te.encode(JSON.stringify(obj)))));
  const out = new Uint8Array(12 + ct.length); out.set(iv); out.set(ct, 12);
  return b64(out);
}
async function unseal(keys, box) {
  try {
    const raw = unb64(box);
    const pt = new Uint8Array(await S.decrypt({ name: "AES-GCM", iv: raw.subarray(0, 12) }, keys.aes, raw.subarray(12)));
    const n = new DataView(pt.buffer, pt.byteOffset).getUint32(0);
    return JSON.parse(td.decode(pt.subarray(4, 4 + n)));
  } catch { return null; }
}
/* One signing key per page load (not per event): single-use keys defeat the per-key anti-spam relays rely on
 * (NIP-59 says as much), and an operator should be able to see, limit or block us by key rather than by the
 * IP address both phones of a household share. Trystero does the same. */
let pageKey = null;
function makeEvent(kind, tag, content, sk) {
  sk = sk || pageKey || (pageKey = newKey());
  const pubkey = pubOf(sk);
  const created_at = Math.floor(now() / 1000);
  const tags = [["t", tag]];
  const id = sha256hex(te.encode(JSON.stringify([0, pubkey, created_at, kind, tags, content])));
  return { id, pubkey, created_at, kind, tags, content, sig: signId(id, sk) };
}

/* ------------------------------------------------------------------ the relay pool
 *
 * Public relays are run by volunteers for social media, and they defend themselves: per-IP rate limits that
 * turn into bans, web-of-trust filters that refuse keys nobody follows, login or payment walls. So the pool
 * plays by their rules instead of pushing through them:
 *
 *   - each relay's NIP-11 rules are read first; one that needs a login, payment, proof-of-work or limits
 *     writes is never written to;
 *   - every relay has a send budget well under common per-IP limits (strfry's usual rate-limit plugin: 10 a
 *     minute per IP; Damus's: about 6): a token bucket 2 deep, one token back every 20 s — at most 5 events in
 *     any minute and 3 a minute after, per page, so two phones on one home IP stay at or under 10 and 6. Relays run by one operator on one server
 *     (nos.lol and nostr.mom) share one bucket. Out of budget, a message tries another relay, then waits;
 *     routine heartbeats are skipped first;
 *   - replies are read by their standard prefixes: "rate-limited:" rests that relay 10 min, doubling to 2 h,
 *     so it never sees a quick second strike (some relays ban an IP after a few); "blocked:", "restricted:",
 *     "auth-required:" and "pow:" retire it for a day (remembered across reloads); "mute:" (nobody was
 *     listening) is fine; the event goes elsewhere either way;
 *   - a relay whose connection keeps failing (often what an IP ban looks like) is retried only every 10 min.
 */
const BUCKET = 2, REFILL_MS = 20000;            // send budget per relay (or per operator group): burst 2, then 3 a minute
const HB_RESERVE = 1;                           // heartbeats only go to relays with this much budget left
const SLOW_MS = 600000, SLOW_MAX_MS = 7200000;  // rest after "rate-limited:", doubling each time
const GROUP = { "wss://nos.lol": "nos.lol", "wss://nostr.mom": "nos.lol" };   // one server, one budget
const STALE_EVENT_S = 40;                       // an event older than this is re-signed before it is sent
const OFF_MS = 24 * 3600e3;                     // a relay that blocked us sits out this long
const DEAD_TRIES = 4, DEAD_RETRY_MS = 600000;   // connection failures before the slow retry, and its pace
/* A relay that worked earlier this session and then stops taking connections is far more likely restarting or
 * briefly down than banning us, so it gets many more ordinary tries (backoff capped at a minute, about 8 min
 * in all) before the slow retry. Before this, a relay down for ~25 s was shunned for 10 minutes. */
const DEAD_TRIES_KNOWN = 12;
/* Dead connections that look alive. A phone that sleeps or hops between wifi and cell can be left holding a
 * socket that still reads "open" while nothing gets through either way, and send() into it never fails. So a
 * connection is probed (a tiny REQ the relay must answer with EOSE) when the page comes back on screen, when
 * the network comes back or changes, when a post goes unanswered, and after a long silence. No answer → it is
 * dropped and reopened at once, everything posted into it since its last answer goes out again, and the
 * subscription asks for what it missed (`since`). */
const CONNECT_MS = 10000;                       // a connection not open after this long is given up and retried
const PROBE_MS = 6000;                          // a probe unanswered this long → the connection is dead
const ACK_MS = 8000;                            // a post with no OK this long → probe
const QUIET_MS = 45000;                         // nothing heard on a connection this long → probe (a REQ, not an event: no budget)
const UNACKED_MS = 120000, UNACKED_MAX = 200, RESEND_MAX = 30;   // posts kept for re-sending after a reconnect
const offline = () => typeof navigator !== "undefined" && navigator.onLine === false;
const lsGet = k => { try { const v = localStorage.getItem("sx.relay." + k); return v ? JSON.parse(v) : null; } catch { return null; } };
const lsSet = (k, v) => { try { localStorage.setItem("sx.relay." + k, JSON.stringify(v)); } catch {} };
export const httpOf = url => String(url).replace(/^ws/, "http");

/* A relay's published rules (NIP-11), cached for a day. Resolves to null when it publishes none. */
export async function relayRules(url, { fresh = false } = {}) {
  const key = "nip11." + url, hit = !fresh && lsGet(key);
  if (hit && now() - hit.at < OFF_MS) return hit.info;
  if (typeof fetch !== "function") return null;
  try {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 5000);
    const r = await fetch(httpOf(url), { headers: { Accept: "application/nostr+json" }, signal: ctl.signal });
    clearTimeout(t);
    const info = await r.json();
    lsSet(key, { at: now(), info });
    return info;
  } catch { return null; }
}
/* Why we can't write to a relay, from its rules — or null if nothing in them stops us. */
export function rulesBar(info) {
  const l = (info && info.limitation) || {};
  if (l.auth_required) return "needs a login (NIP-42)";
  if (l.payment_required) return "paid members only";
  if (l.restricted_writes) return "only accepts writes from approved people";
  if (l.min_pow_difficulty > 0) return `wants proof-of-work (${l.min_pow_difficulty} bits)`;
  return null;
}
/* What a refusal means, from NIP-01's standard prefixes. */
export function reading(msg) {
  const m = String(msg || "").toLowerCase();
  if (m.startsWith("duplicate:") || m.startsWith("mute:")) return "ok";   // mute: delivered, nobody was listening
  if (m.startsWith("rate-limited:") || /rate.?limit|too (many|fast)|slow down/.test(m)) return "slow";
  if (/^(blocked|restricted|auth-required|pow):/.test(m) || /web of trust|\bwot\b|not allowed|whitelist|allowlist|paid|pay to/.test(m)) return "off";
  return "refused";
}

function relayPool(urls, report, houses = []) {
  const rank = url => houses.indexOf(url);
  const conns = new Map();                 // url -> connection state
  const subs = new Map();                  // id -> { filters(since), cb, since }
  const seen = new Set();
  const pending = new Map();               // event id -> { ev, msg, sent:Set(url), at, prio }
  const outbox = [];                       // data events waiting for budget
  const buckets = new Map();               // group -> { tokens, refillAt, slowN, slowUntil }
  const specs = new Map();                 // event id -> { kind, tag, content, at } so a stale event can be re-signed
  let n = 0, droppedNote = 0;
  const bucketOf = url => {
    const g = GROUP[url] || url;
    const own = rank(url) >= 0;
    const cap = own ? HOUSE_BUCKET : BUCKET, refillMs = own ? HOUSE_REFILL_MS : REFILL_MS;
    if (!buckets.has(g)) buckets.set(g, { tokens: cap, cap, refillMs, refillAt: now(), slowN: 0, slowUntil: 0 });
    return buckets.get(g);
  };
  /* Ephemeral events are refused once they are a minute old (strfry's default), so one that waited for budget
   * or for a connection is signed again before it goes. Receivers drop the duplicate by its sequence number. */
  function renew(m, id) {
    const sp = id && specs.get(id);
    if (!sp || now() / 1000 - sp.at < STALE_EVENT_S) return [m, id];
    const ev = makeEvent(sp.kind, sp.tag, sp.content);
    specs.delete(id); specs.set(ev.id, { ...sp, at: ev.created_at }); seen.add(ev.id);
    return [JSON.stringify(["EVENT", ev]), ev.id];
  }
  const remember = ev => { specs.set(ev.id, { kind: ev.kind, tag: ev.tags[0][1], content: ev.content, at: ev.created_at }); if (specs.size > 3000) specs.delete(specs.keys().next().value); };

  const offInfo = url => { const o = lsGet("off." + url); return o && o.until > now() ? o : null; };
  function retire(c, why) {
    const until = now() + OFF_MS;
    c.off = { why, until }; lsSet("off." + c.url, c.off);
    report("relay", c.url, "stopped using it for a day: " + why);
    clearTimeout(c.timer);
    try { c.ws && c.ws.close(); } catch {}
  }
  function slowDown(c, why) {
    const b = c.bk;
    b.slowN = (b.slowN || 0) + 1;
    b.slowUntil = now() + Math.min(SLOW_MAX_MS, SLOW_MS * 2 ** (b.slowN - 1));
    b.tokens = 0;
    report("relay", c.url, `asked us to slow down — resting it ${Math.round((b.slowUntil - now()) / 60000)} min` + (why ? ": " + String(why).slice(0, 100) : ""));
  }

  function make(url) {
    const c = { url, ws: null, open: false, queue: [], attempt: 0, fails: 0, lastAt: 0, refused: {}, timer: null,
      state: "connecting", bytesOut: 0, events: 0, bk: bucketOf(url),
      off: offInfo(url), rules: null, maxLen: 0, everOpen: false, house: rank(url) >= 0, rank: rank(url),
      gen: 0, lastRx: 0, unacked: new Map(), probe: null, probedAt: 0,
      reqAt: new Map(), eose: new Set() };
    conns.set(url, c);
    return c;
  }
  async function start(c) {
    if (c.off) { c.state = "off"; return; }
    const info = await relayRules(c.url);
    c.rules = info;
    const bar = rulesBar(info);
    if (bar) { retire(c, "its published rules: " + bar); c.state = "off"; return; }
    const ml = info && info.limitation && +info.limitation.max_message_length;
    if (ml > 0) c.maxLen = ml;
    connect(c);
  }
  function connect(c) {
    if (c.off) { c.state = "off"; return; }
    let ws;
    c.state = "connecting";
    try { ws = new WebSocket(c.url); } catch (e) { c.state = "closed"; retry(c); return; }
    c.ws = ws; c.gen++;
    let opened = false;
    /* The end of this connection, however it comes: closed, an error before it opened (some WebSocket
     * implementations never follow that with a close), or still not open after CONNECT_MS (a phone on a bad
     * network can sit in "connecting" for minutes). */
    const lost = () => {
      clearTimeout(slow);
      if (conns.get(c.url) !== c || c.ws !== ws) return;
      c.ws = null; c.open = false; c.state = c.off ? "off" : "closed";
      try { ws.onopen = ws.onmessage = ws.onclose = ws.onerror = null; if (!opened) ws.close(); } catch {}
      if (c.probe) { clearTimeout(c.probe.timer); c.probe = null; }
      if (!opened && !offline()) c.fails++;          // failing while the phone has no network says nothing about the relay
      if (!c.off) retry(c);
    };
    const slow = setTimeout(() => { if (!opened) lost(); }, CONNECT_MS);
    ws.onopen = () => {
      if (c.ws !== ws) return;
      clearTimeout(slow);
      opened = true; c.open = true; c.everOpen = true; c.state = "open"; c.attempt = 0; c.fails = 0; c.lastRx = now();
      for (const [id, s] of subs) req(c, id, s.filters(c.lastAt ? c.lastAt - 60 : s.since));
      for (const [m, id] of c.queue.splice(0)) send(c, m, id);
      /* Posts that went into an earlier connection and were never answered: send them again (relays and
       * receivers both drop duplicates by event id). */
      const cut = now() - UNACKED_MS, again = [];
      for (const [id, u] of c.unacked) { if (u.at < cut) c.unacked.delete(id); else if (u.gen !== c.gen) again.push([u.m, id]); }
      again.slice(-RESEND_MAX).forEach(([m, id]) => send(c, m, id));
      if (again.length) report("relay", c.url, `back after a dead connection; sent ${Math.min(again.length, RESEND_MAX)} unanswered post(s) again`);
    };
    ws.onmessage = e => {
      if (c.ws !== ws) return;
      c.lastRx = now();
      let m; try { m = JSON.parse(e.data); } catch { return; }
      if (c.probe && (m[0] === "EOSE" || m[0] === "CLOSED") && m[1] === c.probe.id) {
        /* Alive. Anything posted before the probe that is still unanswered was taken in silence. */
        clearTimeout(c.probe.timer);
        for (const [id, u] of c.unacked) if (u.gen === c.gen && u.at <= c.probe.at) c.unacked.delete(id);
        c.probe = null;
        if (m[0] === "EOSE") try { ws.send(JSON.stringify(["CLOSE", m[1]])); } catch {}
        return;
      }
      if (m[0] === "OK") c.unacked.delete(m[1]);
      if (m[0] === "EOSE") c.eose.add(m[1]);
      if (m[0] === "EVENT") {
        const ev = m[2], s = subs.get(m[1]);
        if (!ev || typeof ev.id !== "string") return;
        if (ev.created_at > c.lastAt && ev.created_at <= now() / 1000 + 60) c.lastAt = ev.created_at;
        if (!s || seen.has(ev.id)) return;
        seen.add(ev.id); if (seen.size > 20000) seen.clear();
        /* Stored (replayed for the `since` window, before the relay's EOSE) or live. A relay that never sends EOSE
         * counts as live 10 s after the request. Judged by the relay's protocol, not the sender's clock. */
        const at = c.reqAt.get(m[1]);
        s.cb(ev, c.url, !!at && !c.eose.has(m[1]) && now() - at < 10000);
      } else if (m[0] === "OK") {
        if (m[2] !== false) return;
        const p = pending.get(m[1]);
        const r = reading(m[3]);
        if (r === "ok") return;
        if (r === "slow") slowDown(c, m[3]);
        else if (r === "off") retire(c, String(m[3] || "refused").slice(0, 120));
        else {
          const kind = p ? p.kind : KIND_DATA;
          c.refused[kind] = now() + REFUSE_MS;
          report("relay", c.url, "refused an event" + (m[3] ? ": " + String(m[3]).slice(0, 120) : ""));
        }
        if (p && p.prio !== "low") {                 // send it somewhere that will take it
          const alt = usable(p.ev.kind).filter(x => !p.sent.has(x.url) && fits(x, p.msg));
          alt.slice(0, 1).forEach(x => { p.sent.add(x.url); spend(x); push(x, p.msg, p.ev.id); });
        }
      } else if (m[0] === "CLOSED") {
        const r = reading(m[2]);
        if (r === "off" || /^(auth-required|restricted|blocked):/i.test(String(m[2] || ""))) retire(c, "won't let us read: " + String(m[2] || "").slice(0, 100));
        else if (r === "slow") slowDown(c, m[2]);
        else report("relay", c.url, "closed a subscription: " + String(m[2] || "").slice(0, 100));
      } else if (m[0] === "NOTICE") {
        if (reading(m[1]) === "slow") slowDown(c, m[1]);
        else report("relay", c.url, "notice: " + String(m[1] || "").slice(0, 120));
      } else if (m[0] === "AUTH") {
        retire(c, "asks for a login (NIP-42)");
      }
    };
    ws.onclose = lost;
    ws.onerror = () => { if (!opened) lost(); };
  }
  function retry(c) {
    clearTimeout(c.timer);
    let wait;
    /* The house relay is ours: nobody to annoy, so it is retried briskly (every 15 s at most, every 2 min after
     * ~10 min down). Each attempt is one request against its daily allowance; this stays far inside it. */
    const tries = c.house ? 40 : c.everOpen ? DEAD_TRIES_KNOWN : DEAD_TRIES;
    if (c.fails >= tries) {
      wait = c.house ? 120000 : DEAD_RETRY_MS;
      if (c.fails === tries) report("relay", c.url, c.house ? "the house relay is down — trying again every 2 min" : "can't connect (down, or it has banned this network) — trying again every 10 min");
      c.state = "unreachable";
    } else wait = Math.min(c.house ? 15000 : 60000, 1500 * 2 ** c.attempt) + Math.random() * 1000;
    c.attempt++;
    c.timer = setTimeout(() => { if (conns.get(c.url) === c && !c.open && !c.off) connect(c); }, wait);
  }
  function req(c, id, filters) {
    c.reqAt.set(id, now()); c.eose.delete(id);
    try { c.ws.send(JSON.stringify(["REQ", id, ...filters])); } catch {}
  }
  function send(c, m, id) {
    const [m2, id2] = renew(m, id);
    if (id2 !== id) { const u = c.unacked.get(id); c.unacked.delete(id); if (u) c.unacked.set(id2, { ...u, m: m2 }); }
    try {
      c.bytesOut += m2.length; c.events++; c.sentAt = now(); c.ws.send(m2);
      const u = id2 && c.unacked.get(id2); if (u) { u.gen = c.gen; u.at = now(); }
    } catch { if (c.queue.length < 100) c.queue.push([m2, id2]); }
  }
  function push(c, m, id) {
    if (id) {
      c.unacked.set(id, { m, at: now(), gen: -1 });
      if (c.unacked.size > UNACKED_MAX) c.unacked.delete(c.unacked.keys().next().value);
    }
    if (c.open) send(c, m, id);
    else if (c.queue.length < 100) c.queue.push([m, id]);
  }
  /* Is this connection really there? Ask it something it must answer. */
  function probe(c, why) {
    if (!c.open || c.probe || !c.ws) return;
    const id = "pr" + hexOf(rnd(4));
    c.probedAt = now();
    try { c.ws.send(JSON.stringify(["REQ", id, { kinds: [KIND_CTRL], "#t": [hexOf(rnd(16))], limit: 1 }])); }
    catch { kill(c, why); return; }
    c.probe = { id, at: now(), timer: setTimeout(() => { if (c.probe && c.probe.id === id) { c.probe = null; kill(c, why); } }, PROBE_MS) };
  }
  /* Drop a connection that stopped answering and open a fresh one right away. */
  function kill(c, why) {
    const ws = c.ws;
    c.ws = null; c.open = false; c.state = "closed";
    if (c.probe) { clearTimeout(c.probe.timer); c.probe = null; }
    if (ws) try { ws.onopen = ws.onmessage = ws.onclose = null; ws.close(); } catch {}
    report("relay", c.url, `stopped answering (${why}) — reconnecting`);
    clearTimeout(c.timer); c.attempt = 0;
    if (!c.off) connect(c);
  }
  setInterval(() => {
    const t = now();
    for (const c of conns.values()) {
      if (!c.open || c.probe) continue;
      let late = false;
      for (const u of c.unacked.values()) if (u.gen === c.gen && t - u.at > ACK_MS) { late = true; break; }
      if (late) probe(c, "a post went unanswered");
      /* Silence is only worth a probe on a relay we rely on: the house relay, or one we've sent to lately.
       * Standby public relays aren't pestered with probes. */
      else if ((c.house || t - (c.sentAt || 0) < 300000) && t - c.lastRx > QUIET_MS && t - c.probedAt > QUIET_MS) probe(c, "silent for a while");
    }
  }, 2000);
  function refill(c) {
    const t = now();
    const b = c.bk;
    if (t < b.slowUntil) { b.refillAt = t; return; }
    const add = Math.floor((t - b.refillAt) / b.refillMs);
    if (add > 0) { b.tokens = Math.min(b.cap, b.tokens + add); b.refillAt += add * b.refillMs; }
    if (b.tokens >= b.cap) b.refillAt = t;
  }
  const spend = c => { refill(c); c.bk.tokens = Math.max(0, c.bk.tokens - 1); };
  const budget = c => { refill(c); return now() < c.bk.slowUntil ? 0 : c.bk.tokens; };
  const fits = (c, msg) => !c.maxLen || msg.length <= c.maxLen;
  /* Relays that are open, not resting, not refusing this kind, and have budget for one more event. */
  function usable(kind, reserve = 1) {
    const t = now();
    return [...conns.values()].filter(c => c.open && !c.off && !((c.refused[kind] || 0) > t) && (reserve <= 0 ? t >= c.bk.slowUntil : budget(c) >= reserve));
  }
  /* The house relay among these targets, if it is connected and not resting or retired (budget aside). */
  const alive = list => (list || []).find(c => c.house && c.open && !c.off && now() >= c.bk.slowUntil) || null;
  /* Data that found no relay with budget waits here and goes out as budget returns. */
  setInterval(() => {
    while (outbox.length) {
      const o = outbox[0];
      const ok = usable(o.ev.kind).filter(c => fits(c, o.msg)).sort((a, b) => (a.house ? a.rank : 99) - (b.house ? b.rank : 99));
      if (!ok.length) break;
      outbox.shift();
      /* Meant for the house relay and it is up: wait for its budget (a second) rather than spill onto public relays. */
      const hw = alive(o.want);
      if (hw && !ok.includes(hw)) break;
      const pick = hw ? [hw] : (o.want.filter(c => ok.includes(c)).length ? o.want.filter(c => ok.includes(c)) : ok).slice(0, o.count);
      pick.forEach(c => { o.sent.add(c.url); spend(c); push(c, o.msg, o.ev.id); });
      if (pick.length && o.onOut) try { o.onOut(); } catch {}
    }
    const cut = now() - 120000; for (const [id, p] of pending) if (p.at < cut) pending.delete(id);
  }, 500);

  for (const u of urls) start(make(u));

  return {
    urls,
    usable,
    /* The house relays that can take this kind right now, best first. */
    houses(kind) { return usable(kind).filter(c => c.house).sort((a, b) => a.rank - b.rank); },
    all: () => [...conns.values()],
    /* Publish to the wanted relays that have budget; top up from others; queue (data) or drop (low). */
    /* onOut: called once the event has actually gone to a relay (now, or later from the outbox). */
    publish(kind, tag, content, targets, prio = "normal", onOut) {
      const ev = makeEvent(kind, tag, content);
      seen.add(ev.id); remember(ev);
      const msg = JSON.stringify(["EVENT", ev]);
      prio = prio || "normal";
      /* "force" (the goodbye): every open relay that isn't resting, whatever its budget. One event each, sent
       * from a closing page that gets no second chance; right after a deal the budgets are often all spent. */
      const reserve = prio === "low" ? HB_RESERVE : prio === "force" ? 0 : 1;
      const ok = usable(kind, reserve).filter(c => fits(c, msg));
      const want = (targets && targets.length ? targets : ok);
      /* Normally one copy per person (targets are chosen that way); budgets low everywhere: one copy, full stop.
       * Lost ones are repaired (want / re-send). */
      const lean = prio === "tip" || prio === "now" || ok.every(c => budget(c) < c.bk.cap / 2);
      const count = prio === "all" || prio === "force" ? ok.length : lean ? 1 : Math.max(1, Math.min(want.length, 3));
      let pick = want.filter(c => ok.includes(c));
      /* First in, first out: while earlier messages wait for budget, a new one waits behind them. Overtaking
       * made the other side see a gap, ask for the waiting message, and get it twice. */
      if (prio === "normal" && outbox.length) pick = [];
      if (prio !== "all" && prio !== "force" && !alive(want) && pick.length < Math.min(count, ok.length)) pick = pick.concat(ok.filter(c => !pick.includes(c)).slice(0, count - pick.length));
      const p = { ev, kind, msg, sent: new Set(), at: now(), prio };
      pending.set(ev.id, p);
      if (!pick.length) {
        /* Only first sends wait for budget. Heartbeats, tips and re-sends are dropped instead: they're
         * repeated anyway, and a queue of stale re-sends is what starves everything else. */
        if (prio === "normal" || prio === "all") {
          /* An "all" (a hello) made before any connection was open had count 0, so the outbox took it out and sent
           * it nowhere: every page lost its first hello and was heard only at the second, 6 s later. Now it goes to
           * the first two relays to open, house relays first (everyone listens on every relay). */
          outbox.push({ ev, msg, want, count: prio === "all" ? 2 : count, sent: p.sent, onOut });
          if (outbox.length > OUTBOX_MAX) { outbox.shift(); if (!droppedNote++) report("relay", "all", "too much waiting for relay budget; dropped the oldest (they'll be repaired)"); }
        }
        return ev;
      }
      pick.forEach(c => { p.sent.add(c.url); spend(c); push(c, msg, ev.id); });
      if (onOut) try { onOut(); } catch {}
      return ev;
    },
    subscribe(filters, cb) {
      const id = "sx" + (++n) + hexOf(rnd(3));
      const s = { filters, cb, since: Math.floor(now() / 1000) - 15 };
      subs.set(id, s);
      for (const c of conns.values()) if (c.open) req(c, id, filters(s.since));
      return {
        refresh() {                                  // tags rotated: same id, new filter (replaces the old one)
          for (const c of conns.values()) if (c.open) req(c, id, filters(c.lastAt ? c.lastAt - 60 : s.since));
        },
        close() {
          subs.delete(id);
          for (const c of conns.values()) if (c.open) try { c.ws.send(JSON.stringify(["CLOSE", id])); } catch {}
        },
      };
    },
    /* The page came back to the foreground (or, with `net`, the network came back or changed): check every open
     * connection and reopen closed ones right away. Banned-looking ones wait, unless the network itself changed:
     * failures while the phone was offline or on another network say nothing about the relay. */
    wake(net = false) {
      for (const c of conns.values()) {
        if (c.off) continue;
        if (net) c.fails = 0;
        if (c.open) probe(c, net ? "the network changed" : "the page came back");
        else if (c.fails < (c.everOpen ? DEAD_TRIES_KNOWN : DEAD_TRIES) && c.state !== "connecting") { clearTimeout(c.timer); c.attempt = 0; connect(c); }
      }
    },
    status() {
      const t = now();
      return Object.fromEntries([...conns.values()].map(c => [c.url,
        c.off ? "off" : t < c.bk.slowUntil ? "resting" : c.open && Object.values(c.refused).some(u => u > t) ? "refusing" : c.state]));
    },
    detail() {
      const t = now();
      return [...conns.values()].map(c => ({ url: c.url, state: c.off ? "off" : t < c.bk.slowUntil ? "resting" : c.state,
        why: c.off ? c.off.why : t < c.bk.slowUntil ? `resting ${Math.ceil((c.bk.slowUntil - t) / 60000)} min more` : c.state === "unreachable" ? "can't connect" : "",
        budget: budget(c), events: c.events, kb: Math.round(c.bytesOut / 1024), name: c.rules && c.rules.name || "" }));
    },
    queued: () => outbox.length,
    bytesOut() { return [...conns.values()].reduce((a, c) => a + c.bytesOut, 0); },
  };
}

/* ------------------------------------------------------------------ checking a relay (for #/net)
 * Reads its rules, then does exactly what the game does, once: subscribe on one connection, post one
 * stored and one passing-through event (throwaway keys, random tag, sealed-size body) on another, and see
 * whether the relay accepts them and delivers them back. Costs the relay two events. */
export async function checkRelay(url, ms = 9000) {
  const t0 = now();
  const out = { url, rules: null, bar: null, connect: null, data: null, ctrl: null, echoData: false, echoCtrl: false, ms: 0 };
  const info = await relayRules(url, { fresh: true });
  out.rules = info ? { name: info.name || "", software: info.software || "", limitation: info.limitation || {} } : null;
  out.bar = rulesBar(info);
  const tag = hexOf(rnd(16));
  const body = b64(rnd(256));
  const evs = [makeEvent(KIND_DATA, tag, body), makeEvent(KIND_CTRL, tag, body)];
  const open = () => new Promise(res => {
    let ws; const t = setTimeout(() => { try { ws && ws.close(); } catch {} res(null); }, 6000);
    try { ws = new WebSocket(url); } catch { clearTimeout(t); res(null); return; }
    ws.onopen = () => { clearTimeout(t); res(ws); };
    ws.onerror = () => {}; ws.onclose = () => { clearTimeout(t); res(null); };
  });
  const [rx, tx] = await Promise.all([open(), open()]);
  out.connect = !!(rx && tx);
  if (!out.connect) { [rx, tx].forEach(w => { try { w && w.close(); } catch {} }); out.ms = now() - t0; return out; }
  out.connect = now() - t0;
  await new Promise(res => {
    const done = () => (out.data !== null && out.ctrl !== null && (out.echoData || out.data !== "ok") && (out.echoCtrl || out.ctrl !== "ok")) && res();
    const t = setTimeout(res, ms);
    rx.onmessage = e => {
      let m; try { m = JSON.parse(e.data); } catch { return; }
      if (m[0] === "EVENT" && m[2] && m[2].id === evs[0].id) out.echoData = true;
      if (m[0] === "EVENT" && m[2] && m[2].id === evs[1].id) out.echoCtrl = true;
      if (m[0] === "CLOSED") { out.readRefused = String(m[2] || "closed"); }
      if (m[0] === "EOSE" && !out.sent) { out.sent = true; evs.forEach(ev => tx.send(JSON.stringify(["EVENT", ev]))); }
      done() && clearTimeout(t);
    };
    tx.onmessage = e => {
      let m; try { m = JSON.parse(e.data); } catch { return; }
      if (m[0] === "OK") {
        const v = m[2] === false ? (String(m[3] || "refused") || "refused") : "ok";
        if (m[1] === evs[0].id) out.data = v;
        if (m[1] === evs[1].id) out.ctrl = v;
      } else if (m[0] === "AUTH") { out.auth = true; }
      done() && clearTimeout(t);
    };
    setTimeout(() => { if (!out.sent) { out.sent = true; evs.forEach(ev => tx.send(JSON.stringify(["EVENT", ev]))); } }, 2000);
    rx.send(JSON.stringify(["REQ", "chk" + tag.slice(0, 6), { kinds: [KIND_DATA, KIND_CTRL], "#t": [tag], since: Math.floor(now() / 1000) - 30 }]));
  });
  [rx, tx].forEach(w => { try { w.close(); } catch {} });
  out.ms = now() - t0;
  return out;
}
/* One line a person can read. */
export function verdict(r) {
  if (r.bar) return { ok: false, text: "No: " + r.bar };
  if (!r.connect) return { ok: false, text: "No: can't connect (down, or blocking this network)" };
  if (r.auth) return { ok: false, text: "No: asks for a login" };
  const bad = [r.data, r.ctrl].find(v => v && v !== "ok");
  if (bad) return { ok: false, text: "No: " + bad.slice(0, 90) };
  if (r.data === null || r.ctrl === null) return { ok: false, text: "No: never answered our test post" };
  if (!r.echoData || !r.echoCtrl) return { ok: false, text: `No: took our posts but never passed ${!r.echoData && !r.echoCtrl ? "them" : "one"} on` };
  return { ok: true, text: `Yes (${(r.ms / 1000).toFixed(1)} s)` };
}

/* ------------------------------------------------------------------ the transport */
export function relayP2P(cfg = {}) {
  const appId = cfg.p2pAppId || "szk5334-schnapsen";
  /* config.js `house` replaces the built-in list entirely: "" or [] means no house relay at all. */
  const own = [].concat(cfg.house !== undefined ? cfg.house : HOUSE_RELAY).filter(Boolean);
  const urls = (cfg.relays && cfg.relays.length ? cfg.relays : DEFAULT_RELAYS).filter(u => !own.includes(u));
  urls.unshift(...own);
  const fpUrl = new Map(urls.map(u => [fpOf(u), u]));
  const errors = [];
  const report = (via, where, error) => {
    const last = errors[errors.length - 1];
    if (last && last.via === via && last.room === where && last.error === error) { last.n = (last.n || 1) + 1; last.at = now(); return; }
    errors.push({ at: now(), via, room: where, error }); if (errors.length > 40) errors.shift();
  };
  const pool = relayPool(urls, report, own);
  /* The house relay if it is up and every one of these people can be reached there (or we don't know their
   * relays yet). Someone whose own house connection is down says so in their heartbeat (their relay list),
   * and then gets public relays instead. */
  const houseFor = (kind, peers) =>
    pool.houses(kind).find(h => peers.every(p => !p.relays || !p.relays.size || p.relays.has(fpOf(h.url)))) || null;
  const selfId = hexOf(rnd(8));
  const rooms = new Map();
  const myFps = kind => pool.usable(kind).map(c => fpOf(c.url));
  let hiddenSince = 0;                       // when the page went out of sight (0 = on screen)

  /* Smallest set of my open relays that reaches every live peer — one copy each, no spare (lost messages are
   * repaired). Someone whose relays we don't know yet: two at random. */
  /* Where a hello or a goodbye goes. Everyone listens on every relay, so two copies reach everyone: the best
   * house relay plus one more (the next house relay, else a public one), or two public relays at random. */
  function everywhere(reserve) {
    const open = pool.usable(KIND_CTRL, reserve);
    const hs = open.filter(c => c.house).sort((a, b) => a.rank - b.rank);
    if (hs.length) return hs.slice(0, 2).concat(hs.length < 2 ? shuffle(open.filter(c => !c.house)).slice(0, 1) : []);
    return shuffle(open).slice(0, 2);
  }
  function cover(kind, peers) {
    const h = houseFor(kind, peers);
    if (h) return [h];
    const open = pool.usable(kind);
    if (!open.length) return [];
    if (!peers.length || peers.some(p => !p.relays || !p.relays.size)) return shuffle(open).slice(0, 2);
    const left = new Set(peers.map((_, i) => i));
    const pick = [];
    while (left.size) {
      let best = null, bestHit = 0;
      for (const c of open) {
        if (pick.includes(c)) continue;
        const f = fpOf(c.url); let hit = 0;
        for (const i of left) if (peers[i].relays.has(f)) hit++;
        if (hit > bestHit) { best = c; bestHit = hit; }
      }
      if (!best) return pick.concat(shuffle(open.filter(c => !pick.includes(c))).slice(0, 2));   // somebody shares none: two more at random
      pick.push(best);
      for (const i of [...left]) if (peers[i].relays.has(fpOf(best.url))) left.delete(i);
    }
    return pick;
  }

  function join(roomId, opts = {}) {
    const secret = `sx1|${appId}|${roomId}|${opts.password || ""}`;
    const peers = new Map();                 // peerId -> { heard, relays:Set, b:stream (to all), d:stream (to me), repair, tries }
    const handlers = new Map();              // action name -> fn
    const sent = new Map();                  // "q" or "peer:dq" -> envelope (for re-sending)
    const dseq = new Map();                  // peerId -> last private number sent to them
    const resentAt = new Map();              // sent-buffer key -> when it was last re-sent
    const waiting = [];                      // sends made before the keys are ready
    let keys = null, seq = 0, sub = null, hour = 0, left = false;
    let onJoin = () => {}, onLeave = () => {};
    let tipTimer = null, hbTimer = null, lastHiReply = 0, lastHello = 0, burstAt = 0;
    const batches = new Map();               // "to" peerId or "*" -> { envs: [], prio, timer }
    /* What has actually left (gone to a relay), as opposed to what is numbered but still waiting for budget.
     * Heartbeats announce only these: announcing a waiting message made the other side see a "hole", ask for it,
     * and the re-send spent budget the queue needed — most of a deal's traffic, measured. */
    let outQ = 0;
    const outD = new Map();                  // peerId -> highest private number gone out
    /* The goodbye, sealed ahead of time. Sealing is async (WebCrypto), and a closing page is frozen before an
     * async step finishes, so a goodbye sealed on the way out almost never left. This one is ready to send
     * synchronously from pagehide. Re-sealed each hour; last hour's tag is still heard (receivers listen on
     * h-1, h, h+1), so one prepared just before the hour turns still works. */
    let byeBox = null;
    const gone = new Set();                  // peers that said goodbye: late copies of their events don't revive them
    async function prepBye() {
      const h = hourOf(now());
      if (byeBox && byeBox.h === h) return;
      byeBox = { h, tag: await tagFor(keys, h), content: await seal(keys, { c: "bye", f: selfId }) };
    }
    const timers = [];
    const stats = { sent: 0, got: 0, hb: 0, wantOut: 0, wantIn: 0, resent: 0, holes: 0 };

    const tags = async () => { const h = hourOf(now()); return Promise.all([h - 1, h, h + 1].map(x => tagFor(keys, x))); };
    async function publish(kind, env, targets, prio, onOut) {
      if (left && env.c !== "bye") return;
      if (cfg.onPublish) try { cfg.onPublish(roomId, kind, env, prio); } catch {}     // tests: what goes out, before sealing
      const tag = await tagFor(keys, hourOf(now()));
      pool.publish(kind, tag, await seal(keys, env), targets, prio, onOut);
    }
    const live = () => [...peers.values()];

    /* ---- sending ---- */
    function dataTargets(to) {
      if (to) {
        const p = peers.get(to);
        const h = houseFor(KIND_DATA, p ? [p] : []);
        if (h) return [h];
        const open = pool.usable(KIND_DATA);
        if (p && p.relays && p.relays.size) {
          const shared = open.filter(c => p.relays.has(fpOf(c.url)));
          if (shared.length) return shuffle(shared).slice(0, 1);
        }
        return shuffle(open).slice(0, 2);
      }
      return cover(KIND_DATA, live());
    }
    /* Messages to the same people within BATCH_MS travel as one event (a move and its card key, say): fewer
     * events on every relay. Each message keeps its own number, so repair still works message by message. */
    function sendData(name, data, to, prio) {
      if (!keys) { waiting.push([name, data, to, prio]); return; }
      const env = { c: "m", f: selfId, a: name, d: data };
      if (to) { env.to = to; env.dq = (dseq.get(to) || 0) + 1; dseq.set(to, env.dq); sent.set(to + ":" + env.dq, env); }
      else { env.q = ++seq; sent.set(String(env.q), env); }
      if (sent.size > BUFFER) sent.delete(sent.keys().next().value);
      stats.sent++;
      const k = to || "*";
      let b = batches.get(k);
      if (!b) { b = { envs: [], prio: "low", timer: null }; batches.set(k, b); }
      b.envs.push(env);
      if ((prio || "normal") !== "low") b.prio = "normal";
      if (!b.timer) b.timer = setTimeout(() => flush(k, to), BATCH_MS);
    }
    function flush(k, to) {
      const b = batches.get(k); if (!b) return;
      batches.delete(k);
      const env = b.envs.length === 1 ? b.envs[0] : { c: "mb", f: selfId, ms: b.envs };
      const onOut = () => {
        for (const e of b.envs) {
          if (e.to) { if ((e.dq | 0) > (outD.get(e.to) || 0)) outD.set(e.to, e.dq); }
          else if ((e.q | 0) > outQ) outQ = e.q;
        }
      };
      publish(KIND_DATA, env, dataTargets(to), b.prio, onOut);
      /* A tip: a heartbeat a little later, so a lost last message is noticed soon. Skipped if everyone here
       * has sent us something since (they are talking to us, and their next heartbeat says the rest). */
      burstAt = now();
      clearTimeout(tipTimer);
      tipTimer = setTimeout(() => {
        const ps = live();
        if (!ps.length || ps.every(p => (p.lastData || 0) > burstAt)) return;
        heartbeat(false, true);
      }, TIP_MS);
    }
    function heartbeat(hi, tip, reply) {
      if (!keys || left) return;
      const env = { c: "hb", f: selfId, top: outQ, r: myFps(KIND_DATA) };
      const d = {};
      for (const id of peers.keys()) if (outD.get(id)) d[id.slice(0, 8)] = outD.get(id);
      if (Object.keys(d).length) env.d = d;
      if (hi) { env.hi = 1; lastHello = now(); }
      stats.hb++;
      /* A hello goes everywhere (that's how people find each other); routine heartbeats go where the
       * people here can hear them, and only to relays with budget to spare. */
      if (hi) publish(KIND_CTRL, env, everywhere(1), "all");
      /* The answer to someone's hello is how a returning page finds the people here. As a routine heartbeat it
       * needed 4 tokens of budget and was skipped without them (often, right after a burst), and the newcomer heard
       * nobody until the next regular heartbeat, up to 45 s later. Now: one copy, on a relay the newcomer said it
       * uses, with 1 token. At most one every 3 s. */
      else if (reply) publish(KIND_CTRL, env, dataTargets(reply), "tip");
      else publish(KIND_CTRL, env, cover(KIND_CTRL, live()), tip ? "tip" : "low");
    }
    function schedule() {
      clearTimeout(hbTimer);
      /* Routine heartbeats only while somebody else is here (a newcomer's hello gets an answer anyway) and the
       * page hasn't been out of sight for a long while: nothing at all goes out from an idle page. */
      hbTimer = setTimeout(() => {
        if (peers.size && !(hiddenSince && now() - hiddenSince > HIDDEN_QUIET_MS)) heartbeat(false);
        schedule();
      }, HB_MS + Math.random() * 5000);
    }

    /* ---- receiving ----
     * Two streams per sender: b (their messages to everyone) and d (their messages to me alone). Each
     * remembers which numbers arrived; anything missing below the highest number known is a hole. */
    const stream = floor => ({ floor, max: floor, seen: new Set() });
    function contact(env) {
      let p = peers.get(env.f);
      if (p) { p.heard = now(); return p; }
      const base = env.c === "m" && env.q ? env.q - 1 : (env.top | 0);
      p = { id: env.f, heard: now(), relays: new Set(), b: stream(base), d: stream(0), repair: null, tries: 0 };
      peers.set(env.f, p);
      onJoin(env.f);
      return p;
    }
    function missing(st) {
      const out = [];
      for (let q = Math.max(st.floor + 1, st.max - 400); q <= st.max && out.length < ASK_MAX; q++) if (!st.seen.has(q)) out.push(q);
      return out;
    }
    function checkHoles(p) {
      if (p.repair || (!missing(p.b).length && !missing(p.d).length)) return;
      p.repair = setTimeout(function again() {
        p.repair = null;
        if (!peers.has(p.id) || left) return;
        const qs = missing(p.b), dqs = missing(p.d);
        if (!qs.length && !dqs.length) { p.tries = 0; return; }
        p.tries++;
        if (p.tries === 6) report("repair", roomId, `still missing ${qs.length + dqs.length} message(s) from ${p.id.slice(0, 6)}`);
        stats.wantOut++; stats.holes = qs.length + dqs.length;
        publish(KIND_CTRL, { c: "want", f: selfId, of: p.id, qs, dqs }, dataTargets(p.id), "now");
        p.repair = setTimeout(again, ASK_MS[Math.min(p.tries - 1, ASK_MS.length - 1)]);
      }, SETTLE_MS);
    }
    function mark(st, q) {
      if (st.seen.has(q)) return false;
      st.seen.add(q);
      if (q > st.max) st.max = q;
      if (st.seen.size > 3000) { const cut = st.max - 2000; for (const x of st.seen) if (x < cut) st.seen.delete(x); st.floor = Math.max(st.floor, cut); }
      return true;
    }
    function deliver(p, env) {
      let fresh;
      if (env.to) { if (env.to !== selfId || typeof env.dq !== "number") return; fresh = mark(p.d, env.dq); }
      else { if (typeof env.q !== "number") return; fresh = mark(p.b, env.q); }
      p.lastData = now();
      if (fresh) {
        stats.got++;
        const h = handlers.get(env.a);
        if (h) try { h(env.d, env.f, { q: env.q, dq: env.dq }); } catch (e) { console.error(e); }
      }
      checkHoles(p);
    }
    async function receive(ev, stored) {
      if (!keys || left) return;
      const env = await unseal(keys, ev.content);
      if (!env || typeof env.f !== "string" || env.f === selfId) return;
      if (env.c === "mb") {                              // a batch: each message in it as if it came alone
        if (Array.isArray(env.ms)) for (const e of env.ms.slice(0, 64)) if (e && e.c === "m" && e.f === env.f) handle(e, stored);
        return;
      }
      handle(env, stored);
    }
    function handle(env, stored) {
      if (env.c === "bye") { gone.add(env.f); const p = peers.get(env.f); if (p) { clearTimeout(p.repair); peers.delete(env.f); onLeave(env.f); } return; }
      if (env.c === "m" && env.to && env.to !== selfId) { const p = peers.get(env.f); if (p) p.heard = now(); return; }
      /* Ghosts. A stored event from someone we haven't met (replayed from before we joined: often a page that has
       * since closed or reloaded, our own old page included) proves nothing about them being here, and a peer
       * that said goodbye stays gone. Before, such ghosts lived 140 s, got greeted every 12 s on every relay, and
       * made every broadcast go to all relays (they know none), draining the send budget. Live people answer our
       * hello within a second or two, so nobody real is missed. */
      if (!peers.has(env.f) && (stored || gone.has(env.f))) return;
      const p = contact(env);
      if (env.c === "m") deliver(p, env);
      else if (env.c === "hb") {
        if (Array.isArray(env.r)) p.relays = new Set(env.r.map(String));
        let grew = false;
        if ((env.top | 0) > p.b.max) { p.b.max = env.top | 0; grew = true; }
        const mine = env.d && env.d[selfId.slice(0, 8)];
        if ((mine | 0) > p.d.max) { p.d.max = mine | 0; grew = true; }
        if (grew) checkHoles(p);
        if (env.hi && now() - lastHiReply > 3000) { lastHiReply = now(); setTimeout(() => heartbeat(false, false, env.f), 200 + Math.random() * 1200); }
      } else if (env.c === "want" && env.of === selfId) {
        const keys = [];
        for (const q of (Array.isArray(env.qs) ? env.qs : []).slice(0, ASK_MAX)) keys.push(String(q));
        for (const q of (Array.isArray(env.dqs) ? env.dqs : []).slice(0, ASK_MAX)) keys.push(env.f + ":" + q);
        stats.wantIn++;
        const t = now();
        const again = [];
        for (const k of keys) {
          const m = sent.get(k);
          if (!m || t - (resentAt.get(k) || 0) < RESEND_GAP_MS) continue;
          resentAt.set(k, t); if (resentAt.size > 2000) resentAt.clear();
          stats.resent++; again.push(m);
        }
        /* Everything asked for goes back as one event (a batch), not one event per message. */
        if (again.length) publish(KIND_DATA, again.length === 1 ? again[0] : { c: "mb", f: selfId, ms: again }, dataTargets(env.f), "now");
        /* Numbers we no longer hold (long gone from the buffer): say so, so they stop asking. */
        const gq = (env.qs || []).filter(q => !sent.has(String(q))), gd = (env.dqs || []).filter(q => !sent.has(env.f + ":" + q));
        if (gq.length || gd.length) publish(KIND_CTRL, { c: "gone", f: selfId, of: env.f, qs: gq, dqs: gd }, dataTargets(env.f), "now");
      } else if (env.c === "gone" && env.of === selfId) {
        (env.qs || []).forEach(q => mark(p.b, +q)); (env.dqs || []).forEach(q => mark(p.d, +q));
      }
    }

    /* ---- liveness ---- */
    timers.push(setInterval(() => {
      const cut = now() - STALE_MS;
      for (const [id, p] of peers) if (p.heard < cut) { clearTimeout(p.repair); peers.delete(id); onLeave(id); }
    }, 5000));
    timers.push(setInterval(async () => {                // the tag rolls over on the hour
      if (!keys || hourOf(now()) === hour) return;
      hour = hourOf(now()); const t = await tags(); sub.tagsNow = t; sub.h.refresh(); prepBye();
    }, 30000));

    (async () => {
      keys = await roomKeys(secret);
      if (left) return;
      hour = hourOf(now());
      sub = { tagsNow: await tags() };
      sub.h = pool.subscribe(since => [{ kinds: [KIND_DATA, KIND_CTRL], "#t": sub.tagsNow, since }], (ev, url, stored) => receive(ev, stored && ev.kind === KIND_DATA));   // control events are never stored: always live
      prepBye();
      heartbeat(true);
      timers.push(setTimeout(() => { if (!peers.size) heartbeat(true); }, 6000));   // again only if nobody answered
      schedule();
      waiting.splice(0).forEach(([a, d, t, pr]) => sendData(a, d, t, pr));
    })();

    const room = {
      selfId,
      set onPeerJoin(f) { onJoin = f; [...peers.keys()].forEach(id => f(id)); },
      set onPeerLeave(f) { onLeave = f; },
      peers: () => [...peers.keys()],
      heard: id => (peers.get(id) || {}).heard || 0,
      action(name) {
        return {
          send(data, to, prio) { sendData(name, data, to, prio); },
          set onMessage(f) { handlers.set(name, f); },
        };
      },
      /* Back in the foreground (or the network came back): say hello so everyone answers, and repair anything
       * missed meanwhile. At most once every HELLO_GAP_MS: a phone flicking between apps shouldn't spray hellos. */
      wake() { if (now() - lastHello >= HELLO_GAP_MS) heartbeat(true); },
      leave() {
        if (left) return;
        /* Synchronously, to every relay open, so it is on the wire before this function returns. */
        if (byeBox) pool.publish(KIND_CTRL, byeBox.tag, byeBox.content, everywhere(0), "force");
        else if (keys) publish(KIND_CTRL, { c: "bye", f: selfId }, cover(KIND_CTRL, live()));
        left = true;
        clearTimeout(tipTimer); for (const b of batches.values()) clearTimeout(b.timer); clearTimeout(hbTimer); timers.forEach(t => { clearInterval(t); clearTimeout(t); });
        for (const p of peers.values()) clearTimeout(p.repair);
        if (sub) sub.h.close();
        rooms.delete(roomId);
      },
      backlog: () => pool.queued(),           // messages of ours still waiting for relay budget
      _stats: () => ({ ...stats, peers: [...peers.values()].map(p => ({ b: [p.b.floor, p.b.max, p.b.seen.size], d: [p.d.floor, p.d.max, p.d.seen.size], tries: p.tries })) }),
      _diag: () => [...peers.values()].map(p => ({ peer: p.id, via: [...p.relays].map(f => (fpUrl.get(f) || f).replace(/^wss?:\/\//, "")) })),
    };
    rooms.set(roomId, room);
    return room;
  }

  /* Back on screen, or the network came back or changed: check the connections and say hello everywhere
   * (hellos posted into a connection that turns out dead go out again once it is reopened). */
  function wake(net = false) {
    pool.wake(net);
    for (const r of rooms.values()) r.wake();
  }
  if (hasDOM) {
    addEventListener("pagehide", () => { for (const r of [...rooms.values()]) r.leave(); });
    /* Restored from the back/forward cache after pagehide left every room: start the page afresh. */
    addEventListener("pageshow", e => { if (e.persisted) location.reload(); });
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") { hiddenSince = 0; wake(false); }
      else if (!hiddenSince) hiddenSince = now();
    });
    addEventListener("online", () => wake(true));
    try { const nc = navigator.connection; nc && nc.addEventListener && nc.addEventListener("change", () => wake(true)); } catch {}
  }

  return {
    kind: "relays",
    join,
    wake,
    diag() {
      const rs = {};
      for (const [id, r] of rooms) rs[id] = r._diag();
      const st = {};
      for (const [id, r] of rooms) st[id] = r._stats();
      return { stats: st, selfId, sockets: { relays: pool.status() }, relays: pool.detail(), queued: pool.queued(), rooms: rs, errors: errors.slice(), sentKB: Math.round(pool.bytesOut() / 1024) };
    },
  };
}
