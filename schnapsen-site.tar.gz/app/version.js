/* The build, shown on #/net so two phones can tell at a glance whether they run the same version.
 * Bump it with every tarball. */
export const BUILD = "2026-10-23.2 (relays, polite)";
