/* The build, shown on #/net so two phones can tell at a glance whether they run the same version.
 * Bump it with every tarball. */
export const BUILD = "2026-11-12.1 (Royal House without the double; no opponent hand-count backs)";
