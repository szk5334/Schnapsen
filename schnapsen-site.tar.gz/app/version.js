/* The build, shown on #/net so two phones can tell at a glance whether they run the same version.
 * Bump it with every tarball. */
export const BUILD = "2026-11-10.1 (17/34 marriages, trumps always, 20 cards)";
