/* The build, shown on #/net so two phones can tell at a glance whether they run the same version.
 * Bump it with every tarball. */
export const BUILD = "2026-11-11.1 (Royal House: 32 cards, three phases, the double)";
