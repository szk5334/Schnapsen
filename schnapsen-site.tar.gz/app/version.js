/* The build, shown on #/net so two phones can tell at a glance whether they run the same version.
 * Bump it with every tarball. */
export const BUILD = "2026-11-18.1 (Scroll & Stone: Onitama with Sensei's Path, promos, Way of the Wind, Light and Shadow)";
