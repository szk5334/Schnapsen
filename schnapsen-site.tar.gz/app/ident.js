import { LS, uid, colorFor, cleanName, cell } from "./util.js";

/* Who this device is. The client id is permanent; the name is whatever the person typed. A second tab
 * on the same phone shares the id (same person), which is what presence de-duplication relies on. */
let cid = LS.get("sx.cid");
if (!cid) { cid = uid(); LS.set("sx.cid", cid); }

export const me = cell({ cid, name: LS.get("sx.name", ""), color: colorFor(cid) });

export function setName(n) {
  const name = cleanName(n);
  LS.set("sx.name", name);
  me.set(v => ({ ...v, name }));
}

/* Settings that only affect this screen. */
export const prefs = cell(Object.assign({ memory: false, sound: true }, LS.get("sx.prefs", {})));
prefs.sub(v => LS.set("sx.prefs", v));
