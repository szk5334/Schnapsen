import { LS, uid, colorFor, cleanName, cell } from "./util.js";

/* Who this device is. The client id is permanent; the name is whatever the person typed. A second tab
 * on the same phone shares the id (same person), which is what presence de-duplication relies on. */
let cid = LS.get("sx.cid");
if (!cid) { cid = uid(); LS.set("sx.cid", cid); }

export const me = cell({ cid, name: LS.get("sx.name", ""), color: colorFor(cid) });

export function setName(n) {
  const name = cleanName(n);
  LS.set("sx.name", name);
  me.set(v => ({ ...v, name }));
}

/* Settings that only affect this screen. */
export const prefs = cell(Object.assign({ memory: false, sound: true, big: false }, LS.get("sx.prefs", {})));
prefs.sub(v => LS.set("sx.prefs", v));

/* HIGH VISIBILITY, per phone: plain tinted card faces with one huge rank and suit, the hand laid out flat with no
 * overlap, won cards as big suit chips, larger type throughout. It is a class on <html>, so the stylesheet does
 * the work. A link with ?big turns it on for whoever opens it (?big=0 turns it off), so it can be sent ready-made. */
if (typeof location !== "undefined") {
  const q = new URLSearchParams(location.search);
  if (q.has("big")) { const on = q.get("big") !== "0"; if (!!prefs.get().big !== on) prefs.set(v => ({ ...v, big: on })); }
}
const paintBig = v => { if (typeof document !== "undefined") document.documentElement.classList.toggle("big", !!(v && v.big)); };
paintBig(prefs.get());
prefs.sub(paintBig);
export const toggleBig = () => prefs.set(v => ({ ...v, big: !v.big }));
