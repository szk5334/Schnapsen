/* Scroll & Stone: the same transport and identity as Schnapsen, its own rooms (lobby and tables). ?local works as there. */
import { html, render } from "../../vendor/preact.js";
import { App } from "./ui/app.js";
import { startHub } from "../hub.js";
import { localP2P } from "../net/local.js";
import { relayP2P } from "../net/relay.js";
import { BUILD } from "../version.js";
import { hangPapers } from "../ui/papers.js";
import { stoneP2P } from "./session.js";

const cfg = window.SX_CONFIG || {};
const local = new URLSearchParams(location.search).has("local");
try {
  const p2p = stoneP2P(local ? localP2P() : relayP2P(cfg));
  const hub = startHub(p2p);
  hangPapers();
  window.__st = { hub, BUILD };
  console.info("Scroll & Stone build", BUILD);
  render(html`<${App} hub=${hub}/>`, document.getElementById("app"));
} catch (e) {
  console.error(e);
  document.getElementById("app").innerHTML = `<div class="screen center"><p>Something went wrong starting up.</p><pre class="err"></pre><button class="btn" onclick="location.reload()">Reload</button></div>`;
  document.querySelector(".err").textContent = String(e && e.message || e);
}
