import { html, useState, useEffect, useMemo } from "../../../vendor/preact.js";
import { useCell, go, useWakeLock } from "../../ui/hooks.js";
import { ChatPanel, ChatDrawer } from "../../ui/chat.js";
import { Avatar, Sheet, Seg, BigToggle } from "../../ui/bits.js";
import { me } from "../../ident.js";
import { openTable } from "../session.js";
import { SETS, WIND_CARDS, poolOf } from "../cards.js";
import { describe, cardsNeeded } from "../engine.js";
import { PlayView } from "./play.js";
import { StoneRules } from "./rules.js";

export const MODES = [
  { v: "classic", l: "Onitama", note: "The base game: a Master and four Students a side, five cards on the table." },
  { v: "wind", l: "Way of the Wind", note: "The Wind Spirit stands in the middle. Any card can move it; wind cards move one of yours and then it." },
  { v: "shadow", l: "Way of the Shadow", note: "A Master, two Students and a hidden Ninja each, and two lanterns to find the other's." },
  { v: "light", l: "Way of the Light", note: "One side plays the pieces with two lanterns; the other plays two hidden Ninjas and nothing else." },
];
const WINDS = [
  { v: "std", l: "Standard", n: "2 wind, 3 move" },
  { v: "m3", l: "Mighty", n: "3 wind, 2 move" },
  { v: "m4", l: "Mightier", n: "4 wind, 1 move" },
  { v: "m5", l: "All wind", n: "5 wind cards" },
  { v: "p1", l: "Peaceful", n: "1 wind, 4 move" },
  { v: "p0", l: "Becalmed", n: "no wind cards" },
];
export const modeLabel = o => (MODES.find(m => m.v === o.mode) || MODES[0]).l + (o.mode === "wind" && o.wind && o.wind !== "std" ? ` (${(WINDS.find(w => w.v === o.wind) || {}).l})` : "");

export function TableScreen({ hub, code }) {
  const sess = useMemo(() => openTable(hub, code), [code]);
  useEffect(() => () => sess.leave(), [sess]);
  const st = useCell(sess.state);
  const chat = useCell(sess.chat);
  const w = useCell(me);
  const [menu, setMenu] = useState(false);
  const [sheet, setSheet] = useState(null);
  const t = st.table;
  const playing = !!(t && t.status === "playing");
  useWakeLock(playing);

  const leave = () => go("/");
  const share = async () => {
    const url = location.origin + location.pathname + location.search + "#/t/" + code;
    try { if (navigator.share) { await navigator.share({ title: "Scroll & Stone", text: `Join my table: ${code}`, url }); return; } } catch { return; }
    try { await navigator.clipboard.writeText(url); setSheet("copied"); setTimeout(() => setSheet(null), 1400); } catch {}
  };
  if (st.closed || st.kicked) return html`<div class="screen center"><p>${st.kicked ? "The table's owner gave your seat to someone else." : st.closed}</p><button class="btn primary" onClick=${leave}>Back to the lobby</button></div>`;
  if (!st.found) return html`<div class="screen center">
    ${st.lost ? html`<p>Couldn't find table <b>${code}</b>. Whoever opened it may have left, or the code is wrong.</p>` : html`<p class="pulse">Looking for table <b>${code}</b>…</p>`}
    <button class="btn" onClick=${leave}>Back to the lobby</button></div>`;

  const owner = sess.owner;
  const seated = st.seat >= 0;
  const v = st.view;
  const names = t.seats.map(x => (x ? x.name : ""));
  const score = v ? v.score : st.pub && st.pub.score;
  const head = html`<header class="bar">
    <button class="nav-back" onClick=${leave} aria-label="Back to the lobby">Lobby</button>
    <span class="tcode" aria-label="Table code">${code}</span>
    ${!playing && html`<button class="btn ghost" onClick=${share}>Invite</button>`}
    ${playing && score && html`<span class="score" aria-label="Games won">${seated ? `${score[st.seat]}–${score[1 - st.seat]}` : `${score[0]}–${score[1]}`}</span>`}
    <button class="btn ghost" onClick=${() => setMenu(true)} aria-label="Menu">Menu</button>
  </header>`;
  const gs = v ? v.st : st.pub && st.pub.st;
  const menuSheet = menu && html`<${Sheet} title="Table" onClose=${() => setMenu(false)}>
    <div class="menu">
      ${gs && html`<button class="row" onClick=${() => { setMenu(false); setSheet("log"); }}>Game log</button>`}
      <button class="row" onClick=${() => { setMenu(false); setSheet("rules"); }}>Rules</button>
      <${BigToggle}/>
      ${owner && playing && html`<button class="row" onClick=${() => { setMenu(false); sess.toSeats(); }}>End the game, back to the seats</button>`}
      ${!owner && seated && !playing && html`<button class="row" onClick=${() => { setMenu(false); sess.stand(); }}>Give up my seat</button>`}
      ${owner && html`<button class="row danger" onClick=${() => { sess.close(); go("/"); }}>Close the table</button>`}
    </div><//>`;
  const extra = sheet === "log" && gs ? html`<${Sheet} title="This game" onClose=${() => setSheet(null)}>
      <ol class="stone-log">${gs.log.length ? gs.log.map((ev, i) => html`<li key=${i}>${describe(gs, ev, names.map((n, s) => (s === st.seat ? "You" : n)))}</li>`) : html`<li class="muted">No moves yet.</li>`}</ol><//>`
    : sheet === "rules" ? html`<${Sheet} title="Rules" onClose=${() => setSheet(null)}><${StoneRules} which=${t.opts.mode}/><//>`
    : sheet === "copied" ? html`<div class="toast" role="status">Invite link copied</div>` : null;

  if (playing && (seated || st.pub)) {
    const m = sess.match();
    const opp = seated ? t.seats[1 - st.seat] : null;
    return html`<div class="screen play stone-play">
      ${head}
      ${seated && !st.oppHere && html`<p class="banner">${opp.name} stepped away.</p>`}
      <${PlayView} v=${seated ? v : { ...st.pub, ready: true }} seat=${seated ? st.seat : 0} names=${names} watching=${!seated}
        act=${a => (m ? m.act(a) : false)} place=${n => m && m.place(n)} next=${() => m && m.next()}/>
      <${ChatDrawer} chat=${chat}/>
      ${menuSheet}${extra}
    </div>`;
  }

  const both = t.seats.every(Boolean);
  return html`<div class="screen room">
    ${head}
    ${!st.ownerHere && !owner && html`<p class="banner">${(t.seats[0] || {}).name || "The host"} stepped away.</p>`}
    <section class="seatsbox" aria-label="Seats">
      ${t.seats.map((x, i) => html`<div key=${i} class=${"seat" + (x && x.cid === w.cid ? " you" : "")}>
        <span class=${"side-dot s" + i} aria-label=${i ? "Blue" : "Red"}></span>
        ${x ? html`<${Avatar} p=${x}/><b>${x.cid === w.cid ? "You" : x.name}</b>
                 ${x.cid === t.ownerCid ? html`<small>Opened the table</small>` : owner && !playing && html`<button class="link" onClick=${() => sess.kick(x.cid)}>Remove</button>`}`
            : html`<span class="av empty"></span><span class="muted">Empty seat</span>
                 ${!seated && !owner && !playing && html`<button class="btn primary" onClick=${() => sess.sit(i)}>Sit here</button>`}`}
      </div>`)}
    </section>
    ${playing ? html`<p class="muted pad">A game is on. The board shows up here once a move is made.</p>`
      : owner ? html`<${HostOptions} t=${t} sess=${sess} ready=${both}/>`
      : html`<section class="opts"><p class="optnote"><b>${modeLabel(t.opts)}</b>. ${setsLine(t.opts)}</p>
          <p class="muted">${seated ? `Waiting for ${(t.seats[0] || {}).name || "the other player"} to start.` : "Take the empty seat to play, or stay and watch."}</p></section>`}
    <${ChatPanel} chat=${chat} placeholder="Message the table" empty="Nothing said yet."/>
    ${menuSheet}${extra}
  </div>`;
}

const setsLine = o => o.mode === "wind" && o.wind === "m5" ? "Wind cards only."
  : "Cards from " + Object.keys(SETS).filter(k => o.sets && o.sets[k]).map(k => SETS[k].label).join(", ") + (o.mode === "wind" ? `. Dealt: ${WINDS.find(w => w.v === (o.wind || "std")).n}.` : ".");

function HostOptions({ t, sess, ready }) {
  const o = t.opts;
  const set = p => sess.setOpts(p);
  const problem = sess.problem();
  const mode = MODES.find(m => m.v === o.mode) || MODES[0];
  const toggle = k => set({ sets: { ...o.sets, [k]: !(o.sets && o.sets[k]) } });
  return html`<section class="opts" aria-label="Game options">
    <div class="opt col"><span>Game</span>
      <div class="modes" role="radiogroup" aria-label="Game">${MODES.map(m => html`<button key=${m.v} role="radio" aria-checked=${o.mode === m.v}
        class=${"mode" + (o.mode === m.v ? " on" : "")} onClick=${() => set({ mode: m.v })}>${m.l}</button>`)}</div>
      <p class="optnote">${mode.note}</p></div>
    ${o.mode === "wind" && html`<div class="opt col"><span>Wind</span>
      <div class="modes" role="radiogroup" aria-label="Wind">${WINDS.map(x => html`<button key=${x.v} role="radio" aria-checked=${(o.wind || "std") === x.v}
        class=${"mode" + ((o.wind || "std") === x.v ? " on" : "")} onClick=${() => set({ wind: x.v })}>${x.l}<small>${x.n}</small></button>`)}</div></div>`}
    ${o.mode === "light" && html`<div class="opt"><span>Light side</span><${Seg} label="Who plays the Light" value=${o.light | 0}
      opts=${t.seats.map((x, i) => ({ v: i, l: x ? x.name : i ? "Blue" : "Red" }))} onPick=${v => set({ light: v })}/></div>`}
    ${!(o.mode === "wind" && o.wind === "m5") && html`<div class="opt col"><span>Move cards from</span>
      <div class="setchips">${Object.keys(SETS).map(k => html`<button key=${k} role="checkbox" aria-checked=${!!(o.sets && o.sets[k])} class=${"setchip" + (o.sets && o.sets[k] ? " on" : "")} onClick=${() => toggle(k)}>
        ${SETS[k].label} <small>${SETS[k].cards.length}</small></button>`)}</div>
      <p class="optnote">${poolOf(o.sets).length} cards in the pool; ${cardsNeeded(o)} are dealt.${o.mode === "wind" ? ` Plus ${WIND_CARDS.length} wind cards.` : ""}</p></div>`}
    <div class="opt"><span>Listed in the lobby</span><${Seg} label="Listed" value=${!o.private} opts=${[{ v: true, l: "Yes" }, { v: false, l: "Invite only" }]} onPick=${v => set({ private: !v })}/></div>
    ${problem && html`<p class="banner">${problem}</p>`}
    <button class="btn primary wide" disabled=${!ready || !!problem} onClick=${() => sess.start()}>${ready ? "Start" : "Waiting for a second player"}</button>
  </section>`;
}
