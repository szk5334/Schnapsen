import { html, useState } from "../../../vendor/preact.js";
import { Seg } from "../../ui/bits.js";

export function StoneRules({ which = "classic" }) {
  const [w, setW] = useState(which);
  return html`<div class="rules">
    <${Seg} label="Which game" value=${w} opts=${[{ v: "classic", l: "Base" }, { v: "wind", l: "Wind" }, { v: "shadow", l: "Shadow" }, { v: "light", l: "Light" }]} onPick=${setW}/>
    ${w === "wind" ? html`<${Wind}/>` : w === "shadow" ? html`<${Shadow}/>` : w === "light" ? html`<${Light}/>` : html`<${Base}/>`}
  </div>`;
}

function Base() {
  return html`
    <p>A 5 by 5 board. Each side has a <b>Master</b> in the middle of its home row, on its temple, and four <b>Students</b> beside it. Red sits at the bottom of the board, Blue at the top; each phone shows your side at the bottom.</p>
    <h3>The cards</h3>
    <p>Five move cards are dealt: two to each of you, one to the side. A card shows a piece in the middle and the squares it may move to, as you look at it: up is forward. Any of your pieces may use either of your cards.</p>
    <p>On your turn, play one of your cards: move one piece to a square it shows. Pieces jump; nothing is in the way. You can't land on your own piece. Land on one of theirs and it's taken.</p>
    <p>The card you played goes to the side, and you take the card that was there. So the card you just used is the next one your opponent gets.</p>
    <p>If none of your pieces can move with either card, you still give up a card: pick which one goes to the side.</p>
    <h3>Winning</h3>
    <p><b>The Way of the Stone:</b> take their Master. <b>The Way of the Stream:</b> move your Master onto their temple, the middle of their home row.</p>
    <h3>Who starts</h3>
    <p>The side card's colour says who starts. Where we don't know a card's colour, the phones toss a coin together that neither can rig.</p>
    <h3>Split cards</h3>
    <p>Some promo cards have two grids: one for a Student, one for the Master. The Master may only use its own grid, a Student only the other.</p>`;
}
function Wind() {
  return html`
    <p>The <b>Wind Spirit</b> stands in the middle of the board. It belongs to nobody.</p>
    <h3>Moving it</h3>
    <p>With a plain move card, you move either one of your pieces or the Spirit, as the card shows.</p>
    <p>A <b>wind card</b> has two grids. First move one of your pieces by the top grid, then the Spirit by the bottom one. If either half can't be done, skip it.</p>
    <h3>What it does</h3>
    <p>The Spirit never takes anything and never lands on a Master. Move it onto a Student, of either side, and the two swap places. No piece can land on the Spirit.</p>
    <h3>The cards</h3>
    <p>Standard: two wind cards, one in each hand, and three move cards. Mighty raises the wind cards to three, four or all five; Peaceful lowers them to one or none.</p>`;
}
function Shadow() {
  return html`
    <p>Each side has a Master, two Students on the outside files, and one <b>Ninja</b>, hidden beside the Master. Only your phone knows where your Ninja is.</p>
    <h3>Your turn</h3>
    <p>Play a card and move a piece on the board, as usual: you must, if any of your pieces can. Then your Ninja may move too, with the same card, or stay put.</p>
    <p>A Ninja moving onto one of their pieces is revealed and takes it. It stays in view until your next turn, then hides again.</p>
    <p>If a piece of theirs lands where your Ninja hides, your Ninja is caught. Your phone says so by itself.</p>
    <p><b>Reveal:</b> at the end of your turn you may also show your Ninja where it stands. If their Ninja is hiding on that square, it's caught.</p>
    <h3>Lanterns</h3>
    <p>Twice a game, not on your first turn, light a lantern on one row or one file. Their phone answers truthfully whether their Ninja is there.</p>
    <h3>Winning</h3>
    <p>Take their Master, with a piece or a Ninja, or reach their temple with yours.</p>
    <h3>Fair play</h3>
    <p>Every turn, your phone seals where your Ninja is. At the end both phones open their seals, and each checks that every answer was true and every Ninja move was legal.</p>`;
}
function Light() {
  return html`
    <p>One of you plays the <b>Light</b>: a Master, four Students and two lanterns. The other plays the <b>Shadow</b>: two hidden Ninjas, and nothing else on the board. Light moves first.</p>
    <h3>The Shadow</h3>
    <p>Hide your two Ninjas on any squares of your home row. Each turn, play a card and move one of them with it; you must, if one can move. A Ninja moving onto a Light piece is revealed and takes it.</p>
    <p>The Shadow wins only by taking the Master.</p>
    <h3>The Light</h3>
    <p>Play as usual. Land on a hidden Ninja and you catch it. Twice a game, light a lantern on a row or a file: the Shadow's phone answers whether at least one Ninja is there.</p>
    <p>The Light wins by catching both Ninjas, or by reaching the Shadow's temple with the Master.</p>
    <h3>Fair play</h3>
    <p>As in the Way of the Shadow: positions are sealed every turn and checked by both phones at the end.</p>`;
}
