import { html, useState } from "../../../vendor/preact.js";
import { useCell, go } from "../../ui/hooks.js";
import { ChatPanel } from "../../ui/chat.js";
import { Avatar, NameSheet } from "../../ui/bits.js";
import { me } from "../../ident.js";
import { LS, cleanCode } from "../../util.js";
import { createTable, SESSION_KEY } from "../session.js";
import { modeLabel } from "./table.js";

export function Lobby({ hub }) {
  const here = useCell(hub.here) || [];
  const tables = useCell(hub.tables) || [];
  const w = useCell(me);
  const [code, setCode] = useState("");
  const [naming, setNaming] = useState(false);
  const last = LS.get(SESSION_KEY);
  const resume = last && (LS.get("st.own." + last.code) || LS.get("st.seen." + last.code) || tables.some(t => t.code === last.code)) ? last.code : null;
  const others = here.filter(p => !p.self);
  const join = e => { e.preventDefault(); const c = cleanCode(code); if (c.length === 4) go("/t/" + c); };
  return html`
    <div class="screen lobby stone-lobby">
      <header class="bar marquee">
        <h1 class="mark">Scroll & Stone</h1>
        <button class="me" onClick=${() => setNaming(true)} aria-label="Change your name"><${Avatar} p=${w}/><span>${w.name}</span></button>
      </header>
      ${resume && html`<a class="resume" href=${"#/t/" + resume}>Back to table <b>${resume}</b></a>`}
      <div class="actions">
        <button class="btn primary" onClick=${() => go("/t/" + createTable(hub))}>New table</button>
        <a class="btn" href=${"./" + location.search}>Schnapsen</a>
      </div>
      <form class="join" onSubmit=${join}>
        <input value=${code} onInput=${e => setCode(cleanCode(e.currentTarget.value))} placeholder="Have a code? Type it here" aria-label="Table code"
          autocapitalize="characters" autocomplete="off" maxlength="4"/>
        <button class="btn" disabled=${code.length !== 4}>Join</button>
      </form>
      <section class="tables" aria-label="Open tables">
        ${tables.length === 0 ? html`<p class="empty">No open tables. Start one and send the link to whoever you're playing.</p>`
          : tables.map(t => html`<${TableRow} key=${t.code} t=${t} mine=${t.hostCid === w.cid}/>`)}
      </section>
      <section class="here" aria-label="Who's here">
        <span class="here-n">${others.length ? `${others.length + 1} here` : "Just you here"}</span>
        <ul>${here.map(p => html`<li key=${p.cid} title=${p.name}><${Avatar} p=${p} ring=${!!p.hosting}/><span>${p.self ? "You" : p.name}</span></li>`)}</ul>
      </section>
      <${ChatPanel} chat=${hub.chat} placeholder="Message everyone here" empty="Nothing said yet."/>
      ${naming && html`<${NameSheet} onDone=${() => setNaming(false)}/>`}
    </div>`;
}

function TableRow({ t, mine }) {
  const filled = (t.seats || []).filter(Boolean);
  const open = (t.seats || []).some(x => !x);
  const status = t.status === "playing" ? (t.score ? `Playing, ${t.score[0]}–${t.score[1]}` : "Playing") : open ? "Waiting for a player" : "About to start";
  return html`<a class="trow" href=${"#/t/" + t.code}>
    <span class="seats">${(t.seats || []).map((x, i) => x ? html`<${Avatar} key=${i} p=${x}/>` : html`<span key=${i} class="av empty" aria-label="Empty seat"></span>`)}</span>
    <span class="tmain"><b>${filled.map(x => x.name).join(" & ") || t.hostName}</b><small>${status}${t.opts ? ", " + modeLabel(t.opts) : ""}</small></span>
    <span class="tgo">${mine ? "Yours" : open && t.status !== "playing" ? "Sit" : "Watch"}</span>
  </a>`;
}
