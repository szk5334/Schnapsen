/* SCROLL & STONE — the board, the pieces and the move cards, drawn for one seat (your home row at the bottom). */
import { html } from "../../../vendor/preact.js";
import { CARDS, nameOf } from "../cards.js";
import { TEMPLE } from "../engine.js";

export const FILES = "abcde";
export const sqName = (x, y) => FILES[x] + (y + 1);
/* screen cell (row r from the top, column c from the left) <-> board square, for the seat at the bottom */
export const toXY = (seat, r, c) => (seat === 1 ? [4 - c, r] : [c, 4 - r]);

/* ---------------------------------------------------------------- pieces */
export function Piece({ s, k, ghost, shown }) {
  const cls = "pc s" + s + (k === "m" ? " master" : k === "n" ? " ninja" : " student") + (ghost ? " ghost" : "") + (shown ? " shown" : "");
  if (k === "n") return html`<svg class=${cls} viewBox="0 0 40 40" aria-hidden="true">
    <circle cx="20" cy="20" r="14" class="body"/><path d="M8 18h24v5H8z" class="band"/><circle cx="15" cy="20.5" r="1.7" class="eye"/><circle cx="25" cy="20.5" r="1.7" class="eye"/></svg>`;
  if (k === "m") return html`<svg class=${cls} viewBox="0 0 40 40" aria-hidden="true">
    <circle cx="20" cy="20" r="16.5" class="body"/><circle cx="20" cy="20" r="11.5" class="ring"/>
    <path d="M12.5 24l2-10 5.5 6 5.5-6 2 10z" class="crown"/></svg>`;
  return html`<svg class=${cls} viewBox="0 0 40 40" aria-hidden="true"><circle cx="20" cy="20" r="12" class="body"/><circle cx="20" cy="20" r="6.5" class="ring"/></svg>`;
}
export function Spirit() {
  return html`<svg class="pc spirit" viewBox="0 0 40 40" aria-hidden="true">
    <circle cx="20" cy="20" r="15" class="halo"/>
    <path d="M20 8c-7 0-11 5-11 10s4 8 8 8 6-3 6-6-2-4-4-4-3 1-3 3" class="swirl"/>
    <path d="M27 28c3-2 5-5 5-9" class="swirl"/></svg>`;
}

/* ---------------------------------------------------------------- the board
 * marks: { "x,y": "pick" | "to" | "cap" | "sp" | "nj" | "sel" } — what a tap there would do now.
 * ghosts: [{s, x, y, i}] Ninjas only this device sees (yours, or theirs after the game).
 * last: the squares the last move touched. lit: a lantern's row or file. */
export function Board({ st, seat, marks = {}, ghosts = [], last = [], lit = null, onTap, label }) {
  const cells = [];
  const pieceAt = (x, y) => st.pieces.find(p => p.x === x && p.y === y);
  for (let r = 0; r < 5; r++) for (let c = 0; c < 5; c++) {
    const [x, y] = toXY(seat, r, c);
    const k = x + "," + y;
    const p = pieceAt(x, y);
    const sp = st.spirit && st.spirit.x === x && st.spirit.y === y;
    const shown = [0, 1].flatMap(s => st.nin[s].shown.map((q, i) => (q && q.x === x && q.y === y ? { s, i } : null)).filter(Boolean));
    const gh = ghosts.filter(g => g.x === x && g.y === y);
    const temple = TEMPLE.findIndex(t => t[0] === x && t[1] === y);
    const m = marks[k];
    const isLit = lit && (lit.ax === "r" ? y === lit.i : x === lit.i);
    const cls = "sq" + ((x + y) % 2 ? " dk" : "") + (temple >= 0 ? " temple t" + temple : "") + (m ? " m-" + m : "") + (last.includes(k) ? " last" : "") + (isLit ? " lit" + (lit.yes ? " yes" : " no") : "");
    const what = [p && `${p.s === seat ? "your" : "their"} ${p.k === "m" ? "Master" : "Student"}`, sp && "the Spirit",
      ...shown.map(n => `${n.s === seat ? "your" : "their"} Ninja, shown`), ...gh.map(g => `${g.s === seat ? "your hidden" : "their"} Ninja`)].filter(Boolean).join(", ");
    cells.push(html`<button key=${k} type="button" class=${cls} disabled=${!m || !onTap} onClick=${() => onTap && m && onTap(x, y, m)}
      aria-label=${sqName(x, y) + (what ? ": " + what : "") + (m ? ` (${MARK_WORD[m]})` : "")}>
      ${p && html`<${Piece} s=${p.s} k=${p.k}/>`}
      ${sp && html`<${Spirit}/>`}
      ${shown.map(n => html`<${Piece} key=${"n" + n.s + n.i} s=${n.s} k="n" shown/>`)}
      ${gh.map(g => html`<${Piece} key=${"g" + g.s + g.i} s=${g.s} k="n" ghost/>`)}
      ${m && m !== "sel" && m !== "pick" && html`<span class="dot" aria-hidden="true"></span>`}
      ${c === 0 && html`<span class="rk" aria-hidden="true">${y + 1}</span>`}${r === 4 && html`<span class="fl" aria-hidden="true">${FILES[x]}</span>`}
    </button>`);
  }
  return html`<div class="board" role="grid" aria-label=${label || "The board"}>${cells}</div>`;
}
const MARK_WORD = { pick: "tap to choose", sel: "chosen", to: "move here", cap: "take it", sp: "move the Spirit here", nj: "move the Ninja here", place: "hide a Ninja here", placed: "Ninja hidden here" };

/* ---------------------------------------------------------------- a move card
 * The grid is the owner's view: forward is up. `flip` turns the whole card to face the far side of the table. */
function Grid({ moves = [], moves2 = [], kind }) {
  const at = new Map();
  for (const [dx, dy] of moves) at.set((2 - dy) * 5 + (2 + dx), "a");
  for (const [dx, dy] of moves2) { const i = (2 - dy) * 5 + (2 + dx); at.set(i, at.get(i) === "a" ? "ab" : "b"); }
  return html`<span class=${"grid " + (kind || "")} aria-hidden="true">${Array.from({ length: 25 }, (_, i) =>
    html`<i key=${i} class=${i === 12 ? "o" : at.get(i) || ""}></i>`)}</span>`;
}
export function cardWords(id) {
  const c = CARDS[id];
  const say = ms => ms.map(([dx, dy]) => [dy > 0 ? `${dy} forward` : dy < 0 ? `${-dy} back` : "", dx > 0 ? `${dx} right` : dx < 0 ? `${-dx} left` : ""].filter(Boolean).join(" ")).join("; ");
  if (c.kind === "split") return `Student: ${say(c.s)}. Master: ${say(c.ma)}.`;
  if (c.kind === "wind") return `Your piece: ${say(c.m)}. Then the Spirit: ${say(c.w)}.`;
  return say(c.m);
}
export function MoveCard({ id, flip, on, dim, onTap, small, label, stampless }) {
  const c = CARDS[id];
  if (!c) return null;
  const cls = "mcard k-" + c.kind + (flip ? " flip" : "") + (on ? " on" : "") + (dim ? " dim" : "") + (small ? " small" : "") + (c.stamp != null && !stampless ? " st" + c.stamp : "");
  const body = html`
    <span class="mname">${nameOf(id)}</span>
    ${c.kind === "wind" ? html`<span class="grids"><${Grid} moves=${c.m}/><${Grid} moves=${c.w} kind="w"/></span>`
      : c.kind === "split" ? html`<span class="grids"><${Grid} moves=${c.s} moves2=${c.ma} kind="split"/></span>`
      : html`<span class="grids"><${Grid} moves=${c.m}/></span>`}`;
  const aria = (label ? label + ": " : "") + nameOf(id) + ". " + cardWords(id);
  return onTap ? html`<button type="button" class=${cls} aria-pressed=${!!on} aria-label=${aria} onClick=${onTap}>${body}</button>`
    : html`<div class=${cls} role="img" aria-label=${aria}>${body}</div>`;
}
