/* SCROLL & STONE — the game on screen, and building your turn one tap at a time:
 *   card -> piece (or the Spirit) -> where -> [wind: the Spirit] -> [Ninja] -> Play
 * Nothing is sent until Play; Undo starts the turn again. */
import { html, useState, useEffect } from "../../../vendor/preact.js";
import { CARDS, nameOf } from "../cards.js";
import { mainMoves, spiritMoves, cardPlayable, needsCommit, hasNinjas, ninjaMoves, ninjaStarts, play, preview, lightSeat, pruneCaught } from "../engine.js";
import { Board, MoveCard, sqName, FILES } from "./board.js";
import { Sheet } from "../../ui/bits.js";

const NJ0 = "0".repeat(64);
const HOW = {
  stone: "took the Master (the Way of the Stone)",
  stream: "reached the temple (the Way of the Stream)",
  ninja: "took the Master with a Ninja",
  ninjas: "caught every Ninja",
};
const live = (st, s, ninjas) => (ninjas ? pruneCaught(st, s, ninjas) : []);

/* What the board looks like after the turn built so far, and what a tap does next. */
function plan(st, seat, t, ninjas) {
  const opp = 1 - seat;
  const hasN = needsCommit(st, seat) && hasNinjas(st, seat);
  const anyMain = st.hand[seat].some(c => mainMoves(st, seat, c).length);
  const stuck = !st.hand[seat].some(c => cardPlayable(st, seat, c));
  const quiet = hasN && !anyMain;                       // nothing on the board can move: the Ninja moves instead
  const selectable = c => (stuck || quiet) ? true : st.mode === "shadow" && anyMain ? mainMoves(st, seat, c).length > 0 : cardPlayable(st, seat, c);
  const out = { stage: "card", marks: {}, board: st, selectable, stuck, quiet, hasN, cands: [] };
  if (!t.card) return out;
  if (t.pass) return { ...out, stage: "ready" };
  const wind = CARDS[t.card].kind === "wind";
  const prim = mainMoves(st, seat, t.card);
  const pick = (k, m) => { out.marks[k] = m; };
  const pieceMarks = (moves, withSpirit) => {
    if (t.sel == null) {
      for (const m of moves) pick(st.pieces.find(p => p.id === m.pid).x + "," + st.pieces.find(p => p.id === m.pid).y, "pick");
      if (withSpirit) pick(st.spirit.x + "," + st.spirit.y, "pick");
    } else if (t.sel === "spirit") {
      for (const p of moves) { const q = st.pieces.find(z => z.id === p.pid); pick(q.x + "," + q.y, "pick"); }
      pick(st.spirit.x + "," + st.spirit.y, "sel");
      for (const m of spiritMoves(st, seat, t.card)) pick(m.x + "," + m.y, "sp");
    } else {
      for (const p of moves) { const q = st.pieces.find(z => z.id === p.pid); pick(q.x + "," + q.y, "pick"); }
      if (withSpirit) pick(st.spirit.x + "," + st.spirit.y, "pick");
      const me = st.pieces.find(p => p.id === t.sel);
      pick(me.x + "," + me.y, "sel");
      for (const m of moves.filter(m => m.pid === t.sel)) pick(m.x + "," + m.y, st.pieces.some(p => p.s === opp && p.x === m.x && p.y === m.y) ? "cap" : "to");
    }
  };
  /* the main step */
  if (wind && prim.length && !t.mv) { pieceMarks(prim, false); return { ...out, stage: "main" }; }
  if (!wind && !quiet && !t.mv && !t.sp) {
    const sp = st.mode === "wind" && spiritMoves(st, seat, t.card).length > 0;
    pieceMarks(prim, sp);
    return { ...out, stage: "main", spiritToo: sp };
  }
  /* a wind card's Spirit */
  const mid = t.mv ? preview(st, seat, t.mv) : st;
  if (wind && mid.winner == null && !t.sp) {
    const sec = spiritMoves(mid, seat, t.card);
    if (sec.length) {
      for (const m of sec) out.marks[m.x + "," + m.y] = "sp";
      out.marks[mid.spirit.x + "," + mid.spirit.y] = "sel";
      return { ...out, stage: "spirit", board: mid };
    }
  }
  const after = play(st, seat, { card: t.card, mv: t.mv, sp: t.sp, nj: needsCommit(st, seat) ? NJ0 : undefined }) || mid;
  out.board = after;
  /* the Ninja */
  if (hasN && after.winner == null && !t.nj) {
    const now = live(st, seat, ninjas);
    const cands = now.flatMap((n, i) => (n ? ninjaMoves(after, seat, t.card, now, i).map(([x, y]) => ({ i, x, y })) : []));
    if (cands.length) {
      const which = t.njSel != null ? t.njSel : new Set(cands.map(c => c.i)).size === 1 ? cands[0].i : null;
      if (which == null) for (const i of new Set(cands.map(c => c.i))) out.marks[now[i][0] + "," + now[i][1]] = "pick";
      else {
        for (const i of new Set(cands.map(c => c.i))) if (i !== which) out.marks[now[i][0] + "," + now[i][1]] = "pick";
        out.marks[now[which][0] + "," + now[which][1]] = "sel";
        for (const c of cands.filter(c => c.i === which)) out.marks[c.x + "," + c.y] = "nj";
      }
      return { ...out, stage: "ninja", cands, which, must: st.mode === "light" && seat !== lightSeat(st) };
    }
  }
  return { ...out, stage: "ready" };
}

export function PlayView({ v, seat, names, act, place, next, watching }) {
  const st = v && v.st;
  const opp = 1 - seat;
  const [t, setT] = useState({});
  const [chosen, setChosen] = useState([]);
  const [sheet, setSheet] = useState(null);
  const turnKey = st ? `${v.n}.${st.ply}.${st.turn}.${!!st.wait}` : "";
  useEffect(() => { setT({}); }, [turnKey]);
  useEffect(() => { setChosen([]); }, [v && v.n]);
  if (!st) return html`<div class="stone-game"><p class="sstatus pulse">${v && v.error ? v.error : "Shuffling the cards…"}</p></div>`;

  const nm = s => (s === seat && !watching ? "You" : names[s] || (s ? "Blue" : "Red"));
  const myTurn = !watching && v.ready && st.winner == null && !st.wait && st.turn === seat;
  const ninjas = watching ? null : v.ninjas;
  const P = myTurn ? plan(st, seat, t, ninjas) : null;
  const board = P ? P.board : st;

  /* What only this device sees: its hidden Ninjas; theirs once the game is over. */
  const ghosts = [];
  if (ninjas) {
    let now = live(st, seat, ninjas);
    if (P && t.nj && t.nj !== "skip") now = now.map((n, i) => (i === t.nj.i ? [t.nj.x, t.nj.y] : n));
    now.forEach((n, i) => { if (n && !st.nin[seat].shown[i]) ghosts.push({ s: seat, i, x: n[0], y: n[1] }); });
  }
  if (st.winner != null && v.theirNinjas) live(st, opp, v.theirNinjas).forEach((n, i) => { if (n && !st.nin[opp].shown[i]) ghosts.push({ s: opp, i, x: n[0], y: n[1] }); });
  if (v.placing) chosen.forEach((c, i) => ghosts.push({ s: seat, i, x: c[0], y: c[1] }));

  /* The last move, and a lantern's answer, stay lit until the next move. */
  const ev = st.log[st.log.length - 1];
  const last = [];
  if (ev && !(P && (t.mv || t.sp))) {
    if (ev.mv) last.push(ev.mv.from + "", ev.mv.to + "");
    if (ev.sp) last.push(ev.sp.from + "", ev.sp.to + "");
    for (const s of ev.show || []) last.push(s.at + "");
  }
  const lit = ev && ev.lan && ev.resp && "lan" in ev.resp ? { ...ev.lan, yes: ev.resp.lan } : null;

  /* taps */
  let marks = P ? P.marks : {};
  if (v.placing && !watching) {
    marks = {};
    for (const [x, y] of ninjaStarts(st, seat)) marks[x + "," + y] = chosen.some(c => c[0] === x && c[1] === y) ? "placed" : "place";
  }
  const tap = (x, y, m) => {
    if (v.placing) {
      const n = st.nin[seat].live.length;
      const has = chosen.some(c => c[0] === x && c[1] === y);
      setChosen(has ? chosen.filter(c => !(c[0] === x && c[1] === y)) : n === 1 ? [[x, y]] : chosen.length < n ? chosen.concat([[x, y]]) : chosen);
      return;
    }
    if (!P) return;
    if (P.stage === "main") {
      if (m === "pick") {
        const sp = st.spirit && st.spirit.x === x && st.spirit.y === y;
        const p = st.pieces.find(q => q.x === x && q.y === y && q.s === seat);
        setT({ ...t, sel: sp && !p ? "spirit" : p ? p.id : "spirit" });
      } else if (m === "to" || m === "cap") setT({ ...t, mv: { pid: t.sel, x, y } });
      else if (m === "sp") setT({ ...t, sp: { x, y } });
    } else if (P.stage === "spirit" && m === "sp") setT({ ...t, sp: { x, y } });
    else if (P.stage === "ninja") {
      if (m === "pick") { const now = live(st, seat, ninjas); setT({ ...t, njSel: now.findIndex(n => n && n[0] === x && n[1] === y) }); }
      else if (m === "nj") setT({ ...t, nj: { i: P.which, x, y } });
    }
  };
  const pickCard = c => {
    if (!P) return;
    if (!P.selectable(c)) return;
    setT(P.stuck && !P.hasN ? { card: c, pass: true } : { card: c });
  };
  const send = () => {
    const a = { card: t.card };
    if (t.pass) a.pass = true;
    if (t.mv) a.mv = t.mv;
    if (t.sp) a.sp = t.sp;
    if (t.nj && t.nj !== "skip") a.ninja = t.nj;
    if (t.attack != null) a.attack = t.attack;
    if (t.lan) a.lan = t.lan;
    if (!act(a)) setT({ ...t, refused: true });
  };

  /* lanterns and the attack (Way of the Shadow; the Light side in Way of the Light) */
  const canLantern = myTurn && st.nin[seat].lant > 0 && st.moved[seat] && hasNinjas(st, opp)
    && (st.mode === "shadow" || (st.mode === "light" && seat === lightSeat(st)));
  const mine = ninjas ? live(st, seat, ninjas) : [];
  const canAttack = myTurn && st.mode === "shadow" && P && P.hasN && !t.pass;

  /* status */
  const hidden = s => st.nin[s].live.filter((l, i) => l && !st.nin[s].shown[i]).length;
  const tally = [0, 1].filter(s => st.nin[s].live.length || st.nin[s].lant).map(s => `${nm(s)}: ${[st.nin[s].live.length ? `${hidden(s)} hidden` : "", st.nin[s].lant ? `${st.nin[s].lant} lantern${st.nin[s].lant > 1 ? "s" : ""}` : ""].filter(Boolean).join(", ")}`).join(" · ");
  let status;
  if (v.error) status = v.error;
  else if (st.winner != null) status = `${nm(st.winner)} ${HOW[st.how] || "won"}.`;
  else if (v.placing && !watching) { const n = st.nin[seat].live.length; status = `Hide your Ninja${n > 1 ? "s" : ""}: tap ${n > 1 ? `${n} squares` : "a square"} on your home row. Only your phone knows.`; }
  else if (!v.ready) status = `Waiting for ${nm(opp)} to hide their Ninja${st.nin[opp].live.length > 1 ? "s" : ""}…`;
  else if (st.wait) status = st.wait.from === seat && !watching ? "Answering…" : `${nm(st.wait.from)}'s phone is checking the move…`;
  else if (!myTurn) status = `${nm(st.turn)}'s turn.`;
  else status = ({
    card: P.stuck && !P.hasN ? "Nothing can move. Pick the card to pass on." : P.quiet ? (st.mode === "light" ? "Pick a card for your Ninjas." : "Nothing on the board can move. Pick a card for your Ninja.") : "Your turn. Pick a card.",
    main: t.sel == null ? (P.spiritToo ? "Pick a piece, or the Spirit." : "Pick a piece.") : "Where to?",
    spirit: "Now the Spirit: where does it go?",
    ninja: P.which == null ? "Pick a Ninja to move." : P.must ? "Move your Ninja." : "Move your Ninja, or leave it where it is.",
    ready: t.pass ? `Pass, giving up ${nameOf(t.card)}?` : "Play this move?",
  })[P.stage];
  const lanternNote = lit ? `${nm(ev.seat)}'s lantern on ${lit.ax === "r" ? "row " + (lit.i + 1) : "file " + FILES[lit.i]}: ${lit.yes ? "a Ninja is there" : "no Ninja there"}.` : null;
  const caught = ev && ev.resp && ev.resp.cap && ev.resp.cap.length ? `${nm(ev.seat)} caught ${ev.resp.cap.length > 1 ? ev.resp.cap.length + " Ninjas" : "a Ninja"} at ${ev.resp.cap.map(c => sqName(...c.at)).join(", ")}.` : null;

  /* the cards: theirs across the table (turned to face them), the side card turned toward whoever takes it next */
  const taker = st.wait ? st.wait.from : st.turn;
  const sideFor = taker === seat && !watching;
  const myCards = st.hand[seat].map(c => html`<${MoveCard} key=${c} id=${c} on=${t.card === c}
      dim=${myTurn && P.stage === "card" && !P.selectable(c)} onTap=${myTurn && !t.card ? () => pickCard(c) : myTurn && P.stage !== "ready" ? () => pickCard(c) : null}/>`);
  const audit = v.audit;
  return html`<div class="stone-game">
    <div class="shand them" aria-label=${`${nm(opp)}'s cards`}>${st.hand[opp].map(c => html`<${MoveCard} key=${c} id=${c} flip small label=${nm(opp)}/>`)}</div>
    <div class="mid">
      <${Board} st=${board} seat=${seat} marks=${marks} ghosts=${ghosts} last=${last} lit=${lit} onTap=${tap} label=${`The board, ${nm(seat)} at the bottom`}/>
    </div>
    <div class="info">
      <div class="sidecard"><${MoveCard} id=${st.side} small flip=${!sideFor} label=${`Side card, ${sideFor ? "yours" : nm(taker) + "'s"} next`}/></div>
      <div class="info-text" role="status" aria-live="polite">
      <p class="sstatus">${status}</p>
      ${(lanternNote || caught) && html`<p class="snote">${[caught, lanternNote].filter(Boolean).join(" ")}</p>`}
      ${st.winner == null && html`<p class="stally">${nameOf(st.side)} goes to ${sideFor ? "you" : nm(taker)} next.${tally ? " " + tally : ""}</p>`}
      ${st.winner != null && audit && html`<p class=${"snote " + (audit.ok ? "fair" : "unfair")}>${audit.ok
        ? (st.nin.some(n => n.live.length) ? "Both phones checked every hidden move: all fair." : "Both phones agree on the game.")
        : `The check found a problem: ${audit.why || "a hidden move didn't add up"}.`}</p>`}
      ${st.winner != null && !audit && !watching && html`<p class="snote pulse">Comparing notes with the other phone…</p>`}
      </div>
    </div>
    <div class="shand mine" aria-label=${watching ? `${nm(seat)}'s cards` : "Your cards"}>${myCards}</div>
    <div class="actbar">
      ${v.placing && !watching && html`<button class="btn primary wide" disabled=${chosen.length !== st.nin[seat].live.length} onClick=${() => place(chosen)}>Hide ${chosen.length > 1 ? "them" : "it"} here</button>`}
      ${myTurn && P.stage !== "card" && html`<button class="btn" onClick=${() => setT({})}>Undo</button>`}
      ${myTurn && P.stage === "ninja" && !P.must && html`<button class="btn" onClick=${() => setT({ ...t, nj: "skip" })}>Leave it</button>`}
      ${myTurn && P.stage === "ready" && canLantern && html`<button class=${"btn" + (t.lan ? " on" : "")} onClick=${() => (t.lan ? setT({ ...t, lan: null }) : setSheet("lantern"))}>
        ${t.lan ? (t.lan.ax === "r" ? "Row " + (t.lan.i + 1) : "File " + FILES[t.lan.i]) : "Lantern"}</button>`}
      ${canAttack && P.stage === "ready" && mine.some(Boolean) && html`<button class=${"btn" + (t.attack != null ? " on" : "")} aria-pressed=${t.attack != null}
        onClick=${() => setT({ ...t, attack: t.attack != null ? null : mine.findIndex(Boolean) })}>${t.attack != null ? "Revealing" : "Reveal"}</button>`}
      ${myTurn && P.stage === "ready" && html`<button class="btn primary" onClick=${send}>${t.pass ? "Pass" : "Play"}</button>`}
      ${st.winner != null && !watching && html`<button class="btn primary wide" disabled=${!audit} onClick=${next}>Play again</button>`}
    </div>
    ${t.refused && html`<p class="banner" role="alert">That move isn't allowed. Undo and try another.</p>`}
    ${sheet === "lantern" && html`<${Sheet} title="Light a lantern" onClose=${() => setSheet(null)}>
      <p class="muted">Ask about one row or one file. ${nm(opp)}'s phone answers whether a Ninja of theirs is there.</p>
      <div class="lanterns">
        <span>Row</span>${[0, 1, 2, 3, 4].map(i => html`<button key=${"r" + i} class="btn" onClick=${() => { setT({ ...t, lan: { ax: "r", i } }); setSheet(null); }}>${i + 1}</button>`)}
        <span>File</span>${[0, 1, 2, 3, 4].map(i => html`<button key=${"c" + i} class="btn" onClick=${() => { setT({ ...t, lan: { ax: "c", i } }); setSheet(null); }}>${FILES[i]}</button>`)}
      </div><//>`}
  </div>`;
}
