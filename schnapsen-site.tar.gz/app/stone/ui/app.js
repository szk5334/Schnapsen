import { html, useState, useRef, useEffect } from "../../../vendor/preact.js";
import { useCell, useRoute } from "../../ui/hooks.js";
import { BigToggle } from "../../ui/bits.js";
import { Lobby } from "./lobby.js";
import { TableScreen } from "./table.js";
import { me, setName } from "../../ident.js";
import { cleanName } from "../../util.js";

export function App({ hub }) {
  const w = useCell(me);
  const r = useRoute();
  if (!w.name) return html`<${Gate}/>`;
  if (r.view === "table") return html`<${TableScreen} key=${r.code} hub=${hub} code=${r.code}/>`;
  return html`<${Lobby} hub=${hub}/>`;
}

/* First visit on this phone (the name is shared with Schnapsen, so most people never see this). */
function Gate() {
  const [v, setV] = useState("");
  const ref = useRef(null);
  useEffect(() => { ref.current && ref.current.focus(); }, []);
  const ok = cleanName(v).length > 0;
  return html`<div class="screen gate"><h1 class="mark big">Scroll & Stone</h1>
    <p class="lede">A duel of masters and students on a five by five board, for two.</p>
    <form class="name-form" onSubmit=${e => { e.preventDefault(); if (ok) setName(v); }}>
      <label for="nm">Pick a name the table will see.</label>
      <input id="nm" ref=${ref} value=${v} maxlength="16" autocomplete="nickname" enterkeyhint="done" onInput=${e => setV(e.currentTarget.value)}/>
      <button class="btn primary" disabled=${!ok}>Come in</button>
    </form><div class="menu gate-opt"><${BigToggle}/></div></div>`;
}
