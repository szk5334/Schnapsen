/* SCROLL & STONE — the move cards.
 *
 * A move is [dx, dy] from the mover's own seat: dx to their right, dy toward the far side (forward).
 * `stamp` is the colour printed on the card that decides who starts when it is the side card: 0 red, 1 blue,
 * null where we haven't seen the card (the start is then decided by the shared coin; see engine.js).
 *
 * Kinds:
 *   plain   one grid, for any of your pieces
 *   split   two grids: one for a Student, one for the Master ("or" on the printed card)
 *   wind    two grids: first one of your pieces (`m`), then the Wind Spirit (`w`)
 *
 * Sources (Nov 2026): base and Sensei's Path as two open-source clones agree; Dice Tower promos and Goat/Sheep
 * read off the publisher's product photos, which also match the clone that has them; wind cards read off
 * reviewers' photos (sytkm.hatenablog.com, justpushstart.com, dottorgadget.it). See CARD-READINGS in HANDOFF.md.
 */
const P = (m, stamp = null) => ({ kind: "plain", m, stamp });
const S = (st, ma, stamp) => ({ kind: "split", s: st, ma, stamp });
const W = (m, w, stamp) => ({ kind: "wind", m, w, stamp });

export const CARDS = {
  /* ---- the 16 of the base box ---- */
  tiger:    P([[0, 2], [0, -1]]),
  dragon:   P([[-2, 1], [2, 1], [-1, -1], [1, -1]]),
  frog:     P([[-2, 0], [-1, 1], [1, -1]]),
  rabbit:   P([[2, 0], [1, 1], [-1, -1]]),
  crab:     P([[0, 1], [-2, 0], [2, 0]]),
  elephant: P([[-1, 0], [1, 0], [-1, 1], [1, 1]]),
  goose:    P([[-1, 0], [1, 0], [-1, 1], [1, -1]]),
  rooster:  P([[-1, 0], [1, 0], [1, 1], [-1, -1]]),
  monkey:   P([[-1, 1], [1, 1], [-1, -1], [1, -1]]),
  mantis:   P([[-1, 1], [1, 1], [0, -1]]),
  horse:    P([[0, 1], [-1, 0], [0, -1]]),
  ox:       P([[0, 1], [1, 0], [0, -1]]),
  crane:    P([[0, 1], [-1, -1], [1, -1]]),
  boar:     P([[0, 1], [-1, 0], [1, 0]]),
  eel:      P([[-1, 1], [-1, -1], [1, 0]]),
  cobra:    P([[1, 1], [1, -1], [-1, 0]]),
  /* ---- Sensei's Path ---- */
  fox:      P([[1, 1], [1, 0], [1, -1]]),
  dog:      P([[-1, 1], [-1, 0], [-1, -1]]),
  giraffe:  P([[-2, 1], [2, 1], [0, -1]]),
  kirin:    P([[-1, 2], [1, 2], [0, -2]]),
  phoenix:  P([[-2, 0], [2, 0], [-1, 1], [1, 1]]),
  turtle:   P([[-2, 0], [2, 0], [-1, -1], [1, -1]]),
  bear:     P([[0, 1], [-1, 1], [1, -1]]),
  panda:    P([[0, 1], [1, 1], [-1, -1]]),
  viper:    P([[0, 1], [-2, 0], [1, -1]]),
  seasnake: P([[0, 1], [2, 0], [-1, -1]]),
  rat:      P([[0, 1], [-1, 0], [1, -1]]),
  mouse:    P([[0, 1], [1, 0], [-1, -1]]),
  iguana:   P([[0, 1], [-2, 1], [1, -1]]),
  tanuki:   P([[0, 1], [2, 1], [-1, -1]]),
  otter:    P([[-1, 1], [1, -1], [2, 0]]),
  sable:    P([[1, 1], [-1, -1], [-2, 0]]),
  /* ---- the two move cards that came with Way of the Wind ---- */
  goat:     P([[1, 1], [-1, 0], [0, -1]], 0),
  sheep:    P([[-1, 1], [1, 0], [0, -1]], 1),
  /* ---- Dice Tower promos ---- */
  okija:    S([[0, 1]], [[-2, 2], [2, 2]], 0),
  mejika:   S([[-2, 1], [2, 1]], [[0, 1]], 1),
  kumo:     S([[-1, 1], [1, 1]], [[-2, 0], [2, 0]], 1),
  sasori:   S([[-2, 0], [2, 0]], [[-1, 2], [1, 2]], 0),
  steer:    P([[-1, 0], [1, 0], [-1, -1], [1, -1]], 1),
  lobster:  P([[-1, 1], [1, 1], [-1, -2], [1, -2]], 0),
  hornet:   P([[0, 1], [1, 0], [-2, -2]], 1),
  centipede:P([[0, 1], [-1, 0], [2, -2]], 0),
  cat:      P([[0, 1], [-1, 0], [2, 0], [0, -2]], 0),
  serow:    P([[0, 1], [1, 0], [-2, 0], [0, -2]], 1),
  moth:     P([[0, 1], [-2, -1], [2, -1]], 1),
  butterfly:P([[-2, 1], [2, 1], [0, -1]], 0),
  whale:    P([[0, 1], [0, -1], [-2, 0], [2, 0]], 0),
  cricket:  P([[-2, 0], [2, 0], [0, -2]], 1),
  nessie:   P([[-2, 1], [2, 0], [-1, -1], [1, -1]]),
  /* ---- Way of the Wind: wind cards (your piece, then the Spirit) ---- */
  bat:      W([[0, 1], [0, -1]], [[-2, 1], [-1, 1], [1, 1], [2, 1]], 1),
  eagle:    W([[-1, 1], [1, 1]], [[-2, 2], [2, 2]], 0),
  hawk:     W([[-1, 1], [-1, -1]], [[-2, 0], [-2, 1], [2, 0], [2, 1]], 1),
  lion:     W([[1, 1], [-1, -1]], [[0, 1], [0, 2]], 0),
  octopus:  W([[-1, 1], [1, -1]], [[0, 1], [-1, 0], [1, 0], [-1, -1], [0, -1], [1, -1]], 1),
  rhinoceros: W([[-1, 1], [0, -1]], [[-2, 0], [-1, 1], [0, 1], [1, 1], [2, 0]], 0),
  scorpion: W([[1, 1], [1, -1]], [[-1, 2], [1, 2], [-2, 1], [2, 1]], 1),
  spider:   W([[1, 1], [0, -1]], [[-1, 1], [0, 1], [1, 1], [0, -1]], 0),
};

export const NAMES = {
  seasnake: "Sea Snake", rhinoceros: "Rhinoceros",
};
export const nameOf = id => NAMES[id] || (id ? id[0].toUpperCase() + id.slice(1) : "");

/* The boxes, as the table options offer them. Wind cards are never in a move-card pool. */
export const SETS = {
  base:    { label: "Base game", cards: ["tiger", "dragon", "frog", "rabbit", "crab", "elephant", "goose", "rooster", "monkey", "mantis", "horse", "ox", "crane", "boar", "eel", "cobra"] },
  sensei:  { label: "Sensei's Path", cards: ["fox", "dog", "giraffe", "kirin", "phoenix", "turtle", "bear", "panda", "viper", "seasnake", "rat", "mouse", "iguana", "tanuki", "otter", "sable"] },
  windmv:  { label: "Goat & Sheep", cards: ["goat", "sheep"] },
  promo:   { label: "Promo cards", cards: ["okija", "mejika", "kumo", "sasori", "steer", "lobster", "hornet", "centipede", "cat", "serow", "moth", "butterfly", "whale", "cricket", "nessie"] },
};
export const WIND_CARDS = ["bat", "eagle", "hawk", "lion", "octopus", "rhinoceros", "scorpion", "spider"];

export function poolOf(sets) {
  const out = [];
  for (const k of Object.keys(SETS)) if (sets && sets[k]) out.push(...SETS[k].cards);
  return out;
}

/* The grid a piece of this kind ("m" master, "s" student, "n" ninja, "w" the spirit) may use on this card. A
 * split card's student grid serves the ninja and the spirit (neither is a master). On a wind card the spirit
 * uses the lower grid, every piece the upper one. */
export function gridFor(id, kind) {
  const c = CARDS[id];
  if (!c) return [];
  if (c.kind === "split") return kind === "m" ? c.ma : c.s;
  if (c.kind === "wind") return kind === "w" ? c.w : c.m;
  return c.m;
}
