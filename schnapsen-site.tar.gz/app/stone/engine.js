/* SCROLL & STONE — the rules, pure. No timers, no network, no DOM.
 *
 * The board: x 0..4 left to right and y 0..4 from seat 0's home row to seat 1's, as seat 0 sees it. Seat 0 is
 * red and plays up the board; seat 1 is blue and plays down it. A card's [dx, dy] is turned to the mover's
 * point of view (seat 1's right is seat 0's left). Temples: seat 0 (2,0), seat 1 (2,4).
 *
 * Ways to play (opts.mode):
 *   classic  the base game, any mix of card sets
 *   wind     Way of the Wind: the Spirit in the middle; wind cards move one of yours, then the Spirit
 *            (opts.wind: std 2+3 · m3 3+2 · m4 4+1 · m5 5+0 · p1 1+4 · p0 0+5, wind+move cards)
 *   shadow   Light and Shadow, Way of the Shadow: Master + 2 Students each, plus one hidden Ninja each
 *   light    Light and Shadow, Way of the Light: Light (Master + 4 Students, 2 lanterns) against Shadow (2 hidden
 *            Ninjas, no pieces on the board). opts.light: which seat plays Light.
 *
 * HIDDEN NINJAS. Only the owner's device knows where its Ninjas are (`priv`). After every move with a live Ninja
 * the owner sends a commitment, sha256 of [positions, salt]. Whatever the rules make the owner announce (a Ninja
 * caught by a piece landing on it, a lantern's row or column) the owner's device answers in a response. When the
 * game ends both devices publish every position and salt, and each checks the other's whole game (audit()).
 *
 * The state is plain JSON. Everything here returns a new state or null; nothing is mutated in place.
 */
import { CARDS, gridFor, poolOf, WIND_CARDS, nameOf } from "./cards.js";
import { sha256hex } from "../../vendor/nostr.js";

export const HOME = [0, 4];
export const TEMPLE = [[2, 0], [2, 4]];
const te = new TextEncoder();
export const H = s => sha256hex(te.encode(s));
export const commitOf = (ninjas, salt) => H(JSON.stringify([ninjas, salt]));
const on = (x, y) => x >= 0 && x < 5 && y >= 0 && y < 5;
export const turnTo = (seat, x, y, [dx, dy]) => (seat === 0 ? [x + dx, y + dy] : [x - dx, y - dy]);
const clone = s => JSON.parse(JSON.stringify(s));

/* ------------------------------------------------------------------ the shared coin */
/* A stream of 32-bit numbers from a hex seed (both devices derive the seed together; see match.js). */
export function rng(seed) {
  let n = 0, buf = [];
  return () => {
    if (!buf.length) { const h = H(seed + ":" + n++); for (let i = 0; i < 64; i += 8) buf.push(parseInt(h.slice(i, i + 8), 16)); }
    return buf.shift();
  };
}
function shuffle(list, R) {
  const a = list.slice();
  for (let i = a.length - 1; i > 0; i--) { const j = R() % (i + 1); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}

/* ------------------------------------------------------------------ setup */
export const WIND_MIX = { std: [2, 3], m3: [3, 2], m4: [4, 1], m5: [5, 0], p1: [1, 4], p0: [0, 5] };
export const DEFAULT_OPTS = { mode: "classic", sets: { base: true }, wind: "std", light: 0 };

/* How many move cards a table's options need from the pool. */
export function cardsNeeded(o) { return o.mode === "wind" ? WIND_MIX[o.wind || "std"][1] : 5; }
export function poolProblem(o) {
  const have = poolOf(o.sets).length, need = cardsNeeded(o);
  return have < need ? `Pick card sets with at least ${need} move cards.` : null;
}

export function deal(opts, seed) {
  const o = { ...DEFAULT_OPTS, ...opts };
  const R = rng(seed);
  const pool = shuffle(poolOf(o.sets), R);
  let hand, side;
  if (o.mode === "wind") {
    const [nw, nm] = WIND_MIX[o.wind] || WIND_MIX.std;
    const W = shuffle(WIND_CARDS, R).slice(0, nw), M = pool.slice(0, nm);
    if (nw === 2) { hand = [[W[0], M[0]], [W[1], M[1]]]; side = M[2]; }
    else if (nw === 3) { hand = [[W[0], M[0]], [W[1], M[1]]]; side = W[2]; }
    else if (nw === 4) { hand = [[W[0], W[1]], [W[2], W[3]]]; side = M[0]; }
    else if (nw === 5) { hand = [[W[0], W[1]], [W[2], W[3]]]; side = W[4]; }
    else if (nw === 1) { hand = [[M[0], M[1]], [M[2], M[3]]]; side = W[0]; }
    else { hand = [[M[0], M[1]], [M[2], M[3]]]; side = M[4]; }
  } else {
    hand = [[pool[0], pool[1]], [pool[2], pool[3]]]; side = pool[4];
  }
  const coin = R() & 1;
  const stamp = CARDS[side].stamp;
  const turn = o.mode === "light" ? (o.light | 0) : stamp == null ? coin : stamp;

  const pieces = [];
  let id = 0;
  for (const s of [0, 1]) {
    if (o.mode === "light" && s !== (o.light | 0)) continue;           // Shadow has nothing on the board
    const xs = o.mode === "shadow" ? [0, 4] : [0, 1, 3, 4];
    pieces.push({ id: id++, s, k: "m", x: 2, y: HOME[s] });
    for (const x of xs) pieces.push({ id: id++, s, k: "s", x, y: HOME[s] });
  }
  const hidden = o.mode === "shadow" ? [1, 1] : o.mode === "light" ? (o.light ? [2, 0] : [0, 2]) : [0, 0];
  const lanterns = o.mode === "shadow" ? [2, 2] : o.mode === "light" ? (o.light ? [0, 2] : [2, 0]) : [0, 0];
  return {
    mode: o.mode, opts: o, hand, side, turn, first: turn, ply: 0,
    pieces, spirit: o.mode === "wind" ? { x: 2, y: 2 } : null,
    /* per seat: which Ninjas still live, where each shown one stands (until its owner's next turn), lanterns left,
     * the owner's latest commitment */
    nin: [0, 1].map(s => ({ live: Array(hidden[s]).fill(true), shown: Array(hidden[s]).fill(null), lant: lanterns[s], commit: null })),
    moved: [false, false],              // has this seat had a turn yet (no lantern on your first turn)
    wait: null,                         // a response the other device owes before the turn passes
    winner: null, how: null, log: [],
  };
}
export const hasNinjas = (st, s) => st.nin[s].live.some(Boolean);
export const needsCommit = (st, s) => st.nin[s].live.length > 0;     // shadow / light owners commit every turn
export const lightSeat = st => (st.mode === "light" ? st.opts.light | 0 : null);

/* ------------------------------------------------------------------ moves */
const pieceAt = (st, x, y) => st.pieces.find(p => p.x === x && p.y === y) || null;
const spiritAt = (st, x, y) => !!(st.spirit && st.spirit.x === x && st.spirit.y === y);

/* Main-board moves of one piece kind with a card. */
export function mainMoves(st, seat, card) {
  if (!st.hand[seat].includes(card)) return [];
  const out = [];
  for (const p of st.pieces) {
    if (p.s !== seat) continue;
    for (const d of gridFor(card, p.k)) {
      const [x, y] = turnTo(seat, p.x, p.y, d);
      if (!on(x, y)) continue;
      const t = pieceAt(st, x, y);
      if (t && t.s === seat) continue;
      if (spiritAt(st, x, y)) continue;
      out.push({ pid: p.id, x, y });
    }
  }
  return out;
}
/* Spirit moves with a card, from the mover's point of view. It never lands on a Master. */
export function spiritMoves(st, seat, card) {
  if (!st.spirit || !st.hand[seat].includes(card)) return [];
  const out = [];
  for (const d of gridFor(card, "w")) {
    const [x, y] = turnTo(seat, st.spirit.x, st.spirit.y, d);
    if (!on(x, y)) continue;
    const t = pieceAt(st, x, y);
    if (t && t.k === "m") continue;
    out.push({ x, y });
  }
  return out;
}
const isWind = c => CARDS[c] && CARDS[c].kind === "wind";

/* Can this card be played at all (publicly)? */
export function cardPlayable(st, seat, card) {
  if (mainMoves(st, seat, card).length) return true;
  if (st.mode === "wind" && spiritMoves(st, seat, card).length) return true;
  return false;
}
/* Must the mover move a main-board piece? (Shadow: if any of your pieces can move with either card.) */
const anyMain = (st, seat) => st.hand[seat].some(c => mainMoves(st, seat, c).length);

/* A step of a piece on a scratch copy: capture, win checks. */
function stepPiece(st, seat, mv) {
  const p = st.pieces.find(q => q.id === mv.pid);
  const t = pieceAt(st, mv.x, mv.y);
  const ev = { pid: p.id, k: p.k, from: [p.x, p.y], to: [mv.x, mv.y] };
  if (t) { st.pieces = st.pieces.filter(q => q !== t); ev.cap = t.k; if (t.k === "m") { st.winner = seat; st.how = "stone"; } }
  p.x = mv.x; p.y = mv.y;
  const opp = 1 - seat;
  if (p.k === "m" && mv.x === TEMPLE[opp][0] && mv.y === TEMPLE[opp][1] && st.winner == null) { st.winner = seat; st.how = "stream"; }
  return ev;
}
function stepSpirit(st, sp) {
  const ev = { from: [st.spirit.x, st.spirit.y], to: [sp.x, sp.y] };
  const t = pieceAt(st, sp.x, sp.y);
  if (t) { t.x = st.spirit.x; t.y = st.spirit.y; ev.swap = t.id; }
  st.spirit = { x: sp.x, y: sp.y };
  return ev;
}

/* The board after a main-board move, for the screen: where a wind card's Spirit may go next, what a Ninja would land on.
 * Not a full move (no card change, no Ninja); null if the move isn't legal. */
export function preview(st0, seat, mv) {
  const p = mv && st0.pieces.find(q => q.id === mv.pid && q.s === seat);
  if (!p || !on(mv.x, mv.y)) return null;
  const st = clone(st0);
  stepPiece(st, seat, mv);
  return st;
}

/* Apply a move by `seat`. Returns the new state, or null if the move breaks a rule that can be seen in public.
 *   a = { card, pass?, mv?: {pid,x,y}, sp?: {x,y}, nj?: commit, show?: [{i,x,y}], lan?: {ax:"r"|"c", i} } */
export function play(st0, seat, a) {
  if (!st0 || st0.winner != null || st0.wait || st0.turn !== seat || !a) return null;
  if (!st0.hand[seat].includes(a.card)) return null;
  const st = clone(st0);
  const opp = 1 - seat;
  /* Your shown Ninjas go back into hiding as your turn begins. */
  st.nin[seat].shown = st.nin[seat].shown.map(() => null);
  const ev = { ply: st.ply, seat, card: a.card };

  if (a.pass) {
    /* Zugzwang: nothing on the board can move with either card. (A Shadow player with a Ninja may still pass.) */
    if (st0.hand[seat].some(c => cardPlayable(st0, seat, c))) return null;
    if (a.mv || a.sp) return null;
    ev.pass = true;
  } else if (isWind(a.card)) {
    /* First one of yours (if it can), then the Spirit (if it can, after that). */
    const prim = mainMoves(st0, seat, a.card);
    if (prim.length) {
      if (!a.mv || !prim.some(m => m.pid === a.mv.pid && m.x === a.mv.x && m.y === a.mv.y)) return null;
      ev.mv = stepPiece(st, seat, a.mv);
    } else if (a.mv) return null;
    if (st.winner == null) {
      const sec = spiritMoves(st, seat, a.card);
      if (sec.length) {
        if (!a.sp || !sec.some(m => m.x === a.sp.x && m.y === a.sp.y)) return null;
        ev.sp = stepSpirit(st, a.sp);
      } else if (a.sp) return null;
    } else if (a.sp) return null;
    if (!ev.mv && !ev.sp) return null;
  } else {
    if (a.mv && a.sp) return null;
    if (a.mv) {
      if (!mainMoves(st0, seat, a.card).some(m => m.pid === a.mv.pid && m.x === a.mv.x && m.y === a.mv.y)) return null;
      ev.mv = stepPiece(st, seat, a.mv);
    } else if (a.sp) {
      if (st0.mode !== "wind" || !spiritMoves(st0, seat, a.card).some(m => m.x === a.sp.x && m.y === a.sp.y)) return null;
      ev.sp = stepSpirit(st, a.sp);
    } else {
      /* No board move with this card: only allowed when nothing of yours on the board can move with either card
       * and you have a Ninja to move instead (Shadow, and Way of the Light's Shadow side). */
      if (!needsCommit(st0, seat) || !hasNinjas(st0, seat) || anyMain(st0, seat)) return null;
      ev.quiet = true;
    }
    if (st0.mode === "shadow" && !ev.mv && anyMain(st0, seat)) return null;
  }

  /* The Ninja: a new commitment, and anything it shows on the board. */
  if (needsCommit(st0, seat)) {
    if (typeof a.nj !== "string" || !/^[0-9a-f]{64}$/.test(a.nj)) return null;
    st.nin[seat].commit = a.nj;
  } else if (a.nj) return null;
  if (a.show && a.show.length) {
    if (!hasNinjas(st0, seat) || a.pass) return null;
    ev.show = [];
    for (const sh of a.show) {
      const i = sh.i | 0;
      if (!st.nin[seat].live[i] || !on(sh.x, sh.y) || st.nin[seat].shown[i]) return null;
      const mine = pieceAt(st, sh.x, sh.y);
      if (mine && mine.s === seat) return null;
      st.nin[seat].shown[i] = { x: sh.x, y: sh.y };
      const e = { i, at: [sh.x, sh.y] };
      if (mine && mine.s === opp) { st.pieces = st.pieces.filter(q => q !== mine); e.cap = mine.k; if (mine.k === "m" && st.winner == null) { st.winner = seat; st.how = "ninja"; } }
      ev.show.push(e);
    }
  }
  /* A lantern, at the end of the turn. */
  if (a.lan) {
    const okSeat = st0.mode === "shadow" || (st0.mode === "light" && seat === lightSeat(st0));
    if (!okSeat || st.nin[seat].lant < 1 || !st0.moved[seat] || !["r", "c"].includes(a.lan.ax) || !(a.lan.i >= 0 && a.lan.i < 5)) return null;
    if (!hasNinjas(st0, opp)) return null;
    st.nin[seat].lant--;
    ev.lan = { ax: a.lan.ax, i: a.lan.i | 0 };
  }

  /* Pass the card on, take the side card. */
  st.hand[seat] = st.hand[seat].map(c => (c === a.card ? st0.side : c));
  st.side = a.card;
  st.moved[seat] = true;
  st.ply++;
  st.log.push(ev);
  if (st.winner == null && hasNinjas(st, opp)) st.wait = { from: opp, lan: ev.lan || null };
  else if (st.winner == null) st.turn = opp;
  return st;
}

/* The other device's answer to a move: which of its Ninjas were caught (and where), and the lantern's answer.
 *   r = { cap: [{i,x,y}], lan?: bool } */
export function respond(st0, seat, r) {
  if (!st0 || !st0.wait || st0.wait.from !== seat || !r) return null;
  const st = clone(st0);
  const opp = 1 - seat;
  const ev = st.log[st.log.length - 1];
  ev.resp = { cap: [] };
  const occupied = (x, y) => st.pieces.some(p => p.s === opp && p.x === x && p.y === y) || st.nin[opp].shown.some(q => q && q.x === x && q.y === y);
  for (const c of r.cap || []) {
    const i = c.i | 0;
    if (!st.nin[seat].live[i] || !occupied(c.x, c.y)) return null;
    st.nin[seat].live[i] = false; st.nin[seat].shown[i] = null;
    ev.resp.cap.push({ i, at: [c.x, c.y] });
  }
  if (st0.wait.lan) { if (typeof r.lan !== "boolean") return null; ev.resp.lan = r.lan; }
  st.wait = null;
  if (st.mode === "light" && seat !== lightSeat(st) && !hasNinjas(st, seat)) { st.winner = opp; st.how = "ninjas"; }
  if (st.winner == null) st.turn = seat;
  return st;
}

/* ------------------------------------------------------------------ the hidden side (owner's device + audit) */
/* Where the Ninjas may start: Way of the Shadow, beside your Master; Way of the Light, any two of your home row. */
export function ninjaStarts(st, seat) {
  const y = HOME[seat];
  if (st.mode === "shadow") return [[1, y], [3, y]];
  if (st.mode === "light") { const out = []; for (let x = 0; x < 5; x++) out.push([x, y]); return out; }
  return [];
}
export function validStart(st, seat, ninjas) {
  const ok = ninjaStarts(st, seat).map(String);
  if (!Array.isArray(ninjas) || ninjas.length !== st.nin[seat].live.length) return false;
  if (!ninjas.every(n => Array.isArray(n) && ok.includes(String(n)))) return false;
  return new Set(ninjas.map(String)).size === ninjas.length;
}
/* Where Ninja i may go with this card, on the board as it stands after this turn's main move (`after`). */
export function ninjaMoves(after, seat, card, ninjas, i) {
  const from = ninjas[i];
  if (!from) return [];
  const out = [];
  for (const d of gridFor(card, "n")) {
    const [x, y] = turnTo(seat, from[0], from[1], d);
    if (!on(x, y)) continue;
    if (after.pieces.some(p => p.s === seat && p.x === x && p.y === y)) continue;
    if (ninjas.some((n, j) => j !== i && n && n[0] === x && n[1] === y)) continue;
    out.push([x, y]);
  }
  return out;
}
/* What a move by the other side makes this device announce. */
export function answer(st, seat, ninjas) {
  const opp = 1 - seat, cap = [];
  ninjas.forEach((n, i) => {
    if (!n || !st.nin[seat].live[i]) return;
    const hit = st.pieces.some(p => p.s === opp && p.x === n[0] && p.y === n[1]) || st.nin[opp].shown.some(q => q && q.x === n[0] && q.y === n[1]);
    if (hit) cap.push({ i, x: n[0], y: n[1] });
  });
  const r = { cap };
  if (st.wait && st.wait.lan) {
    const caught = new Set(cap.map(c => c.i));
    const { ax, i } = st.wait.lan;
    r.lan = ninjas.some((n, j) => n && !caught.has(j) && st.nin[seat].live[j] && (ax === "r" ? n[1] === i : n[0] === i));
  }
  return r;
}
/* After a respond() that caught some of mine: forget them. */
export const pruneCaught = (st, seat, ninjas) => ninjas.map((n, i) => (st.nin[seat].live[i] ? n : null));

/* ------------------------------------------------------------------ the audit
 * rec = { opts, seed, events: [{t:"mv"|"rs", seat, a|r}], hist: [[{ninjas, salt}...], [...]] }
 * hist[s][0] is seat s's starting positions; hist[s][k] the positions committed with its k-th move. */
export function audit(rec) {
  try {
    let st = deal(rec.opts, rec.seed);
    const k = [0, 0], priv = [null, null];
    for (const s of [0, 1]) {
      if (!needsCommit(st, s)) continue;
      const h = rec.hist[s] || [];
      if (!h.length) return { ok: false, who: s, why: "no starting positions" };
      if (!validStart(st, s, h[0].ninjas)) return { ok: false, who: s, why: "an impossible starting place" };
      if (rec.commits && rec.commits[s] && rec.commits[s][0] !== commitOf(h[0].ninjas, h[0].salt)) return { ok: false, who: s, why: "starting positions don't match what was promised" };
      priv[s] = h[0].ninjas;
    }
    let mvCount = [0, 0];
    for (const e of rec.events) {
      if (e.t === "mv") {
        const s = e.seat, before = st;
        const next = play(st, s, e.a);
        if (!next) return { ok: false, who: s, why: "a move the rules refuse" };
        if (needsCommit(before, s)) {
          k[s]++; mvCount[s]++;
          const h = rec.hist[s][k[s]];
          if (!h || commitOf(h.ninjas, h.salt) !== e.a.nj) return { ok: false, who: s, why: "Ninja positions don't match what was promised" };
          const prev = pruneCaught(before, s, priv[s]), now = h.ninjas;
          /* At most one Ninja moved, by one step of the card used, and not onto one of your own pieces. */
          const moved = now.map((n, i) => String(n) !== String(prev[i]) ? i : -1).filter(i => i >= 0);
          if (moved.length > 1) return { ok: false, who: s, why: "two Ninjas moved at once" };
          const afterMain = { ...next, pieces: next.pieces };
          for (const i of moved) {
            if (!prev[i] || !now[i]) return { ok: false, who: s, why: "a captured Ninja came back" };
            if (e.a.pass) return { ok: false, who: s, why: "a Ninja moved on a passed turn" };
            if (!ninjaMoves(afterMain, s, e.a.card, prev, i).some(t => t[0] === now[i][0] && t[1] === now[i][1])) return { ok: false, who: s, why: "a Ninja move the card doesn't allow" };
          }
          for (let i = 0; i < now.length; i++) if (!prev[i] && now[i]) return { ok: false, who: s, why: "a captured Ninja came back" };
          /* Light's Shadow must move a Ninja if one can move. */
          if (before.mode === "light" && s !== lightSeat(before) && !moved.length && !e.a.pass) {
            const could = prev.some((n, i) => n && ninjaMoves(afterMain, s, e.a.card, prev, i).length);
            if (could) return { ok: false, who: s, why: "a Ninja that could move stayed put" };
          }
          if (before.mode === "light" && s !== lightSeat(before) && e.a.pass) {
            const could = before.hand[s].some(c => prev.some((n, i) => n && ninjaMoves(before, s, c, prev, i).length));
            if (could) return { ok: false, who: s, why: "a pass while a Ninja could move" };
          }
          /* Every show is where that Ninja really is; a Ninja landing on an enemy piece must show. */
          const shows = (e.a.show || []).map(x => x.i);
          for (const sh of e.a.show || []) if (!now[sh.i] || now[sh.i][0] !== sh.x || now[sh.i][1] !== sh.y) return { ok: false, who: s, why: "a Ninja shown where it wasn't" };
          for (const i of moved) {
            const t = before.pieces.find(p => p.s !== s && p.x === now[i][0] && p.y === now[i][1]);
            if (t && !shows.includes(i)) return { ok: false, who: s, why: "a Ninja reached a piece and kept quiet" };
          }
          priv[s] = now;
        }
        st = next;
      } else if (e.t === "rs") {
        const s = e.seat;
        const truth = answer(st, s, pruneCaught(st, s, priv[s]));
        const said = e.r || {};
        const sameCap = JSON.stringify((said.cap || []).map(c => [c.i, c.x, c.y]).sort()) === JSON.stringify(truth.cap.map(c => [c.i, c.x, c.y]).sort());
        if (!sameCap) return { ok: false, who: s, why: "a caught Ninja wasn't owned up to" };
        if (st.wait && st.wait.lan && said.lan !== truth.lan) return { ok: false, who: s, why: "a lantern was answered falsely" };
        const next = respond(st, s, said);
        if (!next) return { ok: false, who: s, why: "an answer the rules refuse" };
        st = next;
      }
    }
    return { ok: true, final: st };
  } catch (err) {
    return { ok: false, who: null, why: "the record couldn't be read (" + err.message + ")" };
  }
}

/* ------------------------------------------------------------------ helpers for screens */
export function describe(st, ev, names) {
  const who = names[ev.seat] || (ev.seat ? "Blue" : "Red");
  const sq = ([x, y]) => "abcde"[x] + (y + 1);
  const bits = [];
  if (ev.pass) bits.push("passed");
  if (ev.mv) bits.push(`${ev.mv.k === "m" ? "Master" : "Student"} ${sq(ev.mv.from)}→${sq(ev.mv.to)}${ev.mv.cap ? (ev.mv.cap === "m" ? ", took the Master" : ", took a Student") : ""}`);
  if (ev.sp) bits.push(`Spirit ${sq(ev.sp.from)}→${sq(ev.sp.to)}${ev.sp.swap != null ? ", swapped a Student" : ""}`);
  if (ev.quiet) bits.push("moved in the shadows");
  for (const s of ev.show || []) bits.push(`Ninja shown at ${sq(s.at)}${s.cap ? (s.cap === "m" ? ", took the Master" : ", took a Student") : ""}`);
  if (ev.lan) bits.push(`lantern on ${ev.lan.ax === "r" ? "row " + (ev.lan.i + 1) : "file " + "abcde"[ev.lan.i]}${ev.resp && "lan" in ev.resp ? (ev.resp.lan ? ": yes" : ": no") : ""}`);
  if (ev.resp && ev.resp.cap && ev.resp.cap.length) bits.push(ev.resp.cap.map(c => `caught a Ninja at ${sq(c.at)}`).join(", "));
  return `${who} (${nameOf(ev.card)}): ${bits.join("; ")}`;
}
