/* SCROLL & STONE — a table seen from this device. As Schnapsen's app/session.js, cut down: two seats, the
 * owner's options, and the match (match.js) once the owner starts it. The table's arrangement lives in the
 * owner's presence on the table's mesh, and is advertised in the Scroll & Stone lobby.
 * Storage keys start "st." so nothing is shared with Schnapsen except who you are (sx.cid, sx.name). */
import { LS, uid, cell, makeCode, nudge } from "../util.js";
import { me } from "../ident.js";
import { openMesh } from "../net/mesh.js";
import { openChat } from "../chat.js";
import { openStoneMatch } from "./match.js";
import { DEFAULT_OPTS as ENGINE_OPTS, poolProblem } from "./engine.js";

export const DEFAULT_OPTS = { ...ENGINE_OPTS, sets: { base: true }, private: false };
export const SESSION_KEY = "st.session";

/* Rooms of this game are kept apart from Schnapsen's on the same transport. */
export const stoneP2P = p2p => {
  const o = Object.create(p2p);
  o.join = (roomId, opts) => p2p.join("stone-" + roomId, opts);
  return o;
};

export function createTable(hub, opts = {}) {
  const code = makeCode(hub.tables.get().map(t => t.code));
  const w = me.get();
  const last = LS.get("st.lastOpts") || {};
  const table = {
    code, ownerCid: w.cid,
    seats: [{ cid: w.cid, name: w.name, color: w.color }, null],
    opts: { ...DEFAULT_OPTS, ...last, ...opts },
    status: "open", matchId: null, createdAt: Date.now(),
  };
  LS.set("st.own." + code, table);
  return code;
}

export function openTable(hub, code) {
  const who = () => me.get();
  const owned = LS.get("st.own." + code);
  const owner = !!(owned && owned.ownerCid === who().cid);
  let table = owner ? owned : LS.get("st.seen." + code);
  const st = cell({ owner, code, table, seat: -1, view: null, people: [], found: owner || !!table, lost: false, closed: null, kicked: false, oppHere: false, ownerHere: owner, pub: null });
  const presence = () => { const w = who(); return { cid: w.cid, name: w.name, color: w.color, ...(owner ? { owner: true, table } : {}) }; };
  const mesh = openMesh(hub.p2p, "table-" + code, { presence: presence() });
  const chat = openChat(mesh, { me, persistKey: "stone." + code });
  const offs = [];
  let match = null, matchOff = null, lastPub = null;
  offs.push(me.sub(() => mesh.setPresence(presence())));
  const mySeat = () => (table ? table.seats.findIndex(x => x && x.cid === who().cid) : -1);
  const emit = () => st.set(x => ({ ...x, table, seat: mySeat() }));

  function syncMatch() {
    const seat = mySeat();
    const want = table && table.status === "playing" && table.matchId && seat >= 0;
    if (want && (!match || match.matchId !== table.matchId)) {
      closeMatch();
      const config = { matchId: table.matchId, seats: table.seats, opts: table.opts };
      match = openStoneMatch({ mesh, code, config, seat, peerCid: table.seats[1 - seat].cid });
      match.matchId = table.matchId;
      let prev = null;
      const onView = v => {
        st.set(x => ({ ...x, view: v }));
        const s = v && v.st;
        const mine = !!(s && v.ready && s.winner == null && !s.wait && s.turn === seat);
        if (mine && prev === false) nudge("Your turn");
        prev = mine;
        /* Watchers see the board as everyone may: the pieces, the cards, the Spirit, shown Ninjas. Never a hidden one. */
        if (s) {
          const pub = { st: { ...s, nin: s.nin.map(n => ({ ...n, commit: null })) }, score: v.score, n: v.n };
          const pv = JSON.stringify(pub);
          if (pv !== lastPub) { lastPub = pv; if (watchers()) mesh.send("pub", pub); if (owner) advertise(v.score); }
        }
      };
      matchOff = match.state.sub(onView);
      onView(match.state.get());
    } else if (!want && match) { closeMatch(); st.set(x => ({ ...x, view: null })); }
  }
  function closeMatch() { if (matchOff) matchOff(); if (match) match.close(); match = null; matchOff = null; }
  const watchers = () => {
    const seated = new Set(((table && table.seats) || []).filter(Boolean).map(x => x.cid));
    return mesh.people.get().some(p => !p.self && p.cid && !seated.has(p.cid));
  };

  let lastAd = "";
  const advertise = score => {
    const ad = JSON.stringify([table.status, table.opts, table.seats, score || null]);
    if (ad === lastAd) return;
    lastAd = ad;
    hub.setHosting({ code, private: !!table.opts.private, status: table.status,
      seats: table.seats.map(x => (x ? { name: x.name, color: x.color } : null)), opts: table.opts, score: score || null });
  };
  const setTable = patch => {
    table = { ...table, ...patch };
    LS.set("st.own." + code, table);
    emit(); mesh.setPresence(presence()); advertise(); syncMatch();
  };
  hub.setWhere("table:" + code);
  if (owner) {
    advertise();
    offs.push(mesh.on("sit", (d, from) => {
      if (!from.cid || !d || table.status !== "open") return;
      const seat = d.seat | 0;
      if (seat < 0 || seat > 1 || table.seats[seat] || table.seats.some(x => x && x.cid === from.cid)) return;
      const seats = table.seats.slice();
      seats[seat] = { cid: from.cid, name: String(from.name || "").slice(0, 16), color: from.color };
      setTable({ seats });
    }));
    offs.push(mesh.on("stand", (d, from) => {
      if (table.status !== "open") return;
      const seat = table.seats.findIndex(x => x && x.cid === from.cid);
      if (seat < 0 || from.cid === table.ownerCid) return;
      const seats = table.seats.slice(); seats[seat] = null; setTable({ seats });
    }));
  } else {
    offs.push(mesh.on("kick", (d, from) => { if (from.owner && d && d.cid === who().cid) st.set(x => ({ ...x, kicked: true })); }));
    offs.push(mesh.on("bye", (d, from) => { if (from.owner) st.set(x => ({ ...x, closed: "The table was closed." })); }));
    setTimeout(() => { if (!st.get().found) st.set(x => ({ ...x, lost: true })); }, 25000);
  }
  offs.push(mesh.onJoin(peerId => { if (match && lastPub) mesh.send("pub", JSON.parse(lastPub), peerId); }));
  offs.push(mesh.on("pub", (d, from) => { if (from.cid && d && d.st) st.set(x => ({ ...x, pub: d })); }));
  offs.push(mesh.people.sub(list => {
    if (!owner) {
      const o = list.find(p => p.owner && p.table && p.table.code === code);
      if (o) { table = o.table; if (mySeat() >= 0) LS.set("st.seen." + code, table); }
    }
    const seat = mySeat();
    const opp = table && seat >= 0 ? table.seats[1 - seat] : null;
    st.set(x => ({ ...x, people: list, table, seat, found: x.found || !!table, lost: x.lost && !table,
      ownerHere: owner || list.some(p => p.owner), oppHere: !!(opp && list.some(p => p.cid === opp.cid)) }));
    syncMatch();
  }));

  LS.set(SESSION_KEY, { code, at: Date.now() });
  emit(); syncMatch();

  const ownerPeer = () => (mesh.people.get().find(p => p.owner) || {}).peerId;
  return {
    state: st, chat: cell(chat), owner, mesh,
    match: () => match,
    sit(seat) { const o = ownerPeer(); if (o) mesh.send("sit", { seat }, o); },
    stand() { const o = ownerPeer(); if (o) mesh.send("stand", 1, o); },
    setOpts(patch) {
      if (!owner || table.status !== "open") return;
      const opts = { ...table.opts, ...patch };
      LS.set("st.lastOpts", (({ private: _p, ...k }) => k)(opts));
      setTable({ opts });
    },
    problem: () => (table ? poolProblem(table.opts) : null),
    start() { if (owner && table.seats.every(Boolean) && !poolProblem(table.opts)) setTable({ status: "playing", matchId: uid() }); },
    toSeats() { if (owner && table.status === "playing") { if (match) match.forget(); setTable({ status: "open", matchId: null }); } },
    kick(cid) {
      if (!owner || table.status !== "open") return;
      setTable({ seats: table.seats.map(x => (x && x.cid === cid ? null : x)) });
      mesh.send("kick", { cid });
    },
    close() {
      if (!owner) return;
      mesh.send("bye", 1);
      if (match) match.forget();
      LS.del("st.own." + code); LS.del(SESSION_KEY);
      hub.setHosting(null);
    },
    leave() {
      closeMatch();
      offs.forEach(f => { try { f(); } catch {} });
      chat.close(); mesh.leave();
      if (owner) hub.setHosting(null);
      hub.setWhere("lobby");
    },
  };
}
