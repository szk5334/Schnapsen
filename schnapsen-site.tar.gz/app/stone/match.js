/* SCROLL & STONE — a lockstep match between two devices, no host.
 *
 * Everything that happens is a message in a per-game log, applied in order on both devices and saved, so a
 * reload replays it. The messages:
 *   c   a commitment to my half of the shuffle seed: H("seed|" + r)
 *   r   the seed half itself, sent once I hold theirs committed (so neither side can choose the deal)
 *   n0  a commitment to where my Ninjas start (Light and Shadow)
 *   mv  my move (engine.play's action: card, board moves, Ninja commitment, shows, lantern)
 *   rs  my answer to their move (Ninjas of mine it caught, the lantern's yes or no)
 *   au  game over: every Ninja position and salt I committed to, so the other device can check the game
 *   next  start the next game at this table
 * The deal is H(r0 | r1). Moves are checked on arrival by the same engine; Ninja play is checked by audit().
 * Transport, acknowledgements and re-sends work as in the Schnapsen match (app/mp/match.js).
 */
import { deal, play, respond, needsCommit, hasNinjas, answer, pruneCaught, commitOf, audit, H, ninjaMoves, validStart } from "./engine.js";
import { LS, cell } from "../util.js";

const rand = () => { const a = new Uint8Array(16); crypto.getRandomValues(a); return [...a].map(b => b.toString(16).padStart(2, "0")).join(""); };

export function openStoneMatch({ mesh, code, config, seat, peerCid }) {
  const KEY = "st.match." + code;
  const opp = 1 - seat;
  let p = LS.get(KEY);
  if (!p || p.config.matchId !== config.matchId) p = { config, n: 1, score: [0, 0], log: [], mySeq: 0, peerSeq: 0, prevOwn: [], sec: {} };
  const future = [];
  const out = cell(null);
  let M = null;

  const fresh = () => ({ myC: null, theirC: null, myR: null, theirR: null, seed: null, st: null, n0: [null, null],
    events: [], auditSent: false, theirHist: null, audit: null, error: null });
  const save = () => LS.set(KEY, p);
  const priv = () => p.sec.hist && p.sec.hist.length ? p.sec.hist[p.sec.hist.length - 1].ninjas : null;
  const ready = () => !!M.st && [0, 1].every(s => !needsCommit(M.st, s) || M.n0[s]);
  const publish = () => out.set({ n: p.n, st: M.st, ready: ready(), placing: !!M.st && needsCommit(M.st, seat) && !M.n0[seat],
    waitingPlace: !!M.st && needsCommit(M.st, opp) && !M.n0[opp], ninjas: priv(), theirNinjas: M.theirHist && M.theirHist.length ? M.theirHist[M.theirHist.length - 1].ninjas : null, audit: M.audit, error: M.error, score: p.score.slice() });

  /* ---- applying one message ---- */
  let lastProgress = Date.now();
  function apply(msg, mine) {
    lastProgress = Date.now();
    const who = mine ? seat : opp;
    switch (msg.t) {
      case "c": if (mine) M.myC = msg.h; else M.theirC = msg.h; break;
      case "r":
        if (mine) M.myR = msg.r;
        else { if (H("seed|" + msg.r) !== M.theirC) { M.error = "The other phone's shuffle didn't match its promise."; return; } M.theirR = msg.r; }
        if (M.myR && M.theirR && !M.st) {
          const r0 = seat === 0 ? M.myR : M.theirR, r1 = seat === 0 ? M.theirR : M.myR;
          M.seed = H("deal|" + r0 + "|" + r1);
          M.st = deal(config.opts, M.seed);
        }
        break;
      case "n0": M.n0[who] = msg.h; break;
      case "mv": {
        const nx = play(M.st, who, msg.a);
        if (!nx) { M.error = `${mine ? "Your" : "Their"} move was refused by the rules.`; return; }
        M.st = nx; M.events.push({ t: "mv", seat: who, a: msg.a });
        break;
      }
      case "rs": {
        const nx = respond(M.st, who, msg.r);
        if (!nx) { M.error = `${mine ? "Your" : "Their"} answer was refused by the rules.`; return; }
        M.st = nx; M.events.push({ t: "rs", seat: who, r: msg.r });
        if (mine && p.sec.hist) {
          /* My Ninjas it caught are gone; the next commitment says so. */
          const last = p.sec.hist[p.sec.hist.length - 1];
          p.sec.live = pruneCaught(M.st, seat, last.ninjas);
        }
        break;
      }
      case "au":
        if (mine) M.auditSent = true; else M.theirHist = msg.hist;
        if (M.auditSent && M.theirHist && M.st && M.st.winner != null) runAudit();
        break;
    }
  }
  function runAudit() {
    const hist = [null, null], commits = [[], []];
    hist[seat] = p.sec.hist || []; hist[opp] = M.theirHist || [];
    for (const s of [0, 1]) {
      if (M.n0[s]) commits[s].push(M.n0[s]);
      for (const e of M.events) if (e.t === "mv" && e.seat === s && e.a.nj) commits[s].push(e.a.nj);
    }
    M.audit = audit({ opts: config.opts, seed: M.seed, events: M.events, hist, commits });
  }

  /* ---- what this device sends by itself ---- */
  let busy = false;
  function effects() {
    if (busy || M.error) return;
    busy = true;
    setTimeout(() => {
      busy = false;
      if (M.error) return;
      if (!M.myC) { p.sec.r = rand(); send({ t: "c", h: H("seed|" + p.sec.r) }); return; }
      if (M.theirC && !M.myR) { send({ t: "r", r: p.sec.r }); return; }
      if (!M.st) return;
      if (M.st.wait && M.st.wait.from === seat) {
        const live = p.sec.live || priv() || [];
        send({ t: "rs", r: answer(M.st, seat, pruneCaught(M.st, seat, live)) });
        return;
      }
      if (M.st.winner != null && !M.auditSent) { send({ t: "au", hist: p.sec.hist || [] }); return; }
    }, 0);
  }

  /* ---- the log (as app/mp/match.js) ---- */
  const wire = (m, extra) => ({ ...m, ak: [p.n, p.peerSeq], ...(extra || {}) });
  let theirAck = null;
  function send(body) {
    const msg = { ...body, n: p.n, s: p.mySeq++, from: seat };
    p.log.push({ mine: true, msg });
    if (msg.t !== "next") apply(msg, true);
    save(); publish();
    const peer = mesh.peerOf(peerCid);
    if (peer) mesh.send("sx", wire(msg), peer);
    if (msg.t === "next") transition();
    else effects();
  }
  let lastEcho = 0;
  function receive(raw) {
    if (!raw || typeof raw.n !== "number" || raw.from !== opp) return;
    const { re, ak, ...msg } = raw;
    if (Array.isArray(ak) && (!theirAck || ak[0] > theirAck.n || (ak[0] === theirAck.n && ak[1] > theirAck.s))) theirAck = { n: ak[0], s: ak[1] };
    if (!re && (msg.n < p.n || (msg.n === p.n && msg.s < p.peerSeq)) && Date.now() - lastEcho > 10000) {
      lastEcho = Date.now();
      const peer = mesh.peerOf(peerCid);
      if (peer) setTimeout(() => resend(peer, { echo: true, prio: "low" }), 300);
    }
    if (msg.n < p.n) return;
    if (msg.n > p.n || msg.s > p.peerSeq) { if (!future.some(m => m.n === msg.n && m.s === msg.s)) future.push(msg); return; }
    if (msg.s < p.peerSeq) return;
    p.peerSeq++;
    p.log.push({ mine: false, msg });
    if (msg.t === "next") { save(); transition(); return; }
    apply(msg, false); save(); publish();
    drain(); effects();
  }
  function drain() {
    for (;;) {
      const i = future.findIndex(m => m.n === p.n && m.s === p.peerSeq);
      if (i < 0) break;
      receive(future.splice(i, 1)[0]);
    }
  }
  function transition() {
    if (!M.st || M.st.winner == null) return;
    p.score[M.st.winner]++;
    p.prevOwn = p.log.filter(e => e.mine).map(e => e.msg);
    p.last = { n: p.n, st: M.st, audit: M.audit };
    p.n += 1; p.log = []; p.mySeq = 0; p.peerSeq = 0; p.sec = {};
    M = fresh(); save(); publish();
    drain(); effects();
  }

  /* ---- rebuild from the saved log ---- */
  M = fresh();
  for (const e of p.log) if (e.msg.t !== "next") apply(e.msg, e.mine);
  if (p.log.some(e => e.msg.t === "next")) transition();
  publish();

  const resend = (peerId, { echo = false, prio } = {}) => {
    const a = theirAck;
    if (a && a.n > p.n) return;
    const prev = !a ? p.prevOwn : a.n === p.n - 1 ? p.prevOwn.filter(m => m.s >= a.s) : a.n < p.n - 1 ? p.prevOwn : [];
    const cur = p.log.filter(e => e.mine && (!a || a.n < p.n || e.msg.s >= a.s)).map(e => e.msg);
    for (const m of prev.concat(cur)) mesh.send("sx", wire(m, echo ? { re: 1 } : null), peerId, prio);
  };
  const waitingOnThem = () => {
    if (M.error) return false;
    if (!M.st) return true;
    if (!ready()) return !M.n0[opp];
    if (M.st.winner != null) return !M.audit;
    return M.st.wait ? M.st.wait.from === opp : M.st.turn === opp;
  };
  let netWait = 30000, lastNet = 0, seen = lastProgress;
  const net = setInterval(() => {
    if (lastProgress !== seen) { seen = lastProgress; netWait = 30000; }
    if (mesh.backlog && mesh.backlog() > 0) return;
    if (Date.now() - Math.max(lastProgress, lastNet) < netWait || !waitingOnThem()) return;
    const peer = mesh.peerOf(peerCid);
    if (!peer) return;
    lastNet = Date.now(); resend(peer, { prio: "low" });
    netWait = Math.min(60000, netWait * 2);
  }, 3000);

  const offs = [
    mesh.on("sx", (d, from) => { if (from.cid === peerCid) receive(d); }),
    mesh.onJoin((peerId, pr) => { if (pr.cid === peerCid) resend(peerId); }),
  ];
  const peer0 = mesh.peerOf(peerCid);
  if (peer0) resend(peer0);
  effects();

  /* ---- my side's actions ---- */
  const salt = () => rand();
  function commitNinjas(ninjas) {
    const sl = salt();
    p.sec.hist = (p.sec.hist || []).concat([{ ninjas, salt: sl }]);
    p.sec.live = ninjas;
    return commitOf(ninjas, sl);
  }
  return {
    state: out,
    seat,
    /* Where my Ninjas start: a list of [x, y]. */
    place(ninjas) {
      if (!M.st || M.n0[seat] || !needsCommit(M.st, seat) || !validStart(M.st, seat, ninjas)) return false;
      p.sec.hist = [];
      send({ t: "n0", h: commitNinjas(ninjas) });
      return true;
    },
    /* My move: { card, pass?, mv?, sp?, ninja?: {i, x, y}, attack?: i, lan? }. Builds the commitment and the shows. */
    act(m) {
      const st = M.st;
      if (!st || M.error || !ready() || st.winner != null || st.wait || st.turn !== seat) return false;
      const a = { card: m.card };
      if (m.pass) a.pass = true;
      if (m.mv) a.mv = m.mv;
      if (m.sp) a.sp = m.sp;
      if (m.lan) a.lan = m.lan;
      if (needsCommit(st, seat)) {
        const now = pruneCaught(st, seat, p.sec.live || priv() || []).slice();
        const show = [];
        if (m.ninja && now[m.ninja.i]) {
          /* the board after my main move, to check the Ninja's step and what it lands on */
          const after = play(st, seat, { ...a, nj: "0".repeat(64) }) || st;
          if (!ninjaMoves(after, seat, m.card, now, m.ninja.i).some(t => t[0] === m.ninja.x && t[1] === m.ninja.y)) return false;
          now[m.ninja.i] = [m.ninja.x, m.ninja.y];
          if (after.pieces.some(q => q.s === opp && q.x === m.ninja.x && q.y === m.ninja.y)) show.push({ i: m.ninja.i, x: m.ninja.x, y: m.ninja.y });
        }
        if (m.attack != null && now[m.attack] && !show.some(x => x.i === m.attack)) show.push({ i: m.attack, x: now[m.attack][0], y: now[m.attack][1] });
        const keepHist = p.sec.hist, keepLive = p.sec.live;
        a.nj = commitNinjas(now);
        if (show.length) a.show = show;
        if (!play(st, seat, a)) { p.sec.hist = keepHist; p.sec.live = keepLive; return false; }
      } else if (!play(st, seat, a)) return false;
      send({ t: "mv", a });
      return true;
    },
    next() { if (M.st && M.st.winner != null && M.audit) send({ t: "next" }); },
    forget() { LS.del(KEY); },
    _debug: () => ({ n: p.n, mySeq: p.mySeq, peerSeq: p.peerSeq, log: p.log.map(e => (e.mine ? ">" : "<") + e.msg.t + e.msg.s), err: M.error }),
    close() { clearInterval(net); offs.forEach(f => f()); },
  };
}
