/* CHAT — messages and typing, carried on a mesh (net/mesh.js). There is no server copy of anything said.
 *
 * Two small tricks make it behave like an ordinary chat anyway:
 *  - backlog: when somebody new links up, everyone already there hands them the recent messages, and
 *    messages are de-duplicated by id. Something typed while nobody else was linked is delivered the next
 *    time somebody arrives, because it is part of that backlog.
 *  - local copy: each device keeps the last 120 messages of each room, so a reload doesn't wipe it.
 */
import { LS, uid, cell } from "./util.js";

const KEEP = 120, BACKLOG = 50;

export function openChat(mesh, { me, persistKey }) {
  const key = persistKey ? "sx.chat." + persistKey : null;
  const state = cell({ messages: key ? LS.get(key, []) : [], typing: {} });
  const ids = new Set(state.get().messages.map(m => m.id));
  let incoming = () => {};

  const save = () => { if (key) LS.set(key, state.get().messages.slice(-KEEP)); };
  const add = list => {
    const fresh = list.filter(m => m && m.id && typeof m.text === "string" && !ids.has(m.id));
    if (!fresh.length) return [];
    fresh.forEach(m => ids.add(m.id));
    state.set(s => ({ ...s, messages: s.messages.concat(fresh).sort((a, b) => a.ts - b.ts).slice(-KEEP) }));
    save();
    return fresh;
  };
  const clean = m => ({
    id: String(m.id).slice(0, 40), cid: String(m.cid || "").slice(0, 40),
    name: String(m.name || "").slice(0, 16), color: String(m.color || "").slice(0, 9),
    text: String(m.text || "").slice(0, 500), ts: +m.ts || Date.now(), kind: m.kind === "emote" ? "emote" : undefined,
  });

  const offs = [
    mesh.onJoin(peerId => {
      const back = state.get().messages.slice(-BACKLOG);
      if (back.length) mesh.send("chat.back", back, peerId);
    }),
    mesh.on("chat.msg", d => {
      if (!d) return;
      const got = add([clean(d)]);
      if (got.length) {
        state.set(s => { const typing = { ...s.typing }; delete typing[d.cid]; return { ...s, typing }; });
        incoming(got[0]);
      }
    }),
    mesh.on("chat.back", d => { if (Array.isArray(d)) add(d.slice(-BACKLOG).map(clean)); }),
    mesh.on("chat.typing", (d, from) => {
      if (!from.cid) return;
      state.set(s => ({ ...s, typing: { ...s.typing, [from.cid]: Date.now() + 4000 } }));
    }),
  ];

  let lastTyping = 0;
  return {
    state,
    mesh,
    send(text, kind) {
      const body = String(text || "").trim().slice(0, 500);
      if (!body) return;
      const w = me.get();
      const m = { id: uid(), cid: w.cid, name: w.name, color: w.color, text: body, ts: Date.now(), kind };
      add([m]); mesh.send("chat.msg", m);
    },
    typing() {
      const now = Date.now();
      if (now - lastTyping < 2500) return;
      lastTyping = now; mesh.send("chat.typing", 1);
    },
    onMessage(f) { incoming = f; },
    close() { offs.forEach(f => f()); },
  };
}
