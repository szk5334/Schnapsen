/* SRA COMMUTATIVE ENCRYPTION — the arithmetic under mental poker.
 *
 *   E_k(m) = m^k mod P          D_k(c) = c^(k^-1 mod (P-1)) mod P
 *
 * Because exponents commute, E_a(E_b(m)) = E_b(E_a(m)): two players can each lock the deck with their own
 * key, in either order, and unlock in either order. P is the 1024-bit safe prime of RFC 2409 (Oakley
 * group 2), so P-1 = 2q with q prime, and every odd key below q is invertible.
 *
 * Cards are encoded as quadratic residues ((i+2)^2 mod P). SRA leaks whether a ciphertext is a residue;
 * with every card a residue, that leak says nothing about which card it is. */

export const P = BigInt("0xFFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7EDEE386BFB5A899FA5AE9F24117C4B1FE649286651ECE65381FFFFFFFFFFFFFFFF");
const PM1 = P - 1n;

export function modpow(b, e, m = P) {
  let r = 1n; b %= m;
  while (e > 0n) { if (e & 1n) r = (r * b) % m; b = (b * b) % m; e >>= 1n; }
  return r;
}
function egcdInv(a, m) {
  let [r0, r1] = [a % m, m], [s0, s1] = [1n, 0n];
  while (r1 !== 0n) { const q = r0 / r1; [r0, r1] = [r1, r0 - q * r1]; [s0, s1] = [s1, s0 - q * s1]; }
  if (r0 !== 1n) throw new Error("key not invertible");
  return ((s0 % m) + m) % m;
}

/* A fresh key: 256 random bits, odd (so coprime to P-1 = 2q). */
export function randKey() {
  const u = new Uint32Array(8); crypto.getRandomValues(u);
  let k = 0n; for (const x of u) k = (k << 32n) | BigInt(x);
  return k | 1n | (1n << 255n);
}
export const inv = k => egcdInv(k, PM1);
export const enc = (m, k) => modpow(m, k);
export const dec = (c, k) => modpow(c, inv(k));

/* Unlock with two keys in one exponentiation. */
export const dec2 = (c, k1, k2) => modpow(c, (inv(k1) * inv(k2)) % PM1);

export const encodeCard = i => { const x = BigInt(i + 2); return (x * x) % P; };
const decoders = new Map();
export function decoder(n) {
  if (decoders.has(n)) return decoders.get(n);
  const map = new Map();
  for (let i = 0; i < n; i++) map.set(encodeCard(i).toString(36), i);
  const f = m => { const i = map.get(m.toString(36)); return i === undefined ? -1 : i; };
  decoders.set(n, f);
  return f;
}

/* Fisher–Yates with cryptographic randomness. */
export function shuffleSecure(a) {
  a = a.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const u = new Uint32Array(1); let j;
    do { crypto.getRandomValues(u); j = u[0] % (i + 1); } while (u[0] >= Math.floor(2 ** 32 / (i + 1)) * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export const toHex = x => x.toString(16);
export const fromHex = h => BigInt("0x" + h);
