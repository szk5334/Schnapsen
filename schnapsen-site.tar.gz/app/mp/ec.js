/* COMMUTATIVE ENCRYPTION ON AN ELLIPTIC CURVE — the arithmetic under mental poker (since build 2026-10-29.1).
 *
 *   E_k(P) = k·P          D_k(C) = k⁻¹·C          (k a scalar mod n, P a point of secp256k1)
 *
 * Scalar multiplication commutes, a·(b·P) = b·(a·P), exactly as the old SRA exponents did (m^ab = m^ba), so
 * the four-pass protocol in deck.js is unchanged. What changes is the size: a card is a 33-byte point (66 hex)
 * instead of a 1024-bit number (256 hex), and "unlock with one key, lock with another" is one multiplication
 * by the product of the two scalars instead of two exponentiations.
 *
 * secp256k1 has prime order n (cofactor 1), so every valid point is in the group and decisional Diffie–Hellman
 * is believed hard there: a locked card says nothing about which card it is. That is the job the quadratic
 * residues did for SRA. It needs one more thing, and it is the important one: the card points must have NO
 * known discrete-log relation to each other. Encoding card i as i·G would let anyone holding two locked cards
 * test j·(a·iG) = i·(a·jG) and tell them apart. So each card is hashed to the curve (RFC 9380, SSWU, SHA-256)
 * from a fixed domain tag: nobody knows any card's log, relative to G or to any other card.
 *
 * THE MULTIPLICATION. libsecp256k1 compiled to WebAssembly (vendor/secp256k1.wasm, from tiny-secp256k1 2.2.3,
 * MIT): about 0.36 ms a point here. Until it has loaded — it loads in the background, it never holds up the
 * page — and anywhere it can't load, the same multiplication runs in JavaScript (vendor/ec.js, @noble/curves,
 * about 2.5 ms). Both give the same bytes; tests/ec.test.mjs checks that they agree.
 * noble's variable-time path is fine here: the only party who could time it is the other player, who sees
 * nothing but message arrival times through relays, behind seconds of jitter. */
import { Point, hashToCurve } from "../../vendor/ec.js";

const Fn = Point.Fn;
export const N = Fn.ORDER;
const DST = "SCHNAPSEN-MENTAL-POKER-V1:secp256k1_XMD:SHA-256_SSWU_RO_";
/* The protocol's name on the wire: shuffle messages carry it, so a device still on the old SRA shuffle is
 * recognised instead of being fed numbers it would misread. */
export const SCHEME = "ec1";

/* ---------------------------------------------------------------- the wasm multiplier */
let W = null;
async function loadWasm() {
  const url = new URL("../../vendor/secp256k1.wasm", import.meta.url);
  let bytes;
  if (typeof window === "undefined" && typeof process !== "undefined" && process.versions && process.versions.node) {
    const fs = await import("node:fs");                                // tests run under Node
    bytes = fs.readFileSync(url);
  } else {
    const r = await fetch(url);
    if (!r.ok) throw new Error("wasm " + r.status);
    bytes = await r.arrayBuffer();                                     // not instantiateStreaming: no MIME type needed
  }
  const imports = {
    "./rand.js": { generateInt32: () => crypto.getRandomValues(new Int32Array(1))[0] },   // context blinding
    "./validate_error.js": { throwError: c => { throw new TypeError("secp256k1 error " + c); } },
  };
  const { instance } = await WebAssembly.instantiate(bytes, imports);
  const x = instance.exports;
  x.initializeContext();
  const PUB = x.PUBLIC_KEY_INPUT.value, TW = x.TWEAK_INPUT.value;
  return {
    mul(p33, k32) {
      const m = new Uint8Array(x.memory.buffer);
      m.set(p33, PUB); m.set(k32, TW);
      try { return x.pointMultiply(33, 33) === 1 ? m.slice(PUB, PUB + 33) : null; }
      finally { m.fill(0, PUB, PUB + 65); m.fill(0, TW, TW + 32); }
    },
  };
}
export const ready = loadWasm().then(w => { W = w; return "wasm"; }, () => "js");
export const engine = () => (W ? "wasm" : "js");
/* Tests only: force the JavaScript path (true) or put the wasm back (false). */
let wasmBackup = null;
export function _forceJs(on) { if (on) { wasmBackup = W || wasmBackup; W = null; } else if (wasmBackup) W = wasmBackup; }

/* ---------------------------------------------------------------- scalars */
/* A fresh key: uniform in [1, n-1]. 48 random bytes reduced mod n-1 (bias below 2^-128). */
export function randKey() {
  const b = new Uint8Array(48); crypto.getRandomValues(b);
  let x = 0n; for (const v of b) x = (x << 8n) | BigInt(v);
  return (x % (N - 1n)) + 1n;
}
export const inv = k => Fn.inv(k);
export const mulK = (a, b) => Fn.mul(a, b);
export const kHex = k => k.toString(16);
export function kFrom(h) {
  if (typeof h !== "string" || !/^[0-9a-f]{1,64}$/.test(h)) throw new Error("bad key");
  const k = BigInt("0x" + h);
  if (k <= 0n || k >= N) throw new Error("key out of range");
  return k;
}

/* ---------------------------------------------------------------- points, as 66-hex compressed strings */
const HEXP = /^0[23][0-9a-f]{64}$/;
const hexBytes = h => { const b = new Uint8Array(h.length >> 1); for (let i = 0; i < b.length; i++) b[i] = parseInt(h.substr(2 * i, 2), 16); return b; };
const bytesHex = b => { let s = ""; for (const v of b) s += (v < 16 ? "0" : "") + v.toString(16); return s; };
const scalarBytes = k => hexBytes(k.toString(16).padStart(64, "0"));
/* k·P for a point given as hex; throws unless P is a point on the curve. */
export function mul(h, k) {
  if (typeof h !== "string" || !HEXP.test(h)) throw new Error("bad point");
  if (W) {
    const out = W.mul(hexBytes(h), scalarBytes(k));
    if (!out) throw new Error("bad point");
    return bytesHex(out);
  }
  return Point.fromHex(h).multiplyUnsafe(k).toHex(true);
}

const cards = [];
/* Card i as a point (hex). Cached: hashing to the curve costs about as much as a multiplication. */
export function cardPoint(i) {
  return cards[i] || (cards[i] = hashToCurve(new TextEncoder().encode("card " + i), DST).toHex(true));
}
const decoders = new Map();
/* Point (hex) → canonical card index, or -1 if it is not one of the first n cards. */
export function decoder(n) {
  if (decoders.has(n)) return decoders.get(n);
  const map = new Map();
  for (let i = 0; i < n; i++) map.set(cardPoint(i), i);
  const f = h => { const i = map.get(h); return i === undefined ? -1 : i; };
  decoders.set(n, f);
  return f;
}

/* Fisher–Yates with cryptographic randomness (unchanged from the SRA module). */
export function shuffleSecure(a) {
  a = a.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const u = new Uint32Array(1); let j;
    do { crypto.getRandomValues(u); j = u[0] % (i + 1); } while (u[0] >= Math.floor(2 ** 32 / (i + 1)) * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
