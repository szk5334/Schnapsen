/* MENTAL-POKER DECK — four passes and the deck is shuffled with nobody knowing its order.
 *
 *   1  seat 0 locks every card with key a, shuffles, sends        (seat 1 sees only ciphertext)
 *   2  seat 1 locks every card with key b, shuffles, sends        (now neither knows the order)
 *   3  seat 0 swaps its lock a for a separate key a[j] per position
 *   4  seat 1 swaps its lock b for a separate key b[j] per position  → the final deck
 *
 * Position j now opens only with BOTH a[j] and b[j]. To show a card to one player, the other sends their
 * key for that one position. To show it to everyone, both publish theirs. At the end of a deal both sides
 * publish every key, and audit() re-checks every pass.
 *
 * The locks are elliptic-curve scalars (ec.js, since build 2026-10-29.1; before that, 1024-bit SRA exponents).
 * "Swap lock a for a[j]" is a single multiplication by a⁻¹·a[j], and opening is one multiplication by
 * a[j]⁻¹·b[j]⁻¹. Cards on the wire are 66-hex compressed points; keys are hex scalars. */
import { ENG } from "../../schnapsen/engine/core.js";
import { randKey, inv, mulK, mul, kHex, kFrom, cardPoint, decoder, shuffleSecure } from "./ec.js";
export { SCHEME, ready } from "./ec.js";

/* The canonical deck for a variant. Card ids are 1-based positions in this list, identical on every device. */
export function canonicalDeck(variant) {
  ENG.setVariant(variant);
  const out = [];
  for (const c of ENG.cards()) out.push({ id: out.length + 1, rank: c.rank, suit: c.suit });
  return out;
}

export function pass1(n) {
  const a = randKey();
  const out = shuffleSecure(Array.from({ length: n }, (_, i) => mul(cardPoint(i), a)));
  return { secret: { a: kHex(a) }, out };
}
export function pass2(list) {
  const b = randKey();
  return { secret: { b: kHex(b) }, out: shuffleSecure(list.map(h => mul(h, b))) };
}
/* Re-lock every position: off with the one lock, on with that position's own key, in one multiplication. */
function relock(list, lockHex) {
  const unlock = inv(kFrom(lockHex));
  const keys = list.map(() => randKey());
  return { keys: keys.map(kHex), out: list.map((h, j) => mul(h, mulK(unlock, keys[j]))) };
}
export function pass3(list, aHex) { const r = relock(list, aHex); return { secret: { ak: r.keys }, out: r.out }; }
export function pass4(list, bHex) { const r = relock(list, bHex); return { secret: { bk: r.keys }, out: r.out }; }

/* Open one position with both keys. Returns the canonical index, or -1 if the keys don't fit. */
export function open(finalDeck, j, k1Hex, k2Hex, n) {
  try {
    return decoder(n)(mul(finalDeck[j], mulK(inv(kFrom(k1Hex)), inv(kFrom(k2Hex)))));
  } catch (e) { return -1; }
}

/* Full check once every key is public: each pass did what it claimed, and the deck holds every card once.
 * Returns { ok, deck: [canonical index per position], problem }. */
export function audit({ l1, l2, l3, l4, a, b, ak, bk }, n) {
  try {
    if (![l1, l2, l3, l4, ak, bk].every(x => Array.isArray(x) && x.length === n)) return { ok: false, problem: "A pass has the wrong number of cards." };
    const A = kFrom(a), Bk = kFrom(b), iA = inv(A), iB = inv(Bk);
    const want2 = new Set(l1.map(h => mul(h, Bk)));
    if (want2.size !== n || !l2.every(h => want2.has(h)) || new Set(l2).size !== n) return { ok: false, problem: "Pass 2 was not a shuffle of pass 1." };
    const d = decoder(n), deck = [];
    for (let j = 0; j < n; j++) {
      const kA = kFrom(ak[j]), kB = kFrom(bk[j]);
      if (mul(l2[j], mulK(iA, kA)) !== l3[j]) return { ok: false, problem: `Pass 3 is wrong at position ${j + 1}.` };
      if (mul(l3[j], mulK(iB, kB)) !== l4[j]) return { ok: false, problem: `Pass 4 is wrong at position ${j + 1}.` };
      /* l4[j] = l2[j]·a⁻¹·b⁻¹·a[j]·b[j], and l2[j] = card·a·b — so the card is l2[j]·(ab)⁻¹: same answer as
       * unlocking l4 with both position keys, which the two lines above have just tied to l2. */
      deck.push(d(mul(l2[j], mulK(iA, iB))));
    }
    if (deck.includes(-1) || new Set(deck).size !== n) return { ok: false, problem: "The deck did not contain every card exactly once." };
    return { ok: true, deck };
  } catch (e) {
    return { ok: false, problem: "The keys did not check out." };
  }
}
