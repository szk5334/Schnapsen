/* MENTAL-POKER DECK — four passes and the deck is shuffled with nobody knowing its order.
 *
 *   1  seat 0 locks every card with key a, shuffles, sends        (seat 1 sees only ciphertext)
 *   2  seat 1 locks every card with key b, shuffles, sends        (now neither knows the order)
 *   3  seat 0 swaps its lock a for a separate key a[j] per position
 *   4  seat 1 swaps its lock b for a separate key b[j] per position  → the final deck
 *
 * Position j now opens only with BOTH a[j] and b[j]. To show a card to one player, the other sends their
 * key for that one position. To show it to everyone, both publish theirs. At the end of a deal both sides
 * publish every key, and audit() re-checks every pass. */
import { ENG } from "../../schnapsen/engine/core.js";
import { enc, dec, dec2, randKey, encodeCard, decoder, shuffleSecure, toHex, fromHex } from "./sra.js";

/* The canonical deck for a variant. Card ids are 1-based positions in this list, identical on every device. */
export function canonicalDeck(variant) {
  ENG.setVariant(variant);
  const out = [];
  for (const c of ENG.cards()) out.push({ id: out.length + 1, rank: c.rank, suit: c.suit });
  return out;
}

const H = list => list.map(toHex);
const B = list => list.map(fromHex);

export function pass1(n) {
  const a = randKey();
  const out = shuffleSecure(Array.from({ length: n }, (_, i) => enc(encodeCard(i), a)));
  return { secret: { a: toHex(a) }, out: H(out) };
}
export function pass2(list) {
  const b = randKey();
  return { secret: { b: toHex(b) }, out: H(shuffleSecure(B(list).map(c => enc(c, b)))) };
}
export function pass3(list, aHex) {
  const a = fromHex(aHex);
  const keys = list.map(() => randKey());
  return { secret: { ak: H(keys) }, out: H(B(list).map((c, j) => enc(dec(c, a), keys[j]))) };
}
export const pass4 = (list, bHex) => {
  const b = fromHex(bHex);
  const keys = list.map(() => randKey());
  return { secret: { bk: H(keys) }, out: H(B(list).map((c, j) => enc(dec(c, b), keys[j]))) };
};

/* Open one position with both keys. Returns the canonical index, or -1 if the keys don't fit. */
export function open(finalDeck, j, k1Hex, k2Hex, n) {
  const m = dec2(fromHex(finalDeck[j]), fromHex(k1Hex), fromHex(k2Hex));
  return decoder(n)(m);
}

/* Full check once every key is public: each pass did what it claimed, and the deck holds every card once.
 * Returns { ok, deck: [canonical index per position], problem }. */
export function audit({ l1, l2, l3, l4, a, b, ak, bk }, n) {
  try {
    const A = fromHex(a), Bk = fromHex(b);
    const want2 = new Set(B(l1).map(c => toHex(enc(c, Bk))));
    if (l2.length !== n || !l2.every(h => want2.has(h)) || want2.size !== n) return { ok: false, problem: "Pass 2 was not a shuffle of pass 1." };
    for (let j = 0; j < n; j++) {
      if (toHex(enc(dec(fromHex(l2[j]), A), fromHex(ak[j]))) !== l3[j]) return { ok: false, problem: `Pass 3 is wrong at position ${j + 1}.` };
      if (toHex(enc(dec(fromHex(l3[j]), Bk), fromHex(bk[j]))) !== l4[j]) return { ok: false, problem: `Pass 4 is wrong at position ${j + 1}.` };
    }
    const d = decoder(n);
    const deck = l4.map((h, j) => d(dec2(fromHex(h), fromHex(ak[j]), fromHex(bk[j]))));
    const seen = new Set(deck);
    if (deck.includes(-1) || seen.size !== n) return { ok: false, problem: "The deck did not contain every card exactly once." };
    return { ok: true, deck };
  } catch (e) {
    return { ok: false, problem: "The keys did not check out." };
  }
}
