/* A LOCKSTEP MATCH — two devices, no host, nobody able to peek.
 *
 * Both devices run the same engine on their own VIEW of the deal: their own hand face-up, everything they
 * have not been shown as card backs. Every back remembers its deck position, so when a card is shown —
 * played, declared, swapped, or drawn by you — the right back is turned over.
 *
 * Everything that happens is a MESSAGE in a per-deal log: the four shuffle passes, key gifts, moves, the
 * audit, and "next". Each device applies its own messages and the other's in sequence order, and the log is
 * saved after every step, so a reload simply replays it. Nothing in it goes to a server, and the opponent's
 * device receives only what the rules let them see.
 */
import { reducer, houseDeal } from "../house.js";
import { RULES, other } from "../../schnapsen/engine/rules.js";
import { ENG } from "../../schnapsen/engine/core.js";
import { canonicalDeck, pass1, pass2, pass3, pass4, open, audit, SCHEME } from "./deck.js";
import { LS, cell } from "../util.js";

const back = j => ({ id: -(j + 1), rank: "?", suit: "?", back: true, pos: j });
const vOf = config => ENG.normVariant(config.opts.variant);
const handSizeFor = v => { ENG.setVariant(v); return ENG.handSize(); };

/* What a fresh deal looks like before anyone has seen anything but the turn-up. Mirrors rules.newDeal
 * and reducer.freshDeal exactly — only the cards are backs. */
export function buildDeal(ctx, config, up, upPos, n) {
  const house = !!config.opts.house;
  const h = handSizeFor(vOf(config));
  const hands = { 0: [], 1: [] };
  for (let j = 0; j < h; j++) hands[0].push(back(j));
  for (let j = h; j < 2 * h; j++) hands[1].push(back(j));
  const stock = []; for (let j = upPos + 1; j < n; j++) stock.push(back(j));
  const dealer = ctx.dealer;
  return houseDeal({
    ...(house ? { house: true, piles: config.opts.piles === "down" ? "down" : "up" } : {}),
    mode: "play", n: 2,
    brains: ["human", "human"], names: config.seats.map(x => x.name),
    target: config.opts.target, strictClaim: !!config.opts.strict, variant: vOf(config),
    gp: ctx.gp.slice(), sheet: ctx.sheet.slice(), bummerlNo: ctx.bummerlNo, dealNo: ctx.dealNo,
    bummerlDone: false, bummerlWinner: null, roundEndedAt: null, banner: "",
    trump: up.suit, up, stock, hands,
    trick: [], turn: other(dealer), lead: other(dealer),
    closed: false, closedBy: null, closeSnap: null,
    meldSuit: null, meldedSuits: [[], []],
    trickPts: [0, 0], meldPts: [0, 0], tricksWon: [0, 0],
    lastTrick: null, dealer, phase: "play", result: null, reveals: [], log: [],
  });
}

/* Turn a back over wherever it is in a hand. */
export function reveal(s, pos, card) {
  const id = -(pos + 1);
  for (const seat of [0, 1]) {
    const i = (s.hands[seat] || []).findIndex(c => c.id === id);
    if (i >= 0) {
      const hands = { ...s.hands, [seat]: s.hands[seat].slice() };
      hands[seat][i] = card;
      return { ...s, hands };
    }
  }
  return s;
}

/* THE AUDIT, as a pure function of a finished deal's record: every shuffle pass checks out, and the deal
 * replayed face-up through the real engine accepts every move and ends the same way. */
export function auditDeal(rec) {
  const { config, ctx, seat } = rec;
  const canon = canonicalDeck(vOf(config));
  const N = canon.length, upPos = 2 * handSizeFor(vOf(config));
  const r = audit(rec, N);
  if (!r.ok) return { ok: false, problem: r.problem };
  let full = buildDeal(ctx, config, canon[r.deck[upPos]], upPos, N);
  for (let j = 0; j < N; j++) full = reveal(full, j, canon[r.deck[j]]);
  full.stock = full.stock.map(c => canon[r.deck[c.pos]]);
  ENG.setVariant(vOf(config));
  for (let i = 0; i < rec.moves.length; i++) {
    const a = rec.moves[i];
    let legal = true;
    if (a.type === "PLAY") legal = RULES.legalCards(full, a.seat).some(c => c.id === a.cardId);
    else if (a.type === "MELD") legal = RULES.meldOptions(full, a.seat).some(m => m.suit === a.suit);
    else if (a.type === "EXCHANGE") legal = RULES.canExchange(full, a.seat);
    else if (a.type === "CLOSE") legal = RULES.canClose(full, a.seat);
    else if (a.type === "CLAIM") legal = RULES.canClaim(full, a.seat);
    if (!legal) {
      const nm = a.seat === seat ? "You" : (config.seats[a.seat] || {}).name || "Your opponent";
      const what = a.type === "PLAY" ? "played a card the rules didn't allow with the hand they really held" : `made an impossible ${a.type.toLowerCase()}`;
      return { ok: false, problem: `${nm} ${what} (move ${i + 1}).`, seat: a.seat, move: i };
    }
    full = reducer(full, a);
  }
  const v = rec.result, f = full.result;
  if (!f || !v || f.winner !== v.winner || f.gp !== v.gp) return { ok: false, problem: "Replayed face-up, the deal ends differently from the game you played." };
  return { ok: true };
}

const firstCtx = () => ({ gp: [0, 0], sheet: [], bummerlNo: 1, dealNo: 1, dealer: 0 });

/* ------------------------------------------------------------------ the controller */
export function openMatch({ mesh, code, config, seat, peerCid }) {
  const KEY = "sx.match." + code;
  const N = canonicalDeck(vOf(config)).length;
  const canon = canonicalDeck(vOf(config));
  const h = handSizeFor(vOf(config));
  const upPos = 2 * h;
  const opp = other(seat);

  let p = LS.get(KEY);
  if (!p || p.config.matchId !== config.matchId) {
    p = { config, n: 1, ctx: firstCtx(), secrets: {}, log: [], mySeq: 0, peerSeq: 0, prevOwn: [] };
  }
  /* A deal saved by a build with the old (SRA) shuffle can't be opened by this one. Keep the score and deal
   * number, drop that deal's messages and deal it again; the other phone does the same when it updates. */
  const oldPass = m => /^p[1-4]$/.test(m.t) && m.x !== SCHEME;
  if (p.log.some(e => oldPass(e.msg))) { p.log = []; p.secrets = {}; p.mySeq = 0; p.peerSeq = 0; }
  if ((p.prevOwn || []).some(oldPass)) p.prevOwn = [];
  const future = [];                         // peer messages that arrived early
  const out = cell(null);
  let M = null;                               // runtime state, rebuilt from p.log

  const fresh = () => ({ l1: null, l2: null, l3: null, l4: null, theirKeys: {}, gifted: {}, s: null,
    moves: [], auditSent: false, theirSecrets: null, audit: null, posOf: {} });
  const myKey = j => (p.secrets.ak || p.secrets.bk || [])[j];
  const save = () => LS.set(KEY, p);
  const publish = () => out.set({ s: M.s, n: p.n, ctx: p.ctx, audit: M.audit, shuffling: !M.s, waitingCards: !!(M.s && M.s.hands[seat].some(c => c.back)), error: M.error || null });

  /* ---- opening cards ---- */
  function tryOpen() {
    if (!M.l4 || !myKey(0)) return;
    if (!M.s && M.theirKeys[upPos]) {
      const i = open(M.l4, upPos, myKey(upPos), M.theirKeys[upPos], N);
      if (i < 0) { M.error = "The turn-up did not decrypt. The deal can't continue."; return; }
      M.s = buildDeal(p.ctx, config, canon[i], upPos, N);
    }
    if (!M.s) return;
    for (const c of M.s.hands[seat]) {
      if (!c.back || !M.theirKeys[c.pos]) continue;
      const i = open(M.l4, c.pos, myKey(c.pos), M.theirKeys[c.pos], N);
      if (i < 0) { M.error = "A card dealt to you did not decrypt."; continue; }
      M.posOf[canon[i].id] = c.pos;
      M.s = reveal(M.s, c.pos, canon[i]);
    }
  }

  /* ---- applying one message (own or theirs) ---- */
  let lastProgress = Date.now();
  function apply(msg, mine) {
    lastProgress = Date.now();
    switch (msg.t) {
      case "p1": M.l1 = msg.list; break;
      case "p2": M.l2 = msg.list; break;
      case "p3": M.l3 = msg.list; break;
      case "p4": M.l4 = msg.list; break;
      case "k":
        for (const j of Object.keys(msg.keys)) { if (mine) M.gifted[j] = true; else M.theirKeys[j] = msg.keys[j]; }
        tryOpen(); break;
      case "mv": {
        if (!M.s) break;
        const a = msg.a;
        if (!mine) {
          for (const j of Object.keys(msg.reveal || {})) {
            M.theirKeys[j] = msg.reveal[j];
            const i = open(M.l4, +j, myKey(+j), msg.reveal[j], N);
            if (i < 0) { M.error = "A played card did not match its key."; return; }
            M.s = reveal(M.s, +j, canon[i]);
          }
        } else for (const j of Object.keys(msg.reveal || {})) M.gifted[j] = true;
        const before = M.s;
        ENG.setVariant(vOf(config));
        M.s = reducer(M.s, a);
        if (M.s === before) { M.error = `${mine ? "Your" : "Their"} move was refused by the rules.`; break; }
        M.moves.push(a);
        tryOpen();
        break;
      }
      case "audit":
        if (mine) M.auditSent = true; else M.theirSecrets = msg.sec;
        if (M.auditSent && M.theirSecrets) runAudit();
        break;
    }
  }

  function runAudit() {
    const mineS = p.secrets, theirs = M.theirSecrets;
    M.record = { ctx: p.ctx, config, seat, l1: M.l1, l2: M.l2, l3: M.l3, l4: M.l4,
      a: seat === 0 ? mineS.a : theirs.a, b: seat === 1 ? mineS.b : theirs.b,
      ak: seat === 0 ? mineS.ak : theirs.ak, bk: seat === 1 ? mineS.bk : theirs.bk,
      moves: M.moves.slice(), result: M.s && M.s.result };
    M.audit = auditDeal(M.record);
  }

  /* ---- what this device should send next ---- */
  let busy = false;
  function effects() {
    if (busy || M.error) return;
    busy = true;
    setTimeout(() => {
      busy = false;
      try {
        if (seat === 0 && !M.l1) { const r = pass1(N); p.secrets.a = r.secret.a; send({ t: "p1", list: r.out, x: SCHEME }); }
        else if (seat === 1 && M.l1 && !M.l2) { const r = pass2(M.l1); p.secrets.b = r.secret.b; send({ t: "p2", list: r.out, x: SCHEME }); }
        else if (seat === 0 && M.l2 && !M.l3) { const r = pass3(M.l2, p.secrets.a); p.secrets.ak = r.secret.ak; send({ t: "p3", list: r.out, x: SCHEME }); }
        else if (seat === 1 && M.l3 && !M.l4) { const r = pass4(M.l3, p.secrets.b); p.secrets.bk = r.secret.bk; send({ t: "p4", list: r.out, x: SCHEME }); }
        else if (M.l4) {
          /* Give the other player the key to every card they hold and can't yet see — and to the turn-up. */
          const want = (M.s ? M.s.hands[opp].filter(c => c.back).map(c => c.pos) : [...Array(h).keys()].map(i => i + (opp === 0 ? 0 : h))).concat([upPos]);
          const keys = {};
          for (const j of want) if (!M.gifted[j]) keys[j] = myKey(j);
          if (Object.keys(keys).length) send({ t: "k", keys });
          else if (M.s && M.s.phase === "scored" && !M.auditSent) send({ t: "audit", sec: p.secrets });
        }
      } catch (e) { M.error = "Something went wrong preparing the deal: " + e.message; publish(); }
    }, 0);
  }

  /* ---- the log ---- */
  /* On the wire every message also says how far we've got with theirs ("ak": deal, count applied), so a
   * re-send can carry exactly what the other side is missing. It is not part of the logged message. */
  const wire = (m, extra) => ({ ...m, ak: [p.n, p.peerSeq], ...(extra || {}) });
  let theirAck = null;                          // { n, s }: how many of ours they've applied, in which deal
  function send(body) {
    const msg = { ...body, n: p.n, s: p.mySeq++, from: seat };
    p.log.push({ mine: true, msg });
    apply(msg, true); save(); publish();
    const peer = mesh.peerOf(peerCid);
    if (peer) mesh.send("mx", wire(msg), peer);
    if (msg.t === "next") transition();
    else effects();
  }
  let lastEcho = 0;
  function receive(raw) {
    if (!raw || typeof raw.n !== "number" || raw.from !== opp) return;
    const { re, ak, ...msg } = raw;
    if (Array.isArray(ak) && typeof ak[0] === "number" && typeof ak[1] === "number" &&
        (!theirAck || ak[0] > theirAck.n || (ak[0] === theirAck.n && ak[1] > theirAck.s))) theirAck = { n: ak[0], s: ak[1] };
    /* A copy of something we already have means they are re-sending because they're stuck — most likely
     * waiting on something of ours that got lost. Send ours again (at most every ten seconds). */
    if (!re && (msg.n < p.n || (msg.n === p.n && msg.s < p.peerSeq)) && Date.now() - lastEcho > 10000) {
      lastEcho = Date.now();
      const peer = mesh.peerOf(peerCid);
      if (peer) setTimeout(() => resend(peer, { echo: true, prio: "low" }), 300);
    }
    if (msg.n < p.n) return;
    if (msg.n > p.n || msg.s > p.peerSeq) { if (!future.some(m => m.n === msg.n && m.s === msg.s)) future.push(msg); return; }
    if (msg.s < p.peerSeq) return;                                   // already have it
    if (/^p[1-4]$/.test(msg.t) && msg.x !== SCHEME) {                 // their phone is still on the old shuffle
      M.error = "Your opponent is on an older version of the game. Both of you reload the page.";
      publish(); return;                                             // not applied, not counted: it can come again
    }
    p.peerSeq++;
    p.log.push({ mine: false, msg });
    if (msg.t === "next") { save(); transition(); return; }
    apply(msg, false); save(); publish();
    drain(); effects();
  }
  function drain() {
    for (;;) {
      const i = future.findIndex(m => m.n === p.n && m.s === p.peerSeq);
      if (i < 0) break;
      receive(future.splice(i, 1)[0]);
    }
  }

  function transition() {
    const s = M.s;
    if (!s || s.phase !== "scored") return;
    const done = s.bummerlDone;
    p.ctx = done
      ? { gp: [0, 0], sheet: [], bummerlNo: (s.bummerlNo || 1) + 1, dealNo: 1, dealer: other(s.dealer) }
      : { gp: s.gp.slice(), sheet: (s.sheet || []).slice(), bummerlNo: s.bummerlNo, dealNo: (s.dealNo || 1) + 1, dealer: other(s.dealer) };
    p.prevOwn = p.log.filter(e => e.mine).map(e => e.msg);
    p.n += 1; p.secrets = {}; p.log = []; p.mySeq = 0; p.peerSeq = 0;
    M = fresh(); save(); publish();
    drain(); effects();
  }

  /* ---- rebuild from the saved log ---- */
  M = fresh();
  for (const e of p.log) { if (e.msg.t !== "next") apply(e.msg, e.mine); }
  if (p.log.some(e => e.msg.t === "next")) transition();         // saved just as a new deal began
  publish();

  /* ---- the safety net ----
   * If we've been waiting on the other device for a while with nothing arriving, re-send everything of ours
   * from this deal (they ignore what they already have). Whatever got lost on the way, this un-sticks it. */
  /* Send again what they don't have yet: everything, if we don't know how far they got. */
  const resend = (peerId, { echo = false, prio } = {}) => {
    const a = theirAck;
    if (a && a.n > p.n) return 0;                                    // they're ahead of us: nothing to give
    const prev = !a ? p.prevOwn : a.n === p.n - 1 ? p.prevOwn.filter(m => m.s >= a.s) : a.n < p.n - 1 ? p.prevOwn : [];
    const cur = p.log.filter(e => e.mine && (!a || a.n < p.n || e.msg.s >= a.s)).map(e => e.msg);
    for (const m of prev.concat(cur)) mesh.send("mx", wire(m, echo ? { re: 1 } : null), peerId, prio);
    return prev.length + cur.length;
  };
  const waitingOnThem = () => {
    if (M.error) return false;
    if (!M.s) return true;                                            // still shuffling
    if (M.s.hands[seat].some(c => c.back)) return true;              // waiting for my cards' keys
    if (M.s.phase === "play") return M.s.turn === opp || M.s.hands[opp].length === 0;
    return !M.audit;                                                  // deal over, their keys not in yet
  };
  /* 30 s, and never while our own messages are still queued for relay budget (they are on their way; a re-send
   * would only queue behind them). At 15 s it fired during ordinary budget waits and re-sent whole deals. */
  let netWait = 30000, lastNet = 0, seenProgress = lastProgress;
  const net = setInterval(() => {
    if (lastProgress !== seenProgress) { seenProgress = lastProgress; netWait = 30000; }
    if (mesh.backlog && mesh.backlog() > 0) return;
    if (Date.now() - Math.max(lastProgress, lastNet) < netWait || !waitingOnThem()) return;
    const peer = mesh.peerOf(peerCid);
    if (!peer) return;
    lastNet = Date.now();
    resend(peer, { prio: "low" });
    netWait = Math.min(60000, netWait * 2);                          // and less often while it stays stuck
  }, 3000);

  /* ---- wiring ---- */
  const offs = [
    mesh.on("mx", (d, from) => { if (from.cid === peerCid) receive(d); }),
    /* When the other device (re)appears, hand it everything it might have missed; it de-duplicates. */
    mesh.onJoin((peerId, pr) => {
      if (pr.cid !== peerCid) return;
      resend(peerId);
    }),
  ];
  const peer0 = mesh.peerOf(peerCid);
  if (peer0) resend(peer0);
  effects();

  return {
    state: out,
    seat,
    /* My move. Revealed cards carry my key for their position. */
    act(a) {
      if (!M.s || M.error) return;
      if (a.type === "NEXT_DEAL" || a.type === "NEW_BUMMERL") {
        if (M.s.phase === "scored" && M.audit) send({ t: "next" });
        return;
      }
      if (a.seat !== seat || M.s.turn !== seat) return;
      const s = M.s, reveal = {};
      const keyOf = id => { const j = M.posOf[id]; return j == null ? null : j; };
      const tag = id => { const j = keyOf(id); if (j != null) reveal[j] = myKey(j); };
      if (a.type === "PLAY") {
        if (a.cardId < 0 || !RULES.legalCards(s, seat).some(c => c.id === a.cardId)) return;
        tag(a.cardId);
      } else if (a.type === "MELD") {
        if (!RULES.meldOptions(s, seat).some(m => m.suit === a.suit)) return;
        s.hands[seat].filter(c => c.suit === a.suit && (c.rank === "K" || c.rank === "Q")).forEach(c => tag(c.id));
      } else if (a.type === "EXCHANGE") {
        if (!RULES.canExchange(s, seat)) return;
        const j = s.hands[seat].find(c => c.suit === s.trump && c.rank === ENG.exchangeRank());
        if (j) tag(j.id);
      }
      send({ t: "mv", a, reveal });
    },
    pending: () => M.s && M.s.hands[seat].some(c => c.back),
    forget() { LS.del(KEY); },
    _record: () => M.record,
    _debug: () => ({ n: p.n, mySeq: p.mySeq, peerSeq: p.peerSeq, log: p.log.map(e => (e.mine ? ">" : "<") + e.msg.t + e.msg.s), future: future.map(m => m.t + m.n + "." + m.s), l: [!!M.l1, !!M.l2, !!M.l3, !!M.l4], their: Object.keys(M.theirKeys), gifted: Object.keys(M.gifted), err: M.error }),
    close() { clearInterval(net); offs.forEach(f => f()); },
  };
}
