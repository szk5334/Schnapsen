/* THE REVIEW. After a deal, every choice either player made is judged against the alternatives they had,
 * from WHAT THAT PLAYER COULD SEE AT THE TIME: the hidden cards are dealt many plausible ways (the bot's own
 * sampler, which reads public facts only), each choice is played out in every one of those worlds, and the
 * choices are compared on the game points they average. Nobody is blamed for a card they couldn't know about.
 *
 *   open stock    the rest of the open play is the bot's (fritzl, no closing), then the endgame is solved exactly
 *   strict play   solved exactly in each world; once the stock is gone there is only one world, so it's certain
 *
 * The same seed on both phones (it comes from the deal itself), so both players read the same review.
 * Pure: no DOM, no storage. `reviewSteps` is a generator so the page can run it a slice at a time. */
import { ENG } from "../schnapsen/engine/core.js";
import { RULES, isStrict, stockLeft, other, effPts } from "../schnapsen/engine/rules.js";
import { decide, sampleDeal } from "../schnapsen/engine/bot.js";

/* 66 / 33, or Royal House's 200 / 100: set from the pack when a review starts (reviewSteps). */
let OUT = RULES.OUT, HALF = RULES.HALF;

/* ---------------- seeded randomness ---------------- */
export function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export function seedOf(str) {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 0x01000193); }
  return h >>> 0;
}

const clone = w => ({
  ...w,
  hands: { 0: w.hands[0].slice(), 1: w.hands[1].slice() },
  stock: w.stock.slice(), trick: w.trick.slice(),
  trickPts: w.trickPts.slice(), meldPts: w.meldPts.slice(), tricksWon: w.tricksWon.slice(),
  meldedSuits: [w.meldedSuits[0].slice(), w.meldedSuits[1].slice()],
  closeSnap: w.closeSnap ? { ...w.closeSnap } : null,
  reveals: (w.reveals || []).slice(), log: (w.log || []).slice(),
});

/* What a finished deal is worth to `me`. House rules: no 66, no score. */
function terminal(d, me, house) {
  const r = d.result;
  if (!r) return 0;
  if (house && r.reason === "exhausted") return 0;
  return r.winner === me ? r.gp : -r.gp;
}

/* ---------------- the exact endgame ----------------
 * The engine's solver, minus two things: its alpha-beta stores window-limited values in a memo that ignores
 * the window, and it scores an exhausted deal as "last trick wins" under every rule set. A review has to be
 * right rather than fast, so this is plain minimax with a memo (at most ten cards: a few thousand positions),
 * and house rules score an exhausted deal at 0. Same moves, same melds-on-the-lead, same payouts. */
const eff = (n, p) => n.tp[p] + (n.tw[p] > 0 ? n.mp[p] : 0);
function nodeOf(d) {
  return {
    h: [d.hands[0].slice(), d.hands[1].slice()], trump: d.trump, turn: d.turn,
    led: d.trick.length ? d.trick[0].card : null, ledSeat: d.trick.length ? d.trick[0].seat : null,
    tp: d.trickPts.slice(), mp: d.meldPts.slice(), tw: d.tricksWon.slice(),
    ms: [d.meldedSuits[0].slice(), d.meldedSuits[1].slice()], meldSuit: d.meldSuit,
    closed: d.closed, closedBy: d.closedBy, closeSnap: d.closeSnap, lastWinner: d.lastTrick ? d.lastTrick.winner : null,
    marriages: ENG.marriagesOf(d), cube: d.cube || 1,
  };
}
function gpWin(n, winner) {
  const loser = other(winner), k = n.cube || 1;
  if (n.closed && n.closedBy === winner) {
    const s = n.closeSnap || { pts: eff(n, loser), tricks: n.tw[loser] };
    return k * (s.tricks === 0 ? 3 : s.pts < HALF ? 2 : 1);
  }
  if (n.closed && n.closedBy === loser) {
    const s = n.closeSnap || { pts: 0, tricks: n.tw[winner] };
    return k * (s.tricks === 0 ? 3 : 2);
  }
  return k * (n.tw[loser] === 0 ? 3 : eff(n, loser) < HALF ? 2 : 1);
}
function outOfCards(n, me, house) {
  if (n.closed) {
    const c = n.closedBy, w = eff(n, c) >= OUT ? c : other(c), gp = gpWin(n, w);
    return w === me ? gp : -gp;
  }
  if (house) return 0;
  const w = n.lastWinner != null ? n.lastWinner : n.turn;
  return w === me ? (n.cube || 1) : -(n.cube || 1);
}
function stepN(n, card, me, house) {
  const p = n.turn;
  const c = { ...n, h: [n.h[0].slice(), n.h[1].slice()], tp: n.tp.slice(), mp: n.mp.slice(), tw: n.tw.slice(), ms: [n.ms[0].slice(), n.ms[1].slice()] };
  c.h[p] = c.h[p].filter(x => x.id !== card.id);
  if (c.led === null) {
    const mk = ENG.meldKeyOf(card);
    if (mk && c.ms[p].indexOf(mk) === -1 && c.h[p].some(x => x.suit === card.suit && x.rank === ENG.partnerRank(card))) {
      c.mp[p] += ENG.meldValue(mk, c.trump, { house, marriages: c.marriages });
      c.ms[p] = c.ms[p].concat([mk]);
      if (eff(c, p) >= OUT) { const g = gpWin(c, p); return { done: true, v: p === me ? g : -g }; }
    }
    c.led = card; c.ledSeat = p; c.meldSuit = null; c.turn = other(p);
    return { done: false, n: c };
  }
  const w = ENG.trickWinner(c.led, card, c.trump, c.ledSeat, p);
  c.tp[w] += ENG.val(c.led) + ENG.val(card);
  c.tw[w] += 1; c.lastWinner = w; c.led = null; c.ledSeat = null; c.turn = w;
  if (eff(c, w) >= OUT) { const g = gpWin(c, w); return { done: true, v: w === me ? g : -g }; }
  if (!c.h[0].length && !c.h[1].length) return { done: true, v: outOfCards(c, me, house) };
  return { done: false, n: c };
}
const ids = a => a.map(c => c.id).join(",");
function minimax(n, me, house, memo) {
  const k = ids(n.h[0]) + "|" + ids(n.h[1]) + "|" + n.turn + "|" + (n.led ? n.led.id : 0) + "|" + n.tp + "|" + n.mp + "|" + n.tw + "|" + (n.meldSuit || "-") + "|" + n.ms[0].join("") + "," + n.ms[1].join("");
  const hit = memo.get(k); if (hit !== undefined) return hit;
  const p = n.turn;
  const mv = n.led === null ? ENG.legalLeads(n.h[p], n.meldSuit) : ENG.legalFollows(n.h[p], n.led, n.trump, true);
  const maxing = p === me;
  let best = maxing ? -Infinity : Infinity;
  for (const card of mv) {
    const r = stepN(n, card, me, house);
    const v = r.done ? r.v : minimax(r.n, me, house, memo);
    if (maxing ? v > best : v < best) best = v;
  }
  memo.set(k, best);
  return best;
}
/* The exact value of a strict position for `me` (whoever is to move). */
export function exactValue(d, me, house) {
  OUT = RULES.OUT; HALF = RULES.HALF;
  if (d.phase === "scored") return terminal(d, me, house);
  if (!d.hands[0].length && !d.hands[1].length) return 0;
  return minimax(nodeOf(d), me, house, new Map());
}

/* ---------------- playing a world out ---------------- */
const ROLLOUT = { samples: 0, solve: false, noise: 0, close: false };
function apply(w, a, real) {
  const o = real ? { strictClaim: !!w.strictClaim } : {};       // the real deal is replayed under its own claiming rule
  if (a.type === "PLAY") RULES.play(w, a.seat, a.cardId, o);
  else if (a.type === "MELD") { RULES.meld(w, a.seat, a.suit, o); if (a.then != null && w.phase === "play") RULES.play(w, a.seat, a.then, o); }
  else if (a.type === "EXCHANGE") RULES.exchange(w, a.seat);
  else if (a.type === "CLOSE") RULES.close(w, a.seat);
  else if (a.type === "CLAIM") RULES.claim(w, a.seat);
  else if (a.type === "DOUBLE") RULES.double(w, a.seat);
  else if (a.type === "TAKE") RULES.take(w, a.seat);
  else if (a.type === "DROP") RULES.drop(w, a.seat);
  return w;
}
/* A CLOSED endgame still has hidden cards, so solving it exactly in a sampled world would let each player see the
 * other's hand: closing would look better than it is. There each player chooses the way the bot does, by solving
 * several worlds THEY could believe in. Only an exhausted stock (nothing hidden any more) is solved outright. */
const CLOSED = { samples: 6, solve: true, noise: 0, close: false };
function playOut(w, me, house, rnd) {
  for (let g = 0; g < 80; g++) {
    if (w.phase !== "play") return terminal(w, me, house);
    if (isStrict(w) && !w.closed) return exactValue(w, me, house);
    const dec = decide(w, w.turn, { brain: TUNE.brain, skill: w.closed ? CLOSED : ROLLOUT, style: TUNE.style, rnd });
    if (!dec) break;
    apply(w, dec.action);
  }
  return terminal(w, me, house);
}

/* ---------------- one decision ---------------- */
/* Every choice the player had here. A marriage is its own choice (the lead that follows is the next decision). */
export function choices(d, p) {
  if (d.phase !== "play" || d.turn !== p) return [];
  const out = [];
  if (d.trick.length === 0 && !d.meldSuit) {
    /* A marriage and the card led with it are one choice: declare, then lead the 4 or the 3. */
    for (const m of RULES.meldOptions(d, p))
      for (const c of d.hands[p]) if (ENG.isMeldCard(c, m.suit))
        out.push({ type: "MELD", seat: p, suit: m.suit, then: c.id });
    if (RULES.canExchange(d, p)) out.push({ type: "EXCHANGE", seat: p });
    if (RULES.canClose(d, p)) out.push({ type: "CLOSE", seat: p });
  }
  for (const c of RULES.legalCards(d, p)) out.push({ type: "PLAY", seat: p, cardId: c.id });
  return out;
}
export const sameChoice = (a, b) => a.type === b.type && a.seat === b.seat && (a.type !== "PLAY" || a.cardId === b.cardId)
  && (a.type !== "MELD" || (a.suit === b.suit && a.then === b.then));

/* Average value of each choice over `n` worlds the mover could believe in. Common random numbers: in each
 * world every choice is played out with the same random stream, so the comparison isn't drowned in luck. */
function* evaluate(d, p, opts, house, n, seed) {
  const certain = isStrict(d) && !d.closed && stockLeft(d) === 0;
  const worlds = certain ? 1 : n;
  const R = rng(seed);
  const sum = opts.map(() => 0), wins = opts.map(() => 0);
  const sim = opts.map(() => newSim());
  const L0 = (d.log || []).length;
  for (let i = 0; i < worlds; i++) {
    const w = sampleDeal(d, p, R);
    const ws = (R() * 4294967296) >>> 0;
    for (let k = 0; k < opts.length; k++) {
      const wk = apply(clone(w), opts[k]);
      const v = playOut(wk, p, house, rng(ws));
      sum[k] += v; if (v > 0) wins[k]++;
      note(sim[k], wk, L0, d, p, v);
    }
    yield;
  }
  return { values: sum.map(s => s / worlds), wins: wins.map(x => x / worlds), sim, worlds, certain };
}

/* ---------------- what happened in those worlds ----------------
 * Not just how each choice scored, but what it led to: who took the next trick, which of the player's aces and tens
 * ended up in the other's tricks, whose marriages got shown, how many trumps each side had when the stock ran out or
 * was closed. The review explains a choice with these, not with numbers. */
const newSim = () => ({ n: 0, win: 0, big: 0, bigLoss: 0, next: 0, nextWon: 0, nextPts: 0, lost: {}, mine: {}, opp: 0, tr: 0, trMe: 0, trOpp: 0 });
function note(S, w, L0, d, p, v) {
  const o = other(p);
  S.n++; if (v > 0) S.win++; if (v >= 2) S.big++; if (v <= -2) S.bigLoss++;
  const tricks = (w.log || []).slice(L0).filter(e => e.k === "trick");
  if (tricks.length) { S.next++; if (tricks[0].winner === p) S.nextWon++; S.nextPts += tricks[0].pts; }
  for (const e of tricks) {
    if (e.winner === p) continue;
    const mine = e.lead === p ? e.led : e.fol;
    if (mine.rank === "A" || mine.rank === "10") S.lost[mine.id] = (S.lost[mine.id] || 0) + 1;
  }
  for (const su of w.meldedSuits[p]) if (d.meldedSuits[p].indexOf(su) === -1) S.mine[su] = (S.mine[su] || 0) + 1;
  S.opp += w.meldPts[o] - d.meldPts[o];
  if (w.phase === "play" && w.trump) {
    S.tr++;
    S.trMe += w.hands[p].filter(c => c.suit === w.trump).length;
    S.trOpp += w.hands[o].filter(c => c.suit === w.trump).length;
  }
}

/* What a choice IS, read off the table as the player saw it: takes the trick or gives it, throws an ace away,
 * breaks a marriage, leads a ten into an ace still out, closes with the other on so many points... */
function unseenAce(d, p, suit) {
  if (d.hands[p].some(c => c.suit === suit && c.rank === "A")) return false;
  if (d.up && d.up.suit === suit && d.up.rank === "A") return false;
  for (const e of d.log || []) if (e.k === "trick" && [e.led, e.fol].some(c => c.suit === suit && c.rank === "A")) return false;
  if (d.trick.length && d.trick[0].card.suit === suit && d.trick[0].card.rank === "A") return false;
  return true;
}
function facts(d, p, o) {
  const f = [], o2 = other(p), hand = d.hands[p], T = d.trump;
  /* half of a marriage still held and not yet declared (its key, or null) */
  const partner = c => { const k = ENG.meldKeyOf(c); return k && d.meldedSuits[p].indexOf(k) === -1 && hand.some(x => x.suit === c.suit && x.rank === ENG.partnerRank(c)) ? k : null; };
  if (o.type === "CLOSE") {
    f.push({ k: "close", them: effPts(d, o2), me: effPts(d, p), trumps: T ? hand.filter(c => c.suit === T).length : 0, shut: d.tricksWon[o2] === 0 });
    return f;
  }
  if (o.type === "EXCHANGE") { f.push({ k: "swap", up: d.up }); return f; }
  if (o.type === "MELD") { f.push({ k: "declare", value: ENG.meldValue(o.suit, T, d), suit: o.suit, counts: d.tricksWon[p] > 0 }); return f; }
  const c = hand.find(x => x.id === o.cardId);
  if (d.trick.length) {
    const L = d.trick[0].card, pts = ENG.val(L) + ENG.val(c);
    const winners = RULES.legalCards(d, p).filter(x => ENG.follows(L, x, T));
    if (ENG.follows(L, c, T)) {
      f.push({ k: c.suit === T && L.suit !== T ? "trump" : "take", pts, led: L });
      const plain = winners.filter(x => x.suit !== T && !partner(x)).sort((a, b) => ENG.val(a) - ENG.val(b))[0];
      const cheaper = winners.filter(x => x.id !== c.id && ENG.val(x) < ENG.val(c) && !partner(x)).sort((a, b) => ENG.val(a) - ENG.val(b))[0];
      if (c.suit === T && L.suit !== T && plain) f.push({ k: "wasteTrump", alt: plain, top: c.rank === "A" || c.rank === "10" });
      else if (cheaper && ENG.val(c) - ENG.val(cheaper) >= 7) f.push({ k: "dear", cheaper });
    } else {
      f.push({ k: "give", pts, led: L, could: winners.length > 0 });
      if (ENG.val(c) >= 10) f.push({ k: "throw", card: c });
    }
  } else {
    if (c.suit === T) f.push({ k: "leadTrump" });
    else if (c.rank === "A") f.push({ k: "leadAce" });
    else if (c.rank === "10" && unseenAce(d, p, c.suit)) f.push({ k: "bareTen" });
    else if (ENG.val(c) <= 4) f.push({ k: "cheapLead" });
    const pk = partner(c);
    if (pk && RULES.meldOptions(d, p).some(m => m.suit === pk)) f.push({ k: "noDeclare", value: ENG.meldValue(pk, T, d) });
  }
  const pk = partner(c);
  if (pk && !(d.trick.length === 0 && RULES.meldOptions(d, p).some(m => m.suit === pk))) f.push({ k: "breaks", value: ENG.meldValue(pk, T, d) });
  return f;
}

/* How the two choices played out differently, strongest differences first (at most three). */
function contrast(d, p, B, C) {
  const out = [], o = other(p);
  const pr = (S, x) => (S.n ? x / S.n : 0);
  if (B.next >= B.n * 0.6 && C.next >= C.n * 0.6) {
    const pb = B.nextWon / B.next, pc = C.nextWon / C.next;
    if (pb - pc >= 0.3) out.push({ k: "lead", w: pb - pc, pb, pc });
  }
  let worst = null;
  for (const id of new Set([...Object.keys(B.lost), ...Object.keys(C.lost)])) {
    const x = pr(C, C.lost[id] || 0) - pr(B, B.lost[id] || 0);
    if (x >= 0.25 && (!worst || x > worst.w)) worst = { k: "exposed", w: x, card: d.hands[p].find(c => String(c.id) === id), pc: pr(C, C.lost[id] || 0), pb: pr(B, B.lost[id] || 0) };
  }
  if (worst && worst.card) out.push(worst);
  for (const su of new Set([...Object.keys(B.mine), ...Object.keys(C.mine)])) {
    const x = pr(B, B.mine[su] || 0) - pr(C, C.mine[su] || 0);
    if (x >= 0.25) out.push({ k: "marriage", w: x, suit: su, value: ENG.meldValue(su, d.trump, d), pb: pr(B, B.mine[su] || 0), pc: pr(C, C.mine[su] || 0) });
  }
  const om = pr(C, C.opp) - pr(B, B.opp);
  if (om >= 8) out.push({ k: "oppMarriage", w: om / 20 });
  if (B.tr && C.tr) {
    const dm = B.trMe / B.tr - C.trMe / C.tr, dop = C.trOpp / C.tr - B.trOpp / B.tr;
    if (dm >= 0.6) out.push({ k: "trumps", w: dm / 2, more: dm });
    else if (dop >= 0.6) out.push({ k: "oppTrumps", w: dop / 2 });
  }
  return out.sort((a, b) => b.w - a.w).slice(0, 3);
}

/* With every card known: both sides' best play from here, trick by trick, and how the deal ends. */
function line(w0, p, o, house) {
  const w = apply(clone(w0), o);
  const L0 = (w0.log || []).length;
  for (let g = 0; g < 24 && w.phase === "play"; g++) {
    const q = w.turn;
    const opts = choices(w, q).filter(x => x.type !== "CLOSE");
    let best = null, bv = -Infinity;
    for (const x of opts) { const v = exactValue(apply(clone(w), x), q, house); if (v > bv) { bv = v; best = x; } }
    if (!best) break;
    apply(w, best);
  }
  const tricks = (w.log || []).slice(L0).filter(e => e.k === "trick").map(e => ({ winner: e.winner, led: e.led, fol: e.fol, lead: e.lead }));
  const melds = (w.log || []).slice(L0).filter(e => e.k === "meld").map(e => ({ seat: e.seat, value: e.value }));
  const r = w.result;
  return { tricks, melds, end: r ? { winner: r.winner, reason: r.reason, pts: r.pts, scoreless: house && r.reason === "exhausted", gp: r.gp } : null };
}

/* ---------------- the whole deal ----------------
 * d0: the deal face up as dealt (real hands, real stock order). moves: every action, in order.
 * Yields { done, total } as it goes; returns the review. */
/* MEASURED, Oct 30 2026 (16 fixed deals, greta vs poldi, house rules; review run twice with different seeds):
 *   fritzl rollouts, bar 0.3, 40 worlds on a second look: greta flagged 9, poldi 21, 77% of points stable across seeds
 *   fritzl, 0.5, 80: 6 vs 15, 71%       greta rollouts, 0.5, 80: 4 vs 10, 79%       greta, 0.4, 60: 7 vs 15, 68%
 * Greta plays the rest of each world out (the strongest bot here: the playout is what the choices are judged by), a choice
 * must cost 0.4 game points to be shown, and anything that looks costly gets a second look over 60 worlds. Both phones use
 * the same seed, so a point near the bar is shown on both or neither. */
export const TUNE = { FLAG: 0.4, FIRST: 10, SECOND: 60, ROYAL_FIRST: 6, ROYAL_SECOND: 24, brain: "greta", style: undefined };
export function* reviewSteps(d0, moves, { house = false, variant = "classic", seed = 1 } = {}) {
  ENG.setVariant(variant || "classic");
  OUT = RULES.OUT; HALF = RULES.HALF;
  /* Royal House deals run 16 tricks: fewer worlds per choice, so the review still finishes on a phone. */
  const first = ENG.isRoyal() ? TUNE.ROYAL_FIRST : TUNE.FIRST, second = ENG.isRoyal() ? TUNE.ROYAL_SECOND : TUNE.SECOND;
  let d = clone(d0);
  const points = [];
  let ti = 1;
  for (let i = 0; i < moves.length; i++) {
    let a = moves[i];
    const p = a.seat;
    /* A declaration is judged together with the lead that follows it (that lead is not a choice of its own). */
    const nx = moves[i + 1];
    const asked = a.type === "MELD" && nx && nx.type === "PLAY" && nx.seat === p ? { ...a, then: nx.cardId } : a;
    const opts = a.type === "CLAIM" || d.meldSuit ? [] : choices(d, p);
    if (opts.length > 1) {
      const chosen = opts.findIndex(o => sameChoice(o, asked));
      if (chosen >= 0) points.push({ i, seat: p, trick: ti, d: clone(d), opts, chosen });
    }
    if (a.type === "PLAY" && d.trick.length === 1) ti++;
    apply(d, a, true);
  }
  const total = points.length;
  let done = 0;
  for (const pt of points) {
    const r = yield* evaluate(pt.d, pt.seat, pt.opts, house, first, seed ^ seedOf("pt" + pt.i));
    pt.r = r; done++;
    yield { done, total };
  }
  /* A second, closer look at anything that looked costly, so noise doesn't make the list. */
  for (const pt of points) {
    if (pt.r.certain) continue;
    const best = Math.max(...pt.r.values);
    if (best - pt.r.values[pt.chosen] < TUNE.FLAG * 0.6) continue;
    pt.r = yield* evaluate(pt.d, pt.seat, pt.opts, house, second, seed ^ seedOf("again" + pt.i));
  }
  const found = [];
  for (const pt of points) {
    const v = pt.r.values;
    let b = 0; for (let k = 1; k < v.length; k++) if (v[k] > v[b] + 1e-9) b = k;
    const loss = v[b] - v[pt.chosen];
    if (loss < TUNE.FLAG - 1e-9) continue;
    found.push(describe(pt, b, loss, house));
  }
  const top = found.slice().sort((x, y) => y.loss - x.loss).slice(0, 5).sort((x, y) => x.i - y.i);
  const cost = [0, 1].map(s => found.filter(f => f.seat === s));
  return {
    points: top,
    bySeat: cost.map(list => ({ count: list.length, loss: list.reduce((a, f) => a + f.loss, 0) })),
    decisions: total,
  };
}

/* The data the page needs to say it in words: no strings here, so the page can use its own names and rank labels. */
function describe(pt, b, loss, house) {
  const d = pt.d, p = pt.seat, r = pt.r;
  const card = id => d.hands[p].find(c => c.id === id);
  const opt = k => {
    const o = pt.opts[k], S = r.sim[k];
    return { type: o.type, card: o.type === "PLAY" || o.type === "MELD" ? card(o.type === "MELD" ? o.then : o.cardId) : null, suit: o.suit || null,
      meld: o.type === "MELD" ? ENG.meldValue(o.suit, d.trump, d) : 0, facts: facts(d, p, o), value: r.values[k],
      win: S.n ? S.win / S.n : 0, big: S.n ? S.big / S.n : 0, bigLoss: S.n ? S.bigLoss / S.n : 0,
      line: r.certain ? line(sampleDeal(d, p, rng(1)), p, o, house) : null };
  };
  return {
    i: pt.i, seat: p, trick: pt.trick, loss,
    lead: d.trick.length === 0, led: d.trick.length ? d.trick[0].card : null,
    hand: d.hands[p].slice(), trump: d.trump, up: d.up, strict: isStrict(d), closed: d.closed,
    certain: r.certain, worlds: r.worlds, stock: stockLeft(d),
    me: effPts(d, p), them: effPts(d, other(p)),
    chosen: opt(pt.chosen), best: opt(b), why: contrast(d, p, r.sim[b], r.sim[pt.chosen]),
  };
}

/* Run it to the end in one go (tests, and Node). */
export function review(d0, moves, opts) {
  const it = reviewSteps(d0, moves, opts);
  for (;;) { const r = it.next(); if (r.done) return r.value; }
}
