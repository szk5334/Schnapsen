#!/bin/sh
# Every non-network gate, as many at once as there are cores, longest first. Relay, zombie and house-relay tests
# are not here: they exercise app/net only (run them when the transport changes).
cd "$(dirname "$0")/.." || exit 1
T=$(mktemp -d)
cat > "$T/jobs" <<J
tests|node mp.test.mjs
tests|node house.test.mjs
tests|node house.test.mjs 24
tests|node house.test.mjs 22
tests|node cheat.test.mjs
tests|node review.test.mjs 12
tests|node ec.test.mjs
tests|node dup.test.mjs
schnapsen/tests|node solver.test.mjs
schnapsen/tests|node variant22.mjs
schnapsen/tests|node variant24.mjs
schnapsen/tests|node rules.test.mjs
schnapsen/tests|node guest.test.mjs
J
S=$(date +%s)
i=0
while IFS='|' read -r dir cmd; do i=$((i+1)); echo "$i|$dir|$cmd"; done < "$T/jobs" |
  xargs -P "$(nproc)" -I{} sh -c 'n=$(echo "{}" | cut -d"|" -f1); d=$(echo "{}" | cut -d"|" -f2); c=$(echo "{}" | cut -d"|" -f3); (cd "$d" && $c > "'"$T"'/$n.log" 2>&1; echo $? > "'"$T"'/$n.rc")'
bad=0; i=0
while IFS='|' read -r dir cmd; do
  i=$((i+1)); rc=$(cat "$T/$i.rc"); [ "$rc" = 0 ] || bad=1
  printf '%s  %-28s %s\n' "$([ "$rc" = 0 ] && echo ok || echo FAIL)" "$cmd" "$(grep -v '^\s*$' "$T/$i.log" | tail -1)"
  [ "$rc" = 0 ] || tail -20 "$T/$i.log"
done < "$T/jobs"
echo "gates: $([ $bad = 0 ] && echo all green || echo FAILED) in $(( $(date +%s) - S )) s"
exit $bad
