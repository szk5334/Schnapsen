// Royal House, solo: bots play whole Bummerls with the 32-card pack through the same reducer layer the site uses.
// Checks the pack survives every deal, marriage values by kind, the one-time exchange, scoreless deals feeding the
// pot, Schneider under 100, and the sheet adding up.
// node royal.house.test.mjs [bummerls]
import { freshBummerl, botAction, SETUP } from "../schnapsen/state/reducer.js";
import { ENG } from "../schnapsen/engine/core.js";
import { reducer, withHouse, houseDeal, potOf, rulesetOf } from "../app/house.js";

let pass = 0, fail = 0;
const ok = (c, m) => { if (c) pass++; else { fail++; if (fail < 30) console.log("FAIL", m); } };

const opts = { house: true, piles: "up", variant: "royal" };
function start(brains) {
  ENG.setVariant("royal");
  return houseDeal(withHouse(freshBummerl({ ...SETUP, variant: "royal", bummerlNo: 0 }, brains, ["A", "B"], 7, 0), opts));
}
const NB = +(process.argv[2] || 12);
const V = { H3: 20, H: 40 };
let deals = 0, melds = { KQ: 0, "34": 0 }, scoreless = 0, potPaid = 0, bummerls = 0, maxPot = 0, closes = 0, swaps = 0, schneider = 0;
const t0 = Date.now();
const brainsList = [["fritzl", "greta"], ["greta", "resi"], ["poldi", "ignaz"]];
ok(rulesetOf(opts) === "royal" && rulesetOf({ house: true }) === "house" && rulesetOf({}) === "classic", "ruleset names");
for (let b = 0; b < NB; b++) {
  let s = start(brainsList[b % 3]);
  ok(s.house && s.variant === "royal", "royal house flags on start");
  ok(s.hands[0].length === 5 && s.stock.length === 21, "five each, 21 face down");
  for (let guard = 0; guard < 8000 && !s.bummerlDone; guard++) {
    if (s.phase === "scored") {
      deals++;
      const last = s.sheet[s.sheet.length - 1], r = s.result;
      for (const e of s.log || []) {
        if (e.k === "meld") {
          const kind = e.kind || "KQ", base = kind === "34" ? 20 : 40;
          ok(e.value === (e.suit === s.trump ? base * 2 : base), `marriage ${kind}: ${e.value}`);
          melds[kind]++;
        }
        if (e.k === "exchange") { swaps++; ok(e.gave.rank === "2" || e.gave.rank === "J", "the 2 or the J swaps"); }
        if (e.k === "close") closes++;
      }
      ok(s.log.filter(e => e.k === "exchange").length <= 1, "one exchange a deal at most");
      if (last.scoreless) {
        scoreless++;
        ok(r.reason === "exhausted" && r.pts[0] < 200 && r.pts[1] < 200, "scoreless only when nobody reached 200");
      } else {
        if (last.pot) potPaid += last.pot;
        const lp = r.pts[1 - last.winner];
        if (r.reason === "claim" && r.winner === last.winner && !s.closed && lp < 100 && r.tricks[1 - last.winner] > 0) { schneider++; ok(last.gp - (last.pot || 0) === 2, "Schneider under 100 pays 2"); }
      }
      if (r.reason === "exhausted" && !last.scoreless) ok(Math.max(r.pts[0], r.pts[1]) >= 200, "paid at the end only past 200");
      if (r.reason === "exhausted") ok(s.trickPts[0] + s.trickPts[1] === 356, "every card point taken");
      maxPot = Math.max(maxPot, potOf(s.sheet));
      const sum = [0, 1].map(i => s.sheet.filter(x => x.winner === i).reduce((a, x) => a + x.gp, 0));
      ok(sum.join() === s.gp.join(), "sheet adds up to the score");
      s = reducer(s, { type: "NEXT_DEAL" });
      ok(s.variant === "royal" && s.house === true && s.stock.length === 21, "next deal: the royal pack");
      ok(s.trump === s.up.suit, "the turn-up names trumps");
      continue;
    }
    const d = botAction(s, s.turn);
    if (!d || !d.action) { ok(false, "bot had no move"); break; }
    ok(!/DOUBLE|TAKE|DROP/.test(d.action.type), "no doubling");
    const n = reducer(s, d.action);
    ok(n !== s, "bot move accepted (" + d.action.type + ")");
    s = n;
  }
  ok(s.bummerlDone, "Bummerl finished");
  if (s.bummerlDone) { bummerls++; ok(s.gp[s.bummerlWinner] >= 7, "winner reached 7"); }
  const nb = reducer(s, { type: "NEW_BUMMERL" });
  ok(nb.variant === "royal" && nb.house === true && nb.gp.join() === "0,0" && potOf(nb.sheet) === 0, "new Bummerl keeps Royal House");
}
ok(melds.KQ > 5 && melds["34"] > 5, "both kinds of marriage seen");
console.log(`${pass} passed, ${fail} failed — royal house: ${bummerls} Bummerls, ${deals} deals, ${melds.KQ} royal / ${melds["34"]} common marriages, ${swaps} exchanges, ${closes} closes, ${schneider} Schneider, ${scoreless} scoreless, pot paid ${potPaid}, biggest pot ${maxPot}, ${((Date.now() - t0) / 1000).toFixed(1)} s`);
process.exit(fail ? 1 : 0);
