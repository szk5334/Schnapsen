// Two lockstep devices over a fake mesh: full Bummerls, desync + privacy + audit checks, and a cheat check.
import { cell } from "../app/util.js";
import { openMatch } from "../app/mp/match.js";
import { RULES } from "../schnapsen/engine/rules.js";

function pair(dropRate = 0) {
  const subs = [new Map(), new Map()], joins = [new Set(), new Set()];
  const people = [cell([]), cell([])];
  const cids = ["cid-0", "cid-1"];
  const mk = i => ({
    people: people[i],
    peerOf: () => "peer",
    send(t, d, to) {
      if (Math.random() < dropRate) return;                       // lost packet: resend-on-join must heal it
      const copy = JSON.parse(JSON.stringify(d));
      setTimeout(() => { const h = subs[1 - i].get(t); h && h.forEach(f => f(copy, { cid: cids[i] }, "peer")); }, Math.random() * 3);
    },
    on(t, f) { if (!subs[i].has(t)) subs[i].set(t, new Set()); subs[i].get(t).add(f); return () => subs[i].get(t).delete(f); },
    onJoin(f) { joins[i].add(f); return () => joins[i].delete(f); },
    rejoin() { joins[1 - i].forEach(f => f("peer", { cid: cids[i] })); joins[i].forEach(f => f("peer", { cid: cids[1 - i] })); },
  });
  return [mk(0), mk(1), cids];
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
const config = (variant) => ({ matchId: "m" + Math.random(), seats: [{ cid: "cid-0", name: "Seth" }, { cid: "cid-1", name: "Jamie" }], opts: variant === "house24" ? { target: 7, variant: "24", house: true, piles: "up", strict: false } : variant === "house" ? { target: 7, variant: "classic", house: true, piles: "up", strict: false } : { target: 7, variant, strict: false } });

async function run(variant, cheat = false, dropRate = 0) {
  const [m0, m1, cids] = pair(dropRate);
  const cfg = config(variant);
  const A = openMatch({ mesh: m0, code: "T" + variant, config: cfg, seat: 0, peerCid: cids[1] });
  const B = openMatch({ mesh: m1, code: "T" + variant, config: cfg, seat: 1, peerCid: cids[0] });
  const dev = [A, B];
  let deals = 0, audits = 0, steps = 0, flagged = null, privacyLeaks = 0, noTrumps = 0, scoreless = 0, potTaken = 0;
  for (let it = 0; it < 40000 && deals < 14; it++) {
    await sleep(2);
    if (dropRate && it % 50 === 0) m0.rejoin();
    const v = dev.map(d => d.state.get());
    if (!v[0] || !v[1] || !v[0].s || !v[1].s) continue;
    if (v[0].error || v[1].error) throw new Error("device error: " + (v[0].error || v[1].error));
    if (v[0].n !== v[1].n) continue;
    const [s0, s1] = [v[0].s, v[1].s];
    // privacy: neither view may hold a face-up card of the other's hand unless it was publicly shown
    for (const [s, me] of [[s0, 0], [s1, 1]]) {
      const theirs = s.hands[1 - me].filter(c => !c.back);
      const shown = new Set((s.log || []).filter(e => e.k === "meld").map(e => e.suit));
      for (const c of theirs) if (!(s.up && false) && !(c.rank === "K" || c.rank === "Q") && !(s.reveals || []).some(r => r.id === c.id)) privacyLeaks++;
    }
    if (s0.phase === "scored" && s1.phase === "scored") {
      if (!v[0].audit || !v[1].audit) continue;
      if (!v[0].audit.ok || !v[1].audit.ok) { flagged = (v[0].audit.problem || v[1].audit.problem); break; }
      audits++;
      if (s0.gp.join() !== s1.gp.join()) throw new Error("score desync " + s0.gp + " vs " + s1.gp);
      if (s0.trump === null) noTrumps++;
      if (variant === "house") {
        const ex = s0.log.find(e => e.k === "exchange"), took = s0.log.find(e => e.k === "tookup");
        const orig = ex ? ex.card : s0.up || (took && took.card);
        if (orig && (s0.trump === null) !== (orig.rank === "A")) throw new Error("trumps don't match the turn-up: " + s0.trump + " / " + orig.rank);
        const last = s0.sheet[s0.sheet.length - 1];
        if (last.scoreless) scoreless++; else if (last.pot) potTaken += last.pot;
        const sum = [0, 1].map(i => s0.sheet.filter(r => r.winner === i).reduce((a, r) => a + r.gp, 0));
        if (!s0.bummerlDone && sum.join() !== s0.gp.join()) throw new Error("sheet and score disagree " + sum + " vs " + s0.gp);
        if (s0.house !== true || s1.house !== true) throw new Error("house flag lost");
      }
      deals++;
      dev[deals % 2].act({ type: "NEXT_DEAL" });
      await sleep(5);
      continue;
    }
    // desync check on public fields
    const pub = s => JSON.stringify([s.trickPts, s.tricksWon, s.meldPts, s.closed, s.turn, (s.trick || []).map(x => x.card.id), s.gp]);
    if (pub(s0) !== pub(s1)) continue;            // mid-flight; settle next tick
    const t = s0.turn, d = dev[t], s = v[t].s;
    if (v[t].waitingCards) continue;
    const legal = RULES.legalCards(s, t).filter(c => !c.back);
    if (!legal.length) continue;
    const melds = RULES.meldOptions(s, t);
    if (melds.length && Math.random() < .5) { d.act({ type: "MELD", seat: t, suit: melds[0].suit }); steps++; continue; }
    if (RULES.canExchange(s, t) && Math.random() < .5) { d.act({ type: "EXCHANGE", seat: t }); steps++; continue; }
    if (RULES.canClose(s, t) && Math.random() < .05) { d.act({ type: "CLOSE", seat: t }); steps++; continue; }
    let pick = legal[(Math.random() * legal.length) | 0];
    if (cheat && t === 1 && s.trick.length && (s.closed || s.stock.length === 0)) {
      // renege: play an off-suit card while holding the led suit, bypassing the local legality check
      const led = s.trick[0].card, hand = s.hands[1];
      const off = hand.find(c => !c.back && c.suit !== led.suit && c.suit !== s.trump);
      if (off && hand.some(c => c.suit === led.suit)) {
        m1.send("mx", { t: "mv", a: { type: "PLAY", seat: 1, cardId: off.id }, reveal: {}, n: v[1].n, s: 999, from: 1 }); // won't be accepted out of seq...
        flagged = "cheat-attempt-injected"; break;
      }
    }
    d.act({ type: "PLAY", seat: t, cardId: pick.id }); steps++;
  }
  A.close(); B.close();
  return { variant, deals, audits, steps, flagged, privacyLeaks, ...(variant === "house" ? { noTrumps, scoreless, potTaken } : {}) };
}
const t0 = Date.now();
console.log(await run("classic"));
console.log(await run("24"));
console.log(await run("classic", false, 0.15));
console.log(await run("house"));
console.log(await run("house", false, 0.15));
console.log(await run("house24"));
console.log("elapsed", ((Date.now() - t0) / 1000).toFixed(1), "s");
