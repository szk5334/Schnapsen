// Two lockstep devices over a fake mesh: full Bummerls, desync + privacy + audit checks, and a cheat check.
import { cell } from "../app/util.js";
import { openMatch } from "../app/mp/match.js";
import { RULES } from "../schnapsen/engine/rules.js";
import { ENG } from "../schnapsen/engine/core.js";
import { spawn } from "node:child_process";
import { cpus } from "node:os";

function pair(dropRate = 0) {
  const subs = [new Map(), new Map()], joins = [new Set(), new Set()];
  const people = [cell([]), cell([])];
  const cids = ["cid-0", "cid-1"];
  const mk = i => ({
    people: people[i],
    peerOf: () => "peer",
    send(t, d, to) {
      if (Math.random() < dropRate) return;                       // lost packet: resend-on-join must heal it
      const copy = JSON.parse(JSON.stringify(d));
      const deliver = () => { const h = subs[1 - i].get(t); h && h.forEach(f => f(copy, { cid: cids[i] }, "peer")); };
      if (Math.random() < .25) setTimeout(deliver, 1); else setImmediate(deliver);   // some arrive out of order
    },
    on(t, f) { if (!subs[i].has(t)) subs[i].set(t, new Set()); subs[i].get(t).add(f); return () => subs[i].get(t).delete(f); },
    onJoin(f) { joins[i].add(f); return () => joins[i].delete(f); },
    rejoin() { joins[1 - i].forEach(f => f("peer", { cid: cids[i] })); joins[i].forEach(f => f("peer", { cid: cids[1 - i] })); },
  });
  return [mk(0), mk(1), cids];
}
/* No pacing: a bare yield lets the fake mesh's timers and the match's handlers run, nothing more. */
const sleep = ms => new Promise(r => (ms ? setTimeout(r, ms) : setImmediate(r)));
const config = (variant) => ({ matchId: "m" + Math.random(), seats: [{ cid: "cid-0", name: "Seth" }, { cid: "cid-1", name: "Jamie" }], opts: variant.startsWith("house") ? { target: 7, variant: variant.slice(5) || "classic", house: true, piles: "up", strict: false } : { target: 7, variant, strict: false } });
const deckOf = variant => ENG.normVariant(variant.startsWith("house") ? variant.slice(5) : variant);

async function run(variant, cheat = false, dropRate = 0) {
  const [m0, m1, cids] = pair(dropRate);
  const cfg = config(variant);
  const A = openMatch({ mesh: m0, code: "T" + variant, config: cfg, seat: 0, peerCid: cids[1] });
  const B = openMatch({ mesh: m1, code: "T" + variant, config: cfg, seat: 1, peerCid: cids[0] });
  const dev = [A, B];
  let deals = 0, audits = 0, steps = 0, flagged = null, privacyLeaks = 0, noTrumps = 0, scoreless = 0, potTaken = 0, doubles = 0;
  const tEnd = Date.now() + 240000;                     // a wall-clock guard, not a step count
  for (let it = 0; deals < 14 && Date.now() < tEnd; it++) {
    await sleep(0);
    if (dropRate && it % 50 === 0) m0.rejoin();
    const v = dev.map(d => d.state.get());
    if (!v[0] || !v[1] || !v[0].s || !v[1].s) continue;
    if (v[0].error || v[1].error) throw new Error("device error: " + (v[0].error || v[1].error));
    if (v[0].n !== v[1].n) continue;
    const [s0, s1] = [v[0].s, v[1].s];
    // privacy: neither view may hold a face-up card of the other's hand unless it was publicly shown
    for (const [s, me] of [[s0, 0], [s1, 1]]) {
      const theirs = s.hands[1 - me].filter(c => !c.back);
      const shown = (s.log || []).filter(e => e.k === "meld" && e.seat === 1 - me).map(e => e.key || e.suit);
      for (const c of theirs) if (!shown.some(k => ENG.isMeldCard(c, k)) && !(s.reveals || []).some(r => r.id === c.id)) privacyLeaks++;
    }
    if (s0.phase === "scored" && s1.phase === "scored") {
      if (!v[0].audit || !v[1].audit) continue;
      if (!v[0].audit.ok || !v[1].audit.ok) { flagged = (v[0].audit.problem || v[1].audit.problem); break; }
      audits++;
      if (s0.gp.join() !== s1.gp.join()) throw new Error("score desync " + s0.gp + " vs " + s1.gp);
      if (s0.trump === null) noTrumps++;
      if (variant.startsWith("house")) {
        const ex = s0.log.find(e => e.k === "exchange"), took = s0.log.find(e => e.k === "tookup");
        const orig = ex ? ex.card : s0.up || (took && took.card);
        if (orig && s0.trump !== orig.suit) throw new Error("trumps don't match the turn-up: " + s0.trump + " / " + orig.suit);
        const last = s0.sheet[s0.sheet.length - 1];
        if (last.scoreless) scoreless++; else if (last.pot) potTaken += last.pot;
        const sum = [0, 1].map(i => s0.sheet.filter(r => r.winner === i).reduce((a, r) => a + r.gp, 0));
        if (!s0.bummerlDone && sum.join() !== s0.gp.join()) throw new Error("sheet and score disagree " + sum + " vs " + s0.gp);
        if (s0.house !== true || s1.house !== true) throw new Error("house flag lost");
      }
      deals++;
      dev[deals % 2].act({ type: "NEXT_DEAL" });
      await sleep(0);
      continue;
    }
    // desync check on public fields
    const pub = s => JSON.stringify([s.trickPts, s.tricksWon, s.meldPts, s.closed, s.turn, (s.trick || []).map(x => x.card.id), s.gp]);
    if (pub(s0) !== pub(s1)) continue;            // mid-flight; settle next tick
    const t = s0.turn, d = dev[t], s = v[t].s;
    if (v[t].waitingCards) continue;
    ENG.setVariant(deckOf(variant));                    // the test's own legality check reads the deck's rank order
    if (RULES.canAnswer(s, t)) { d.act({ type: Math.random() < .6 ? "TAKE" : "DROP", seat: t }); steps++; doubles++; continue; }
    if (RULES.canDouble(s, t) && Math.random() < .06) { d.act({ type: "DOUBLE", seat: t }); steps++; continue; }
    const legal = RULES.legalCards(s, t).filter(c => !c.back);
    if (!legal.length) continue;
    const melds = RULES.meldOptions(s, t);
    if (melds.length && Math.random() < .5) { d.act({ type: "MELD", seat: t, suit: melds[0].suit }); steps++; continue; }
    if (RULES.canExchange(s, t) && Math.random() < .5) { d.act({ type: "EXCHANGE", seat: t }); steps++; continue; }
    if (RULES.canClose(s, t) && Math.random() < .05) { d.act({ type: "CLOSE", seat: t }); steps++; continue; }
    let pick = legal[(Math.random() * legal.length) | 0];
    if (cheat && t === 1 && s.trick.length && (s.closed || s.stock.length === 0)) {
      // renege: play an off-suit card while holding the led suit, bypassing the local legality check
      const led = s.trick[0].card, hand = s.hands[1];
      const off = hand.find(c => !c.back && c.suit !== led.suit && c.suit !== s.trump);
      if (off && hand.some(c => c.suit === led.suit)) {
        m1.send("mx", { t: "mv", a: { type: "PLAY", seat: 1, cardId: off.id }, reveal: {}, n: v[1].n, s: 999, from: 1 }); // won't be accepted out of seq...
        flagged = "cheat-attempt-injected"; break;
      }
    }
    d.act({ type: "PLAY", seat: t, cardId: pick.id }); steps++;
  }
  A.close(); B.close();
  return { variant: variant + (dropRate ? " @" + dropRate * 100 + "% loss" : ""), deals, audits, steps, flagged, privacyLeaks, ...(variant.startsWith("house") ? { noTrumps, scoreless, potTaken } : {}), ...(doubles ? { doubles } : {}) };
}
/* Each run in its own process, as many at once as there are cores (runs can't share a process: the engine's deck
 * setting is global). `node mp.test.mjs house 0.15` runs one configuration in-process. */
const RUNS = [["classic", 0], ["classic", 0.15], ["house", 0], ["house", 0.15], ["houseroyal", 0], ["houseroyal", 0.15]];
const t0 = Date.now();
if (process.argv[2]) {
  console.log(JSON.stringify(await run(process.argv[2], false, +(process.argv[3] || 0))));
} else {
  const out = new Array(RUNS.length);
  let next = 0, bad = 0;
  const worker = () => new Promise(done => {
    const go = () => {
      if (next >= RUNS.length) return done();
      const k = next++, [v, drop] = RUNS[k];
      const ch = spawn(process.execPath, [new URL(import.meta.url).pathname, v, String(drop)], { stdio: ["ignore", "pipe", "inherit"] });
      let buf = ""; ch.stdout.on("data", d => (buf += d));
      ch.on("close", code => {
        try { out[k] = JSON.parse(buf.trim().split("\n").pop()); } catch { out[k] = { variant: v, error: buf || "exit " + code }; }
        const r = out[k];
        if (code || r.error || r.flagged || r.privacyLeaks || r.audits !== 14 || r.deals !== 14) bad++;
        go();
      });
    };
    go();
  });
  await Promise.all(Array.from({ length: Math.max(2, cpus().length) }, worker));
  for (const r of out) console.log(r);
  const audited = out.reduce((a, r) => a + (r.audits || 0), 0);
  console.log(`${bad ? "FAIL" : "ok"}: ${audited}/${RUNS.length * 14} deals audited across ${RUNS.length} runs, no desync or leak, ${((Date.now() - t0) / 1000).toFixed(1)} s`);
  process.exit(bad ? 1 : 0);
}
