// Does the end-of-deal audit catch (1) a renege and (2) a rigged shuffle?
import { cell } from "../app/util.js";
import { openMatch, auditDeal, buildDeal, reveal } from "../app/mp/match.js";
import { canonicalDeck, audit } from "../app/mp/deck.js";
import { reducer } from "../schnapsen/state/reducer.js";
import { RULES, isStrict } from "../schnapsen/engine/rules.js";
import { ENG } from "../schnapsen/engine/core.js";

const subs = [new Map(), new Map()], cids = ["cid-0", "cid-1"];
const mk = i => ({ people: cell([]), peerOf: () => "peer",
  send(t, d) { setTimeout(() => { const h = subs[1 - i].get(t); h && h.forEach(f => f(JSON.parse(JSON.stringify(d)), { cid: cids[i] }, "peer")); }, 1); },
  on(t, f) { if (!subs[i].has(t)) subs[i].set(t, new Set()); subs[i].get(t).add(f); return () => {}; }, onJoin() { return () => {}; } });
const sleep = ms => new Promise(r => setTimeout(r, ms));
let found = 0, caught = 0, honestOk = 0, rigCaught = 0, rigTried = 0, deals = 0;
for (let round = 0; round < 12 && found < 5; round++) {
  const cfg = { matchId: "c" + round, seats: [{ cid: "cid-0", name: "Seth" }, { cid: "cid-1", name: "Jamie" }], opts: { target: 7, variant: "classic", strict: false } };
  subs[0].clear(); subs[1].clear();
  const D = [openMatch({ mesh: mk(0), code: "C" + round, config: cfg, seat: 0, peerCid: cids[1] }), openMatch({ mesh: mk(1), code: "C" + round, config: cfg, seat: 1, peerCid: cids[0] })];
  for (let it = 0; it < 4000; it++) {
    await sleep(1);
    const v = D.map(d => d.state.get()); if (!v[0].s || !v[1].s) continue;
    if (v[0].s.phase === "scored") { if (v[0].audit && v[1].audit) break; continue; }
    const t = v[0].s.turn; if (v[1].s.turn !== t || v[t].waitingCards) continue;
    const legal = RULES.legalCards(v[t].s, t).filter(c => !c.back); if (!legal.length) continue;
    D[t].act({ type: "PLAY", seat: t, cardId: legal[(Math.random() * legal.length) | 0].id });
  }
  const rec = D[0]._record(); if (!rec) continue;
  deals++;
  if (auditDeal(rec).ok) honestOk++;
  // ---- renege: replay face-up, find a strict follow where the follower held the led suit, swap in an off-suit card
  const canon = canonicalDeck("classic"), N = 20, upPos = 10;
  const deck = audit(rec, N).deck;
  let full = buildDeal(rec.ctx, cfg, canon[deck[upPos]], upPos, N);
  for (let j = 0; j < N; j++) full = reveal(full, j, canon[deck[j]]);
  full.stock = full.stock.map(c => canon[deck[c.pos]]);
  ENG.setVariant("classic");
  for (let i = 0; i < rec.moves.length; i++) {
    const a = rec.moves[i];
    if (a.type === "PLAY" && full.trick.length && isStrict(full)) {
      const led = full.trick[0].card, hand = full.hands[a.seat];
      const off = hand.find(c => c.suit !== led.suit && c.suit !== full.trump);
      if (off && hand.some(c => c.suit === led.suit)) {
        const bad = { ...rec, moves: rec.moves.slice(0, i).concat([{ ...a, cardId: off.id }]) };
        const r = auditDeal(bad); found++;
        if (!r.ok && r.move === i) caught++;
        if (found === 1) console.log("renege verdict:", r.problem);
        break;
      }
    }
    full = reducer(full, a);
  }
  // ---- rigged shuffle: seat 1 swaps one final ciphertext for a copy of another
  const rig = { ...rec, l4: rec.l4.slice() }; rig.l4[3] = rig.l4[4];
  rigTried++; if (!auditDeal(rig).ok) rigCaught++;
  D.forEach(d => d.close());
}
console.log({ deals, honestOk, renegeFound: found, renegeCaught: caught, riggedTried: rigTried, riggedCaught: rigCaught });
process.exit(0);
