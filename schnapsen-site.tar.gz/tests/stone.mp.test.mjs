/* Two simulated devices play Scroll & Stone through openStoneMatch over a fake, lossy mesh.
 * Usage: node tests/stone.mp.test.mjs [games-per-mode] [loss 0..1] */
import { openStoneMatch } from "../app/stone/match.js";
import { mainMoves, spiritMoves, cardPlayable, needsCommit, hasNinjas, ninjaStarts, ninjaMoves, lightSeat, play, pruneCaught, rng } from "../app/stone/engine.js";
import { CARDS } from "../app/stone/cards.js";

const GAMES = +(process.argv[2] || 6), LOSS = +(process.argv[3] || 0.1), RELOAD = process.argv[4] === "reload";
/* A memory localStorage, so a "reload" (closing a match and opening it again) replays from what was saved. */
if (!globalThis.localStorage) { const m = new Map(); globalThis.localStorage = { getItem: k => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)), removeItem: k => m.delete(k) }; }
let fails = 0;
const ok = (c, m) => { if (!c) { fails++; console.log("FAIL", m); } };

function fakeNet(R) {
  const nodes = {};
  const mk = (cid, peerCid) => {
    const topics = {}, joins = new Set();
    const node = {
      cid, on(t, cb) { (topics[t] ||= new Set()).add(cb); return () => topics[t].delete(cb); },
      onJoin(cb) { joins.add(cb); return () => joins.delete(cb); },
      peerOf: c => (nodes[c] ? "peer-" + c : null), backlog: () => 0,
      send(t, d, to) {
        if (R() / 2 ** 32 < LOSS) return;                                    // lost on the way
        const target = nodes[peerCid]; if (!target) return;
        const copy = JSON.parse(JSON.stringify(d));
        const late = R() % 4 === 0;
        (late ? setTimeout : setImmediate)(() => (target._topics[t] || new Set()).forEach(f => f(copy, { cid }, "peer-" + cid)), late ? 1 : undefined);
      },
      _topics: topics, _joins: joins,
    };
    nodes[cid] = node; return node;
  };
  return { mk };
}

/* A random but legal player for one seat, through the match API. */
function player(m, seat, R) {
  const pick = a => a[R() % a.length];
  return v => {
    if (!v || v.error) return;
    const st = v.st;
    if (!st) return;
    if (v.placing) {
      const starts = ninjaStarts(st, seat), n = st.nin[seat].live.length, chosen = [];
      while (chosen.length < n) { const c = pick(starts); if (!chosen.some(x => String(x) === String(c))) chosen.push(c); }
      m.place(chosen); return;
    }
    if (!v.ready || st.winner != null || st.wait || st.turn !== seat) return;
    const choices = [];
    for (const card of st.hand[seat]) {
      const wind = CARDS[card].kind === "wind";
      const mm = mainMoves(st, seat, card);
      if (wind) {
        for (const mv of (mm.length ? mm : [null])) {
          const after = mv ? play({ ...st, nin: st.nin.map(x => ({ ...x, live: [], shown: [] })) }, seat, { card, mv }) : null;
          const base = mv ? null : st;
          let sp = null;
          const scratch = mv ? (() => { const t = JSON.parse(JSON.stringify(st)); const q = t.pieces.find(z => z.id === mv.pid); t.pieces = t.pieces.filter(z => !(z.x === mv.x && z.y === mv.y)); q.x = mv.x; q.y = mv.y; return t; })() : st;
          const sec = spiritMoves(scratch, seat, card);
          const c = { card, mv: mv || undefined, sp: sec.length ? pick(sec) : undefined };
          if (play(st, seat, c) || needsCommit(st, seat)) choices.push(c);
          else if (sec.length) choices.push({ card, mv: mv || undefined });   // won before the Spirit: no Spirit move
        }
      } else {
        for (const mv of mm) choices.push({ card, mv });
        if (st.mode === "wind") for (const sp of spiritMoves(st, seat, card)) choices.push({ card, sp });
      }
    }
    let a;
    const anyMain = st.hand[seat].some(c => mainMoves(st, seat, c).length);
    if (!choices.length && !(needsCommit(st, seat) && hasNinjas(st, seat))) a = { card: pick(st.hand[seat]), pass: true };
    else if (!choices.length) a = { card: pick(st.hand[seat]) };
    else a = pick(choices);
    if (needsCommit(st, seat) && hasNinjas(st, seat) && !a.pass) {
      const now = pruneCaught(st, seat, v.ninjas || []);
      const after = play(st, seat, { ...a, nj: "0".repeat(64) }) || st;
      const cand = now.flatMap((n, i) => (n ? ninjaMoves(after, seat, a.card, now, i).map(t => ({ i, x: t[0], y: t[1] })) : []));
      const must = st.mode === "light" && seat !== lightSeat(st);
      if (cand.length && (must || R() % 2 === 0)) a.ninja = pick(cand);
      if (st.mode === "shadow" && R() % 10 === 0) { const i = now.findIndex(Boolean); if (i >= 0 && !(a.ninja)) a.attack = i; }
    }
    if (st.nin[seat].lant > 0 && st.moved[seat] && hasNinjas(st, 1 - seat) && (st.mode === "shadow" || (st.mode === "light" && seat === lightSeat(st))) && R() % 3 === 0)
      a.lan = { ax: R() % 2 ? "r" : "c", i: R() % 5 };
    if (!m.act(a)) {
      /* an attack on a square shared with my own piece etc.: try plainly */
      delete a.attack; delete a.lan;
      if (!m.act(a)) { delete a.ninja; if (!m.act(a)) console.log("could not move", seat, JSON.stringify(a)); }
    }
  };
}

async function runOne(opts, seed) {
  const R = rng("net" + seed);
  const net = fakeNet(R);
  const meshes = [net.mk("A", "B"), net.mk("B", "A")];
  const code = "T" + seed.replace(/\W/g, "").slice(-8);
  const config = { matchId: "m-" + seed, seats: [{ cid: "A" }, { cid: "B" }], opts };
  const ms = [], players = [], unsub = [];
  const open = s => {
    ms[s] = openStoneMatch({ mesh: meshes[s], code: code + s, config, seat: s, peerCid: s ? "A" : "B" });
    players[s] = player(ms[s], s, rng("p" + s + seed + Math.random()));
    const m = ms[s];
    unsub[s] = m.state.sub(v => setImmediate(() => { if (ms[s] === m) players[s](v); }));
    players[s](m.state.get());
  };
  open(0); open(1);
  let reloads = 0;
  const t0 = Date.now();
  /* the safety net re-sends after 30 s; here we nudge it: a stuck pair asks again quickly */
  for (;;) {
    await new Promise(r => setTimeout(r, 5));
    const v = ms.map(m => m.state.get());
    if (v.every(x => x.audit) || v.some(x => x.error)) break;
    if (Date.now() - t0 > 60000) break;
    if (RELOAD && R() % 60 === 0) {
      const s = R() % 2; ms[s].close(); unsub[s] && unsub[s](); reloads++;
      /* the mesh listeners of the old match are gone; the new one re-sends its log on open */
      open(s);
    }
    if ((Date.now() - t0) % 400 < 6) for (let s = 0; s < 2; s++) meshes[s]._joins.forEach(f => f("peer-" + (s ? "A" : "B"), { cid: s ? "A" : "B" }));
  }
  const v = ms.map(m => m.state.get());
  ms.forEach(m => m.close());
  return { v, ms: Date.now() - t0, reloads };
}

const modes = [
  { mode: "classic", sets: { base: true, sensei: true, promo: true } },
  { mode: "wind", wind: "std", sets: { base: true, sensei: true } },
  { mode: "wind", wind: "m5", sets: { base: true } },
  { mode: "shadow", sets: { base: true } },
  { mode: "light", light: 1, sets: { base: true } },
];
for (const o of modes) {
  let done = 0, audited = 0, time = 0, totalReloads = 0;
  for (let g = 0; g < GAMES; g++) {
    const { v, ms, reloads } = await runOne(o, `${o.mode}${o.wind || ""}${o.light ?? ""}-${g}`);
    time += ms; totalReloads += reloads;
    ok(!v.some(x => x.error), `${o.mode} no error: ${v.map(x => x.error).join(" / ")}`);
    if (v.every(x => x.st && x.st.winner != null)) done++;
    ok(JSON.stringify(v[0].st) === JSON.stringify(v[1].st), `${o.mode} both devices hold the same game`);
    if (v.every(x => x.audit && x.audit.ok)) audited++;
    else ok(false, `${o.mode} audit: ${v.map(x => x.audit && x.audit.why).join(" / ")}`);
  }
  console.log(`${(o.mode + (o.wind ? "/" + o.wind : "")).padEnd(12)} ${done}/${GAMES} finished, ${audited}/${GAMES} audited on both phones, ${(time / GAMES / 1000).toFixed(2)} s a game at ${LOSS * 100}% loss${RELOAD ? `, ${totalReloads} reloads` : ""}`);
}
console.log(fails ? `FAILED ${fails}` : "stone match: all games agree and pass the audit");
process.exit(fails ? 1 : 0);
