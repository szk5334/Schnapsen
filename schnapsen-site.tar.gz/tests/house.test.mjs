// House rules, solo: bots play whole Bummerls under no-trump house rules. Checks the five-way turn-up,
// that no-trump deals never allow a swap and pay 20 for every marriage, that a deal nobody wins scores
// nothing and feeds the pot, and that the next scorer takes the pot.
import { freshBummerl, botAction, SETUP } from "../schnapsen/state/reducer.js";
import { RULES } from "../schnapsen/engine/rules.js";
import { reducer, withHouse, houseDeal, potOf } from "../app/house.js";

let pass = 0, fail = 0;
const ok = (c, m) => { if (c) pass++; else { fail++; console.log("FAIL", m); } };

function start(brains, piles = "up") {
  return houseDeal(withHouse(freshBummerl({ ...SETUP, bummerlNo: 0 }, brains, ["A", "B"], 7, 0), { house: true, piles }));
}
let deals = 0, nt = 0, scoreless = 0, potPaid = 0, swapsAtNT = 0, meldVals = new Set(), bummerls = 0, maxPot = 0;
const brainsList = [["fritzl", "vroni"], ["greta", "resi"], ["poldi", "ignaz"]];
for (let b = 0; b < 150; b++) {
  let s = start(brainsList[b % 3]);
  ok(s.house && s.piles === "up" && s.variant === "classic", "house flags on start");
  for (let guard = 0; guard < 4000 && !s.bummerlDone; guard++) {
    if (s.phase === "scored") {
      deals++;
      const last = s.sheet[s.sheet.length - 1];
      if (last.scoreless) { scoreless++; ok(s.result.reason === "exhausted", "scoreless only when the stock ran out"); }
      else if (last.pot) potPaid += last.pot;
      maxPot = Math.max(maxPot, potOf(s.sheet));
      const sum = [0, 1].map(i => s.sheet.filter(r => r.winner === i).reduce((a, r) => a + r.gp, 0));
      ok(sum.join() === s.gp.join(), "sheet adds up to the score");
      s = reducer(s, { type: "NEXT_DEAL" });
      ok(s.house === true, "house flag survives next deal");
      const orig = s.up;
      ok((s.trump === null) === (orig.rank === "A"), "trumps follow the turn-up");
      if (s.trump === null) nt++;
      continue;
    }
    if (s.trump === null) {
      if (RULES.canExchange(s, s.turn)) swapsAtNT++;
      for (const m of RULES.meldOptions(s, s.turn)) meldVals.add(m.value);
    }
    const d = botAction(s, s.turn);
    if (!d || !d.action) { ok(false, "bot had no move"); break; }
    const n = reducer(s, d.action);
    ok(n !== s, "bot move accepted (" + d.action.type + ")");
    s = n;
  }
  ok(s.bummerlDone, "Bummerl finished");
  if (s.bummerlDone) { bummerls++; ok(s.gp[s.bummerlWinner] >= 7, "winner reached 7"); }
  const nb = reducer(s, { type: "NEW_BUMMERL" });
  ok(nb.house === true && nb.gp.join() === "0,0" && potOf(nb.sheet) === 0, "new Bummerl keeps house rules, clears score");
}
ok(swapsAtNT === 0, "no swaps at no-trumps");
ok([...meldVals].every(v => v === 20), "every no-trump marriage is 20");
const share = nt / deals;
ok(share > 0.14 && share < 0.26, "about a fifth of deals are no-trumps: " + share.toFixed(3));
ok(scoreless > 0 && potPaid > 0, "some scoreless deals, and the pot gets paid");

// classic tables are untouched by the layer
let c = freshBummerl({ ...SETUP, bummerlNo: 0 }, ["fritzl", "vroni"], ["A", "B"], 7, 0);
for (let g = 0; g < 400 && c.phase !== "scored"; g++) c = reducer(c, botAction(c, c.turn).action);
ok(!c.house && c.trump !== null, "classic stays classic");

console.log(`${pass} passed, ${fail} failed — house rules: ${bummerls} Bummerls, ${deals} deals, ${nt} no-trump (${(share * 100).toFixed(1)}%), ${scoreless} scoreless, pot paid ${potPaid}, biggest pot ${maxPot}`);
process.exit(fail ? 1 : 0);
