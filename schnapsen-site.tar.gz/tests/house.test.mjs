// House rules, solo: bots play whole Bummerls under house rules. Checks that the turned card always names
// trumps (no-trump deals were dropped Nov 2026), that a deal nobody wins scores nothing and feeds the pot,
// and that the next scorer takes the pot.
import { freshBummerl, botAction, SETUP } from "../schnapsen/state/reducer.js";
import { RULES } from "../schnapsen/engine/rules.js";
import { reducer, withHouse, houseDeal, potOf } from "../app/house.js";

let pass = 0, fail = 0;
const ok = (c, m) => { if (c) pass++; else { fail++; console.log("FAIL", m); } };

function start(brains, piles = "up") {
  return houseDeal(withHouse(freshBummerl({ ...SETUP, bummerlNo: 0 }, brains, ["A", "B"], 7, 0), { house: true, piles }));
}
let melds = 0, deals = 0, nt = 0, scoreless = 0, potPaid = 0, bummerls = 0, maxPot = 0;
const brainsList = [["fritzl", "vroni"], ["greta", "resi"], ["poldi", "ignaz"]];
for (let b = 0; b < 150; b++) {
  let s = start(brainsList[b % 3]);
  ok(s.house && s.piles === "up", "house flags on start");
  ok(s.hands[0].length === 5, "five cards each");
  for (let guard = 0; guard < 4000 && !s.bummerlDone; guard++) {
    if (s.phase === "scored") {
      deals++;
      const last = s.sheet[s.sheet.length - 1];
      for (const e of s.log || []) if (e.k === "meld") { ok(e.value === (e.suit === s.trump ? 34 : 17), "house marriages are 17, or 34 in trumps"); melds++; }
      if (last.scoreless) { scoreless++; ok(s.result.reason === "exhausted", "scoreless only when the stock ran out"); }
      else if (last.pot) potPaid += last.pot;
      maxPot = Math.max(maxPot, potOf(s.sheet));
      const sum = [0, 1].map(i => s.sheet.filter(r => r.winner === i).reduce((a, r) => a + r.gp, 0));
      ok(sum.join() === s.gp.join(), "sheet adds up to the score");
      s = reducer(s, { type: "NEXT_DEAL" });
      ok(s.house === true, "house flag survives next deal");
      const orig = s.up;
      ok(s.trump === orig.suit, "the turn-up names trumps, an Ace included");
      if (orig.rank === "A") nt++;   // turned Aces: these used to be the no-trump deals
      continue;
    }
    const d = botAction(s, s.turn);
    if (!d || !d.action) { ok(false, "bot had no move"); break; }
    const n = reducer(s, d.action);
    ok(n !== s, "bot move accepted (" + d.action.type + ")");
    s = n;
  }
  ok(s.bummerlDone, "Bummerl finished");
  if (s.bummerlDone) { bummerls++; ok(s.gp[s.bummerlWinner] >= 7, "winner reached 7"); }
  const nb = reducer(s, { type: "NEW_BUMMERL" });
  ok(nb.house === true && nb.gp.join() === "0,0" && potOf(nb.sheet) === 0, "new Bummerl keeps house rules, clears score");
}
const share = nt / deals;
/* A turned Ace is 4 cards in 20: one deal in five. Allow 4 standard deviations. */
const expNT = 4 / 20, sdNT = Math.sqrt(expNT * (1 - expNT) / deals);
ok(Math.abs(share - expNT) < 4 * sdNT, `turned Aces near ${(expNT * 100).toFixed(1)}%: ${(share * 100).toFixed(1)}%`);
ok(melds > 100, "plenty of marriages checked: " + melds);
ok(scoreless > 0 && potPaid > 0, "some scoreless deals, and the pot gets paid");

// classic tables are untouched by the layer
let c = freshBummerl({ ...SETUP, bummerlNo: 0 }, ["fritzl", "vroni"], ["A", "B"], 7, 0);
for (let g = 0; g < 400 && c.phase !== "scored"; g++) c = reducer(c, botAction(c, c.turn).action);
ok(!c.house && c.trump !== null, "classic stays classic");

console.log(`${pass} passed, ${fail} failed — house rules: ${bummerls} Bummerls, ${deals} deals, ${nt} turned Aces (${(share * 100).toFixed(1)}%), ${scoreless} scoreless, pot paid ${potPaid}, biggest pot ${maxPot}`);
process.exit(fail ? 1 : 0);
