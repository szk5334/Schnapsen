/* A small NIP-01 relay for tests: EVENT (answers OK), REQ (kinds, #t, since, limit), CLOSE, EOSE, plus a NIP-11
 * document over HTTP. Stores regular events (honours NIP-40 expiration), forwards ephemeral ones without storing.
 *
 *   node relay-server.mjs PORT [options]
 *     --drop F       silently drop this fraction of forwards to subscribers (stored copies stay)
 *     --reject       answer OK=false "blocked: kind not accepted here" to every event
 *     --wot          answer OK=false "blocked: not in web of trust" to every event (like a web-of-trust relay)
 *     --rate N       more than N events a minute from one connection → OK=false "rate-limited: slow down";
 *                    three such strikes → the connection is closed and new connections are refused for 60 s
 *                    (what an IP ban looks like from a browser: the socket never opens)
 *     --nip11 JSON   serve this as the relay's NIP-11 document (e.g. '{"limitation":{"auth_required":true}}')
 *     --log FILE     one JSON line per event received
 * Prints {port, events, bytesIn, bytesOut, refusedRate, connsRefused} on SIGTERM. */
import { WebSocketServer } from "ws";
import { createServer } from "node:http";
import { appendFileSync, writeFileSync } from "node:fs";

const args = process.argv.slice(2);
const port = +args[0];
const opt = k => { const i = args.indexOf(k); return i < 0 ? null : (args[i + 1] && !args[i + 1].startsWith("--") ? args[i + 1] : true); };
const drop = +(opt("--drop") || 0), reject = !!opt("--reject"), wot = !!opt("--wot"), rate = +(opt("--rate") || 0);
const nip11 = opt("--nip11"), LOG = opt("--log");
if (LOG) writeFileSync(LOG, "");
const store = [];
const subs = new Map();
let bytesIn = 0, bytesOut = 0, events = 0, refusedRate = 0, connsRefused = 0, bannedUntil = 0;
const match = (f, ev) =>
  (!f.kinds || f.kinds.includes(ev.kind)) &&
  (!f.since || ev.created_at >= f.since) &&
  (!f["#t"] || ev.tags.some(t => t[0] === "t" && f["#t"].includes(t[1])));
const expired = ev => { const x = ev.tags.find(t => t[0] === "expiration"); return x && +x[1] < Date.now() / 1000; };
const out = (ws, m) => { const s = JSON.stringify(m); bytesOut += s.length; try { ws.send(s); } catch {} };

const http = createServer((req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "*");
  if (req.method === "OPTIONS") { res.end(); return; }
  if (/nostr\+json/.test(req.headers.accept || "")) {
    res.setHeader("Content-Type", "application/nostr+json");
    res.end(JSON.stringify({ name: "test relay " + port, software: "relay-server.mjs", ...(nip11 && nip11 !== true ? JSON.parse(nip11) : {}) }));
  } else { res.statusCode = 426; res.end("use a websocket"); }
});
const wss = new WebSocketServer({ server: http, maxPayload: 512 * 1024,
  verifyClient: (_, cb) => { if (Date.now() < bannedUntil) { connsRefused++; cb(false, 429, "banned"); } else cb(true); } });
http.listen(port);
wss.on("connection", ws => {
  subs.set(ws, new Map());
  const times = []; let strikes = 0;
  ws.on("message", raw => {
    bytesIn += raw.length;
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (m[0] === "EVENT") {
      const ev = m[1]; events++;
      if (LOG) appendFileSync(LOG, JSON.stringify(ev) + "\n");
      if (rate) {
        const t = Date.now(); times.push(t); while (times.length && times[0] < t - 60000) times.shift();
        if (times.length > rate) {
          refusedRate++; strikes++;
          out(ws, ["OK", ev.id, false, "rate-limited: slow down"]);
          if (strikes >= 3) { bannedUntil = Date.now() + 60000; ws.close(); }
          return;
        }
      }
      if (reject) { out(ws, ["OK", ev.id, false, "blocked: kind not accepted here"]); return; }
      if (wot) { out(ws, ["OK", ev.id, false, "blocked: not in web of trust"]); return; }
      const eph = ev.kind >= 20000 && ev.kind < 30000;
      if (!eph) store.push(ev);
      out(ws, ["OK", ev.id, true, ""]);
      for (const [c, map] of subs) for (const [id, fs] of map) {
        if (!fs.some(f => match(f, ev))) continue;
        if (drop && Math.random() < drop) continue;
        out(c, ["EVENT", id, ev]);
      }
    } else if (m[0] === "REQ") {
      const [, id, ...fs] = m;
      subs.get(ws).set(id, fs);
      for (const f of fs) store.filter(ev => match(f, ev) && !expired(ev)).slice(-(f.limit || 500)).forEach(ev => out(ws, ["EVENT", id, ev]));
      out(ws, ["EOSE", id]);
    } else if (m[0] === "CLOSE") subs.get(ws).delete(m[1]);
  });
  ws.on("close", () => subs.delete(ws));
});
const bye = () => { console.log(JSON.stringify({ port, events, bytesIn, bytesOut, refusedRate, connsRefused })); process.exit(0); };
process.on("SIGTERM", bye); process.on("SIGINT", bye);
console.log("relay on", port);
