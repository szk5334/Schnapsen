/* A small NIP-01 relay for tests: EVENT (answers OK), REQ (kinds, #t, since, limit), CLOSE, EOSE.
 * Stores regular events (honours NIP-40 expiration), forwards ephemeral ones (20000–29999) without storing.
 *
 *   node relay-server.mjs PORT [--drop 0.25] [--reject] [--log FILE]
 *     --drop F    silently drop this fraction of forwards to subscribers (stored copies stay)
 *     --reject    answer OK=false to every event and store/forward nothing
 *     --log FILE  one JSON line per event received (so a test can inspect what a relay sees)
 * Prints byte totals in and out on SIGTERM. */
import { WebSocketServer } from "ws";
import { appendFileSync, writeFileSync } from "node:fs";

const args = process.argv.slice(2);
const port = +args[0];
const opt = k => { const i = args.indexOf(k); return i < 0 ? null : (args[i + 1] && !args[i + 1].startsWith("--") ? args[i + 1] : true); };
const drop = +(opt("--drop") || 0), reject = !!opt("--reject"), LOG = opt("--log");
if (LOG) writeFileSync(LOG, "");
const store = [];
const subs = new Map();
let bytesIn = 0, bytesOut = 0, events = 0;
const match = (f, ev) =>
  (!f.kinds || f.kinds.includes(ev.kind)) &&
  (!f.since || ev.created_at >= f.since) &&
  (!f["#t"] || ev.tags.some(t => t[0] === "t" && f["#t"].includes(t[1])));
const expired = ev => { const x = ev.tags.find(t => t[0] === "expiration"); return x && +x[1] < Date.now() / 1000; };
const out = (ws, m) => { const s = JSON.stringify(m); bytesOut += s.length; ws.send(s); };

const wss = new WebSocketServer({ port, maxPayload: 512 * 1024 });
wss.on("connection", ws => {
  subs.set(ws, new Map());
  ws.on("message", raw => {
    bytesIn += raw.length;
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (m[0] === "EVENT") {
      const ev = m[1]; events++;
      if (LOG) appendFileSync(LOG, JSON.stringify(ev) + "\n");
      if (reject) { out(ws, ["OK", ev.id, false, "blocked: kind not accepted here"]); return; }
      const eph = ev.kind >= 20000 && ev.kind < 30000;
      if (!eph) store.push(ev);
      out(ws, ["OK", ev.id, true, ""]);
      for (const [c, map] of subs) for (const [id, fs] of map) {
        if (!fs.some(f => match(f, ev))) continue;
        if (drop && Math.random() < drop) continue;
        out(c, ["EVENT", id, ev]);
      }
    } else if (m[0] === "REQ") {
      const [, id, ...fs] = m;
      subs.get(ws).set(id, fs);
      for (const f of fs) store.filter(ev => match(f, ev) && !expired(ev)).slice(-(f.limit || 500)).forEach(ev => out(ws, ["EVENT", id, ev]));
      out(ws, ["EOSE", id]);
    } else if (m[0] === "CLOSE") subs.get(ws).delete(m[1]);
  });
  ws.on("close", () => subs.delete(ws));
});
const bye = () => { console.log(JSON.stringify({ port, events, bytesIn, bytesOut })); process.exit(0); };
process.on("SIGTERM", bye); process.on("SIGINT", bye);
console.log("relay on", port);
