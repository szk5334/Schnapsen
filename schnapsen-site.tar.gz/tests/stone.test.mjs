/* Scroll & Stone engine gate: random games in every way to play, the audit on honest games, and the cheats the
 * audit must catch. Usage: node tests/stone.test.mjs [games-per-mode] */
import { deal, play, respond, mainMoves, spiritMoves, cardPlayable, needsCommit, hasNinjas, ninjaStarts,
  ninjaMoves, answer, pruneCaught, commitOf, audit, lightSeat, rng, TEMPLE } from "../app/stone/engine.js";
import { CARDS, SETS, WIND_CARDS, gridFor } from "../app/stone/cards.js";

const N = +(process.argv[2] || 60);
let fails = 0, checks = 0;
const ok = (c, m) => { checks++; if (!c) { fails++; console.log("FAIL", m); } };

/* ---- cards: shape, mirrors, every promo pair is a mirror ---- */
const mirror = g => g.map(([x, y]) => [-x, y]).map(String).sort().join(" ");
const same = g => g.map(String).sort().join(" ");
for (const [a, b] of [["frog", "rabbit"], ["goose", "rooster"], ["horse", "ox"], ["eel", "cobra"], ["fox", "dog"], ["bear", "panda"],
  ["viper", "seasnake"], ["rat", "mouse"], ["iguana", "tanuki"], ["otter", "sable"], ["goat", "sheep"], ["hornet", "centipede"], ["cat", "serow"]])
  ok(mirror(CARDS[a].m) === same(CARDS[b].m), `${a}/${b} are mirrors`);
for (const id of Object.keys(CARDS)) {
  const c = CARDS[id];
  for (const g of [c.m, c.s, c.ma, c.w].filter(Boolean)) ok(g.every(([x, y]) => Math.abs(x) <= 2 && Math.abs(y) <= 2 && (x || y)), `${id} grid in range`);
}
ok(SETS.base.cards.length === 16 && SETS.sensei.cards.length === 16 && SETS.promo.cards.length === 15 && WIND_CARDS.length === 8, "set sizes");

/* ---- a random player that knows its own Ninjas ---- */
function randomGame(opts, seed, cheat = null) {
  const R = rng(seed + ":play");
  const pick = a => a[R() % a.length];
  let st = deal(opts, seed);
  const priv = [null, null], hist = [[], []], commits = [[], []], events = [];
  const salt = () => R().toString(16) + R().toString(16);
  for (const s of [0, 1]) if (needsCommit(st, s)) {
    const starts = ninjaStarts(st, s), n = st.nin[s].live.length, chosen = [];
    while (chosen.length < n) { const c = pick(starts); if (!chosen.some(x => String(x) === String(c))) chosen.push(c); }
    priv[s] = chosen; const sl = salt(); hist[s].push({ ninjas: chosen, salt: sl }); commits[s].push(commitOf(chosen, sl));
  }
  for (let guard = 0; guard < 400 && st.winner == null; guard++) {
    if (st.wait) {
      const s = st.wait.from;
      priv[s] = pruneCaught(st, s, priv[s]);
      let r = answer(st, s, priv[s]);
      if (cheat === "lie-lantern" && s === 1 && "lan" in r) r = { ...r, lan: !r.lan };
      if (cheat === "hide-capture" && s === 1 && r.cap.length) r = { ...r, cap: [] };
      const nx = respond(st, s, r);
      if (!nx) { ok(false, "respond refused an honest answer " + JSON.stringify(r)); return null; }
      events.push({ t: "rs", seat: s, r });
      st = nx;
      priv[s] = pruneCaught(st, s, priv[s]);
      continue;
    }
    const s = st.turn;
    /* every public option */
    const opts2 = [];
    for (const card of st.hand[s]) {
      const wind = CARDS[card].kind === "wind";
      const mm = mainMoves(st, s, card);
      if (wind) {
        if (!mm.length && !spiritMoves(st, s, card).length) continue;
        for (const mv of (mm.length ? mm : [null])) opts2.push({ card, mv, wind: true });
      } else {
        for (const mv of mm) opts2.push({ card, mv });
        if (st.mode === "wind") for (const sp of spiritMoves(st, s, card)) opts2.push({ card, sp });
      }
    }
    let a;
    const anyMain = st.hand[s].some(c => mainMoves(st, s, c).length);
    if (!opts2.length && !(needsCommit(st, s) && hasNinjas(st, s))) a = { card: pick(st.hand[s]), pass: true };
    else if (!opts2.length || (needsCommit(st, s) && !anyMain && hasNinjas(st, s) && R() % 3 === 0)) a = { card: pick(st.hand[s]) };
    else a = { ...pick(opts2) };
    if (a.wind) {
      delete a.wind;
      /* the Spirit after the primary move */
      const after = a.mv ? (() => { const t = JSON.parse(JSON.stringify(st)); const p = t.pieces.find(q => q.id === a.mv.pid); t.pieces = t.pieces.filter(q => !(q.x === a.mv.x && q.y === a.mv.y)); p.x = a.mv.x; p.y = a.mv.y; return t; })() : st;
      const won = a.mv && (st.pieces.some(p => p.s !== s && p.k === "m" && p.x === a.mv.x && p.y === a.mv.y) ||
        (st.pieces.find(p => p.id === a.mv.pid).k === "m" && a.mv.x === TEMPLE[1 - s][0] && a.mv.y === TEMPLE[1 - s][1]));
      const sec = won ? [] : spiritMoves(after, s, a.card);
      if (sec.length) a.sp = pick(sec);
      if (!a.mv && !a.sp) a = { card: a.card, pass: true };
    }
    if (a.pass && st.hand[s].some(c => cardPlayable(st, s, c))) { a = { card: a.card }; }
    if (needsCommit(st, s)) {
      /* the hidden half: maybe move a Ninja (Light's Shadow must if it can), show it if it lands on a piece */
      const tmp = play(st, s, { ...a, nj: "0".repeat(64), show: [] });
      const after = tmp || st;
      let mine = pruneCaught(st, s, priv[s]).slice();
      const live = mine.map((n, i) => (n ? i : -1)).filter(i => i >= 0);
      const mustMove = st.mode === "light" && s !== lightSeat(st);
      const cand = a.pass ? [] : live.flatMap(i => ninjaMoves(after, s, a.card, mine, i).map(t => ({ i, t })));
      const show = [];
      if (cand.length && (mustMove || R() % 2 === 0)) {
        const c = pick(cand); mine[c.i] = c.t;
        if (st.pieces.some(p => p.s !== s && p.x === c.t[0] && p.y === c.t[1]) && !(a.mv && a.mv.x === c.t[0] && a.mv.y === c.t[1])) show.push({ i: c.i, x: c.t[0], y: c.t[1] });
      }
      if (cheat === "lazy-ninja" && s === lightSeat(st) ^ 1 && mustMove && cand.length) mine = pruneCaught(st, s, priv[s]).slice();
      if (cheat === "sneak" && s === 0 && st.mode === "shadow" && show.length) show.length = 0;
      if (!show.length && live.length && st.mode === "shadow" && R() % 9 === 0) {
        const i = pick(live);
        if (!after.pieces.some(p => p.s === s && p.x === mine[i][0] && p.y === mine[i][1])) show.push({ i, x: mine[i][0], y: mine[i][1] });
      }
      const sl = salt();
      a.nj = commitOf(mine, sl);
      if (show.length) a.show = show;
      hist[s].push({ ninjas: mine, salt: sl }); commits[s].push(a.nj);
      priv[s] = mine;
    }
    if (st.nin[s].lant > 0 && st.moved[s] && hasNinjas(st, 1 - s) && (st.mode === "shadow" || (st.mode === "light" && s === lightSeat(st))) && R() % 3 === 0)
      a.lan = { ax: R() % 2 ? "r" : "c", i: R() % 5 };
    const nx = play(st, s, a);
    if (!nx) {
      if (cheat === "sneak") return { st, events, hist, commits, refused: true };
      ok(false, `play refused ${st.mode} ${JSON.stringify(a)}`); return null;
    }
    events.push({ t: "mv", seat: s, a });
    st = nx;
  }
  return { st, events, hist, commits };
}

const modes = [
  { mode: "classic", sets: { base: true } },
  { mode: "classic", sets: { base: true, sensei: true, windmv: true, promo: true } },
  { mode: "classic", sets: { promo: true } },
  ...["std", "m3", "m4", "m5", "p1", "p0"].map(w => ({ mode: "wind", wind: w, sets: { base: true, sensei: true, promo: true } })),
  { mode: "shadow", sets: { base: true, sensei: true } },
  { mode: "light", light: 0, sets: { base: true } },
  { mode: "light", light: 1, sets: { base: true, promo: true } },
];
const tally = {};
for (const o of modes) {
  const key = o.mode + (o.wind ? "/" + o.wind : "") + (o.mode === "light" ? "/L" + o.light : "") + "/" + Object.keys(o.sets).join("+");
  tally[key] = { games: 0, won: 0, how: {}, plies: 0, audits: 0 };
  for (let g = 0; g < N; g++) {
    const seed = key + ":" + g;
    const d0 = deal(o, seed);
    /* deal sanity */
    const cards = [...d0.hand[0], ...d0.hand[1], d0.side];
    ok(new Set(cards).size === 5, key + " five different cards");
    if (o.mode === "wind") ok(cards.filter(c => WIND_CARDS.includes(c)).length === { std: 2, m3: 3, m4: 4, m5: 5, p1: 1, p0: 0 }[o.wind], key + " wind mix");
    if (o.mode === "light") ok(d0.turn === o.light, "Light starts");
    const res = randomGame(o, seed);
    if (!res) continue;
    const t = tally[key];
    t.games++; t.plies += res.st.ply;
    if (res.st.winner != null) { t.won++; t.how[res.st.how] = (t.how[res.st.how] || 0) + 1; }
    const au = audit({ opts: o, seed, events: res.events, hist: res.hist, commits: res.commits });
    ok(au.ok, `${key} honest audit: ${au.why}`);
    if (au.ok) { t.audits++; ok(JSON.stringify(au.final.pieces) === JSON.stringify(res.st.pieces), key + " audit replays to the same board"); }
  }
}
for (const [k, t] of Object.entries(tally)) console.log(k.padEnd(52), `${t.games} games, ${t.won} won ${JSON.stringify(t.how)}, ${(t.plies / Math.max(1, t.games)).toFixed(1)} plies, audits ${t.audits}`);

/* ---- cheats ---- */
let caught = { "lie-lantern": [0, 0], "hide-capture": [0, 0], "lazy-ninja": [0, 0] };
for (const cheat of Object.keys(caught)) {
  const o = cheat === "lazy-ninja" ? { mode: "light", light: 0, sets: { base: true } } : { mode: "shadow", sets: { base: true, sensei: true } };
  for (let g = 0; g < N * 3; g++) {
    const seed = cheat + g;
    const res = randomGame(o, seed, cheat);
    const honest = randomGame(o, seed);
    if (!res || !honest) continue;
    const differs = JSON.stringify(res.events) !== JSON.stringify(honest.events) || JSON.stringify(res.hist) !== JSON.stringify(honest.hist);
    if (!differs) continue;                       // the cheat never came up in this game
    caught[cheat][0]++;
    const au = audit({ opts: o, seed, events: res.events, hist: res.hist, commits: res.commits });
    if (!au.ok) caught[cheat][1]++;
  }
}
for (const [k, [n, c]] of Object.entries(caught)) { console.log(`cheat ${k}: ${c}/${n} caught`); ok(n > 0 && c === n, `every ${k} caught`); }

/* ---- a tampered commitment ---- */
{
  const o = { mode: "shadow", sets: { base: true } };
  const res = randomGame(o, "tamper");
  const h = JSON.parse(JSON.stringify(res.hist));
  const k = h[0].length > 2 ? 2 : 1;
  h[0][k] = { ...h[0][k], ninjas: h[0][k].ninjas.map(n => n && [n[0] === 4 ? 3 : n[0] + 1, n[1]]) };
  ok(!audit({ opts: o, seed: "tamper", events: res.events, hist: h, commits: res.commits }).ok, "rewritten history caught");
}
/* ---- public rule refusals ---- */
{
  const st = deal({ mode: "classic", sets: { base: true } }, "x");
  const s = st.turn, c = st.hand[s][0];
  ok(play(st, 1 - s, { card: st.hand[1 - s][0], mv: mainMoves(st, 1 - s, st.hand[1 - s][0])[0] }) === null, "out of turn refused");
  ok(play(st, s, { card: st.side, mv: { pid: 0, x: 2, y: 2 } }) === null, "side card refused");
  ok(play(st, s, { card: c, pass: true }) === null, "pass with a legal move refused");
  const mv = mainMoves(st, s, c)[0];
  const nx = play(st, s, { card: c, mv });
  ok(nx && nx.side === c && nx.hand[s].includes(st.side) && nx.turn === 1 - s, "card rotation");
}
console.log(fails ? `FAILED ${fails}/${checks}` : `stone engine: all ${checks} checks pass`);
process.exit(fails ? 1 : 0);
