// Duplicate deals (app/dup.js): the same cards again, the other way round.
//   Part A, every deck, house and classic: the duplicate holds exactly the old cards with the hands swapped,
//     the suits renamed only among suits with the same ranks, the same turned card and stock order; and the
//     first deal's moves, mirrored (other seat, renamed card), replay move for move to the mirrored result.
//   Part B, two devices over a fake mesh: either seat can ask; both devices lay out the identical deal; it
//     plays and settles on both; a duplicate can't be duplicated; when the two press different buttons at the
//     same moment, seat 0's choice wins on both devices; a device reloaded mid-duplicate carries on.
//   node dup.test.mjs
const store = new Map();
globalThis.localStorage = { getItem: k => (store.has(k) ? store.get(k) : null), setItem: (k, v) => store.set(k, String(v)), removeItem: k => store.delete(k) };

const { cell } = await import("../app/util.js");
const { openMatch } = await import("../app/mp/match.js");
const { freshBummerl, botAction, SETUP } = await import("../schnapsen/state/reducer.js");
const { reducer, withHouse, houseDeal } = await import("../app/house.js");
const { RULES, other } = await import("../schnapsen/engine/rules.js");
const { ENG } = await import("../schnapsen/engine/core.js");
const { dupDeal, dupPerm, canDup, dupTally, dealValue } = await import("../app/dup.js");

let pass = 0, fail = 0;
const ok = (c, m) => { if (c) pass++; else { fail++; if (fail < 15) console.log("FAIL", m); } };
const key = c => c.rank + "." + c.suit;
const sortKeys = a => a.map(key).sort().join(" ");
const cardsOf = d => [...d.hands[0], ...d.hands[1], ...(d.up ? [d.up] : []), ...d.stock];

/* ------------------------------------------------------------------ Part A: the deal itself */
let mirrored = 0, nt = 0;
for (const variant of ["classic", "22", "24"]) {
  for (const house of [true, false]) {
    for (let g = 0; g < 40; g++) {
      ENG.setVariant(variant);
      let s = freshBummerl({ ...SETUP, bummerlNo: 0, variant }, ["fritzl", "greta"], ["A", "B"], 7, g % 2);
      if (house) s = houseDeal(withHouse(s, { house: true, piles: "up" }));
      const d0 = JSON.parse(JSON.stringify(s)), moves = [];
      for (let guard = 0; guard < 300 && s.phase === "play"; guard++) {
        const a = botAction(s, s.turn).action;
        moves.push(a); s = reducer(s, a);
      }
      ok(s.phase === "scored", "deal finished");
      ok(canDup(s, d0), "a finished deal can be duplicated");
      const base = reducer(s, { type: s.bummerlDone ? "NEW_BUMMERL" : "NEXT_DEAL" });
      const perm = dupPerm(d0);
      const dp = dupDeal(base, d0, perm, s);
      ENG.setVariant(variant);

      // the renaming: a permutation, only among suits holding the same ranks
      const sig = su => cardsOf(d0).filter(c => c.suit === su).map(c => c.rank).sort().join();
      ok(Object.keys(perm).length === 4 && new Set(Object.values(perm)).size === 4, "suits renamed one to one");
      ok(Object.keys(perm).every(su => sig(su) === sig(perm[su])), "suits only swap with suits holding the same ranks");
      if (variant === "22") ok(["H", "S"].every(su => ["H", "S"].includes(perm[su])), "22 deck: the 9 suits stay the 9 suits");

      // the layout: hands swapped, same turned card and stock order, renamed
      const ren = c => c.rank + "." + perm[c.suit];
      ok(dp.dealer === other(d0.dealer) && dp.turn === d0.dealer, "the dealer alternates; the leading hand still leads");
      ok(dp.hands[0].map(key).join() === d0.hands[1].map(ren).join() && dp.hands[1].map(key).join() === d0.hands[0].map(ren).join(), "each seat holds the other's old hand");
      ok(key(dp.up) === ren(d0.up) && dp.stock.map(key).join() === d0.stock.map(ren).join(), "same turned card and stock order");
      ok(new Set(cardsOf(dp).map(c => c.id)).size === cardsOf(d0).length, "ids still unique");
      ok(dp.trump === (house && dp.up.rank === "A" ? null : dp.up.suit), "trumps follow the turned card");
      if (dp.trump === null) nt++;
      ok(dp.dup && dp.dup.of === s.dealNo && dp.dup.lead === other(d0.dealer), "marked as a duplicate of the deal");
      ok(dp.gp.join() === base.gp.join() && dp.dealNo === base.dealNo, "score and deal number as the table had them");

      // the mirror: the old moves, other seat, renamed cards, replay to the mirrored result
      const byKey = Object.fromEntries(cardsOf(dp).map(c => [key(c), c]));
      const byId = Object.fromEntries(cardsOf(d0).map(c => [c.id, c]));
      let t = dp, accepted = true;
      for (const a of moves) {
        const m = { ...a, seat: other(a.seat) };
        if (a.type === "PLAY") m.cardId = byKey[ren(byId[a.cardId])].id;
        if (a.type === "MELD") m.suit = perm[a.suit];
        const n = reducer(t, m);
        if (n === t) { accepted = false; break; }
        t = n;
      }
      ok(accepted && t.phase === "scored", "mirrored moves replay move for move");
      if (accepted && t.phase === "scored") {
        mirrored++;
        ok(t.result.reason === s.result.reason && t.result.winner === other(s.result.winner) && t.result.gp === s.result.gp, "mirrored result");
        ok(t.result.pts[0] === s.result.pts[1] && t.result.pts[1] === s.result.pts[0], "card points mirrored");
        ok([0, 1].every(i => dealValue(t, i) === dealValue(s, other(i))), "each seat's deal value mirrored");
        const tl = dupTally(t);
        ok(tl && tl.sum[0] === 0 && tl.sum[1] === 0, "mirrored play nets out to zero");
        ok(!canDup(t, JSON.parse(JSON.stringify(dp))), "a duplicate can't be duplicated");
        ok(t.sheet[t.sheet.length - 1].dup === s.dealNo, "the sheet marks the duplicate row");
        const after = reducer(t, { type: t.bummerlDone ? "NEW_BUMMERL" : "NEXT_DEAL" });
        ok(!after.dup, "the next deal is an ordinary one");
      }
    }
  }
}
ENG.setVariant("classic");

/* ------------------------------------------------------------------ Part B: two devices */
function pair() {
  const subs = [new Map(), new Map()], joins = [new Set(), new Set()];
  const cids = ["cid-0", "cid-1"];
  const mk = i => ({
    people: cell([]), peerOf: () => "peer",
    send(t, d) {
      const copy = JSON.parse(JSON.stringify(d));
      const deliver = () => { const h = subs[1 - i].get(t); h && h.forEach(f => f(copy, { cid: cids[i] }, "peer")); };
      if (Math.random() < .25) setTimeout(deliver, 1); else setImmediate(deliver);
    },
    on(t, f) { if (!subs[i].has(t)) subs[i].set(t, new Set()); subs[i].get(t).add(f); return () => subs[i].get(t).delete(f); },
    onJoin(f) { joins[i].add(f); return () => joins[i].delete(f); },
    rejoin() { joins[1 - i].forEach(f => f("peer", { cid: cids[i] })); joins[i].forEach(f => f("peer", { cid: cids[1 - i] })); },
  });
  return [mk(0), mk(1), cids];
}
const tick = () => new Promise(r => setImmediate(r));
const pub = s => JSON.stringify([s.trickPts, s.tricksWon, s.meldPts, s.closed, s.turn, (s.trick || []).map(x => x.card.id), s.gp, s.phase, s.hands[0].length, s.hands[1].length]);

async function online(variant, house) {
  const tag = variant + (house ? "h" : "c");
  const cfg = { matchId: "dup-" + tag, seats: [{ cid: "cid-0", name: "Seth" }, { cid: "cid-1", name: "Jamie" }], opts: { target: 99, variant, house, piles: "up", strict: false } };
  const [m0, m1, cids] = pair();
  const open = i => openMatch({ mesh: i ? m1 : m0, code: "D" + tag + i, config: cfg, seat: i, peerCid: cids[1 - i] });   // own storage key per device
  const dev = [open(0), open(1)];
  const views = () => dev.map(d => d.state.get());
  const until = async (f, what, n = 20000) => { for (let i = 0; i < n; i++) { const v = views(); if (v[0] && v[1] && f(v)) return v; await tick(); } ok(false, tag + ": timed out waiting for " + what); return null; };
  const settled = (v, n) => v[0].n === n && v[1].n === n && v[0].s && v[1].s && !v[0].waitingCards && !v[1].waitingCards && pub(v[0].s) === pub(v[1].s);

  /* play the deal on screen to the end: random legal moves, or the given list (as the given seat-mapping says) */
  async function playOut(n, script) {
    let i = 0;
    for (let guard = 0; guard < 400; guard++) {
      const v = await until(w => settled(w, n), "a settled deal " + n); if (!v) return false;
      const s = v[0].s;
      if (s.phase === "scored") return true;
      const t = s.turn, me = v[t].s;
      ENG.setVariant(variant);
      let a;
      if (script) { a = script[i++]; if (!a) { ok(false, tag + ": script ran out"); return false; } }
      else {
        const legal = RULES.legalCards(me, t).filter(c => !c.back);
        const melds = RULES.meldOptions(me, t);
        a = melds.length && Math.random() < .5 ? { type: "MELD", seat: t, suit: melds[0].suit }
          : RULES.canClose(me, t) && Math.random() < .08 ? { type: "CLOSE", seat: t }
          : { type: "PLAY", seat: t, cardId: legal[(Math.random() * legal.length) | 0].id };
      }
      const before = pub(s);
      dev[a.seat].act(a);
      await until(w => w[0].s && w[1].s && pub(w[0].s) === pub(w[1].s) && (pub(w[0].s) !== before || w[0].s.phase === "scored"), "the move to land");
    }
    return false;
  }

  // deal 1, ordinary
  ok(await playOut(1), tag + ": deal 1 played");
  let v = await until(w => w[0].audit && w[1].audit, "deal 1 audit");
  const d0 = v[0].audit.d0, moves1 = v[0].audit.moves, s1 = v[0].s;
  ok(v[0].audit.ok && v[1].audit.ok, tag + ": deal 1 audited");

  // seat 1 asks for the duplicate
  dev[1].act({ type: "DUPLICATE_DEAL" });
  v = await until(w => settled(w, 2), "the duplicate");
  if (!v) return;
  const [a, b] = [v[0].s, v[1].s];
  ok(a.dup && b.dup && a.dup.of === s1.dealNo, tag + ": both devices are in the duplicate of deal 1");
  ok(JSON.stringify([a.hands, a.up, a.stock, a.trump]) === JSON.stringify([b.hands, b.up, b.stock, b.trump]), tag + ": both devices laid out the same deal");
  ok(sortKeys(a.hands[0].map(c => ({ rank: c.rank, suit: "x" }))) === sortKeys(d0.hands[1].map(c => ({ rank: c.rank, suit: "x" }))), tag + ": seat 0 holds seat 1's old ranks");
  // the renaming, read off the layout (dupDeal maps card for card in order)
  const perm = {};
  d0.hands[other(d0.dealer)].forEach((c, k) => (perm[c.suit] = a.hands[d0.dealer][k].suit));
  d0.hands[d0.dealer].forEach((c, k) => (perm[c.suit] = a.hands[other(d0.dealer)][k].suit));
  d0.stock.forEach((c, k) => (perm[c.suit] = a.stock[k].suit)); perm[d0.up.suit] = a.up.suit;
  ok(d0.stock.map(c => c.rank + "." + perm[c.suit]).join() === a.stock.map(key).join(), tag + ": stock in the same order, renamed");
  // replay deal 1 mirrored through the two devices
  const byKey = Object.fromEntries(cardsOf(a).map(c => [key(c), c]));
  const byId = Object.fromEntries(cardsOf(d0).map(c => [c.id, c]));
  const script = moves1.map(m => {
    const x = { ...m, seat: other(m.seat) };
    if (m.type === "PLAY") { const c = byId[m.cardId]; x.cardId = byKey[c.rank + "." + perm[c.suit]].id; }
    if (m.type === "MELD") x.suit = perm[m.suit];
    return x;
  });
  ok(await playOut(2, script), tag + ": the duplicate played");
  v = await until(w => w[0].audit && w[1].audit, "duplicate audit");
  const e = v[0].s;
  ok(v[0].audit.ok && v[1].audit.ok && v[0].audit.dup, tag + ": duplicate settled on both devices");
  ok(e.result.winner === other(s1.result.winner) && e.result.gp === s1.result.gp, tag + ": mirrored play, mirrored result");
  const tl = dupTally(e);
  ok(tl && tl.sum.join() === "0,0", tag + ": tally nets out");
  ok(v[0].s.gp.join() === v[1].s.gp.join(), tag + ": scores agree");

  // a duplicate can't be duplicated: the request deals an ordinary hand
  dev[0].act({ type: "DUPLICATE_DEAL" });
  v = await until(w => settled(w, 3), "deal 3");
  ok(v && !v[0].s.dup && !v[1].s.dup, tag + ": duplicating a duplicate deals a fresh hand");
  ok(await playOut(3), tag + ": deal 3 played");
  await until(w => w[0].audit && w[1].audit, "deal 3 audit");

  // the race: seat 0 says Next, seat 1 says Duplicate, in the same instant -> seat 0's choice on both
  dev[0].act({ type: "NEXT_DEAL" }); dev[1].act({ type: "DUPLICATE_DEAL" });
  v = await until(w => settled(w, 4), "deal 4");
  ok(v && !v[0].s.dup && !v[1].s.dup && key(v[0].s.up) === key(v[1].s.up), tag + ": race (seat 0 next, seat 1 duplicate) -> an ordinary deal on both");
  ok(await playOut(4), tag + ": deal 4 played");
  await until(w => w[0].audit && w[1].audit, "deal 4 audit");

  // the other race: seat 0 says Duplicate, seat 1 says Next -> a duplicate on both
  dev[1].act({ type: "NEXT_DEAL" }); dev[0].act({ type: "DUPLICATE_DEAL" });
  v = await until(w => settled(w, 5), "deal 5");
  ok(v && v[0].s.dup && v[1].s.dup && v[0].s.dup.of === 4, tag + ": race (seat 0 duplicate, seat 1 next) -> the duplicate on both");

  // reload seat 1 halfway through the duplicate
  for (let k = 0; k < 3; k++) {
    const w = await until(x => settled(x, 5), "deal 5 settled");
    const s = w[0].s; if (s.phase !== "play") break;
    const t = s.turn; ENG.setVariant(variant);
    const legal = RULES.legalCards(w[t].s, t);
    const before = pub(s);
    dev[t].act({ type: "PLAY", seat: t, cardId: legal[0].id });
    await until(x => pub(x[0].s) === pub(x[1].s) && pub(x[0].s) !== before, "move");
  }
  dev[1].close();
  dev[1] = open(1);
  m1.rejoin();
  v = await until(w => settled(w, 5), "after the reload");
  ok(v && v[1].s.dup && JSON.stringify(v[0].s.hands) === JSON.stringify(v[1].s.hands), tag + ": the reloaded device is back in the same duplicate");
  ok(await playOut(5), tag + ": the duplicate finished after the reload");
  v = await until(w => w[0].audit && w[1].audit, "deal 5 audit");
  ok(v && v[0].audit.ok && v[1].audit.ok && v[0].s.gp.join() === v[1].s.gp.join(), tag + ": settled and agreed after the reload");
  dev.forEach(d => d.close());
}
const t0 = Date.now();
for (const [variant, house] of [["classic", true], ["classic", false], ["22", true], ["24", false]]) await online(variant, house);

console.log(`${fail ? "FAILED" : "ok"}: dup ${pass}/${pass + fail} (${mirrored} deals mirrored move for move, ${nt} at no trumps; 4 two-device runs), ${Date.now() - t0} ms online`);
process.exit(fail ? 1 : 0);
