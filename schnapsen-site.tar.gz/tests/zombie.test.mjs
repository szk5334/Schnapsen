// Dead connections that look alive, a network that comes back, and a goodbye that leaves synchronously.
//
//   7831-7833, three relays. Their connections are made to go dead without closing (SIGUSR2): what a phone sees after
//        hopping from wifi to cell. Before build 2026-10-26.4 nothing ever noticed and the table stalled for good.
//   Then 7831 restarts (down 35 s): a relay that worked earlier must not be shunned for 10 minutes, and comes back
//   on its own. Then it is down again and the page is told the network is back: it must reconnect at once.
//   Last, Jamie's page closes: her goodbye must be on the wire before leave() returns.
// Run from tests/:  node zombie.test.mjs      (needs `ws` resolvable, e.g. a node_modules symlink)
import { spawn } from "node:child_process";

const mem = new Map();
globalThis.localStorage = {
  getItem: k => (mem.has(k) ? mem.get(k) : null), setItem: (k, v) => mem.set(k, String(v)),
  removeItem: k => mem.delete(k), key: i => [...mem.keys()][i], get length() { return mem.size; },
};
const { relayP2P } = await import("../app/net/relay.js");
const { openMesh } = await import("../app/net/mesh.js");

const sleep = ms => new Promise(r => setTimeout(r, ms));
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) { pass++; console.log("  ok  ", m); } else { fail++; console.log("  FAIL", m); } };
async function until(f, ms, step = 50) { const t = Date.now(); while (Date.now() - t < ms) { if (await f()) return true; await sleep(step); } return false; }
/* Three relays, all going dead or down together: what a phone hopping networks sees. (One relay alone would
 * also test the send budget: since build .5 a page sends at most 2 events at once to any one relay.) */
const PORTS = [7831, 7832, 7833];
const procs = {};
function relay(port) {
  const proc = spawn(process.execPath, ["relay-server.mjs", String(port)], { stdio: ["ignore", "pipe", "inherit"] });
  procs[port] = proc;
  return new Promise(res => proc.stdout.once("data", () => res(proc)));
}
const relays = () => Promise.all(PORTS.map(relay));
const signal = sig => PORTS.forEach(p => procs[p].kill(sig));
await relays();

const APP = "zt-" + Math.random().toString(36).slice(2, 8);
const dev = (cid, name) => { const p2p = relayP2P({ house: [], relays: PORTS.map(p => "ws://localhost:" + p), p2pAppId: APP }); return { p2p, mesh: openMesh(p2p, "table-ZOMB", { presence: { cid, name } }) }; };
const X = dev("cid-x", "Seth"), Y = dev("cid-y", "Jamie");
ok(await until(() => X.mesh.people.get().some(p => p.cid === "cid-y") && Y.mesh.people.get().some(p => p.cid === "cid-x"), 15000), "each sees the other");
const got = [];
Y.mesh.on("move", d => got.push(d));
X.mesh.send("move", 0);
ok(await until(() => got.length === 1, 10000), "a message gets through");

console.log("every relay's connections go dead without closing");
signal("SIGUSR2");
await sleep(300);
let t0 = Date.now();
for (let i = 1; i <= 5; i++) X.mesh.send("move", i);
const back = await until(() => got.length === 6, 90000);
ok(back, `5 messages sent into the dead connection arrive anyway (${got.length - 1}/5, ${((Date.now() - t0) / 1000).toFixed(1)} s)`);
ok(new Set(got).size === got.length, "no duplicates delivered");
const notes = X.p2p.diag().errors.map(e => e.error).join(" | ");
ok(/stopped answering/.test(notes), "the dead connection was noticed and replaced");
t0 = Date.now();
Y.mesh.send("move", 100);
const gotX = [];
X.mesh.on("move", d => gotX.push(d));
Y.mesh.send("move", 101);
ok(await until(() => gotX.includes(101), 40000), `and the other way too (${((Date.now() - t0) / 1000).toFixed(1)} s)`);

console.log("the relays go down for 35 s (a restart), then come back");
signal("SIGTERM"); await sleep(35000);
const states = d => d.p2p.diag().relays.map(r => r.state);
ok(!states(X).includes("unreachable"), `relays that worked earlier aren't shunned after a short outage (${states(X).join(",")})`);
await relays();
t0 = Date.now();
ok(await until(() => [X, Y].every(d => states(d).every(s => s === "open")), 75000, 200), `both reconnect on their own (${((Date.now() - t0) / 1000).toFixed(1)} s)`);
X.mesh.send("move", 150);
ok(await until(() => got.includes(150), 30000), "messages flow again");

console.log("the phone loses its network, then gets it back");
signal("SIGTERM"); await sleep(8000);
await relays();
t0 = Date.now();
X.p2p.wake(true); Y.p2p.wake(true);              // what the "online" event does in a browser
ok(await until(() => [X, Y].every(d => states(d).every(s => s === "open")), 10000), `the network coming back reconnects at once (${((Date.now() - t0) / 1000).toFixed(1)} s)`);
X.mesh.send("move", 200);
ok(await until(() => got.includes(200), 30000), "messages flow again");

console.log("Jamie's page closes");
await sleep(2500);
const sends = [];
const WS = globalThis.WebSocket, orig = WS.prototype.send;
WS.prototype.send = function (m) { sends.push(String(m)); return orig.call(this, m); };
Y.mesh.leave();
WS.prototype.send = orig;
ok(sends.some(m => m.startsWith('["EVENT"')), `the goodbye is on the wire before leave() returns (${sends.length} frame(s))`);
t0 = Date.now();
ok(await until(() => !X.mesh.people.get().some(p => p.cid === "cid-y"), 15000), `Seth sees her go (${((Date.now() - t0) / 1000).toFixed(1)} s)`);

console.log(`\n${pass} passed, ${fail} failed`);
signal("SIGTERM");
process.exit(fail ? 1 : 0);
