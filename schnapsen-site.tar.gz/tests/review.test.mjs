// The post-deal review: bot-vs-bot deals recorded face up, then reviewed.
// Checks: same seed -> same review; a noisy bot gets flagged more than a strong one; the exact endgame
// agrees with an independent brute force; and it reports how long a review takes.
//   node review.test.mjs [deals=24] [variant=classic] [house=1]
import { ENG } from "../schnapsen/engine/core.js";
import { freshBummerl, botAction, SETUP } from "../schnapsen/state/reducer.js";
import { reducer, withHouse, houseDeal } from "../app/house.js";
import { review, exactValue, seedOf, TUNE } from "../app/review.js";
import { RULES, isStrict } from "../schnapsen/engine/rules.js";

const N = +(process.argv[2] || 24), variant = ENG.normVariant(process.argv[3] || "classic"), house = process.argv[4] !== "0";
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) pass++; else { fail++; console.log("FAIL " + m); } };

/* Play one deal between two bots, recording the face-up start and every action. */
function playDeal(brains, dealer) {
  ENG.setVariant(variant);
  let s = houseDeal(withHouse(freshBummerl({ ...SETUP, variant, bummerlNo: 0 }, brains, ["A", "B"], 7, dealer), { house }));
  const d0 = JSON.parse(JSON.stringify(s)), moves = [];
  for (let g = 0; g < 200 && s.phase === "play"; g++) {
    const dec = botAction(s, s.turn);
    if (!dec || !dec.action) break;
    const n = reducer(s, dec.action);
    if (n === s) break;
    moves.push(dec.action); s = n;
  }
  return { d0, moves, s };
}

const flagged = [0, 0], loss = [0, 0], times = [];
let decisions = 0;
for (let k = 0; k < N; k++) {
  // seat 0 = greta (strong), seat 1 = poldi (noisy, never closes)
  const { d0, moves, s } = playDeal(["greta", "poldi"], k % 2);
  const seed = seedOf(JSON.stringify(moves));
  const t0 = performance.now();
  const r = review(d0, moves, { house, variant, seed });
  times.push(performance.now() - t0);
  decisions += r.decisions;
  if (k < 3) {
    const r2 = review(d0, moves, { house, variant, seed });
    ok(JSON.stringify(r) === JSON.stringify(r2), "same seed gave a different review (deal " + k + ")");
  }
  for (const sIdx of [0, 1]) { flagged[sIdx] += r.bySeat[sIdx].count; loss[sIdx] += r.bySeat[sIdx].loss; }
  for (const p of r.points) {
    ok(p.loss >= TUNE.FLAG - 1e-9, "a shown point costs less than the bar");
    ok(p.best.value >= p.chosen.value, "best worse than chosen");
  }
  ok(r.points.length <= 5, "more than five turning points");
}
times.sort((a, b) => a - b);
console.log(`deals ${N} (${variant}${house ? ", house" : ""}): ${decisions} decisions reviewed`);
console.log(`ms per review: median ${times[N >> 1].toFixed(0)}, worst ${times[N - 1].toFixed(0)}`);
console.log(`flagged: strong ${flagged[0]} (${loss[0].toFixed(1)} gp) · noisy ${flagged[1]} (${loss[1].toFixed(1)} gp)`);
if (N >= 10) ok(flagged[1] > flagged[0], "the noisy bot should be flagged more than the strong one");   // needs a sample

/* The exact endgame against a brute force with no memo at all, on random strict positions. */
let checked = 0;
for (let k = 0; k < 60; k++) {
  const { d0, moves } = playDeal(["poldi", "poldi"], k % 2);
  ENG.setVariant(variant);
  let d = JSON.parse(JSON.stringify(d0));
  for (const a of moves) {
    if (d.phase !== "play") break;
    if (isStrict(d) && d.hands[0].length + d.hands[1].length <= 8) {
      const v = exactValue(d, d.turn, house), b = brute(d, d.turn);
      ok(v === b, `exact endgame ${v} vs brute force ${b}`); checked++; break;
    }
    if (a.type === "PLAY") RULES.play(d, a.seat, a.cardId, {}); else if (a.type === "MELD") RULES.meld(d, a.seat, a.suit, {});
    else if (a.type === "EXCHANGE") RULES.exchange(d, a.seat); else if (a.type === "CLOSE") RULES.close(d, a.seat);
  }
}
function brute(d, me) {
  if (d.phase !== "play") return d.result ? (house && d.result.reason === "exhausted" ? 0 : d.result.winner === me ? d.result.gp : -d.result.gp) : 0;
  const p = d.turn, vals = [];
  const opts = [];
  if (!d.trick.length && !d.meldSuit) for (const m of RULES.meldOptions(d, p)) opts.push(x => RULES.meld(x, p, m.suit, {}));
  for (const c of RULES.legalCards(d, p)) opts.push(x => RULES.play(x, p, c.id, {}));
  for (const f of opts) vals.push(brute(f(JSON.parse(JSON.stringify(d))), me));
  return p === me ? Math.max(...vals) : Math.min(...vals);
}
console.log(`exact endgame checked against brute force: ${checked} positions`);
console.log(fail ? `review: ${fail} FAILED, ${pass} ok` : `review: all ${pass} ok`);
process.exit(fail ? 1 : 0);
