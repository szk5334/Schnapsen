// The house relays: the first one carries everything and the public relays stay all but silent; when it dies the
// second takes over (still nothing on public relays); when both are down the game carries on over the public
// ones; when they come back, traffic returns to the first.
//
//   7841 house A, 7844 house B (in that order) · 7842, 7843 public relays (small budgets). Two devices, real
//   deals at a quick pace.
// Run from tests/:  node house.relay.test.mjs      (needs `ws` resolvable, e.g. a node_modules symlink)
import { spawn } from "node:child_process";
import { readFileSync } from "node:fs";

const mem = new Map();
globalThis.localStorage = {
  getItem: k => (mem.has(k) ? mem.get(k) : null), setItem: (k, v) => mem.set(k, String(v)),
  removeItem: k => mem.delete(k), key: i => [...mem.keys()][i], get length() { return mem.size; },
};
const { relayP2P } = await import("../app/net/relay.js");
const { openMesh } = await import("../app/net/mesh.js");
const { openMatch } = await import("../app/mp/match.js");
const { RULES } = await import("../schnapsen/engine/rules.js");

const sleep = ms => new Promise(r => setTimeout(r, ms));
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) { pass++; console.log("  ok  ", m); } else { fail++; console.log("  FAIL", m); } };
const PORTS = [7841, 7844, 7842, 7843], HOUSES = ["ws://localhost:7841", "ws://localhost:7844"];
const LOG = p => `/tmp/sx-house-${p}.log`;
const procs = {};
function relay(port) {
  const pr = spawn(process.execPath, ["relay-server.mjs", String(port), "--log", LOG(port)], { stdio: ["ignore", "pipe", "inherit"] });
  procs[port] = pr;
  return new Promise(res => pr.stdout.once("data", () => res(pr)));
}
const events = () => PORTS.map(p => { try { return readFileSync(LOG(p), "utf8").split("\n").filter(Boolean).length; } catch { return 0; } });
for (const p of PORTS) await relay(p);

const APP = "house-" + Math.random().toString(36).slice(2, 8);
const config = { matchId: "m1", seats: [{ cid: "cid-x", name: "Seth" }, { cid: "cid-y", name: "Jamie" }], opts: { target: 7, variant: "classic", strict: false } };
function device(name, cid, seat) {
  const p2p = relayP2P({ relays: [7842, 7843].map(p => "ws://localhost:" + p), house: HOUSES, p2pAppId: APP });
  const mesh = openMesh(p2p, "table-HOUSE", { presence: { cid, name } });
  const d = { p2p, mesh, seat };
  d.match = openMatch({ mesh, code: name, config, seat, peerCid: seat === 0 ? "cid-y" : "cid-x" });
  return d;
}
const X = device("X", "cid-x", 0), Y = device("Y", "cid-y", 1);
let deals = 0;
async function step() {
  for (const dv of [X, Y]) {
    const v = dv.match.state.get(); if (!v.s || v.waitingCards || v.error) continue;
    if (v.s.phase === "scored" && v.audit) { if (dv.seat === 0 && Y.match.state.get().audit) { dv.match.act({ type: "NEXT_DEAL" }); deals++; return true; } continue; }
    if (v.s.phase !== "play" || v.s.turn !== dv.seat) continue;
    const legal = RULES.legalCards(v.s, dv.seat).filter(c => !c.back); if (!legal.length) continue;
    dv.match.act({ type: "PLAY", seat: dv.seat, cardId: legal[0].id }); return true;
  }
  return false;
}
async function play(n, ms) { const t = Date.now(); while (deals < n && Date.now() - t < ms) { await step(); await sleep(250); } return (Date.now() - t) / 1000; }

const stateOf = (dv, url) => (dv.p2p.diag().relays.find(r => r.url === url) || {}).state;
async function phase(label, target, ms, check) {
  const e0 = events(); const secs = await play(target, ms); const e1 = events();
  const d = e1.map((x, i) => x - e0[i]);
  ok(deals >= target, `${label}: deals to ${target} in ${secs.toFixed(0)} s`);
  check(d);
}
// events() is in PORTS order: [A, B, public1, public2]
console.log("both house relays up");
await sleep(3000);
await phase("house A carries it", 2, 180000, d => ok(d[0] > 40 && d[1] + d[2] + d[3] <= 4, `house A ${d[0]}, house B ${d[1]}, public ${d[2]} + ${d[3]}`));

console.log("house A dies mid-deal");
await play(3, 3000);
procs[7841].kill("SIGTERM"); await sleep(500);
await phase("house B takes over", 4, 300000, d => ok(d[1] > 20 && d[2] + d[3] <= 6, `house B ${d[1]}, public ${d[2]} + ${d[3]}`));

console.log("house B dies too");
await play(5, 3000);
procs[7844].kill("SIGTERM"); await sleep(500);
await phase("public relays carry it", 6, 600000, d => ok(d[2] + d[3] > 10, `public ${d[2]} + ${d[3]}`));

console.log("both come back");
await relay(7841); await relay(7844);
const back = Date.now();
while (Date.now() - back < 90000 && ![X, Y].every(dv => HOUSES.every(u => stateOf(dv, u) === "open"))) await sleep(200);
ok([X, Y].every(dv => HOUSES.every(u => stateOf(dv, u) === "open")), `reconnected to both house relays (${((Date.now() - back) / 1000).toFixed(1)} s)`);
await sleep(70000);                                    // heartbeats carry the new relay lists both ways
await phase("back on house A", 8, 300000, d => ok(d[0] > 40 && d[1] + d[2] + d[3] <= 6, `house A ${d[0]}, house B ${d[1]}, public ${d[2]} + ${d[3]}`));

const errs = [X, Y].map(dv => dv.match.state.get().error).filter(Boolean);
ok(!errs.length, "no match errors" + (errs.length ? ": " + errs.join("; ") : ""));
console.log(`\n${pass} passed, ${fail} failed`);
for (const p of PORTS) procs[p].kill("SIGTERM");
process.exit(fail ? 1 : 0);
