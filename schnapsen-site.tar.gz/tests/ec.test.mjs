// The curve shuffle: wasm and JavaScript multiply give identical bytes; locks commute and undo; card points are
// distinct and valid; bad points and keys are refused; a full four-pass deck opens and audits; tampering fails.
import { ready, engine, _forceJs, mul, randKey, inv, mulK, kHex, kFrom, cardPoint, decoder, N } from "../app/mp/ec.js";
import { pass1, pass2, pass3, pass4, open, audit } from "../app/mp/deck.js";
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) pass++; else { fail++; console.log("FAIL", m); } };
const eng = await ready;
ok(eng === "wasm" && engine() === "wasm", "the wasm multiplier loads under Node: " + eng);

// wasm and JS agree, point by point
let agree = 0;
for (let i = 0; i < 40; i++) {
  const P = cardPoint(i % 24), k = randKey();
  const w = mul(P, k); _forceJs(true); const j = mul(P, k); _forceJs(false);
  if (w === j) agree++;
}
ok(agree === 40, `wasm and JavaScript give the same point (${agree}/40)`);
ok(engine() === "wasm", "wasm restored after the comparison");

// algebra
const P = cardPoint(3), a = randKey(), b = randKey();
ok(mul(mul(P, a), b) === mul(mul(P, b), a), "locks commute");
ok(mul(mul(mul(P, a), b), mulK(inv(a), inv(b))) === P, "unlocking with both keys gives the card back");
ok(mul(mul(P, a), mulK(inv(a), b)) === mul(P, b), "re-locking in one multiplication");
const pts = Array.from({ length: 24 }, (_, i) => cardPoint(i));
ok(new Set(pts).size === 24 && pts.every(h => /^0[23][0-9a-f]{64}$/.test(h)), "24 distinct card points, compressed");
ok(cardPoint(5) === cardPoint(5) && decoder(24)(cardPoint(17)) === 17 && decoder(24)(mul(P, a)) === -1, "decoder");

// refusals
const throws = f => { try { f(); return false; } catch { return true; } };
ok(throws(() => mul("02" + "0".repeat(64), a)), "a non-point is refused (wasm)");
_forceJs(true); ok(throws(() => mul("02" + "0".repeat(64), a)), "a non-point is refused (JS)"); _forceJs(false);
ok(throws(() => mul("04" + "1".repeat(64), a)) && throws(() => mul(P.slice(0, 60), a)), "malformed hex refused");
ok(throws(() => kFrom("0")) && throws(() => kFrom(N.toString(16))) && throws(() => kFrom("xyz")) && kFrom(kHex(a)) === a, "keys range-checked");
let inRange = true; for (let i = 0; i < 200; i++) { const k = randKey(); if (k <= 0n || k >= N) inRange = false; } ok(inRange, "random keys in [1, n-1]");

// a whole deck, both engines
for (const js of [false, true]) {
  _forceJs(js);
  const n = 22;
  const r1 = pass1(n), r2 = pass2(r1.out), r3 = pass3(r2.out, r1.secret.a), r4 = pass4(r3.out, r2.secret.b);
  const rec = { l1: r1.out, l2: r2.out, l3: r3.out, l4: r4.out, a: r1.secret.a, b: r2.secret.b, ak: r3.secret.ak, bk: r4.secret.bk };
  const opened = r4.out.map((_, j) => open(r4.out, j, r3.secret.ak[j], r4.secret.bk[j], n));
  ok(new Set(opened).size === n && !opened.includes(-1), `${js ? "JS" : "wasm"}: every position opens to a different card`);
  const A = audit(rec, n);
  ok(A.ok && A.deck.join() === opened.join(), `${js ? "JS" : "wasm"}: audit passes and agrees with the opened cards`);
  ok(open(r4.out, 0, r3.secret.ak[1], r4.secret.bk[0], n) === -1, "a wrong key opens nothing");
  ok(JSON.stringify(r1.out).length < 1600, "a pass of 22 cards is under 1.6 KB: " + JSON.stringify(r1.out).length);
  const bad = k => ({ ...rec, [k]: rec[k].slice() });
  let t = bad("l2"); t.l2[2] = t.l2[3]; ok(!audit(t, n).ok, "pass 2 with a repeated card fails");
  t = bad("l3"); t.l3[5] = mul(t.l3[5], 2n); ok(!audit(t, n).ok, "pass 3 tampered fails");
  t = bad("l4"); t.l4[0] = t.l4[1]; ok(!audit(t, n).ok, "pass 4 tampered fails");
  t = bad("ak"); t.ak[4] = kHex(randKey()); ok(!audit(t, n).ok, "a wrong published key fails");
  ok(!audit({ ...rec, b: kHex(randKey()) }, n).ok, "a wrong lock fails");
}
_forceJs(false);
// speed, for the record
const t0 = performance.now(); for (let i = 0; i < 200; i++) mul(P, a); const tw = (performance.now() - t0) / 200;
_forceJs(true); const t1 = performance.now(); for (let i = 0; i < 50; i++) mul(P, a); const tj = (performance.now() - t1) / 50; _forceJs(false);
console.log(`${pass} passed, ${fail} failed — curve shuffle (multiply: wasm ${tw.toFixed(2)} ms, JS ${tj.toFixed(2)} ms)`);
process.exit(fail ? 1 : 0);
