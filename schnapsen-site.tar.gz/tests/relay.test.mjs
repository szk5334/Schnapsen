// Two devices playing real deals through local Nostr relays — the production transport, end to end.
//
//   7801 well-behaved      7802 drops 30% of what it forwards      7803 web of trust: "blocked: not in web of trust"
//   7804 rate limit: 30 events/min per connection, three strikes → closes and refuses connections for 60 s
//   7805 publishes NIP-11 rules saying a login is required (so it must never be written to)
//
// Checks: presence both ways; broadcast + private messages; full deals with the shuffle, key gifts and the
// end-of-deal audit; then relay 1 is killed mid-game (only the lossy relay is left), comes back, and one
// device "reloads" (new page, same saved game) and later goes away while the other plays on.
// Run from tests/:  node relay.test.mjs      (needs `ws` resolvable, e.g. a node_modules symlink)
import { spawn } from "node:child_process";

const mem = new Map();
globalThis.localStorage = {
  getItem: k => (mem.has(k) ? mem.get(k) : null), setItem: (k, v) => mem.set(k, String(v)),
  removeItem: k => mem.delete(k), key: i => [...mem.keys()][i], get length() { return mem.size; },
};

const { relayP2P } = await import("../app/net/relay.js");
const { openMesh } = await import("../app/net/mesh.js");
const { openMatch } = await import("../app/mp/match.js");
const { RULES } = await import("../schnapsen/engine/rules.js");

const sleep = ms => new Promise(r => setTimeout(r, ms));
const PORTS = [7801, 7802, 7803, 7804, 7805];
const URLS = PORTS.map(p => "ws://localhost:" + p);
const procs = {};
function relay(port, extra = []) {
  const p = spawn(process.execPath, ["relay-server.mjs", String(port), ...extra], { stdio: ["ignore", "pipe", "inherit"] });
  p.stats = new Promise(res => { let buf = ""; p.stdout.on("data", d => { buf += d; }); p.on("exit", () => { const l = buf.trim().split("\n").pop(); try { res(JSON.parse(l)); } catch { res(null); } }); });
  procs[port] = p;
  return new Promise(res => p.stdout.once("data", () => res(p)));
}
const kill = async port => { const p = procs[port]; p.kill("SIGTERM"); return p.stats; };

let pass = 0, fail = 0;
const ok = (c, m) => { if (c) { pass++; console.log("  ok  ", m); } else { fail++; console.log("  FAIL", m); } };
async function until(f, ms, step = 50) { const t = Date.now(); while (Date.now() - t < ms) { if (await f()) return true; await sleep(step); } return false; }

await relay(7801); await relay(7802, ["--drop", "0.3"]); await relay(7803, ["--wot"]);
await relay(7804, ["--rate", "30"]); await relay(7805, ["--nip11", JSON.stringify({ limitation: { auth_required: true } })]);

const APP = "test-" + Math.random().toString(36).slice(2, 8);
const config = { matchId: "m1", seats: [{ cid: "cid-x", name: "Seth" }, { cid: "cid-y", name: "Jamie" }], opts: { target: 7, variant: "classic", strict: false } };
function device(name, cid, seat) {
  const p2p = relayP2P({ relays: URLS, p2pAppId: APP });
  const mesh = openMesh(p2p, "table-TEST", { presence: { cid, name } });
  const d = { name, cid, seat, p2p, mesh, match: null };
  d.start = () => { d.match = openMatch({ mesh, code: name, config, seat, peerCid: seat === 0 ? "cid-y" : "cid-x" }); };
  d.stop = () => { if (d.match) d.match.close(); mesh.leave(); };
  return d;
}

/* ---------------- 1. presence and messages ---------------- */
console.log("presence and messages");
let X = device("X", "cid-x", 0), Y = device("Y", "cid-y", 1);
ok(await until(() => X.mesh.people.get().some(p => p.cid === "cid-y") && Y.mesh.people.get().some(p => p.cid === "cid-x"), 15000), "each sees the other within 15 s");
const gotB = [], gotP = [];
Y.mesh.on("hello", d => gotB.push(d)); Y.mesh.on("secret", d => gotP.push(d));
for (let i = 0; i < 10; i++) X.mesh.send("hello", i);
for (let i = 0; i < 10; i++) X.mesh.send("secret", i, X.mesh.peerOf("cid-y"));
ok(await until(() => gotB.length === 10 && gotP.length === 10, 60000), `a burst of 10 broadcast + 10 private arrives within the send budgets (${gotB.length}/${gotP.length})`);
ok(new Set(gotB).size === 10 && new Set(gotP).size === 10, "no duplicates delivered");
const st = X.p2p.diag().relays.reduce((a, r) => (a[r.url.slice(-4)] = r.state, a), {});
ok(st["7803"] === "off", `the web-of-trust relay is set aside after its first refusal (${st["7803"]})`);
ok(st["7805"] === "off", `the login-only relay is never used, from its published rules (${st["7805"]})`);

/* ---------------- 2. deals ---------------- */
X.start(); Y.start();
let dev = () => [X, Y];
let deals = 0, audits = 0, steps = 0, waits = [];
async function play(target, until_ms, hook) {
  const t0 = Date.now(); let lastMove = Date.now();
  while (deals < target && Date.now() - t0 < until_ms) {
    await sleep(20);
    if (hook && await hook()) continue;
    const v = dev().map(d => d.match && d.match.state.get());
    if (!v[0] || !v[1] || !v[0].s || !v[1].s) continue;
    if (v[0].error || v[1].error) throw new Error("device error: " + (v[0].error || v[1].error));
    if (v[0].n !== v[1].n) continue;
    const [s0, s1] = [v[0].s, v[1].s];
    if (s0.phase === "scored" && s1.phase === "scored") {
      if (!v[0].audit || !v[1].audit) continue;
      if (!v[0].audit.ok || !v[1].audit.ok) throw new Error("audit: " + (v[0].audit.problem || v[1].audit.problem));
      if (s0.gp.join() !== s1.gp.join()) throw new Error("score desync");
      audits++; deals++;
      dev()[deals % 2].match.act({ type: "NEXT_DEAL" });
      await until(() => dev().every(d => d.match.state.get().n === v[0].n + 1), 30000);
      continue;
    }
    const pub = s => JSON.stringify([s.trickPts, s.tricksWon, s.meldPts, s.closed, s.turn, (s.trick || []).map(x => x.card.id)]);
    if (pub(s0) !== pub(s1)) continue;
    const t = s0.turn, d = dev()[t], s = v[t].s;
    if (v[t].waitingCards) continue;
    const legal = RULES.legalCards(s, t).filter(c => !c.back);
    if (!legal.length) continue;
    await sleep(MOVE_MS);                          // brisk human pace (a real game is slower still)
    waits.push(Date.now() - lastMove); lastMove = Date.now();
    const melds = RULES.meldOptions(s, t);
    if (melds.length && Math.random() < .5) d.match.act({ type: "MELD", seat: t, suit: melds[0].suit });
    else if (RULES.canExchange(s, t) && Math.random() < .5) d.match.act({ type: "EXCHANGE", seat: t });
    else if (RULES.canClose(s, t) && Math.random() < .05) d.match.act({ type: "CLOSE", seat: t });
    else d.match.act({ type: "PLAY", seat: t, cardId: legal[(Math.random() * legal.length) | 0].id });
    steps++;
  }
}
const MOVE_MS = 1200;                             // a brisk human (a real game is slower)
const med = a => { const b = a.slice().sort((x, y) => x - y); return b[(b.length / 2) | 0] || 0; };
const p90 = a => { const b = a.slice().sort((x, y) => x - y); return b[(b.length * 0.9) | 0] || 0; };

console.log("two deals, played as fast as the budgets allow");
let t0 = Date.now();
await play(2, 600000);
ok(deals === 2 && audits === 2, `2 deals played and audited on both sides (${deals}) in ${((Date.now() - t0) / 1000).toFixed(0)} s`);
console.log(`       moves: ${steps}, wait between moves median ${med(waits)} ms, 90th ${p90(waits)} ms`);

console.log("relay 1 dies mid-deal: only the lossy relay carries anything");
waits = [];
const s1 = await kill(7801);
await play(3, 600000);
ok(deals >= 3, `another deal with relay 1 gone (${deals} total)`);
console.log(`       wait between moves median ${med(waits)} ms, 90th ${p90(waits)} ms`);
await relay(7801);

console.log("Jamie's page reloads mid-deal (new connection, same saved game)");
await play(deals + 1, 5000);                 // a few moves into the next deal
Y.stop(); await sleep(500);
Y = device("Y", "cid-y", 1); Y.start();
t0 = Date.now();
ok(await until(() => X.match.state.get().n === Y.match.state.get().n && !!Y.match.state.get().s, 90000), "the reloaded page picks the game back up");
console.log(`       back in ${((Date.now() - t0) / 1000).toFixed(1)} s`);
await play(4, 600000);
ok(deals >= 4, `deals continue after the reload (${deals} total)`);

console.log("Jamie goes away for a while, Seth's moves wait for her");
Y.stop();
await sleep(1500);
const before = X.match.state.get();
/* Seth makes whatever moves are his to make while she's gone */
for (let i = 0; i < 30; i++) {
  const v = X.match.state.get(); if (!v.s || v.s.phase !== "play" || v.s.turn !== 0 || v.waitingCards) { await sleep(100); continue; }
  const legal = RULES.legalCards(v.s, 0).filter(c => !c.back); if (!legal.length) break;
  X.match.act({ type: "PLAY", seat: 0, cardId: legal[0].id }); await sleep(100); break;
}
await sleep(20000);
Y = device("Y", "cid-y", 1); Y.start();
t0 = Date.now();
ok(await until(() => { const a = X.match.state.get(), b = Y.match.state.get(); return a.n === b.n && b.s && a.s && JSON.stringify(a.s.trickPts) === JSON.stringify(b.s.trickPts) && (a.s.trick || []).length === (b.s.trick || []).length; }, 90000), "back after 20 s away: she has everything Seth did meanwhile");
console.log(`       caught up in ${((Date.now() - t0) / 1000).toFixed(1)} s`);
await play(5, 600000);
ok(deals >= 5, `deals continue (${deals} total)`);
void before; void s1;

X.stop(); Y.stop();
await sleep(500);
const stats = [];
for (const p of PORTS) stats.push(await kill(p));
const kb = stats.filter(Boolean).reduce((a, s) => a + s.bytesIn, 0) / 1024;
const by = Object.fromEntries(stats.filter(Boolean).map(s => [s.port, s]));
console.log("per relay:", stats.filter(Boolean).map(s => `${s.port}: ${s.events} events${s.refusedRate ? `, ${s.refusedRate} rate-refused` : ""}${s.connsRefused ? `, ${s.connsRefused} connections refused` : ""}`).join(" · "));
ok(by[7805] && by[7805].events === 0, "the login-only relay received nothing");
ok(by[7803] && by[7803].events <= 8, `the web-of-trust relay received only a few events before being dropped (${by[7803] && by[7803].events})`);
ok(by[7804] && by[7804].connsRefused === 0, `the rate-limited relay never had to ban us (${by[7804] && by[7804].refusedRate} rate refusals)`);
console.log(`relays received ${kb.toFixed(0)} KB in all (both devices, ${deals} deals, ${steps} moves, plus the tests above)`);
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
