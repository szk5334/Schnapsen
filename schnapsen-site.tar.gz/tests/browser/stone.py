# Scroll & Stone in the browser: two players in two tabs (?local), one game in every mode, by tapping.
#   python3 tests/browser/stone.py        (with the site served at :8765, e.g. python3 -m http.server 8765)
#  - lobby -> new table -> the other sits -> options -> Start
#  - hide Ninjas, then each turn: a card, a highlighted piece, a highlighted square (and the Spirit, the Ninja), Play
#  - the game ends on both phones with the same winner, both phones' check passes, and Play again deals a new game
#  - no page errors; screenshots of every mode at 390x844 in $SHOTS
import asyncio, os, random, sys
from playwright.async_api import async_playwright
BASE = "http://localhost:8765/stone.html"; OUT = os.environ.get("SHOTS", "/tmp/st-shots")
MODES = sys.argv[1:] or ["Onitama", "Way of the Wind", "Way of the Shadow", "Way of the Light"]
ok = []; bad = []
def check(c, m): (ok if c else bad).append(m); print(("  ok  " if c else "FAIL  ") + m, flush=True)
R = random.Random(7)

async def status(pg):
    l = pg.locator(".sstatus")
    return (await l.inner_text()) if await l.count() else ""

async def step(pg):
    """One tap toward a move. True if something was tapped."""
    s = await status(pg)
    if s.startswith("Hide your Ninja"):
        need = 2 if "2 squares" in s else 1
        places = pg.locator(".sq.m-place")
        for i in range(need):
            if await places.count(): await places.nth(R.randrange(await places.count())).click()
        await pg.click("button:has-text('Hide')"); return True
    for label in ("Play", "Pass"):
        b = pg.locator(f".actbar button:text-is('{label}')")
        if await b.count():
            rv = pg.locator(".actbar button:text-is('Reveal')")
            if label == "Play" and await rv.count() and R.random() < 0.1: await rv.click()
            if label == "Play" and R.random() < 0.15:
                lan = pg.locator(".actbar button:text-is('Lantern')")
                if await lan.count():
                    await lan.click(); bs = pg.locator(".lanterns .btn"); await bs.nth(R.randrange(await bs.count())).click()
            try: await b.click(timeout=5000)
            except Exception:
                await pg.screenshot(path=f"{OUT}/stuck.png"); print("stuck:", await status(pg), await pg.locator(".actbar").inner_text(), flush=True); raise
            return True
    if s.startswith("Your turn") or s.startswith("Nothing") or s.startswith("Pick a card"):
        cards = pg.locator(".shand.mine button.mcard:not(.dim)")
        n = await cards.count()
        if n: await cards.nth(R.randrange(n)).click(); return True
        return False
    leave = pg.locator(".actbar button:text-is('Leave it')")
    if await leave.count() and R.random() < 0.4: await leave.click(); return True
    for cls in ("m-cap", "m-to", "m-sp", "m-nj", "m-pick"):
        t = pg.locator(f".sq.{cls}")
        n = await t.count()
        if n: await t.nth(R.randrange(n)).click(); return True
    return False

async def main():
    os.makedirs(OUT, exist_ok=True)
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path=os.environ.get("CHROME") or None, args=["--no-sandbox"])
        ctx = await b.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, is_mobile=True, has_touch=True)
        errs = []
        async def newp(tag, name):
            pg = await ctx.new_page()
            pg.on("pageerror", lambda e: errs.append(f"[{tag}] {e}"))
            pg.on("console", lambda m: errs.append(f"[{tag}] {m.text}") if m.type == "error" and "404" not in m.text else None)
            await pg.goto(f"{BASE}?local&as={tag}")
            if await pg.locator("#nm").count(): await pg.fill("#nm", name); await pg.click("text=Come in")
            return pg
        A = await newp("sa", "Seth"); await A.wait_for_selector(".lobby")
        B = await newp("sb", "Jamie"); await B.wait_for_selector(".lobby")
        await A.screenshot(path=f"{OUT}/lobby.png")
        for mode in MODES:
            await A.goto(f"{BASE}?local&as=sa#/"); await A.wait_for_selector(".lobby")
            await B.goto(f"{BASE}?local&as=sb#/"); await B.wait_for_selector(".lobby")
            await A.click("text=New table"); await A.wait_for_selector(".room")
            code = (await A.locator(".tcode").inner_text()).strip()
            await B.fill(".join input", code); await B.click(".join button")
            await B.click("text=Sit here", timeout=15000)
            await A.wait_for_selector(".seat >> text=Jamie", timeout=10000)
            await A.click(f".modes button:text-is('{mode}')")
            if mode == "Way of the Wind": await A.click(".setchip:has-text('Sensei')")
            if mode == "Way of the Light": await A.click(".seg button:text-is('Jamie')")
            await B.wait_for_selector(f".optnote >> text={mode}", timeout=8000)
            await A.screenshot(path=f"{OUT}/options-{mode.split()[-1].lower()}.png")
            await A.click("button:text-is('Start')")
            await A.wait_for_selector(".stone-game", timeout=10000); await B.wait_for_selector(".stone-game", timeout=10000)
            shot = False
            for i in range(6000):
                moved = False
                for pg in (A, B):
                    if await step(pg): moved = True
                if not shot and i > 6:
                    await A.screenshot(path=f"{OUT}/play-{mode.split()[-1].lower()}.png"); shot = True
                if await A.locator(".actbar button:has-text('Play again'):not([disabled])").count() and await B.locator(".actbar button:has-text('Play again'):not([disabled])").count(): break
                if not moved: await asyncio.sleep(0.05)
            sa, sb = await status(A), await status(B)
            check(await A.locator(".actbar button:has-text('Play again'):not([disabled])").count() == 1, f"{mode}: game over and checked on both phones ({sa} / {sb})")
            won = lambda s: s.split(" ")[0]
            check((won(sa) == "You") != (won(sb) == "You"), f"{mode}: one winner, the same on both")
            fa = await A.locator(".snote.fair").count(); fb = await B.locator(".snote.fair").count()
            check(fa == 1 and fb == 1, f"{mode}: both phones' check passed")
            await A.screenshot(path=f"{OUT}/end-{mode.split()[-1].lower()}.png")
            await (A if R.random() < .5 else B).click(".actbar button:has-text('Play again')")
            await A.wait_for_function("() => !document.querySelector('.actbar button') || !/Play again/.test(document.querySelector('.actbar').innerText)", timeout=15000)
            await asyncio.sleep(0.5)
            sc = (await A.locator(".bar .score").inner_text()).strip()
            check(sc in ("1–0", "0–1"), f"{mode}: a new game, score {sc}")
            await A.click("button[aria-label=Menu]"); await A.click("text=Close the table"); await asyncio.sleep(0.3)
        check(not errs, "no page errors" + ("" if not errs else ": " + " | ".join(errs[:5])))
        await b.close()
    print(f"stone browser: {len(ok)} ok, {len(bad)} failed")
    sys.exit(1 if bad else 0)
asyncio.run(main())
