# The score screen and the review, two players in two tabs (?local):
#  - when one presses Next deal, the other stays where they were (the last table, then its score) until they choose to move on
#  - the one who moved on sees "<name> is still looking at the score" if it's the other's lead
#  - Review opens on the score screen for both, and finishes; the same in solo
import asyncio, os, sys
from playwright.async_api import async_playwright
BASE = "http://localhost:8765/index.html"; OUT = os.environ.get("SHOTS", "/tmp/sx-shots")
ok = []; bad = []
def check(c, m): (ok if c else bad).append(m); print(("  ok  " if c else "FAIL  ") + m)
async def playable(pg):
    if not await pg.locator(".status").count(): return False
    st = await pg.locator(".status").inner_text()
    return st.startswith("Your") or st.startswith("Lead the")
async def move(pg):
    cards = pg.locator(".hand button.card:not(.dim)")
    if await cards.count():
        await cards.nth(0).click(); await asyncio.sleep(0.05)
        sel = pg.locator(".hand .card.sel")
        if await sel.count(): await sel.first.click()
        return True
    return False
async def review_done(pg, tag):
    await pg.click("button:has-text('Review')")
    await pg.wait_for_selector(".rv-wait, .rv", timeout=5000)
    await pg.wait_for_selector(".rv", timeout=120000)
    pts = await pg.locator(".rv-pt").count()
    head = await pg.locator(".rv-head, .rv-clean").first.inner_text()
    await pg.screenshot(path=f"{OUT}/review-{tag}.png", full_page=True)
    print(f"   [{tag}] {head.replace(chr(10),' / ')} · {pts} turning points")
    await pg.click(".sheet-head .x")
    return pts
async def main():
    os.makedirs(OUT, exist_ok=True)
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path=os.environ.get("CHROME") or None, args=["--no-sandbox"])
        ctx = await b.new_context(viewport={"width":390,"height":844}, device_scale_factor=2, is_mobile=True, has_touch=True)
        errs = []
        async def newp(tag, name, url=None):
            pg = await ctx.new_page()
            pg.on("pageerror", lambda e: errs.append(f"[{tag}] {e}"))
            pg.on("console", lambda m: errs.append(f"[{tag}] {m.text}") if m.type == "error" and "404" not in m.text else None)
            await pg.goto(url or f"{BASE}?local&fast&as={tag}")
            if await pg.locator("#nm").count():
                await pg.fill("#nm", name); await pg.click("text=Come in")
            return pg
        A = await newp("ra", "Seth"); await A.wait_for_selector(".lobby")
        B = await newp("rb", "Jamie"); await B.wait_for_selector(".lobby")
        await A.click("text=New table"); await A.wait_for_selector(".room")
        code = (await A.locator(".tcode").inner_text()).strip()
        await B.fill(".join input", code); await B.click(".join button")
        await B.click("text=Sit here", timeout=10000)
        await A.wait_for_selector(".seat >> text=Jamie", timeout=8000)
        await A.click("button:has-text('Deal')")
        await B.wait_for_selector(".game", timeout=10000)

        async def play_to_end():
            for _ in range(1500):
                for pg in (A, B):
                    if await playable(pg): await move(pg)
                if await A.locator("button:has-text('See the score')").count() and await B.locator("button:has-text('See the score')").count(): return True
                await asyncio.sleep(0.1)
            return False
        check(await play_to_end(), "deal 1 played to the end")
        # A looks at the score; B stays on the table
        await A.click("button:has-text('See the score')")
        await A.wait_for_selector("button:has-text('Next deal'):not([disabled])", timeout=20000)
        check(await A.locator("button:has-text('Review')").count() == 1, "Review button on the score screen")
        await review_done(A, "seth-deal1")
        await A.click("button:has-text('Next deal')")
        await A.wait_for_selector(".hand .card", timeout=20000)
        await asyncio.sleep(1.5)
        check(await B.locator("button:has-text('See the score')").count() == 1 and await B.locator(".hand").count() == 1,
              "Jamie is still on the last table after Seth dealt")
        stA = await A.locator(".status").inner_text()
        if "Jamie" in stA: check("still looking at the score" in stA, f"Seth's status says Jamie is at the score ({stA!r})")
        else: print("   (Seth's lead in deal 2, status:", stA, ")")
        await B.screenshot(path=f"{OUT}/review-held-table.png")
        await B.click("button:has-text('See the score')")
        await B.wait_for_selector("button:has-text('Back to the table')", timeout=5000)
        check(await B.locator("button:has-text('Next deal')").count() == 0, "Jamie's score offers Back to the table, not Next deal")
        await B.screenshot(path=f"{OUT}/review-held-score.png")
        await review_done(B, "jamie-deal1")
        # a reload keeps Jamie on the score
        await B.reload(); await asyncio.sleep(2)
        check(await B.locator("button:has-text('See the score'), button:has-text('Back to the table')").count() >= 1, "after a reload Jamie is still on the last deal")
        if await B.locator("button:has-text('See the score')").count(): await B.click("button:has-text('See the score')")
        await B.click("button:has-text('Back to the table')")
        await B.wait_for_selector(".hand .card", timeout=20000)
        check(True, "Back to the table puts Jamie in deal 2")
        await asyncio.sleep(1.5)
        stA = await A.locator(".status").inner_text()
        check("still looking" not in stA, f"Seth's status no longer says so ({stA!r})")
        # deal 2: Jamie presses Next first this time, from the score; Seth is on the score too
        check(await play_to_end(), "deal 2 played to the end")
        for pg in (A, B): await pg.click("button:has-text('See the score')")
        await B.wait_for_selector("button:has-text('Next deal'):not([disabled])", timeout=20000)
        await B.click("button:has-text('Next deal')")
        await asyncio.sleep(1.5)
        check(await A.locator("button:has-text('Back to the table')").count() == 1, "Seth stays on his score when Jamie deals")
        await A.click("button:has-text('Back to the table')")
        await A.wait_for_selector(".hand .card", timeout=20000)
        # solo
        S = await newp("rs", "Solo")
        await S.wait_for_selector(".lobby"); await S.click("text=Play a bot")
        await S.click("text=Greta"); await S.click("button:has-text('Deal')")
        await S.wait_for_selector(".game")
        for _ in range(600):
            if await playable(S): await move(S)
            if await S.locator("button:has-text('See the score')").count(): break
            await asyncio.sleep(0.05)
        await S.click("button:has-text('See the score')")
        check(await S.locator("button:has-text('Review')").count() == 1, "Review in solo")
        await review_done(S, "solo")
        check(not errs, "no page errors" + ("" if not errs else ": " + " | ".join(errs[:5])))
        await b.close()
    print(f"review.py: {len(ok)} ok, {len(bad)} failed")
    sys.exit(1 if bad else 0)
asyncio.run(main())
