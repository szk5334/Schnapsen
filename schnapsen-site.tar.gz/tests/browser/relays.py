# Two people in two separate browsers, everything through local Nostr relays (no ?local, no shared storage).
#   7811 normal · 7812 drops 20% of forwards · 7813 web of trust (refuses everything) · 7814 30 events/min, bans
# Lobby presence and chat, a listed table, seats, deal, play, both reloads, a watcher, one player leaving
# and coming back, two audited deals, the #/net page — then what the relays saw: no names, no words.
#
# Run from the site root:  python3 tests/browser/relays.py   (writes config.js; starts relays + a web server)
import asyncio, json, os, re, subprocess, sys, time, glob
from playwright.async_api import async_playwright

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
OUT = os.environ.get("SHOTS", "/tmp/sx-shots"); os.makedirs(OUT, exist_ok=True)
CHROME = os.environ.get("CHROME") or (glob.glob("/opt/pw-browsers/chromium-*/chrome-linux*/chrome") or [None])[0]
PORTS = [7811, 7812, 7813, 7814]
BASE = "http://localhost:8765/index.html"
results = []
def ok(c, m): results.append((bool(c), m)); print(("  ok   " if c else "  FAIL ") + m, flush=True)

def start():
    with open(os.path.join(ROOT, "config.js"), "w") as f:
        f.write("window.SX_CONFIG = { p2pAppId: 'browser-test-%d', relays: %s };\n" % (int(time.time()), json.dumps(["ws://localhost:%d" % p for p in PORTS])))
    procs = []
    extra = {7811: [], 7812: ["--drop", "0.2"], 7813: ["--wot"], 7814: ["--rate", "30"]}
    for p in PORTS:
        procs.append(subprocess.Popen(["node", "tests/relay-server.mjs", str(p), *extra[p], "--log", "/tmp/sx-relay-%d.log" % p], cwd=ROOT, stdout=subprocess.PIPE))
    procs.append(subprocess.Popen([sys.executable, "-m", "http.server", "8765"], cwd=ROOT, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
    time.sleep(1.5)
    return procs

async def playable(pg):
    if not await pg.locator(".status").count(): return False
    st = await pg.locator(".status").inner_text()
    return st.startswith("Your") or st.startswith("Lead the")
async def move(pg):
    cards = pg.locator(".hand button.card:not(.dim)")
    if await cards.count():
        await cards.nth(0).click(); await asyncio.sleep(0.05)
        sel = pg.locator(".hand .card.sel")
        if await sel.count(): await sel.first.click()
        return True
    return False

async def main():
    procs = start()
    errs = []
    try:
        async with async_playwright() as p:
            b = await p.chromium.launch(executable_path=CHROME, args=["--no-sandbox"])
            def ctx(): return b.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, is_mobile=True, has_touch=True)
            def hook(pg, tag):
                pg.on("console", lambda m: errs.append(f"[{tag}] {m.text}") if m.type == "error" and "404" not in m.text and "favicon" not in m.text and "TUNNEL" not in m.text else None)   # TUNNEL: the web font, blocked in the sandbox
                pg.on("pageerror", lambda e: errs.append(f"[{tag}] PAGEERROR {e}"))
            async def person(tag, name, hash_=""):
                c = await ctx(); pg = await c.new_page(); hook(pg, tag)
                await pg.goto(BASE + hash_)
                if await pg.locator("#nm").count():
                    await pg.fill("#nm", name); await pg.click("text=Come in")
                return c, pg

            ca, A = await person("seth", "Seth"); await A.wait_for_selector(".lobby")
            cb, B = await person("jamie", "Jamie"); await B.wait_for_selector(".lobby")
            t = time.time()
            await A.wait_for_selector(".here-n:has-text('2 here')", timeout=20000)
            await B.wait_for_selector(".here-n:has-text('2 here')", timeout=20000)
            ok(True, "lobby: each sees the other (%.1f s)" % (time.time() - t))

            await A.fill(".lobby .composer input", "evening, fancy a game?"); await A.click(".lobby .composer button")
            t = time.time()
            await B.wait_for_selector(".msg .txt:has-text('fancy a game')", timeout=20000)
            ok(True, "lobby chat arrives (%.1f s)" % (time.time() - t))
            await A.screenshot(path=f"{OUT}/r1-lobby.png")

            await A.click("text=New table"); await A.wait_for_selector(".room")
            code = (await A.locator(".tcode").inner_text()).strip()
            t = time.time()
            row = f".tables .trow[href='#/t/{code}']"
            await B.wait_for_selector(row, timeout=20000)
            ok(True, "the new table shows in Jamie's lobby (%.1f s)" % (time.time() - t))
            await B.screenshot(path=f"{OUT}/r2-table-listed.png")
            await B.click(row)
            await B.click("text=Sit here", timeout=20000)
            await A.wait_for_selector(".seat >> text=Jamie", timeout=20000)
            await A.click("button:has-text('Deal')")
            t = time.time()
            await A.wait_for_selector(".hand .card", timeout=30000); await B.wait_for_selector(".hand .card", timeout=30000)
            await A.wait_for_selector(".status", timeout=30000)
            ok(True, "dealt: shuffle and key exchange done on both phones (%.1f s)" % (time.time() - t))

            n = 0; lat = []
            for _ in range(200):
                for pg in (A, B):
                    if await playable(pg):
                        t = time.time()
                        if await move(pg):
                            n += 1
                if n >= 6: break
                await asyncio.sleep(0.15)
            ok(n >= 6, f"{n} moves played")
            await A.screenshot(path=f"{OUT}/r3-play.png")

            await A.reload(); await A.wait_for_selector(".hand .card", timeout=30000)
            await B.reload(); await B.wait_for_selector(".hand .card", timeout=30000)
            ok(True, "both pages reloaded mid-deal and picked the game back up")

            cc, C = await person("ollie", "Ollie", f"#/t/{code}")
            try:
                await C.wait_for_selector(".watch .status", timeout=30000); ok(True, "a watcher sees the table")
                await C.screenshot(path=f"{OUT}/r4-watcher.png")
            except Exception:
                ok(False, "a watcher sees the table"); await C.screenshot(path=f"{OUT}/x-watcher.png")
            await cc.close()

            state_b = await cb.storage_state()          # her phone keeps its storage while the page is closed
            await B.close(run_before_unload=True); await cb.close()
            t = time.time()
            await A.wait_for_selector("text=stepped away", timeout=90000)
            ok(True, "Jamie closes the page: Seth sees 'stepped away' (%.1f s)" % (time.time() - t))
            await asyncio.sleep(3)
            cb = await b.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, is_mobile=True, has_touch=True, storage_state=state_b)
            B = await cb.new_page(); hook(B, "jamie")
            await B.goto(BASE + f"#/t/{code}")
            t = time.time()
            await B.wait_for_selector(".hand .card", timeout=40000)
            await A.wait_for_selector("text=stepped away", state="detached", timeout=40000)
            ok(True, "Jamie comes back: same seat, same cards, banner gone (%.1f s)" % (time.time() - t))

            deals = 0; shot = False
            for _ in range(1200):
                for pg in (A, B):
                    if await playable(pg): await move(pg)
                    if await pg.locator("button:has-text('See the score')").count(): await pg.click("button:has-text('See the score')")
                if await A.locator("button:has-text('Next deal'):not([disabled])").count():
                    deals += 1
                    if not shot: await A.screenshot(path=f"{OUT}/r5-score.png"); shot = True
                    if deals >= 2: break
                    t = time.time()
                    await A.click("button:has-text('Next deal')")
                    await B.wait_for_selector(".hand .card", timeout=90000)
                    print("       next deal dealt in %.1f s" % (time.time() - t))
                await asyncio.sleep(1.2)                   # brisk human pace
            ok(deals >= 2, f"{deals} deals played to the end and checked")

            await A.goto(BASE + "#/net"); await A.wait_for_selector(".netpage")
            txt = await A.locator(".netpage").inner_text()
            ok("Build " + re.search(r'BUILD = "([^"]+)"', open(os.path.join(ROOT, "app/version.js")).read()).group(1) in txt, "#/net shows the build")
            ok("7813" in txt and "off" in txt and "web of trust" in txt, "#/net shows the web-of-trust relay set aside, with its reason")
            await A.click("button:has-text('Check relays')")
            await A.wait_for_selector("button:has-text('Check again')", timeout=120000)
            chk = await A.locator(".chk").inner_text()
            lines = {l.split()[0]: l for l in chk.splitlines() if l.startswith("localhost")}
            ok("Yes" in lines.get("localhost:7811", ""), "checker: the normal relay works")
            ok("No" in lines.get("localhost:7813", "") and "web of trust" in lines.get("localhost:7813", ""), "checker: the web-of-trust relay says why it won't work")
            ok(await A.locator("textarea.snip").count() == 1, "checker offers a config.js list of the relays that work")
            await A.screenshot(path=f"{OUT}/r6-net.png", full_page=True)
            await b.close()
    finally:
        for pr in procs: pr.terminate()
        time.sleep(0.5)
        tot = 0
        for pr in procs[:4]:
            try:
                st = json.loads(pr.stdout.read().decode().strip().splitlines()[-1]); tot += st["bytesIn"]
                print("       relay %d: %d events, %d rate-refused, %d connections refused" % (st["port"], st["events"], st["refusedRate"], st["connsRefused"]))
                if st["port"] == 7814: ok(st["connsRefused"] == 0, "the rate-limited relay never had to ban us")
                if st["port"] == 7813: ok(st["events"] <= 12, "the web-of-trust relay got only a handful of events before being dropped")
            except Exception as e: print("       (stats unavailable)", e)
        print("       relays received %.0f KB from all three pages in all" % (tot / 1024))
    # what did the relays see?
    seen = ""
    for port in [7811, 7812, 7814]:
        try: seen += open("/tmp/sx-relay-%d.log" % port).read()
        except FileNotFoundError: pass
    events = list({e["id"]: e for e in (json.loads(l) for l in seen.splitlines() if l.strip())}.values())   # one copy per event
    # Readable fields (everything but the sealed body) must not hold any name, word, room or code. The sealed
    # body is base64, where a short word like a 4-letter code turns up by chance, so there we look only for
    # things base64 can't contain (spaces, hyphens) and check that the body is pure base64.
    import re as _re
    plain = " ".join(json.dumps({k: v for k, v in e.items() if k != "content"}) for e in events)
    leaks = [w for w in ["Seth", "Jamie", "Ollie", "fancy a game", code, "lobby", "table-"] if w in plain]
    leaks += [w for w in ["fancy a game", "table-" + code] if any(w in e["content"] for e in events)]
    leaks += ["non-base64 body"] if any(not _re.fullmatch(r"[A-Za-z0-9+/=]+", e["content"]) for e in events) else []
    ok(not leaks, "relays saw no names, words, rooms or table code (%d events)%s" % (len(events), (" — " + ", ".join(leaks)) if leaks else ""))
    keys = [e["pubkey"] for e in events]
    ok(len(set(keys)) == len(keys), "every event signed by a different throwaway key")
    sizes = sorted({len(e["content"]) for e in events})
    print("       event body sizes seen:", sizes[:12])
    print("\n".join(errs) or "no page errors")
    good = sum(1 for c, _ in results if c)
    print(f"\n{good} passed, {len(results) - good} failed")

asyncio.run(main())
