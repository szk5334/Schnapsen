# Duplicate deals in the browser: two players in two tabs (?local), then solo.
#  - the score screen offers Next deal and Duplicate deal; Jamie (seat 1) asks for the duplicate
#  - the duplicate opens with its notice over the felt; Seth, still on his score, goes Back to the table into it
#  - at its end both see the comparison, and no Duplicate deal button (a duplicate can't be duplicated)
#  - the score sheet marks the row; the same in solo
import asyncio, os, sys
from playwright.async_api import async_playwright
BASE = "http://localhost:8765/index.html"; OUT = os.environ.get("SHOTS", "/tmp/sx-shots")
ok = []; bad = []
def check(c, m): (ok if c else bad).append(m); print(("  ok  " if c else "FAIL  ") + m)
async def playable(pg):
    if not await pg.locator(".status").count(): return False
    st = await pg.locator(".status").inner_text()
    return st.startswith("Your") or st.startswith("Lead the")
async def move(pg):
    cards = pg.locator(".hand button.card:not(.dim)")
    if await cards.count():
        await cards.nth(0).click(); await asyncio.sleep(0.05)
        sel = pg.locator(".hand .card.sel")
        if await sel.count(): await sel.first.click()
        return True
    return False
async def main():
    os.makedirs(OUT, exist_ok=True)
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path=os.environ.get("CHROME") or None, args=["--no-sandbox"])
        ctx = await b.new_context(viewport={"width":390,"height":844}, device_scale_factor=2, is_mobile=True, has_touch=True)
        errs = []
        async def newp(tag, name):
            pg = await ctx.new_page()
            pg.on("pageerror", lambda e: errs.append(f"[{tag}] {e}"))
            pg.on("console", lambda m: errs.append(f"[{tag}] {m.text}") if m.type == "error" and "404" not in m.text else None)
            await pg.goto(f"{BASE}?local&fast&as={tag}")
            if await pg.locator("#nm").count():
                await pg.fill("#nm", name); await pg.click("text=Come in")
            return pg
        A = await newp("da", "Seth"); await A.wait_for_selector(".lobby")
        B = await newp("db", "Jamie"); await B.wait_for_selector(".lobby")
        await A.click("text=New table"); await A.wait_for_selector(".room")
        code = (await A.locator(".tcode").inner_text()).strip()
        await B.fill(".join input", code); await B.click(".join button")
        await B.click("text=Sit here", timeout=10000)
        await A.wait_for_selector(".seat >> text=Jamie", timeout=8000)
        await A.click("button:has-text('Deal')")
        await B.wait_for_selector(".game", timeout=10000)

        async def play_to_end():
            for _ in range(1500):
                for pg in (A, B):
                    if await playable(pg): await move(pg)
                if await A.locator("button:has-text('See the score')").count() and await B.locator("button:has-text('See the score')").count(): return True
                await asyncio.sleep(0.1)
            return False
        check(await play_to_end(), "deal 1 played to the end")
        for pg in (A, B): await pg.click("button:has-text('See the score')")
        await B.wait_for_selector("button:has-text('Duplicate deal'):not([disabled])", timeout=20000)
        check(await A.locator("button:has-text('Next deal')").count() == 1 and await A.locator("button:has-text('Duplicate deal')").count() == 1,
              "the score offers Next deal and Duplicate deal")
        await B.screenshot(path=f"{OUT}/dup-score-buttons.png")
        await B.click("button:has-text('Duplicate deal')")
        await B.wait_for_selector(".dpop", timeout=10000)
        txt = await B.locator(".dpop").inner_text()
        check("Deal 1 again" in txt and "Seth has your hand" in txt, f"the duplicate opens with its notice ({txt.splitlines()[0]!r})")
        await B.screenshot(path=f"{OUT}/dup-notice.png")
        await asyncio.sleep(0.5)
        check(await A.locator("button:has-text('Back to the table')").count() == 1, "Seth stays on his score until he moves on")
        await A.click("button:has-text('Back to the table')")
        await A.wait_for_selector(".hand .card", timeout=20000)
        check(await play_to_end(), "the duplicate played to the end")
        for pg in (A, B): await pg.click("button:has-text('See the score')")
        for pg, nm in ((A, "Seth"), (B, "Jamie")):
            await pg.wait_for_selector(".duptally", timeout=10000)
            rows = await pg.locator(".duptally tbody tr").count()
            verdict = await pg.locator(".duptally p").first.inner_text()
            check(rows == 2, f"{nm} sees the comparison ({verdict!r})")
            await pg.wait_for_selector("button:has-text('Next deal'):not([disabled])", timeout=20000)
            check(await pg.locator("button:has-text('Duplicate deal')").count() == 0, f"{nm}: no Duplicate deal after a duplicate")
        await A.screenshot(path=f"{OUT}/dup-tally-seth.png", full_page=True)
        await B.screenshot(path=f"{OUT}/dup-tally-jamie.png", full_page=True)
        # the two verdicts agree (one's lead is the other's deficit)
        tot = []
        for pg in (A, B):
            cells = await pg.locator(".duptally tbody tr:first-child td").all_inner_texts()
            tot.append(cells[-1].replace("−", "-"))
        check(int(tot[0]) == -int(tot[1]), f"both devices tally the pair the same way ({tot[0]} / {tot[1]})")
        await A.click("button:has-text('Next deal')")
        await A.wait_for_selector(".hand .card", timeout=20000)
        await A.click("button:has-text('Menu')"); await A.click("text=Score sheet")
        check(await A.locator(".dupm").count() == 1 and "1 again" in await A.locator(".dupm").inner_text(), "the score sheet marks the duplicate")
        await A.screenshot(path=f"{OUT}/dup-sheet.png")

        # solo
        S = await newp("ds", "Solo")
        await S.wait_for_selector(".lobby"); await S.click("text=Play a bot")
        await S.click("text=Greta"); await S.click("button:has-text('Deal')")
        await S.wait_for_selector(".game")
        async def solo_end():
            for _ in range(900):
                if await playable(S): await move(S)
                if await S.locator("button:has-text('See the score')").count(): return True
                await asyncio.sleep(0.05)
            return False
        check(await solo_end(), "solo deal 1 played")
        await S.click("button:has-text('See the score')")
        await S.click("button:has-text('Duplicate deal')")
        await S.wait_for_selector(".dpop", timeout=5000)
        check("Greta has your hand" in await S.locator(".dpop").inner_text(), "solo: the notice names the bot")
        await S.screenshot(path=f"{OUT}/dup-solo-notice.png")
        check(await solo_end(), "solo duplicate played")
        await S.click("button:has-text('See the score')")
        await S.wait_for_selector(".duptally", timeout=5000)
        check(await S.locator("button:has-text('Duplicate deal')").count() == 0, "solo: no Duplicate deal after a duplicate")
        await S.screenshot(path=f"{OUT}/dup-solo-tally.png", full_page=True)
        await S.reload(); await S.wait_for_selector(".game, .result", timeout=10000)
        if await S.locator("button:has-text('See the score')").count(): await S.click("button:has-text('See the score')")
        check(await S.locator(".duptally").count() == 1, "solo: the comparison survives a reload")
        check(not errs, "no page errors" + ("" if not errs else ": " + " | ".join(errs[:5])))
        await b.close()
    print(f"dup.py: {len(ok)} ok, {len(bad)} failed")
    sys.exit(1 if bad else 0)
asyncio.run(main())
