import asyncio, os
from playwright.async_api import async_playwright
BASE = "http://localhost:8765/index.html"; OUT = "/home/claude/work/test/shots"
async def playable(pg):
    if not await pg.locator(".status").count(): return False
    st = await pg.locator(".status").inner_text()
    return st.startswith("Your") or st.startswith("Lead the")
async def move(pg):
    cards = pg.locator(".hand button.card:not(.dim)")
    if await cards.count():
        c = cards.nth(0); await c.click(); await asyncio.sleep(0.05)
        sel = pg.locator(".hand .card.sel")
        if await sel.count(): await sel.first.click()
        return True
    return False
async def main():
    os.makedirs(OUT, exist_ok=True)
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path="/opt/pw-browsers/chromium-1194/chrome-linux/chrome", args=["--no-sandbox"])
        ctx = await b.new_context(viewport={"width":390,"height":844}, device_scale_factor=2, is_mobile=True, has_touch=True)
        errs=[]
        def hook(pg, tag):
            pg.on("console", lambda m: errs.append(f"[{tag}] {m.type}: {m.text}") if m.type=="error" and "404" not in m.text and "TUNNEL" not in m.text else None)
            pg.on("pageerror", lambda e: errs.append(f"[{tag}] PAGEERROR {e}"))
        async def newp(tag, name, url=None):
            pg = await ctx.new_page(); hook(pg, tag)
            await pg.goto(url or f"{BASE}?local&as={tag}")
            if await pg.locator("#nm").count():
                await pg.fill("#nm", name); await pg.click("text=Come in")
            return pg
        A = await newp("a","Seth"); await A.wait_for_selector(".lobby")
        await A.screenshot(path=f"{OUT}/20-lobby.png")
        B = await newp("b","Jamie"); await B.wait_for_selector(".lobby")
        await A.click("text=New table"); await A.wait_for_selector(".room")
        code = (await A.locator(".tcode").inner_text()).strip()
        # B joins by code
        await B.fill(".join input", code); await B.click(".join button")
        await B.click("text=Sit here", timeout=10000)
        await A.screenshot(path=f"{OUT}/20b-room-ready.png")
        await A.wait_for_selector(".seat >> text=Jamie", timeout=8000)
        await A.click("button:has-text('Deal')")
        await B.wait_for_selector(".game", timeout=10000)
        # a few moves
        n=0
        for _ in range(60):
            for pg in (A,B):
                if await playable(pg) and await move(pg): n+=1
            if n>=4: break
            await asyncio.sleep(0.3)
        await asyncio.sleep(0.6)
        await A.screenshot(path=f"{OUT}/21-host-before-reload.png")
        handA = await A.locator(".hand .card").count()
        # HOST RELOAD
        await A.reload(); await A.wait_for_selector(".hand .card", timeout=10000)
        print("host resumed; hand", handA, "->", await A.locator(".hand .card").count())
        # GUEST RELOAD
        await B.reload(); await B.wait_for_selector(".hand .card", timeout=15000)
        print("guest resumed after reload")
        # spectator
        C = await newp("c","Ollie", f"{BASE}?local&as=c#/t/{code}")
        try:
            await C.wait_for_selector(".watch .status", timeout=12000)
        except Exception:
            await C.screenshot(path=f"{OUT}/x-spectator-fail.png"); print("C text:", (await C.locator("body").inner_text())[:400]); raise
        await asyncio.sleep(1)
        await C.screenshot(path=f"{OUT}/22-spectator.png")
        print("spectator status:", await C.locator(".watch .status").inner_text())
        # guest drops: banner, then returns and the game carries on
        await B.close()
        await A.wait_for_selector("text=stepped away", timeout=20000)
        await A.screenshot(path=f"{OUT}/23-host-guest-away.png")
        B = await newp("b","Jamie", f"{BASE}?local&as=b#/t/{code}")
        await B.wait_for_selector(".game", timeout=15000)
        await A.wait_for_selector("text=stepped away", state="detached", timeout=15000)
        print("guest came back, banner cleared")
        # play out this deal and the next one
        deals=0
        for _ in range(900):
            for pg in (A,B):
                if await playable(pg): await move(pg)
                if await pg.locator("button:has-text('See the score')").count(): await pg.click("button:has-text('See the score')")
            if await A.locator("button:has-text('Next deal'):not([disabled])").count():
                deals += 1
                if deals == 1: await A.screenshot(path=f"{OUT}/26-audited.png")
                if deals >= 2: break
                await A.click("button:has-text('Next deal')")
                await B.wait_for_selector(".hand .card", timeout=15000)
            await asyncio.sleep(0.2)
        print("audited deals:", deals)
        # solo
        S = await newp("s","Solo")
        await S.wait_for_selector(".lobby"); await S.click("text=Play a bot")
        await S.screenshot(path=f"{OUT}/24-solo-setup.png")
        await S.click("text=Greta"); await S.click("button:has-text('Deal')")
        await S.wait_for_selector(".game")
        for _ in range(200):
            if await S.locator("text=See the score").count(): break
            if await playable(S): await move(S)
            await asyncio.sleep(0.25)
        await S.screenshot(path=f"{OUT}/25-solo-end.png")
        print("solo deal finished:", await S.locator("text=See the score").count()>0)
        print("\n".join(errs) or "no page errors")
        await b.close()
asyncio.run(main())
