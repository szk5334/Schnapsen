"""ROYAL HOUSE in the browser. Serve the site on :8765, then: python3 tests/browser/royal.py
Solo, at several sizes, High visibility on and off: picks Royal House, plays whole deals (declaring marriages along
the way), and after every move checks that every card and label sits inside its own cell (the fit.cjs check) and
that the opponent's hand isn't drawn. Then two tabs (?local): a Royal House table played online, and a reload. Screenshots go to $SHOTS (default /tmp/sx-royal). Fails on any page error or anything out of place."""
import asyncio, os, sys, json
from playwright.async_api import async_playwright
BASE = "http://localhost:8765/index.html"; OUT = os.environ.get("SHOTS", "/tmp/sx-royal")
SIZES = json.loads(os.environ.get("SIZES", "[[412,744],[360,640],[390,844]]"))
DEALS = int(os.environ.get("DEALS", "2"))

CHECK = """() => {
  const R = e => e.getBoundingClientRect(), out = [], t = .6;
  const inside = (a, c, what) => { const x = R(a), y = R(c); const d = [y.top - x.top, x.bottom - y.bottom, y.left - x.left, x.right - y.right];
    if (d.some(v => v > t)) out.push(`${what} out by ${d.map(v => v.toFixed(1)).join("/")}`); };
  const felt = document.querySelector('.felt'); if (!felt) return out;
  const fs = getComputedStyle(felt), fr = R(felt);
  const inner = { top: fr.top + parseFloat(fs.borderTopWidth), bottom: fr.bottom - parseFloat(fs.borderBottomWidth) };
  for (const cell of felt.children) {
    const c = R(cell); if (c.top < inner.top - t || c.bottom > inner.bottom + t) out.push(cell.className + ' outside the felt');
    for (const k of cell.querySelectorAll('.card, .trump, .tcap, .rchips, .pot')) if (k.offsetParent) inside(k, cell, `${cell.className.split(' ')[0]} > ${k.className.split(' ').slice(0, 2).join('.')}`);
  }
  const g = document.querySelector('.game');
  for (const k of g.children) if (!k.classList.contains('mpop')) inside(k, g, k.className);
  for (const k of document.querySelectorAll('.hand .card:not(.sel)')) inside(k, document.querySelector('.hand'), 'hand card');
  if (document.querySelector('.side .backs')) out.push("the opponent's hand is drawn");
  const se = document.scrollingElement; if (se.scrollHeight > se.clientHeight + 1) out.push('page scrolls');
  return out;
}"""
SETTLE = """() => Promise.race([Promise.all(document.getAnimations().filter(a => a.effect && a.effect.getTiming().iterations !== Infinity).map(a => a.finished.catch(() => 0))), new Promise(r => setTimeout(r, 1200))])"""

async def status(pg):
    l = pg.locator(".game .status")
    return (await l.inner_text()).strip() if await l.count() else ""

async def step(pg, k, log):
    """One thing to do as the human, if it's our turn. Returns what was done, or None."""
    st = await status(pg)
    if not (st.startswith("Your") or st.startswith("Lead the") or st.startswith("Follow suit")): return None
    meld = pg.locator(".acts button.meld")
    if await meld.count() and k % 2 == 0:
        await meld.first.click(); return "meld"
    cards = pg.locator(".hand button.card:not(.dim)")
    if await cards.count():
        c = cards.nth(k % await cards.count()); await c.click(); await asyncio.sleep(0.03)
        sel = pg.locator(".hand .card.sel")
        if await sel.count(): await sel.first.click()
        return "play"
    return None

async def main():
    os.makedirs(OUT, exist_ok=True)
    bad = []
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path=os.environ.get("CHROME") or "/usr/bin/google-chrome", args=["--no-sandbox"])
        for W, H in SIZES:
            for big in (0, 1):
                tag = f"r{W}x{H}{'b' if big else ''}"
                ctx = await b.new_context(viewport={"width": W, "height": H}, device_scale_factor=2, is_mobile=True, has_touch=True)
                pg = await ctx.new_page(); errs = []
                pg.on("pageerror", lambda e: errs.append(f"PAGEERROR {e}"))
                pg.on("console", lambda m: errs.append(f"console {m.text}") if m.type == "error" and "404" not in m.text else None)
                await pg.goto(f"{BASE}?local&big={big}&as={tag}")
                if await pg.locator("#nm").count(): await pg.fill("#nm", "Seth"); await pg.click("text=Come in")
                await pg.goto(f"{BASE}?local&fast&as={tag}#/solo"); await pg.wait_for_selector('.seg[aria-label="Rules"]')
                await pg.click('.seg[aria-label="Rules"] button:text-is("Royal House")')
                if W == 390 and not big: await pg.screenshot(path=f"{OUT}/{tag}-00-setup.png")
                await pg.click('button.btn.primary:has-text("Deal")'); await pg.wait_for_selector('.game')
                seen, k, done, did = {}, 0, 0, {}
                shots = set()
                for it in range(4000):
                    await pg.evaluate(SETTLE)
                    for v in await pg.evaluate(CHECK): seen.setdefault(v, k)
                    if W == 390:
                        st = await status(pg)
                        for key, cond in (("01-first", k == 0),
                                          ("03-follow", await pg.locator(".trump.md-follow").count() > 0),
                                          ("04-strict", await pg.locator(".trump.md-strict").count() > 0),
                                          ("06-pop", await pg.locator(".mpop").count() > 0)):
                            if cond and key not in shots: shots.add(key); await pg.screenshot(path=f"{OUT}/{tag}-{key}.png")
                    see = pg.locator("button:has-text('See the score')")
                    if await see.count():
                        await see.click(); await pg.wait_for_selector(".result")
                        if W == 390 and done == 0: await pg.screenshot(path=f"{OUT}/{tag}-07-score.png", full_page=True)
                        done += 1
                        if done >= DEALS: break
                        nx = pg.locator(".result button:has-text('Next deal'), .result button:has-text('New Bummerl')")
                        await nx.first.click(); await pg.wait_for_selector(".game"); continue
                    a = await step(pg, k, did)
                    if a: did[a] = did.get(a, 0) + 1; k += 1
                    else: await asyncio.sleep(0.05)
                if W == 390 and not big:
                    await pg.click("button:has-text('Menu')"); await pg.click("button.row:has-text('Rules')")
                    await pg.wait_for_selector(".rules"); await pg.screenshot(path=f"{OUT}/{tag}-08-rules.png")
                print(f"{tag}: {done} deals, {k} moves {did}, {len(seen)} layout problems, {len(errs)} errors")
                for v, at in list(seen.items())[:8]: print("   ", v, "at move", at)
                for e in errs[:5]: print("   ", e)
                if seen or errs or done < DEALS: bad.append(tag)
                await ctx.close()

        # ---- two tabs: a Royal House table online, a reload
        ctx = await b.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, is_mobile=True, has_touch=True)
        errs = []
        async def newp(tag, name):
            pg = await ctx.new_page()
            pg.on("pageerror", lambda e: errs.append(f"[{tag}] PAGEERROR {e}"))
            await pg.goto(f"{BASE}?local&as={tag}")
            if await pg.locator("#nm").count(): await pg.fill("#nm", name); await pg.click("text=Come in")
            await pg.wait_for_selector(".lobby"); return pg
        A = await newp("ra", "Seth"); B = await newp("rb", "Jamie")
        await A.click("text=New table"); await A.wait_for_selector(".room")
        code = (await A.locator(".tcode").inner_text()).strip()
        await A.click('.seg[aria-label="Rules"] button:text-is("Royal House")')
        await B.fill(".join input", code); await B.click(".join button"); await B.click("text=Sit here", timeout=10000)
        await A.wait_for_selector(".seat >> text=Jamie", timeout=8000)
        await A.screenshot(path=f"{OUT}/online-00-room.png")
        await A.click("button:has-text('Deal')"); await B.wait_for_selector(".game", timeout=15000); await A.wait_for_selector(".game")
        k = 0
        for it in range(400):
            for pg in (A, B):
                st = await status(pg)
                if st.startswith("Your") or st.startswith("Lead the") or st.startswith("Follow suit"):
                    if await step(pg, k + 1, {}): k += 1
            if k >= 12: break
            await asyncio.sleep(0.15)
        await asyncio.sleep(0.8)
        cols = [await pg.locator(".piles.near .rchips").count() for pg in (A, B)]
        backs = [await pg.locator(".side .backs").count() for pg in (A, B)]
        await A.screenshot(path=f"{OUT}/online-02-after.png")
        await B.reload(); await B.wait_for_selector(".hand .card", timeout=15000); await asyncio.sleep(1)
        cols_b = await B.locator(".piles.near .rchips").count()
        print(f"online: {k} moves, won-card columns {cols} -> after reload {cols_b}, opponent backs {backs}, {len(errs)} errors")
        for e in errs[:5]: print("   ", e)
        if k < 12 or cols != [8, 8] or cols_b != 8 or any(backs) or errs: bad.append("online")
        await b.close()
    print("royal browser:", "FAILED " + ", ".join(bad) if bad else "all green")
    sys.exit(1 if bad else 0)

asyncio.run(main())
