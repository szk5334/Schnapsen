// SELF-HOSTED GATE: the site must load nothing from anywhere but itself. Walks every screen (first-visit name
// screen, lobby, a table, solo setup, a solo deal with play, every menu sheet, both card-face sets, High
// visibility, the hidden #/net page) and records every request and WebSocket the page opens.
//   Pass 1, ?local: any request off this origin fails the gate.
//   Pass 2, real transport: the only off-site traffic allowed is to the Nostr relay pool in app/net/relay.js
//   (WebSockets, and the NIP-11 info fetch to the same hosts). Anything else fails. Relays are aborted here.
// It also checks that every web font the stylesheet declares and the page uses came from app/fonts/.
// Serve the site on :8765, then:  node tests/browser/selfhosted.cjs
const { chromium } = require('playwright');
const fs = require('fs'), path = require('path');
const ORIGIN = 'http://localhost:8765';
const relaySrc = fs.readFileSync(path.join(__dirname, '../../app/net/relay.js'), 'utf8');
const RELAY_HOSTS = new Set([...relaySrc.matchAll(/"wss:\/\/([^"/]+)/g)].map(m => m[1]));
const FAMILIES = ['Josefin Sans', 'Playfair Display SC', 'Playfair Display', 'Limelight'];
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function walk(b, local, tag) {
  const ctx = await b.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  const offsite = [], relay = [], fonts = new Set(), errors = [];
  await ctx.route('**/*', r => {
    const u = new URL(r.request().url());
    if (u.origin === ORIGIN || u.protocol === 'data:' || u.protocol === 'blob:') return r.continue();
    (RELAY_HOSTS.has(u.host) && !local ? relay : offsite).push(r.request().url());
    return r.abort();
  });
  // Relays are never really dialled: every off-site WebSocket is recorded (below) and closed here.
  await ctx.routeWebSocket(u => !String(u).startsWith('ws://localhost:8765'), ws => ws.close());
  const pg = await ctx.newPage();
  pg.on('request', q => { if (/\.woff2?($|\?)/.test(q.url())) fonts.add(q.url()); });
  pg.on('websocket', ws => { const u = new URL(ws.url()); (RELAY_HOSTS.has(u.host) && !local ? relay : offsite).push(ws.url()); });
  pg.on('pageerror', e => errors.push(String(e)));
  const q = local ? `?local&as=${tag}` : `?as=${tag}`;
  const url = h => `${ORIGIN}/index.html${q}${h || ''}`;
  const step = async (what, fn) => { try { await fn(); } catch (e) { errors.push(`${what}: ${e.message.split('\n')[0]}`); } };
  const closeSheet = () => pg.keyboard.press('Escape').then(() => sleep(200));

  await pg.goto(url()); await pg.waitForSelector('#nm');
  await pg.fill('#nm', 'Seth'); await pg.click('text=Come in'); await sleep(600);
  await step('new table', async () => { await pg.click('text=New table', { timeout: 4000 }); await sleep(800); await pg.goto(url('#/')); await sleep(400); });
  await pg.goto(url('#/solo')); await sleep(500);
  await step('deal', async () => { await pg.click('button.btn.primary:has-text("Deal")'); await pg.waitForSelector('.game'); await sleep(500); });
  for (let i = 0; i < 14; i++) {     // a few tricks, so courts, pips, prints, won-card piles and a back all show
    const c = pg.locator('.hand button.card:not(.dim)');
    if (await c.count()) { await c.first().click(); await sleep(60); const s = pg.locator('.hand .card.sel'); if (await s.count()) await s.first().click(); }
    await sleep(450);
  }
  for (const item of ['Deal log', 'Score sheet', 'Rules']) {
    await step(item, async () => { await pg.click('text=Menu'); await pg.click(`.menu >> text=${item}`); await sleep(300); await closeSheet(); });
  }
  await step('faces', async () => { await pg.click('text=Menu'); await pg.click('.menu >> text=Card faces'); await sleep(500); await closeSheet(); });
  await step('big', async () => { await pg.click('text=Menu'); await pg.click('.menu >> text=High visibility'); await sleep(500); await closeSheet(); });
  await pg.goto(url('#/net')); await sleep(1200);
  await pg.goto(url('#/')); await sleep(600);
  // A late look at which faces the page actually loaded, and from where.
  const loaded = await pg.evaluate(async () => { await document.fonts.ready;
    return [...document.fonts].filter(f => f.status === 'loaded').map(f => `${f.family.replace(/["']/g, '')} ${f.weight} ${f.style}`); });
  await ctx.close();
  return { offsite, relay, fonts: [...fonts], loaded: [...new Set(loaded)].sort(), errors };
}

(async () => {
  const b = await chromium.launch(); let bad = 0;
  for (const local of [true, false]) {
    const r = await walk(b, local, local ? 'shl' : 'shr');
    const name = local ? 'pass 1 (?local)' : 'pass 2 (relays)';
    const badFonts = r.fonts.filter(u => !u.startsWith(`${ORIGIN}/app/fonts/`));
    const missing = FAMILIES.filter(f => !r.loaded.some(l => l.startsWith(f + ' ')));
    console.log(`${name}: ${r.offsite.length} off-site, ${r.relay.length} relay, fonts fetched ${r.fonts.length}, faces loaded: ${r.loaded.join(' | ')}`);
    if (r.offsite.length) { bad++; console.log('  OFF-SITE:', [...new Set(r.offsite)].join('\n            ')); }
    if (badFonts.length) { bad++; console.log('  FONTS NOT FROM app/fonts:', badFonts.join(' ')); }
    if (missing.length) { bad++; console.log('  FAMILIES NEVER LOADED:', missing.join(', ')); }
    if (!local) console.log('  relay hosts touched:', [...new Set(r.relay.map(u => new URL(u).host))].sort().join(' ') || 'none');
    if (r.errors.length) { bad++; console.log('  ERRORS:', r.errors.join('\n          ')); }
  }
  await b.close();
  console.log(bad ? `FAIL (${bad})` : 'PASS: nothing loads from off the site but the relay pool');
  process.exit(bad ? 1 : 0);
})();
