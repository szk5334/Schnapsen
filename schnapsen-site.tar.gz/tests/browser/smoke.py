import asyncio, sys, json
from playwright.async_api import async_playwright
BASE = "http://localhost:8765/index.html"
OUT = "/home/claude/work/test/shots"
async def main():
    import os; os.makedirs(OUT, exist_ok=True)
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path="/opt/pw-browsers/chromium-1194/chrome-linux/chrome", args=["--no-sandbox"])
        ctx = await b.new_context(viewport={"width":390,"height":844}, device_scale_factor=2, is_mobile=True, has_touch=True)
        errs = []
        async def page(tag, name):
            pg = await ctx.new_page()
            pg.on("console", lambda m: errs.append(f"[{tag}] {m.type}: {m.text}") if m.type in ("error","warning") else None)
            pg.on("pageerror", lambda e: errs.append(f"[{tag}] PAGEERROR {e}"))
            await pg.goto(f"{BASE}?local&as={tag}")
            await pg.fill("#nm", name); await pg.click("text=Come in")
            await pg.wait_for_selector(".lobby")
            return pg
        A = await page("a","Seth"); await A.screenshot(path=f"{OUT}/01-lobby-a.png")
        B = await page("b","Jamie")
        await B.fill(".composer input", "Evening! Up for a Bummerl?"); await B.click(".composer button")
        await A.wait_for_selector("text=Up for a Bummerl", timeout=8000)
        await A.fill(".composer input", "Always. Making a table."); await A.press(".composer input", "Enter")
        await asyncio.sleep(0.5)
        await A.screenshot(path=f"{OUT}/02-lobby-chat-a.png")
        await A.click("text=New table"); await A.wait_for_selector(".room")
        await asyncio.sleep(1)
        await A.screenshot(path=f"{OUT}/03-room-host.png")
        await B.wait_for_selector(".trow", timeout=8000)
        await B.screenshot(path=f"{OUT}/04-lobby-b-table.png")
        await B.click(".trow"); await B.wait_for_selector("text=Sit here", timeout=10000)
        await B.click("text=Sit here"); await A.wait_for_selector(".seat >> text=Jamie", timeout=8000)
        await B.fill(".composer input", "Sat down. Deal 'em."); await B.click(".composer button")
        await A.wait_for_selector("text=Deal 'em", timeout=8000)
        await B.screenshot(path=f"{OUT}/05-room-guest.png")
        await A.click("button:has-text('Deal')", timeout=8000)
        await A.wait_for_selector(".game", timeout=8000); await B.wait_for_selector(".game", timeout=10000)
        await A.screenshot(path=f"{OUT}/06-game-host.png"); await B.screenshot(path=f"{OUT}/07-game-guest.png")
        # play one full deal
        moves = 0
        for it in range(400):
            done = False
            for pg in (A,B):
                if await pg.locator(".result").count() or await pg.locator("text=See the score").count():
                    done = True
                st = await pg.locator(".status").inner_text() if await pg.locator(".status").count() else ""
                if st.startswith("Your") or st.startswith("Lead the"):
                    cards = pg.locator(".hand button.card:not(.dim)")
                    n = await cards.count()
                    if n:
                        await cards.nth(0).click(); await cards.nth(0).click() if await pg.locator(".hand .card.sel").count() else None
                        moves += 1
                        if moves == 3: await pg.screenshot(path=f"{OUT}/08-midgame.png")
            if done: break
            await asyncio.sleep(0.35)
        print("moves", moves)
        await A.screenshot(path=f"{OUT}/09-end-a.png")
        if await A.locator("text=See the score").count():
            await A.click("text=See the score"); await asyncio.sleep(0.3)
            await A.screenshot(path=f"{OUT}/10-result-a.png")
        await A.click(".drawer-bar") if await A.locator(".drawer-bar").count() else None
        await asyncio.sleep(0.3); await A.screenshot(path=f"{OUT}/11-drawer.png")
        print("\n".join(errs[:40]) or "no console errors")
        await b.close()
asyncio.run(main())
