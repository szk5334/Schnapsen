// FIT GATE: plays whole solo deals and, after every move, checks that each card and label on the table sits
// inside its own cell on all four sides (upward spills included: a scroll check can't see those).
// Josefin Sans is served locally in place of Google Fonts so the real metrics apply. Needs the font files:
//   npm i @fontsource/josefin-sans  and copy files/josefin-sans-latin-{700,400}-normal.woff2 to the site root
//   as jf700.woff2 / jf400.woff2 (delete them after). Serve the site on :8765, then:
//   SIZES='[[412,744],[360,640]]' [D24=1] [OFF=1] node tests/browser/fit.cjs
// OFF=1 checks with High visibility off.
const { chromium } = require('playwright');
const sizes = JSON.parse(process.env.SIZES), D24 = !!process.env.D24;
(async () => {
  const b = await chromium.launch(); let bad = 0;
  for (const [W, H] of sizes) {
    const ctx = await b.newContext({ viewport: { width: W, height: H }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
    const pg = await ctx.newPage();
    await pg.route('https://fonts.googleapis.com/**', r => r.fulfill({ contentType: 'text/css', body:
      "@font-face{font-family:'Josefin Sans';font-weight:700;src:url(http://localhost:8765/jf700.woff2) format('woff2')}@font-face{font-family:'Josefin Sans';font-weight:400;src:url(http://localhost:8765/jf400.woff2) format('woff2')}" }));
    const tag = `c${W}x${H}${D24 ? 'd' : ''}`;
    await pg.goto(`http://localhost:8765/index.html?local&big=${process.env.OFF ? 0 : 1}&as=${tag}`);
    await pg.fill('#nm', 'Seth'); await pg.click('text=Come in');
    await pg.goto(`http://localhost:8765/index.html?local&as=${tag}#/solo`); await pg.waitForTimeout(400);
    if (D24) await pg.click('text=24 with');
    await pg.click('button.btn.primary:has-text("Deal")'); await pg.waitForSelector('.game'); await pg.waitForTimeout(700);
    const check = () => pg.evaluate(() => {
      const R = e => e.getBoundingClientRect(), out = [], t = .6;
      const inside = (a, c, what) => { const x = R(a), y = R(c); const d = [y.top - x.top, x.bottom - y.bottom, y.left - x.left, x.right - y.right];
        if (d.some(v => v > t)) out.push(`${what} out by top ${d[0].toFixed(1)} bottom ${d[1].toFixed(1)} left ${d[2].toFixed(1)} right ${d[3].toFixed(1)}`); };
      const felt = document.querySelector('.felt'); if (!felt) return out;
      const fs = getComputedStyle(felt), fr = R(felt);
      const inner = { top: fr.top + parseFloat(fs.borderTopWidth), bottom: fr.bottom - parseFloat(fs.borderBottomWidth), left: fr.left + parseFloat(fs.borderLeftWidth), right: fr.right - parseFloat(fs.borderRightWidth) };
      for (const cell of felt.children) {
        const c = R(cell); if (c.top < inner.top - t || c.bottom > inner.bottom + t) out.push(cell.className + ' outside the felt');
        for (const k of cell.querySelectorAll('.card, .slabel, .trump, .tcap, .rchips, .pot')) if (k.offsetParent) inside(k, cell, `${cell.className.split(' ')[0]} > ${k.className.split(' ').slice(0, 2).join('.')}`);
      }
      for (const g of document.querySelector('.game').children) inside(g, document.querySelector('.game'), g.className);
      for (const k of document.querySelectorAll('.hand .card:not(.sel)')) inside(k, document.querySelector('.hand'), 'hand card');
      return out;
    });
    const seen = new Map(); let moves = 0;
    const note = async () => { for (const v of await check()) { if (!seen.has(v)) seen.set(v, moves); } };
    await note();
    for (let i = 0; i < 400; i++) {
      if (await pg.locator('text=See the score').count()) break;
      const st = await pg.locator('.status').innerText().catch(() => '');
      if (/^(Your|Lead the)/.test(st)) { const c = pg.locator('.hand button.card:not(.dim)'); if (await c.count()) { await c.last().click(); await c.last().click();   /* the rightmost playable card is never covered (the hand overlaps with the mode off) */ moves++; await pg.waitForTimeout(150); await note(); } }
      await pg.waitForTimeout(200); await note();
    }
    console.log(`${W}x${H}${D24 ? ' 24' : ''}: ${moves} moves, ${seen.size ? 'PROBLEMS:\n   ' + [...seen.keys()].join('\n   ') : 'all inside'}`);
    bad += seen.size; await ctx.close();
  }
  await b.close(); process.exit(bad ? 1 : 0);
})();
