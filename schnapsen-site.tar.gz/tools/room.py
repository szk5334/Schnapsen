"""The back room's two surfaces, drawn from noise (build 2026-10-25.4).

    python3 tools/room.py app/room

felt.webp  320x320, tiles seamlessly: billiard-cloth green with a fine nap (short fibres, mostly along one
           direction) and a faint mottle. Opaque; the lamp light and the dark edges are CSS gradients laid over it.
wood.webp  640x160, tiles left to right: dark mahogany for the rails (the header and the chat drawer), long
           grain with a little figure. Lacquer sheen and the gold inlay are CSS on top.

Everything is periodic (noise filtered in the frequency domain), so neither texture shows a seam.
"""
import sys, os
import numpy as np
from PIL import Image

rng = np.random.default_rng(66)


def band(shape, lo, hi, aniso=(1.0, 1.0)):
    """Periodic noise keeping spatial frequencies between lo and hi (cycles per tile), stretched by aniso (a value above 1 makes features that much longer along that axis)."""
    h, w = shape
    fy = np.fft.fftfreq(h)[:, None] * h * aniso[0]
    fx = np.fft.fftfreq(w)[None, :] * w * aniso[1]
    f = np.sqrt(fx ** 2 + fy ** 2)
    mask = np.exp(-((np.log(f + 1e-9) - np.log((lo * hi) ** .5)) ** 2) / (2 * (np.log(hi / lo) / 2.5) ** 2))
    mask[0, 0] = 0
    n = np.real(np.fft.ifft2(np.fft.fft2(rng.standard_normal(shape)) * mask))
    return (n - n.mean()) / (n.std() + 1e-9)


def felt(size=320):
    s = (size, size)
    nap = band(s, 60, 160, aniso=(1.0, 3.2))        # fibres: fine, combed sideways
    fuzz = band(s, 90, 160)                          # loose fluff
    mottle = band(s, 2, 5)                           # cloth that has been played on
    t = .07 * nap + .035 * fuzz + .012 * mottle
    base = np.array([16, 78, 54], float)            # billiard green
    rgb = base[None, None, :] * (1 + t[..., None] * np.array([1.1, 1.0, 0.95]))
    rgb += np.array([.0, .8, .4]) * mottle[..., None]   # mottle drifts a touch toward blue-green
    return Image.fromarray(np.clip(rgb, 0, 255).astype(np.uint8), "RGB")


def wood(w=640, h=160):
    y = np.linspace(0, 1, h, endpoint=False)[:, None]
    warp = band((h, w), 1, 4, aniso=(1.0, 6.0)) * .05 + band((h, w), 3, 10, aniso=(1.0, 8.0)) * .012
    rings = np.sin((y + warp) * 2 * np.pi * 26)                  # long grain lines along the rail
    fine = band((h, w), 40, 120, aniso=(1.0, 12.0))              # pores
    figure = band((h, w), 2, 6, aniso=(1.0, 3.0))                # chatoyance
    t = .5 + .5 * rings
    t = t ** 2.2
    dark = np.array([34, 14, 8], float); light = np.array([92, 40, 22], float)
    rgb = dark + (light - dark) * (.35 * t + .2 * (.5 + .5 * np.tanh(figure)))[..., None]
    rgb *= (1 + .06 * fine)[..., None]
    return Image.fromarray(np.clip(rgb, 0, 255).astype(np.uint8), "RGB")


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "app/room"
    os.makedirs(out, exist_ok=True)
    felt().save(os.path.join(out, "felt.webp"), quality=82, method=6)
    wood().save(os.path.join(out, "wood.webp"), quality=80, method=6)
    for f in ("felt.webp", "wood.webp"):
        print(f, os.path.getsize(os.path.join(out, f)), "bytes")
