"""Rebuilds app/fonts/ (the self-hosted web fonts) from unpacked Fontsource packages.
   npm pack @fontsource/josefin-sans @fontsource/playfair-display-sc @fontsource/playfair-display @fontsource/limelight
   for f in fontsource-*.tgz; do mkdir -p ${f%.tgz} && tar xzf $f -C ${f%.tgz}; done
   python3 tools/fonts.py <dir with the unpacked fontsource-* folders> app/fonts
Faces: Josefin Sans 400/700, Playfair Display SC 700/900, Playfair Display italic 400, Limelight 400."""
import re, shutil, sys, pathlib
src = pathlib.Path(sys.argv[1]); out = pathlib.Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True)
want = [("josefin-sans","400.css"),("josefin-sans","700.css"),
        ("playfair-display-sc","700.css"),("playfair-display-sc","900.css"),
        ("playfair-display","400-italic.css"),("limelight","400.css")]
css = ["/* Self-hosted web fonts (no third-party requests). Files from the Fontsource npm packages v5.3.0,",
       " * which repackage Google Fonts' own builds. woff2 only; each face is split by unicode-range exactly as",
       " * Google serves it, so a phone downloads only the subsets the page's text needs (normally just latin).",
       " * Licences: SIL Open Font License 1.1, see the *-OFL.txt files here. */",""]
for pkg, f in want:
    d = next(src.glob(f"fontsource-{pkg}-[0-9]*/package"))
    t = (d / f).read_text()
    for blk in re.findall(r"/\*.*?\*/\s*@font-face\s*\{.*?\}", t, re.S):
        m = re.search(r"url\(\./files/([^)]+\.woff2)\)", blk); name = m.group(1)
        shutil.copy(d / "files" / name, out / name)
        blk = re.sub(r"src:[^;]+;", f"src: url(./{name}) format('woff2');", blk)
        css.append(blk + "\n")
    lic = out / f"{pkg}-OFL.txt"
    if not lic.exists(): shutil.copy(d / "LICENSE", lic)
(out / "fonts.css").write_text("\n".join(css))
