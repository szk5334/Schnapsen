"""Twenty grandma prints, one per card, as SVG <pattern> tiles (card box 250 x 350).
Each card's print is drawn in its suit's palette: reddish hearts, bluish spades, yellowish diamonds, greenish clubs.
The card lays its print faintly behind everything, fading toward the middle, under the gold frame."""
import math

f = lambda v: f"{v:.1f}".rstrip("0").rstrip(".")

PAL = {   # main, second, third, leaf, leaf2, ground (checks and stripes), dark accent
    "H": dict(a="#d8466a", b="#f39ab3", c="#e8735a", l="#8fa878", l2="#b5c79a", g="#f4b8c6", d="#9e2a45"),
    "S": dict(a="#5679d4", b="#9fb3f0", c="#8b78d8", l="#7aa39f", l2="#a9c8c2", g="#b9c9f3", d="#2f4a8c"),
    "D": dict(a="#e3a514", b="#f4d46a", c="#ec9446", l="#a5a456", l2="#cfcf86", g="#f6dc8a", d="#9a6a08"),
    "C": dict(a="#4c9a58", b="#9fd4a3", c="#3f9a8c", l="#6f9a3a", l2="#b8d77a", g="#b6e0b4", d="#2c6a3a"),
}

# --------------------------------------------------------------- little drawing kit
def petals(cx, cy, r, n, col, w=.42, rot=0, d=.55, op=1):
    o = []
    for k in range(n):
        a = rot + k * 360 / n
        x = cx + r * d * math.cos(math.radians(a)); y = cy + r * d * math.sin(math.radians(a))
        o.append(f'<ellipse cx="{f(x)}" cy="{f(y)}" rx="{f(r*.5)}" ry="{f(r*w)}" transform="rotate({f(a)} {f(x)} {f(y)})" fill="{col}"{"" if op == 1 else f" opacity=" + chr(34) + f(op) + chr(34)}/>')
    return "".join(o)

def dot(x, y, r, col): return f'<circle cx="{f(x)}" cy="{f(y)}" r="{f(r)}" fill="{col}"/>'

def bloom(cx, cy, r, n, col, mid, rot=0):
    return petals(cx, cy, r, n, col, rot=rot) + dot(cx, cy, r * .26, mid)

def leaf(x, y, ln, a, col, vein=None):
    w = ln * .34
    s = f'<path d="M0 0Q{f(ln*.5)} {f(-w)} {f(ln)} 0Q{f(ln*.5)} {f(w)} 0 0Z" fill="{col}" transform="translate({f(x)} {f(y)}) rotate({f(a)})"/>'
    if vein: s += f'<path d="M0 0L{f(ln*.85)} 0" stroke="{vein}" stroke-width=".6" transform="translate({f(x)} {f(y)}) rotate({f(a)})"/>'
    return s

def rose(cx, cy, r, p):
    """A cabbage rose: a light cup, then darker petals curling inward, a tight heart."""
    o = [dot(cx, cy, r, p["b"])]
    for k in range(7):
        a = k * 51
        x = cx + r * .55 * math.cos(math.radians(a)); y = cy + r * .55 * math.sin(math.radians(a))
        o.append(f'<path d="M{f(x - r*.5)} {f(y)} Q{f(x)} {f(y - r*.55)} {f(x + r*.5)} {f(y)}" fill="none" stroke="{p["a"]}" stroke-width="{f(r*.16)}" stroke-linecap="round" transform="rotate({f(a + 90)} {f(x)} {f(y)})"/>')
    o.append(dot(cx, cy, r * .45, p["a"]))
    o.append(f'<path d="M{f(cx - r*.3)} {f(cy)} A{f(r*.3)} {f(r*.3)} 0 1 1 {f(cx + r*.1)} {f(cy + r*.25)}" fill="none" stroke="{p["d"]}" stroke-width="{f(r*.12)}" stroke-linecap="round"/>')
    return "".join(o)

def bud(x, y, r, p, a=0):
    return (f'<g transform="rotate({f(a)} {f(x)} {f(y)})"><ellipse cx="{f(x)}" cy="{f(y)}" rx="{f(r*.6)}" ry="{f(r)}" fill="{p["a"]}"/>'
            f'<path d="M{f(x - r*.7)} {f(y + r*.3)} Q{f(x)} {f(y + r*1.5)} {f(x + r*.7)} {f(y + r*.3)}" fill="{p["l"]}"/></g>')

def stem(d, col, w=1.2): return f'<path d="{d}" fill="none" stroke="{col}" stroke-width="{w}" stroke-linecap="round"/>'

def curl(x, y, r, a, sweep, w, col):
    pts = []
    for k in range(36):
        t = k / 35 * 1.75 * math.pi; rr = r * (1 - t / (2.1 * math.pi)); ang = math.radians(a) + sweep * t
        pts.append((x + rr * math.cos(ang), y + rr * math.sin(ang)))
    return f'<path d="M{" L".join(f"{f(px)} {f(py)}" for px, py in pts)}" fill="none" stroke="{col}" stroke-width="{w}" stroke-linecap="round"/>'

def tile(pid, w, h, body, rot=0):
    t = f' patternTransform="rotate({rot})"' if rot else ""
    return f'<pattern id="{pid}" width="{w}" height="{h}" patternUnits="userSpaceOnUse"{t}>{body}</pattern>'

# --------------------------------------------------------------- the twenty prints
def chintz(p):            # big fat cabbage roses with leafy sprays: grandma's sofa
    b = [leaf(22, 30, 20, 160, p["l"], p["l2"]), leaf(36, 22, 18, -40, p["l"], p["l2"]), leaf(30, 44, 16, 80, p["l2"]),
         rose(28, 28, 15, p), leaf(70, 76, 15, 200, p["l"], p["l2"]), leaf(80, 64, 14, -20, p["l2"]), rose(74, 72, 10, p),
         bud(64, 30, 4, p, 30), bud(14, 72, 4, p, -20), stem("M60 36 Q56 46 48 50", p["l"], 1), dot(86, 20, 1.6, p["c"]), dot(50, 86, 1.6, p["c"])]
    return 96, 96, "".join(b), 0

def ribbon_stripe(p):     # Victorian parlour: roses and a ribbon trailing down soft stripes
    b = [f'<rect x="0" y="0" width="16" height="84" fill="{p["g"]}"/>', f'<rect x="20" y="0" width="2" height="84" fill="{p["g"]}"/>',
         stem("M8 0 Q2 21 8 42 Q14 63 8 84", p["c"], 2.2), rose(8, 22, 6.5, p), rose(8, 64, 6.5, p),
         leaf(10, 30, 9, 40, p["l"]), leaf(6, 56, 9, 220, p["l"]), bloom(36, 42, 5, 5, p["b"], p["d"], 10),
         leaf(36, 46, 7, 100, p["l2"]), dot(36, 12, 1.4, p["a"]), dot(36, 74, 1.4, p["a"])]
    return 48, 84, "".join(b), 0

def strawberry(p):        # kitchen print: berries, blossoms, leaves
    def berry(x, y, s, a):
        return (f'<g transform="rotate({a} {x} {y})"><path d="M{x} {y + 9*s} C{x - 8*s} {y + 2*s} {x - 7*s} {y - 5*s} {x} {y - 5*s} C{x + 7*s} {y - 5*s} {x + 8*s} {y + 2*s} {x} {y + 9*s}Z" fill="{p["a"]}"/>'
                + "".join(dot(x + dx * s, y + dy * s, .6 * s, "#fff6d8") for dx, dy in ((-3, -1), (2, -2), (0, 2), (-2, 4), (3, 3), (0, 6)))
                + f'<path d="M{x - 5*s} {y - 5*s} L{x} {y - 2*s} L{x + 5*s} {y - 5*s} L{x + 2*s} {y - 7*s} L{x} {y - 4*s} L{x - 2*s} {y - 7*s}Z" fill="{p["l"]}"/></g>')
    b = [berry(18, 20, 1.3, -15), berry(48, 46, 1.1, 20), leaf(30, 14, 12, 20, p["l"], p["l2"]), leaf(56, 30, 10, 200, p["l2"]),
         bloom(46, 14, 5, 5, "#fff4ee", p["d"]), bloom(14, 50, 4.5, 5, p["b"], p["d"], 30), dot(32, 34, 1.3, p["c"])]
    return 62, 62, "".join(b), 0

def polka_rosebud(p):     # polka dots with tiny rosebuds
    b = [dot(6, 6, 3, p["g"]), dot(26, 26, 3, p["g"]), dot(26, 6, 1.6, p["b"]), dot(6, 26, 1.6, p["b"]),
         bud(16, 16, 3.6, p, 25), leaf(18, 19, 6, 60, p["l"])]
    return 32, 32, "".join(b), 0

def doily(p):             # crocheted doilies: scalloped rings and lace holes
    o = []
    for cx, cy, R in ((35, 35, 26),):
        for k in range(16):
            a = math.radians(k * 22.5)
            o.append(f'<circle cx="{f(cx + R*math.cos(a))}" cy="{f(cy + R*math.sin(a))}" r="5.2" fill="none" stroke="{p["a"]}" stroke-width="1.1"/>')
        o.append(f'<circle cx="{cx}" cy="{cy}" r="{R - 6}" fill="none" stroke="{p["b"]}" stroke-width="1.4" stroke-dasharray="2 2.4"/>')
        for k in range(8):
            a = math.radians(k * 45 + 22.5)
            o.append(dot(cx + 12 * math.cos(a), cy + 12 * math.sin(a), 2.2, p["b"]))
        o.append(bloom(cx, cy, 7, 8, p["a"], p["g"]))
    o.append(dot(0, 0, 3, p["c"])); o.append(dot(70, 0, 3, p["c"])); o.append(dot(0, 70, 3, p["c"])); o.append(dot(70, 70, 3, p["c"]))
    return 70, 70, "".join(o), 0

def wisteria(p):          # hanging wisteria: cones of tiny blooms on a vine
    o = [stem("M0 8 Q15 2 30 8 T60 8", p["l"], 1.6), leaf(12, 6, 10, 150, p["l"]), leaf(44, 8, 10, 30, p["l2"])]
    for x0, col in ((16, p["a"]), (44, p["c"])):
        for k in range(9):
            y = 14 + k * 6.5; spread = 7 * (1 - k / 10)
            for j in (-1, 0, 1):
                if k > 6 and j: continue
                o.append(dot(x0 + j * spread * .7, y + (j * 1.5), 2.6 - k * .17, col if (k + j) % 2 else p["b"]))
    return 60, 84, "".join(o), 0

def damask(p):            # damask: a mirrored medallion of scrolls and a flower
    o = []
    cx, cy = 35, 50
    for s in (1, -1):
        o.append(curl(cx + s * 12, cy - 14, 9, 180 if s > 0 else 0, s, 1.6, p["a"]))
        o.append(curl(cx + s * 12, cy + 14, 9, 180 if s > 0 else 0, -s, 1.6, p["a"]))
        o.append(leaf(cx, cy - 22, 14, -90 + s * 35, p["l"]))
        o.append(leaf(cx, cy + 22, 14, 90 - s * 35, p["l"]))
    o.append(f'<path d="M{cx} {cy - 34} L{cx + 18} {cy} L{cx} {cy + 34} L{cx - 18} {cy}Z" fill="none" stroke="{p["b"]}" stroke-width="1"/>')
    o.append(bloom(cx, cy, 10, 6, p["a"], p["g"])); o.append(petals(cx, cy, 5, 6, p["b"], rot=30))
    o.append(dot(0, 0, 2.4, p["c"])); o.append(dot(70, 0, 2.4, p["c"])); o.append(dot(0, 100, 2.4, p["c"])); o.append(dot(70, 100, 2.4, p["c"]))
    return 70, 100, "".join(o), 0

def violets(p):           # sweet violets in little clusters, heart-shaped leaves
    def violet(x, y, s, col):
        return (f'<ellipse cx="{x - 3*s}" cy="{y - 3*s}" rx="{3.2*s}" ry="{4*s}" fill="{col}" transform="rotate(-25 {x - 3*s} {y - 3*s})"/>'
                f'<ellipse cx="{x + 3*s}" cy="{y - 3*s}" rx="{3.2*s}" ry="{4*s}" fill="{col}" transform="rotate(25 {x + 3*s} {y - 3*s})"/>'
                + petals(x, y + 1.5 * s, 7 * s, 3, p["b"], rot=30) + dot(x, y, 1.2 * s, "#ffe58a"))
    heart = lambda x, y, s: f'<path d="M{x} {y + 6*s} C{x - 8*s} {y} {x - 4*s} {y - 6*s} {x} {y - 2*s} C{x + 4*s} {y - 6*s} {x + 8*s} {y} {x} {y + 6*s}Z" fill="{p["l"]}"/>'
    b = [heart(14, 34, 1.2), heart(40, 14, 1), violet(16, 16, 1, p["a"]), violet(24, 24, .8, p["c"]), violet(40, 40, 1, p["a"])]
    return 52, 52, "".join(b), 0

def forgetmenot(p):       # forget-me-nots: tiny round five-petal flowers with sunny eyes
    fl = lambda x, y, r, col: petals(x, y, r, 5, col, w=.5, d=.62) + dot(x, y, r * .3, "#ffd84a")
    b = [fl(8, 8, 6, p["a"]), fl(26, 18, 5, p["b"]), fl(12, 30, 4.5, p["c"]), leaf(18, 8, 7, 20, p["l"]), leaf(30, 30, 6, 210, p["l2"])]
    return 38, 38, "".join(b), 0

def gingham(p):           # gingham check, a tiny flower in every dark square
    b = [f'<rect x="0" y="0" width="12" height="24" fill="{p["g"]}" opacity=".75"/>', f'<rect x="0" y="0" width="24" height="12" fill="{p["g"]}" opacity=".75"/>',
         bloom(6, 6, 4.5, 5, p["a"], "#fff6d8")]
    return 24, 24, "".join(b), 0

def daisies70s(p):        # 70s kitchen: chunky daisies in three colours
    chunk = lambda x, y, r, col, mid: petals(x, y, r, 8, col, w=.36, d=.62) + dot(x, y, r * .32, mid)
    b = [chunk(20, 20, 17, p["a"], p["d"]), chunk(56, 50, 14, p["c"], p["a"]), chunk(16, 62, 9, p["b"], p["c"]),
         leaf(42, 20, 14, -20, p["l"]), leaf(34, 64, 12, 160, p["l2"])]
    return 74, 74, "".join(b), 0

def tulips(p):            # Dutch tulips in offset rows
    def tulip(x, y, col):
        return (stem(f"M{x} {y + 6} L{x} {y + 22}", p["l"], 1.6) + leaf(x, y + 20, 10, -120, p["l"]) + leaf(x, y + 18, 10, -60, p["l2"])
                + f'<path d="M{x - 6} {y - 4} L{x - 6} {y + 4} Q{x} {y + 10} {x + 6} {y + 4} L{x + 6} {y - 4} L{x + 3} {y} L{x} {y - 6} L{x - 3} {y}Z" fill="{col}"/>')
    b = [tulip(12, 10, p["a"]), tulip(37, 40, p["c"])]
    return 50, 60, "".join(b), 0

def trellis(p):           # a garden trellis with a rose at every crossing
    b = [stem("M0 0 L40 40", p["l"], 1.2), stem("M40 0 L0 40", p["l"], 1.2), rose(20, 20, 6.5, p), leaf(24, 24, 7, 40, p["l2"]),
         leaf(16, 16, 7, 220, p["l2"]), dot(0, 20, 1.5, p["c"]), dot(40, 20, 1.5, p["c"])]
    return 40, 40, "".join(b), 0

def calico(p):            # calico: tiny flowers packed close, like a quilt square
    b = [bloom(6, 6, 4, 5, p["a"], p["d"]), bloom(20, 12, 3.4, 5, p["c"], p["d"], 30), bloom(10, 22, 3.4, 5, p["b"], p["d"], 15),
         bloom(24, 26, 3.8, 5, p["a"], p["d"], 40), dot(16, 3, 1, p["l"]), dot(2, 16, 1, p["l"]), dot(28, 18, 1, p["l"])]
    return 30, 30, "".join(b), 0

def sunflowers(p):        # sunflowers: big heads of petals round seed-dotted hearts
    def sun(x, y, r):
        return (petals(x, y, r, 14, p["a"], w=.24, d=.72) + petals(x, y, r * .85, 14, p["b"], w=.22, d=.66, rot=13)
                + dot(x, y, r * .38, "#7a4a1a") + "".join(dot(x + r * .2 * math.cos(k), y + r * .2 * math.sin(k), .9, "#c08a3a") for k in range(6)))
    b = [leaf(30, 34, 18, 120, p["l"], p["l2"]), leaf(30, 34, 16, 30, p["l2"]), sun(26, 26, 18), sun(66, 66, 11), leaf(72, 52, 12, -60, p["l"])]
    return 84, 84, "".join(b), 0

def hydrangea(p):         # hydrangea mopheads: domes of four-petal florets
    o = [leaf(20, 40, 18, 150, p["l"], p["l2"]), leaf(44, 40, 18, 30, p["l"], p["l2"])]
    for k, (dx, dy) in enumerate([(0, 0), (8, 2), (-8, 2), (4, -7), (-4, -7), (0, 9), (9, -5), (-9, -5), (6, 9), (-6, 9)]):
        x, y = 32 + dx, 28 + dy
        o.append(petals(x, y, 6, 4, [p["a"], p["b"], p["c"]][k % 3], w=.48, d=.5, rot=45 + k * 10))
        o.append(dot(x, y, 1, p["d"]))
    o.append(petals(4, 62, 5, 4, p["b"], w=.48, rot=45)); o.append(petals(62, 4, 5, 4, p["c"], w=.48, rot=45))
    return 66, 66, "".join(o), 0

def sweetpea(p):          # sweet peas climbing on curly tendrils
    def pea(x, y, col):
        return (f'<path d="M{x} {y} C{x - 9} {y - 4} {x - 8} {y - 13} {x} {y - 9} C{x + 8} {y - 13} {x + 9} {y - 4} {x} {y}Z" fill="{col}"/>'
                + f'<ellipse cx="{x}" cy="{y - 1}" rx="2.6" ry="3.6" fill="{p["b"]}"/>')
    b = [stem("M0 60 C18 44 22 30 40 22 S56 4 60 0", p["l"], 1.5), curl(24, 40, 5, 0, 1, .9, p["l"]), curl(50, 12, 4, 90, -1, .9, p["l"]),
         leaf(34, 26, 10, -150, p["l2"]), leaf(12, 50, 9, -30, p["l2"]), pea(20, 34, p["a"]), pea(46, 16, p["c"]), pea(52, 50, p["a"])]
    return 60, 60, "".join(b), 0

def pansies(p):           # pansies with their dark velvet faces
    def pansy(x, y, s, top, low):
        return (f'<ellipse cx="{x - 3.5*s}" cy="{y - 4*s}" rx="{4.2*s}" ry="{4.6*s}" fill="{top}"/>'
                f'<ellipse cx="{x + 3.5*s}" cy="{y - 4*s}" rx="{4.2*s}" ry="{4.6*s}" fill="{top}"/>'
                f'<ellipse cx="{x - 4.8*s}" cy="{y + 1*s}" rx="{3.8*s}" ry="{3.4*s}" fill="{low}"/>'
                f'<ellipse cx="{x + 4.8*s}" cy="{y + 1*s}" rx="{3.8*s}" ry="{3.4*s}" fill="{low}"/>'
                f'<ellipse cx="{x}" cy="{y + 4*s}" rx="{4.6*s}" ry="{4*s}" fill="{low}"/>'
                f'<circle cx="{x}" cy="{y + 1*s}" r="{2.6*s}" fill="{p["d"]}"/>' + dot(x, y + .6 * s, 1 * s, "#ffe066"))
    b = [leaf(22, 30, 12, 140, p["l"]), leaf(48, 44, 11, -20, p["l2"]), pansy(18, 18, 1.15, p["c"], p["a"]), pansy(46, 44, 1, p["a"], p["b"])]
    return 62, 62, "".join(b), 0

def feedsack(p):          # 1940s feedsack print: bold simple flowers, leaves and dots
    b = [petals(14, 14, 11, 4, p["a"], w=.5, d=.55, rot=45), dot(14, 14, 2.6, "#fff6d8"), leaf(26, 22, 12, 30, p["l"]),
         leaf(6, 30, 10, 120, p["l2"]), petals(38, 38, 7, 4, p["c"], w=.5, d=.55), dot(38, 38, 1.8, "#fff6d8"),
         dot(40, 10, 2, p["b"]), dot(10, 44, 2, p["b"])]
    return 52, 52, "".join(b), 0

def toile(p):             # toile: one-colour line-drawn sprigs
    d = p["d"]
    def sprig(x, y, a):
        return (f'<g transform="rotate({a} {x} {y})" fill="none" stroke="{d}" stroke-width="1" stroke-linecap="round">'
                f'<path d="M{x} {y + 16} Q{x + 2} {y} {x} {y - 14}"/>'
                + "".join(f'<path d="M{x} {y + k} q{6 * s} -4 {9 * s} -1 q-4 4 -9 1z"/>' for k, s in ((8, 1), (2, -1), (-5, 1)))
                + f'<circle cx="{x}" cy="{y - 17}" r="3.5"/><circle cx="{x}" cy="{y - 17}" r="1.2" fill="{d}"/></g>')
    b = [sprig(18, 22, -20), sprig(52, 54, 25), f'<circle cx="52" cy="14" r="1.4" fill="{d}"/>', f'<circle cx="14" cy="58" r="1.4" fill="{d}"/>']
    return 70, 70, "".join(b), 0

DESIGN = {   # card -> print
    "AH": chintz, "KH": ribbon_stripe, "QH": strawberry, "JH": polka_rosebud, "10H": doily,
    "AS": wisteria, "KS": damask, "QS": violets, "JS": forgetmenot, "10S": gingham,
    "AD": daisies70s, "KD": tulips, "QD": trellis, "JD": calico, "10D": sunflowers,
    "AC": hydrangea, "KC": sweetpea, "QC": pansies, "JC": feedsack, "10C": toile,
}

def defs():
    out = []
    for card, fn in DESIGN.items():
        w, h, body, rot = fn(PAL[card[-1]])
        out.append(tile(f"wp-{card}", w, h, body, rot))
    # the fade: the print at full strength by the edges, falling to about a third in the middle of the card
    out.append('<radialGradient id="wp-fade-g" cx="125" cy="175" r="205" gradientUnits="userSpaceOnUse">'
               '<stop offset="0" stop-color="#555"/><stop offset=".45" stop-color="#8a8a8a"/><stop offset="1" stop-color="#fff"/></radialGradient>'
               '<mask id="wp-fade" maskUnits="userSpaceOnUse" x="0" y="0" width="250" height="350"><rect x="0" y="0" width="250" height="350" fill="url(#wp-fade-g)"/></mask>')
    return "".join(out)

# --------------------------------------------------------------- THE BACK: 70s flower power in the four suit colours
SEV = dict(red="#c8452c", blue="#3d6fa3", green="#7a8b2c", yellow="#e0a526", brown="#6b4423", cream="#f3e6c4", orange="#d9772b")

def power(x, y, r, petal, ring, eye):
    """A chunky 70s daisy: round fat petals, a contrasting ring, a dark eye."""
    o = [petals(x, y, r, 8, petal, w=.46, d=.6)]
    o.append(dot(x, y, r * .44, ring)); o.append(dot(x, y, r * .3, SEV["cream"])); o.append(dot(x, y, r * .18, eye))
    return "".join(o)

def back70s():
    S = SEV
    t = [f'<rect width="100" height="100" fill="{S["cream"]}"/>',
         leaf(30, 50, 22, 200, S["green"]), leaf(70, 50, 22, -20, S["green"]),
         power(26, 26, 22, S["red"], S["yellow"], S["brown"]), power(76, 76, 22, S["blue"], S["orange"], S["brown"]),
         power(78, 22, 14, S["yellow"], S["red"], S["brown"]), power(22, 78, 14, S["green"], S["yellow"], S["brown"]),
         dot(50, 50, 4, S["orange"]), dot(50, 4, 2.4, S["brown"]), dot(4, 50, 2.4, S["brown"]), dot(96, 50, 2.4, S["brown"]), dot(50, 96, 2.4, S["brown"])]
    pat = tile("bk70", 100, 100, "".join(t))
    G, GL = "#c99a2e", "#7a5a14"
    body = [f'<rect width="250" height="350" fill="{S["cream"]}"/>',
            # the print fills the panel; its tile is scaled down so several flowers show even on a small card
            f'<g transform="translate(22 22) scale(.62)"><rect width="333" height="493" fill="url(#bk70)"/></g>',
            # a brown-and-mustard band between the print and the gold frame, very 1974
            f'<rect x="14" y="14" width="222" height="322" rx="10" fill="none" stroke="{S["brown"]}" stroke-width="9"/>',
            f'<rect x="20" y="20" width="210" height="310" rx="7" fill="none" stroke="{S["yellow"]}" stroke-width="3"/>',
            f'<rect x="5" y="5" width="240" height="340" rx="6" fill="none" stroke="{G}" stroke-width="2.4"/>',
            f'<rect x="10" y="10" width="230" height="330" rx="3" fill="none" stroke="{GL}" stroke-width=".8"/>',
            # the 66 in a rounded cartouche, mustard on brown
            f'<rect x="80" y="150" width="90" height="50" rx="25" fill="{S["brown"]}" stroke="{S["yellow"]}" stroke-width="3"/>',
            f'<rect x="86" y="156" width="78" height="38" rx="19" fill="none" stroke="{S["orange"]}" stroke-width="1.5"/>',
            f'<text x="125" y="187" text-anchor="middle" font-family="Limelight, Georgia, serif" font-size="30" fill="{S["yellow"]}">66</text>']
    return pat, "".join(body)
