"""Card-face prints cut from Cooper Hewitt wallpaper scans (Smithsonian Open Access; Seth's Archive.zip).
Each card gets one 5:7 cutout, tinted slightly toward its suit, saved as WebP in app/prints/<rank><suit>.webp.
Usage: python3 prints.py <folder with the scans> <output folder> [<folder with the second batch>]"""
import sys, os
import numpy as np
from PIL import Image

SRC, OUT = sys.argv[1], sys.argv[2]
# card: (file, centre x, centre y, width) as fractions of the scan; height follows from the card's 5:7 shape
CUTS = {
    "AH":  ("CHSDM-186467_51-000001.jpg",        .68, .68, .50),   # red damask with cabbage roses
    "KH":  ("CHSDM-5059AE0FDFC22_04-000001.jpg", .55, .40, .60),   # red leaves and blossoms
    "QH":  ("CHSDM-5059AE0FDFC22_01-000001.jpg", .55, .45, .60),   # red roses, blue vines
    "JH":  ("CHSDM-2DFCE5295BF72-000001.jpg",    .50, .45, .55),   # pink blossom tree
    "10H": ("CHSDM-1973-69-2MattFlynn.jpg",      .72, .36, .45),   # rose corner of the garden scene
    "AS":  ("CHSDM-5059AE0FDFC22_03-000001.jpg", .45, .38, .55),   # blue flowers, dark leaves
    "KS":  ("CHSDM-5059AE0FDFC22_02-000001.jpg", .52, .45, .60),   # fleur-de-lis damask
    "QS":  ("CHSDM-1977-28-14-aMattFlynn.jpg",   .50, .40, .70),   # teal Art Nouveau
    "JS":  ("CHSDM-6CC094F3AC072-000001.jpg",    .19, .19, .24),   # blue hydrangea from the flower sampler
    "10S": ("CHSDM-CHP6565.jpg",                 .50, .615, .50),   # grey rosette damask
    "AD":  ("CHSDM-5059AE0FDFC22_06-000001.jpg", .55, .38, .60),   # big gold flowers
    "KD":  ("CHSDM-5059AE0FDFC22_05-000001.jpg", .55, .40, .55),   # yellow and brown daisies
    "QD":  ("CHSDM-1930-18-1-aMattFlynn.jpg",    .50, .48, .50),   # bouquet on orange trellis
    "JD":  ("CHSDM-160538_01-000001.jpg",        .50, .40, .80),   # yellow rose trellis
    "10D": ("CHSDM-1977-28-7-hMattFlynn.jpg",    .50, .40, .90),   # gold leaves
    "AC":  ("CHSDM-AE9120ACCFD42-000001.jpg",    .55, .42, .60),   # honeysuckle
    "KC":  ("CHSDM-1914-21-54MattFlynn.jpg",     .50, .50, .39),   # flower bed
    "QC":  ("CHSDM-1940-120-33MattFlynn.jpg",    .50, .56, .50),   # green lace
    "JC":  ("CHSDM-1940-120-70MattFlynn.jpg",    .50, .585, .48),  # green check
    "10C": ("CHSDM-1940-120-41MattFlynn.jpg",    .50, .585, .48),  # green and pink stripe
    # the nines (shown as 0 on house tables), from papers not used elsewhere
    "9H":  ("CHSDM-1930-18-1-eMattFlynn.jpg",    .66, .50, .50),   # poppy bouquet
    "9S":  ("CHSDM-6CC094F3AC072-000001.jpg",    .19, .50, .24),   # pansies from the flower sampler
    "9D":  ("CHSDM-8539706870502-000001.jpg",    .50, .50, .55),   # beige trellis with posies
    "9C":  ("CHSDM-1930-18-1-hMattFlynn.jpg",    .58, .47, .56),   # pastel watercolour meadow
}
TINT = {"H": (232, 86, 96), "S": (92, 128, 220), "D": (232, 176, 40), "C": (72, 160, 92)}
AMOUNT = .12                     # how far each cutout leans toward its suit colour (a light touch)
W, H = 250, 350

def tint(card, c):
    a = np.asarray(c).astype(float)
    lum = (a @ [.299, .587, .114])[..., None] / 255
    t = np.array(TINT[card[-1]], float)
    tinted = lum * t + (1 - lum) * t * .25
    return Image.fromarray(np.clip(a * (1 - AMOUNT) + tinted * AMOUNT, 0, 255).astype(np.uint8))

def cut(card):
    f, cx, cy, wf = CUTS[card]
    im = Image.open(os.path.join(SRC, f)).convert("RGB")
    iw, ih = im.size
    w = wf * iw; h = w * 1.4
    if h > ih * .98: h = ih * .98; w = h / 1.4
    x0 = min(max(cx * iw - w / 2, 0), iw - w); y0 = min(max(cy * ih - h / 2, 0), ih - h)
    c = im.crop((round(x0), round(y0), round(x0 + w), round(y0 + h))).resize((W, H), Image.LANCZOS)
    a = np.asarray(c).astype(float)
    lum = (a @ [.299, .587, .114])[..., None] / 255
    t = np.array(TINT[card[-1]], float)
    tinted = lum * t + (1 - lum) * t * .25                 # the suit colour, carrying the paper's light and shade
    out = a * (1 - AMOUNT) + tinted * AMOUNT
    return Image.fromarray(np.clip(out, 0, 255).astype(np.uint8)), (round(x0), round(y0), round(w), round(h))

# THE NEW PICKS (both sets). The sun prints were judged on their own against a second batch of scans (Seth's
# second Archive.zip: Cooper Hewitt and National Museum of American History textiles and wallpapers); where a new
# paper made the better sun print it replaces the old one here, in both the sun-print and the wallpaper set. Entries name the
# folder too, since they come from two archives: (folder key, file, cx, cy, width).
SRC2 = sys.argv[3] if len(sys.argv) > 3 else os.path.join(os.path.dirname(SRC.rstrip("/")), "archive2")
CYANO_PICKS = {
    "10H": (2, "CHSDM-5D5011E64A462-000001.jpg",  .60, .32, .46),   # block-printed rose vine (replaces the washed garden scene)
    "JS":  (2, "CHSDM-B15A41F6A8722-000001.jpg",  .83, .55, .32),   # Indian chintz medallion (replaces the soft hydrangea)
    "9S":  (2, "CHSDM-C38C74DF205E2-000001.jpg",  .50, .30, .80),   # chintz florals (replaces the soft pansies)
    "QD":  (2, "CHSDM-294456_01-000001.jpg",      .50, .72, .80),   # feathered floral stripe, lower (replaces the bare trellis bouquet)
    "JD":  (2, "CHSDM-4B74AA0A8D402-000001.jpg",  .50, .42, .68),   # trellis chintz (replaces the pale rococo trellis)
    "9D":  (2, "CHSDM-1973-51-21MattFlynn.jpg",   .50, .50, .55),   # scattered chintz on yellow (replaces the sparse posies)
    "KC":  (2, "CHSDM-294456_01-000001.jpg",      .55, .30, .80),   # feathered floral stripe, upper (replaces the soft flower bed)
    "JC":  (2, "CHSDM-C38C74DF205E2-000001.jpg",  .50, .72, .80),   # chintz florals, lower (replaces the plain check)
    "10C": (2, "CHSDM-3790258B2C4A2-000001.jpg",  .48, .56, .62),   # flower and lattice (replaces the faint stripe)
    "9C":  (2, "CHSDM-B15A41F6A8722-000001.jpg",  .22, .52, .40),   # chintz flower sprays (replaces the blotchy watercolour)
}

def crop_from(folder, f, cx, cy, wf):
    im = Image.open(os.path.join(folder, f)).convert("RGB"); iw, ih = im.size
    w = wf * iw; h = w * 1.4
    if h > ih * .96: h = ih * .96; w = h / 1.4
    x0 = min(max(cx * iw - w / 2, 0), iw - w); y0 = min(max(cy * ih - h / 2, 0), ih - h)
    return im.crop((round(x0), round(y0), round(x0 + w), round(y0 + h))).resize((W, H), Image.LANCZOS)

# CYANOTYPE: the same cutout as a one-colour sun print. Shadows take the suit's deep pigment, highlights go to
# cream paper; contrast is stretched first, then a little paper grain and an uneven wash so it reads as printed.
INK = {"H": (128, 18, 30), "S": (16, 52, 118), "D": (112, 72, 0), "C": (16, 80, 44)}
PAPER = np.array((246, 240, 226), float)

def cyanotype(card, im):
    import numpy as np
    a = np.asarray(im).astype(float)
    lum = a @ [.299, .587, .114]
    lo, hi = np.percentile(lum, 3), np.percentile(lum, 97)
    t = np.clip((lum - lo) / max(hi - lo, 1), 0, 1) ** .85          # 0 = deepest shadow, 1 = paper
    rng = np.random.default_rng(sum(map(ord, card)))
    yy, xx = np.mgrid[0:H, 0:W]
    wash = .06 * np.sin(xx / 37 + rng.uniform(0, 6)) * np.sin(yy / 53 + rng.uniform(0, 6))
    t = np.clip(t + wash + rng.normal(0, .025, t.shape), 0, 1)[..., None]
    out = np.array(INK[card] if card in INK else INK[card[-1]], float) * (1 - t) + PAPER * t
    return Image.fromarray(np.clip(out, 0, 255).astype(np.uint8))

# THE BACK: one paper for every card, the lilies Seth linked first. Wallpaper set: the paper as it is (no suit tint);
# sun-print set: classic Prussian-blue cyanotype, a positive (pale ground, blue lilies), as Seth preferred. Larger than the faces, since the stock card shows a back.
BACK = ("CHSDM-154584_02-000001.jpg", .5, .46, .94)
BACK_INK = (16, 46, 104)

def back_images(out_dir):
    global W, H
    w0, h0 = W, H
    W, H = 400, 560
    f, cx, cy, wf = BACK
    im = Image.open(os.path.join(SRC, f)).convert("RGB"); iw, ih = im.size
    w = wf * iw; h = w * 1.4
    if h > ih * .98: h = ih * .98; w = h / 1.4
    x0 = min(max(cx * iw - w / 2, 0), iw - w); y0 = min(max(cy * ih - h / 2, 0), ih - h)
    raw = im.crop((round(x0), round(y0), round(x0 + w), round(y0 + h))).resize((W, H), Image.LANCZOS)
    os.makedirs(out_dir, exist_ok=True)
    raw.save(os.path.join(out_dir, "back-print.webp"), quality=74, method=6)
    INK["BACK"] = BACK_INK
    cyanotype("BACK", raw).save(os.path.join(out_dir, "back-cyano.webp"), quality=70, method=6)
    W, H = w0, h0

if __name__ == "__main__":
    back_images(os.path.join(os.path.dirname(OUT.rstrip("/")), "backs"))
    os.makedirs(OUT, exist_ok=True)
    cy = os.path.join(os.path.dirname(OUT.rstrip("/")), "cyano"); os.makedirs(cy, exist_ok=True)
    for card in CUTS:
        im, box = cut(card)
        if card in CYANO_PICKS:                                         # the wallpaper set takes the same new papers
            _, f2, cx2, cy2, wf2 = CYANO_PICKS[card]
            im = tint(card, crop_from(SRC2, f2, cx2, cy2, wf2))
        im.save(os.path.join(OUT, f"{card}.webp"), quality=72, method=6)
        if card in CYANO_PICKS:
            _, f, cx, cyy, wf = CYANO_PICKS[card]
            raw = crop_from(SRC2, f, cx, cyy, wf)
        else:
            f, cx, cyy, wf = CUTS[card]
            raw = Image.open(os.path.join(SRC, f)).convert("RGB").crop((box[0], box[1], box[0] + box[2], box[1] + box[3])).resize((W, H), Image.LANCZOS)
        cyanotype(card, raw).save(os.path.join(cy, f"{card}.webp"), quality=62, method=6)
        print(card, CUTS[card][0], box)
