"""Generates the card ornament as SVG <symbol>s (viewBox 250 x 350, one card) for app/ui/ornament.js.
Half the card is drawn; the card shows it twice, the second turned 180 degrees, like any two-way deck.
References: corner flourishes from Nicu's Ornamental; the lace rosette, wreath and border of the Ovale Salon
aces; the floral cartouches of the Dondorf and Hamburg 1864 aces (PySolFC cardsets)."""
import math
import wallpaper            # the twenty grandma prints behind the faces (wallpaper.py, beside this file)
GOLD, GOLD_HI, GOLD_LO = "#c99a2e", "#f0cf6a", "#7a5a14"
PETALS = ["#e8217a", "#ff7a1a", "#8a3ffc", "#ffc61a", "#2f7bff", "#ff4fa3", "#13b5a6", "#ff3b3b"]
LEAF = ["#2e9e46", "#69c23a", "#0f8a6a"]
f = lambda v: f"{v:.1f}".rstrip("0").rstrip(".")

def flower(cx, cy, r, n, col, inner, rot=0):
    out = []
    for k in range(n):
        a = rot + k * 360 / n
        x = cx + r * .55 * math.cos(math.radians(a)); y = cy + r * .55 * math.sin(math.radians(a))
        out.append(f'<ellipse cx="{f(x)}" cy="{f(y)}" rx="{f(r*.5)}" ry="{f(r*.3)}" transform="rotate({f(a)} {f(x)} {f(y)})" fill="{col}" stroke="{GOLD_LO}" stroke-width=".5"/>')
    for k in range(n):
        a = rot + 180 / n + k * 360 / n
        x = cx + r * .3 * math.cos(math.radians(a)); y = cy + r * .3 * math.sin(math.radians(a))
        out.append(f'<ellipse cx="{f(x)}" cy="{f(y)}" rx="{f(r*.3)}" ry="{f(r*.17)}" transform="rotate({f(a)} {f(x)} {f(y)})" fill="{inner}"/>')
    out.append(f'<circle cx="{f(cx)}" cy="{f(cy)}" r="{f(r*.22)}" fill="{GOLD_HI}" stroke="{GOLD_LO}" stroke-width=".6"/>')
    out.append(f'<circle cx="{f(cx)}" cy="{f(cy)}" r="{f(r*.08)}" fill="{GOLD_LO}"/>')
    return "".join(out)

def leaf(x, y, ln, a, col):
    w = ln * .32
    return (f'<path d="M0 0Q{f(ln*.5)} {f(-w)} {f(ln)} 0Q{f(ln*.5)} {f(w)} 0 0Z" fill="{col}" stroke="#145a2a" stroke-width=".5" '
            f'transform="translate({f(x)} {f(y)}) rotate({f(a)})"/>'
            f'<path d="M0 0L{f(ln*.85)} 0" stroke="#d6f5b0" stroke-width=".5" transform="translate({f(x)} {f(y)}) rotate({f(a)})"/>')

def curl(x, y, r, a, sweep=1, w=1.6, col=GOLD):
    """A gold C-scroll ending in a tight spiral: the basic stroke of filigree."""
    pts = []
    for k in range(48):
        t = k / 47 * 1.75 * math.pi
        rr = r * (1 - t / (2.1 * math.pi))
        ang = math.radians(a) + sweep * t
        pts.append((x + rr * math.cos(ang), y + rr * math.sin(ang)))
    d = "M" + " L".join(f"{f(px)} {f(py)}" for px, py in pts)
    return f'<path d="{d}" fill="none" stroke="{col}" stroke-width="{w}" stroke-linecap="round"/>'

def dots(pts, r=1.3, col=GOLD_HI):
    return "".join(f'<circle cx="{f(x)}" cy="{f(y)}" r="{f(r)}" fill="{col}" stroke="{GOLD_LO}" stroke-width=".4"/>' for x, y in pts)

def vine(x0, y0, x1, y1, amp, waves, cols, start=0):
    """A garland: a gold-green stem waving between two points, leaves on every crest, a flower on every other."""
    n = 60; pts = []
    L = math.hypot(x1 - x0, y1 - y0); ux, uy = (x1 - x0) / L, (y1 - y0) / L; nx, ny = -uy, ux
    for k in range(n + 1):
        t = k / n; s = amp * math.sin(t * waves * 2 * math.pi)
        pts.append((x0 + ux * L * t + nx * s, y0 + uy * L * t + ny * s))
    out = [f'<path d="M{" L".join(f"{f(a)} {f(b)}" for a, b in pts)}" fill="none" stroke="#3f7d2a" stroke-width="1.6"/>',
           f'<path d="M{" L".join(f"{f(a)} {f(b)}" for a, b in pts)}" fill="none" stroke="{GOLD_HI}" stroke-width=".5" stroke-dasharray="2 3"/>']
    crests = int(waves * 2)
    for c in range(crests):
        t = (c + .5) / crests
        side = 1 if c % 2 == 0 else -1
        px, py = x0 + ux * L * t + nx * amp * side, y0 + uy * L * t + ny * amp * side
        ang = math.degrees(math.atan2(uy, ux))
        out.append(leaf(px, py, 9, ang + 140 * side, LEAF[c % 3]))
        out.append(leaf(px, py, 8, ang + 40 * side, LEAF[(c + 1) % 3]))
    for c in range(crests):
        t = (c + .5) / crests; side = 1 if c % 2 == 0 else -1
        px, py = x0 + ux * L * t + nx * amp * side * .2, y0 + uy * L * t + ny * amp * side * .2
        col = cols[(start + c) % len(cols)]
        out.append(flower(px, py, 7 if c % 2 else 8.5, 5 + c % 2, col, "#fff3c4" if c % 3 else "#ffe36b", rot=c * 17))
    return "".join(out)

def bouquet(cx, cy, s, cols):
    """The corner illumination's flowers: one big bloom, two smaller, buds and leaves, gold curls behind."""
    o = []
    o.append(curl(cx - 20 * s, cy + 2 * s, 11 * s, 200, 1, 1.7)); o.append(curl(cx + 4 * s, cy + 22 * s, 11 * s, 290, -1, 1.7))
    o.append(curl(cx - 30 * s, cy - 6 * s, 7 * s, 160, -1, 1.2)); o.append(curl(cx + 12 * s, cy + 30 * s, 7 * s, 330, 1, 1.2))
    for a, col in [(200, 0), (250, 1), (300, 2), (150, 0), (340, 1)]:
        o.append(leaf(cx, cy, 20 * s, a, LEAF[col]))
    o.append(flower(cx - 16 * s, cy + 13 * s, 10 * s, 5, cols[1], "#fff3c4", 20))
    o.append(flower(cx + 14 * s, cy - 14 * s, 9 * s, 6, cols[2], "#ffe9ff", 10))
    o.append(flower(cx, cy, 15 * s, 8, cols[0], "#ffd0e4", 0))
    o.append(dots([(cx - 26 * s, cy - 18 * s), (cx + 24 * s, cy + 6 * s), (cx - 6 * s, cy + 26 * s), (cx + 6 * s, cy - 26 * s)], 2.1 * s, cols[3]))
    return "".join(o)

def crest(cx, cy, w):
    """Top-centre filigree: symmetric lace scrolls around a small rosette."""
    o = []
    for sg in (1, -1):
        o.append(curl(cx + sg * w * .25, cy + 1, 7, 180 if sg > 0 else 0, -sg, 1.3))
        o.append(curl(cx + sg * w * .5, cy - 1, 5.5, 180 if sg > 0 else 0, sg, 1.1))
        o.append(f'<path d="M{f(cx)} {f(cy+6)} Q{f(cx+sg*w*.3)} {f(cy+12)} {f(cx+sg*w*.62)} {f(cy+3)}" fill="none" stroke="{GOLD}" stroke-width="1.1"/>')
        o.append(leaf(cx + sg * w * .38, cy + 9, 8, 90 - sg * 60, LEAF[1]))
    o.append(flower(cx, cy + 2, 7.5, 6, PETALS[4], "#dff0ff", 0))
    o.append(dots([(cx - w * .68, cy + 3), (cx + w * .68, cy + 3), (cx, cy - 8)], 1.4))
    return "".join(o)

def frame():
    return (f'<rect x="5" y="5" width="240" height="340" rx="6" fill="none" stroke="{GOLD}" stroke-width="2.4"/>'
            f'<rect x="10" y="10" width="230" height="330" rx="3" fill="none" stroke="{GOLD_LO}" stroke-width=".8"/>'
            f'<rect x="10" y="10" width="230" height="330" rx="3" fill="none" stroke="{GOLD_HI}" stroke-width=".6" stroke-dasharray="1 4"/>')

def index_cartouche():
    """Corner illumination around the index: a gold scroll bracket with curls and a rosette at the corner."""
    o = [f'<path d="M14 122 L14 22 Q14 14 22 14 L70 14" fill="none" stroke="{GOLD}" stroke-width="2"/>',
         f'<path d="M18.5 112 L18.5 26 Q18.5 18.5 26 18.5 L64 18.5" fill="none" stroke="#1f3fbf" stroke-width="1.6"/>',
         f'<path d="M22 104 L22 28 Q22 22 28 22 L58 22" fill="none" stroke="{GOLD}" stroke-width=".7"/>',
         dots([(18.5, 40 + 14 * k) for k in range(5)] + [(30 + 12 * k, 18.5) for k in range(3)], 1.5, "#e0301e"),
         curl(14, 128, 6, 270, 1, 1.6), curl(76, 14, 6, 180, -1, 1.6),
         curl(14, 140, 4, 90, -1, 1.1), curl(88, 14, 4, 0, 1, 1.1),
         flower(14, 14, 10, 6, PETALS[0], "#ffd0e4", 15),
         flower(10, 50, 5, 5, PETALS[3], "#fff3c4", 0), flower(40, 9, 5, 5, PETALS[4], "#dff0ff", 0),
         leaf(18, 18, 12, 45, LEAF[0]),
         dots([(14, 150), (98, 14)], 1.5)]
    return "".join(o)

half = (frame()                                                      # drawn once per half; the double rule overlaps cleanly
        + index_cartouche()
        + bouquet(212, 42, 1.2, [PETALS[0], PETALS[1], PETALS[2], PETALS[3]])
        + crest(125, 22, 70)
        + vine(16, 160, 16, 320, 6, 2, [PETALS[5], PETALS[4], PETALS[3], PETALS[6]], 0))
# A faint gold lace over the whole face, under the pips: the texture of an engraved card stock.
lace_tile = (curl(12.5, 12.5, 7, 0, 1, .9) + curl(37.5, 37.5, 7, 180, 1, .9) + curl(37.5, 12.5, 5, 90, -1, .7) + curl(12.5, 37.5, 5, 270, -1, .7)
             + dots([(25, 25), (0, 0), (50, 0), (0, 50), (50, 50)], 1.1, GOLD))
lace = (f'<pattern id="orn-lace-tile" width="50" height="50" patternUnits="userSpaceOnUse">{lace_tile}</pattern>')
# The centre medallion for cards with an empty middle (the 2 and the 4): a smaller wreath of lace and flowers.
mid = []
for k in range(12):
    a = k * 30
    x = 125 + 34 * math.cos(math.radians(a)); y = 175 + 34 * math.sin(math.radians(a))
    mid.append(curl(x, y, 7, a + 90, 1 if k % 2 else -1, 1.2))
for k in range(6):
    a = k * 60 + 30
    x = 125 + 46 * math.cos(math.radians(a)); y = 175 + 46 * math.sin(math.radians(a))
    mid.append(leaf(x, y, 11, a + 100, LEAF[k % 3]))
for k in range(6):
    a = k * 60
    x = 125 + 48 * math.cos(math.radians(a)); y = 175 + 48 * math.sin(math.radians(a))
    mid.append(flower(x, y, 9, 6, PETALS[(k * 3) % 8], "#fff3c4", k * 11))
mid.append(flower(125, 175, 16, 8, PETALS[0], "#ffd0e4", 0))
mid.append(f'<circle cx="125" cy="175" r="24" fill="none" stroke="{GOLD}" stroke-width="1.3"/>')
mid = "".join(mid)
# The ace: an Ovale Salon lace rosette and a wreath of flowers around the big pip.
ace = []
for k in range(16):
    a = k * 22.5
    x = 125 + 62 * math.cos(math.radians(a)); y = 175 + 62 * math.sin(math.radians(a))
    ace.append(curl(x, y, 9, a + 90, 1 if k % 2 else -1, 1.3))
for k in range(12):
    a = k * 30 + 15
    x = 125 + 80 * math.cos(math.radians(a)); y = 175 + 80 * math.sin(math.radians(a))
    ace.append(leaf(x, y, 12, a + 100, LEAF[k % 3]))
for k in range(8):
    a = k * 45
    x = 125 + 82 * math.cos(math.radians(a)); y = 175 + 82 * math.sin(math.radians(a))
    ace.append(flower(x, y, 11, 6, PETALS[k], "#fff3c4", k * 9))
ace.append(f'<circle cx="125" cy="175" r="48" fill="none" stroke="{GOLD}" stroke-width="1.4"/>')
ace.append(f'<circle cx="125" cy="175" r="44" fill="none" stroke="{GOLD_HI}" stroke-width=".8" stroke-dasharray="1.5 3"/>')
for k in range(24):
    a = math.radians(k * 15)
    ace.append(f'<path d="M{f(125+50*math.cos(a))} {f(175+50*math.sin(a))} L{f(125+56*math.cos(a))} {f(175+56*math.sin(a))}" stroke="{GOLD}" stroke-width="1.1"/>')
ace = "".join(ace)

# THE BACK, after PySolFC tksol back101 (the house back): a chain of scrolls round the border, a mirrored scroll
# band across the middle, here in gold on a powder blue and indigo watercolour wash, with a flowered rosette.
# The ground: a watercolour wash, powder blue and powder indigo, laid as soft blotches. Each blotch is a shape
# pushed out of round by noise and blurred, with a darker tide line where the pigment pooled at its edge.
import random
rnd = random.Random(1966)
WASH = ["#a9c7ec", "#9aa8e6", "#b9d3f2", "#8f9ddc", "#c3cff5", "#9cbbe8", "#a59fe0"]
# Smoothed: the blotches now melt into one continuous gradient, powder blue at the top left running to powder
# indigo at the bottom right, with the layered washes still giving it depth but no edges anywhere.
wc = [f'<rect x="0" y="0" width="250" height="350" fill="url(#orn-wash)"/>']
def jitter_grid(nx, ny, j):
    """Points on an nx-by-ny grid over (and a little past) the card, each nudged at random: full coverage, no rows."""
    for gx in range(nx):
        for gy in range(ny):
            yield ((gx + .5) / nx * 290 - 20 + rnd.uniform(-j, j), (gy + .5) / ny * 390 - 20 + rnd.uniform(-j, j))
# Three layers, back to front: broad pale washes, then mid-size blotches, then small dense blooms. Each layer is one
# group under one displacement-and-blur filter (cheap to draw), and every shape carries its own transparency, so
# overlaps build up darker where they cross, the way glazes of watercolour do.
layers = [
    (list(jitter_grid(3, 4, 30)), (70, 130), (.30, .50), ["#b9d3f2", "#c3cff5", "#a9c7ec", "#b4bdf0"], 1),
    (list(jitter_grid(5, 7, 18)), (28, 66), (.38, .62), ["#9aa8e6", "#a9c7ec", "#8f9ddc", "#9cbbe8", "#a59fe0", "#b6c4f2"], 2),
    ([(rnd.uniform(-5, 255), rnd.uniform(-5, 355)) for _ in range(48)], (6, 22), (.42, .72), ["#8f9ddc", "#7f8fd8", "#9aa8e6", "#8fb2e6", "#9b93dc"], 3),
]
for pts, (r0, r1), (o0, o1), cols, li in layers:
    fill, edge = [], []
    for k, (cx, cy) in enumerate(pts):
        rx, ry = rnd.uniform(r0, r1), rnd.uniform(r0, r1) * rnd.uniform(.7, 1.1)
        t = f'transform="rotate({f(rnd.uniform(0, 180))} {f(cx)} {f(cy)})"'
        col = cols[k % len(cols)]
        fill.append(f'<ellipse cx="{f(cx)}" cy="{f(cy)}" rx="{f(rx)}" ry="{f(ry)}" {t} fill="{col}" opacity="{f(rnd.uniform(o0, o1))}"/>')
        if False:                                     # tide lines retired: the wash is one smooth gradient now
            edge.append(f'<ellipse cx="{f(cx)}" cy="{f(cy)}" rx="{f(rx)}" ry="{f(ry)}" {t} fill="none" stroke="#6a70c8" stroke-width="{f(2.6 - li * .5)}" opacity="{f(.22 + li * .05)}"/>')
    wc.append(f'<g filter="url(#orn-wc{li})">' + "".join(fill) + '</g>')

BK_GOLD = "#a8750f"                                    # deeper gold, to hold its own on the pale wash
bk = ["".join(wc),
      f'<rect x="6" y="6" width="238" height="338" rx="5" fill="none" stroke="{GOLD}" stroke-width="3"/>',
      f'<rect x="12" y="12" width="226" height="326" rx="3" fill="none" stroke="{BK_GOLD}" stroke-width="1"/>',
      f'<rect x="34" y="34" width="182" height="282" rx="2" fill="none" stroke="{GOLD}" stroke-width="1.6"/>',
      f'<rect x="38" y="38" width="174" height="274" rx="2" fill="none" stroke="{GOLD_LO}" stroke-width=".8"/>']
def chain(x0, y0, x1, y1, n):
    out = []
    for k in range(n):
        t = (k + .5) / n; x = x0 + (x1 - x0) * t; y = y0 + (y1 - y0) * t
        ang = math.degrees(math.atan2(y1 - y0, x1 - x0))
        out.append(curl(x, y, 6.5, ang + (90 if k % 2 else -90), 1 if k % 2 else -1, 1.4, BK_GOLD))
    return "".join(out)
bk += [chain(24, 23, 226, 23, 14), chain(24, 327, 226, 327, 14), chain(23, 26, 23, 324, 20), chain(227, 26, 227, 324, 20)]
bk += [dots([(23, 23), (227, 23), (23, 327), (227, 327)], 3.2, BK_GOLD)]
# ELABORATION. Everything below is drawn for one half and turned 180 degrees for the other, like the faces.
half_bk = []
# 1. a gold lace ground over the inner panel (the faces' lace, stronger here so it reads on the wash)
half_bk.append('<rect x="38" y="38" width="174" height="137" fill="url(#orn-lace-tile)" opacity=".55"/>')
# 2. blooms on the corners of the outer scroll chain
half_bk += [flower(23, 23, 9, 6, PETALS[0], "#ffd0e4", 10), flower(227, 23, 9, 6, PETALS[2], "#ffe9ff", 25)]
# 3. corner illuminations inside the panel: gold curls and a small bouquet in each corner
for cx, sx in ((46, 1), (204, -1)):
    half_bk += [curl(cx + sx * 8, 58, 9, 90 if sx > 0 else 90, sx, 1.6, BK_GOLD), curl(cx + sx * 22, 46, 9, 0 if sx > 0 else 180, -sx, 1.6, BK_GOLD),
                curl(cx + sx * 4, 74, 5.5, 270, -sx, 1.1, GOLD), curl(cx + sx * 38, 44, 5.5, 180 if sx > 0 else 0, sx, 1.1, GOLD)]
    half_bk += [leaf(cx, 46, 15, 45 if sx > 0 else 135, LEAF[0]), leaf(cx, 46, 13, 90 if sx > 0 else 90, LEAF[1]), leaf(cx, 46, 13, 0 if sx > 0 else 180, LEAF[2])]
    half_bk += [flower(cx + sx * 12, 62, 7, 5, PETALS[1], "#fff3c4", 15), flower(cx + sx * 24, 50, 6.5, 5, PETALS[4], "#dff0ff", 40),
                flower(cx, 46, 11, 8, PETALS[5], "#ffe0ef", 0), dots([(cx + sx * 30, 60), (cx + sx * 16, 76)], 1.6, PETALS[3])]
# 4. flowering garlands down both sides of the panel, from the corner bouquets to the band
half_bk.append(vine(46, 86, 46, 150, 4.5, 1.5, [PETALS[6], PETALS[3], PETALS[0]], 1))
half_bk.append(vine(204, 86, 204, 150, 4.5, 1.5, [PETALS[4], PETALS[1], PETALS[7]], 2))
bk.append("".join(half_bk) + '<g transform="rotate(180 125 175)">' + "".join(half_bk) + '</g>')
for sg in (1, -1):                                   # the mirrored band across the middle
    y = 175
    bk.append(f'<path d="M50 {y} Q88 {f(y - sg*26)} 125 {y} Q162 {f(y + sg*26)} 200 {y}" fill="none" stroke="{GOLD}" stroke-width="1.6"/>')
    bk.append(curl(62, y - sg * 10, 9, 90 if sg > 0 else 270, sg, 1.5, BK_GOLD)); bk.append(curl(188, y + sg * 10, 9, 270 if sg > 0 else 90, sg, 1.5, BK_GOLD))
for yy, rot in ((92, 0), (92, 180)):                  # top and bottom scroll crowns, the second turned over
    g = [curl(110, yy, 10, 0, -1, 1.6, BK_GOLD), curl(140, yy, 10, 180, 1, 1.6, BK_GOLD), curl(95, yy + 14, 7, 30, 1, 1.2, GOLD),
         curl(155, yy + 14, 7, 150, -1, 1.2, GOLD), leaf(125, yy + 4, 14, 270, LEAF[0]), flower(125, yy - 10, 8, 6, PETALS[2], "#ffe9ff", 0),
         f'<ellipse cx="125" cy="{yy + 26}" rx="34" ry="19" fill="#fbfdff" opacity=".9" filter="url(#orn-soft)"/>',
         f'<text x="125" y="{yy + 34}" text-anchor="middle" font-family="Limelight, Georgia, serif" font-size="22" fill="{BK_GOLD}" stroke="{GOLD_LO}" stroke-width=".6">66</text>']
    bk.append(f'<g transform="rotate({rot} 125 175)">' + "".join(g) + '</g>' if rot else "".join(g))
# 5. the centre medallion: a ring of filigree curls, a dotted gold ring, and a wreath of small flowers
for k in range(16):
    ang = k * 22.5
    bk.append(curl(125 + 31 * math.cos(math.radians(ang)), 175 + 31 * math.sin(math.radians(ang)), 5.5, ang + 90, 1 if k % 2 else -1, 1.2, BK_GOLD))
bk.append(f'<circle cx="125" cy="175" r="27" fill="#f4f7ff" fill-opacity=".55" stroke="{GOLD}" stroke-width="1.2"/>')
for k in range(24):
    ang = math.radians(k * 15)
    bk.append(f'<path d="M{f(125+22*math.cos(ang))} {f(175+22*math.sin(ang))} L{f(125+27*math.cos(ang))} {f(175+27*math.sin(ang))}" stroke="{BK_GOLD}" stroke-width="1"/>')
for k in range(8):
    ang = k * 45 + 22.5
    bk.append(flower(125 + 39 * math.cos(math.radians(ang)), 175 + 39 * math.sin(math.radians(ang)), 5.5, 5, PETALS[(k * 5) % 8], "#fff3c4", k * 9))
bk.append(f'<circle cx="125" cy="175" r="22" fill="#3f4296" stroke="{GOLD}" stroke-width="2"/>')
bk.append(f'<circle cx="125" cy="175" r="18" fill="none" stroke="{BK_GOLD}" stroke-width=".8" stroke-dasharray="1.5 2.5"/>')
for k in range(6):
    a = k * 60 + 30
    bk.append(flower(125 + 30 * math.cos(math.radians(a)), 175 + 30 * math.sin(math.radians(a)), 7, 5, PETALS[(k * 3 + 1) % 8], "#fff3c4", k * 13))
bk.append(flower(125, 175, 14, 8, PETALS[0], "#ffd0e4", 0))
back = "".join(bk)
def wcf(i, seed, freq, scale, blur, edge_blur):
    t = f'<feTurbulence type="fractalNoise" baseFrequency="{freq}" numOctaves="3" seed="{seed}"/><feDisplacementMap in="SourceGraphic" scale="{scale}" xChannelSelector="R" yChannelSelector="G"/>'
    return (f'<filter id="orn-wc{i}" x="-40%" y="-40%" width="180%" height="180%" color-interpolation-filters="sRGB">{t}<feGaussianBlur stdDeviation="{blur}"/></filter>'
            f'<filter id="orn-wce{i}" x="-20%" y="-20%" width="140%" height="140%" color-interpolation-filters="sRGB">{t}<feGaussianBlur stdDeviation="{edge_blur}"/></filter>')
filters = (wcf(1, 7, ".012", 30, 24, 1.6) + wcf(2, 11, ".02", 22, 15, .9) + wcf(3, 23, ".04", 10, 9, .5)
           + '<linearGradient id="orn-wash" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#cfe2f6"/>'
           + '<stop offset=".45" stop-color="#b3c6f0"/><stop offset="1" stop-color="#9c9fe2"/></linearGradient>'
           + '<filter id="orn-grain" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" seed="3"/>'
           + '<feColorMatrix values="0 0 0 0 .35  0 0 0 0 .38  0 0 0 0 .6  0 0 0 .55 -.18"/></filter>')
# PIPS: a deep core, the suit colour through the middle, a fade to near-white just inside the edge (built from the
# pip's own outline, so it follows the lobes of a heart or a club, not a circle), and an outline drawn on top.
PIP = {"S": ("#081a55", "#2b4bb0"), "H": ("#7e0c07", "#dc3a30"), "D": ("#5e3f00", "#c48d12"), "C": ("#073f1a", "#2e9150")}
pips = "".join(f'<radialGradient id="pip-g-{k}" cx=".5" cy="{".42" if k == "H" else ".55"}" r=".62"><stop offset="0" stop-color="{c0}"/>'
               f'<stop offset=".72" stop-color="{c1}"/><stop offset="1" stop-color="{c1}"/></radialGradient>' for k, (c0, c1) in PIP.items())
pips += ('<filter id="pip-edge" x="-15%" y="-15%" width="130%" height="130%" color-interpolation-filters="sRGB">'
         '<feMorphology in="SourceAlpha" operator="erode" radius="2.6" result="core"/>'
         '<feGaussianBlur in="core" stdDeviation="2.4" result="soft"/>'
         '<feComposite in="SourceAlpha" in2="soft" operator="out" result="rim"/>'
         '<feFlood flood-color="#ffffff" flood-opacity=".92"/><feComposite in2="rim" operator="in" result="white"/>'
         '<feMerge><feMergeNode in="SourceGraphic"/><feMergeNode in="white"/></feMerge></filter>')
# The corner numbers have thinner strokes than a pip, so their fade is finer: same recipe, smaller radii.
pips += ('<filter id="rk-edge" x="-15%" y="-15%" width="130%" height="130%" color-interpolation-filters="sRGB">'
         '<feMorphology in="SourceAlpha" operator="erode" radius="1.4" result="core"/>'
         '<feGaussianBlur in="core" stdDeviation="1.5" result="soft"/>'
         '<feComposite in="SourceAlpha" in2="soft" operator="out" result="rim"/>'
         '<feFlood flood-color="#ffffff" flood-opacity=".9"/><feComposite in2="rim" operator="in" result="white"/>'
         '<feMerge><feMergeNode in="SourceGraphic"/><feMergeNode in="white"/></feMerge></filter>')
soft = '<filter id="orn-soft" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur stdDeviation="7"/></filter>'
stripe = '<pattern id="orn-stripe" width="5" height="10" patternUnits="userSpaceOnUse"><rect x="4" width="1" height="10" fill="#edd590" opacity=".28"/></pattern>'

bk70_pattern, back = wallpaper.back70s()   # the 70s flower-power back replaces the watercolour one
js = f'''/* GENERATED by gen/ornament.py — the card ornament, as SVG symbols in one 250 x 350 card box.
 * "orn-half" is the top half (frame, illuminated index corner, bouquet, crest, garland); a card shows it twice,
 * the second turned 180 degrees. "orn-ace" is the lace rosette and wreath behind an Ace; "orn-mid" the smaller
 * medallion in the empty middle of a 2 or a 4; "orn-lace" the faint engraved texture under everything. */
export const ORNAMENT_DEFS = `<svg xmlns="http://www.w3.org/2000/svg" width="0" height="0" style="position:absolute" aria-hidden="true"><defs>
{lace}
{stripe}
{filters}
{pips}
{soft}
<symbol id="orn-back" viewBox="0 0 250 350">{back}</symbol>
{wallpaper.defs()}
{bk70_pattern}
<symbol id="orn-frame" viewBox="0 0 250 350">{frame()}</symbol>
</defs></svg>`;
'''
open("/home/claude/site/app/ui/ornament.js", "w").write(js)
print(len(js), "bytes")
