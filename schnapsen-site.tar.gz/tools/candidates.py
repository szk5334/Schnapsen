"""Candidate sun-print cutouts from the second Archive.zip, each in all four suit inks, for comparison."""
import sys, os
sys.argv = ["prints.py", "/home/claude/ref/archive2", "/tmp/unused"]
sys.path.insert(0, "/home/claude/gen")
import prints
from PIL import Image
import numpy as np
SRC2 = "/home/claude/ref/archive2"
C = {   # name: (file, cx, cy, width as fraction of scan)
 "n00-stitch-sunflower": ("ACM-2011_0004_0104-r001.jpg", .14, .50, .25),
 "n00-stitch-tulips":    ("ACM-2011_0004_0104-r001.jpg", .86, .52, .25),
 "n02-chintz-yellow":    ("CHSDM-1973-51-21MattFlynn.jpg", .5, .5, .55),
 "n03-red-damask":       ("CHSDM-1977-28-9-bMattFlynn.jpg", .55, .38, .62),
 "n04-feather-floral":   ("CHSDM-294456_01-000001.jpg", .55, .30, .80),
 "n04-feather-floral-b": ("CHSDM-294456_01-000001.jpg", .5, .72, .80),
 "n05-flower-lattice":   ("CHSDM-3790258B2C4A2-000001.jpg", .48, .56, .62),
 "n06-trellis-chintz":   ("CHSDM-4B74AA0A8D402-000001.jpg", .5, .42, .68),
 "n07-rose-vine":        ("CHSDM-5D5011E64A462-000001.jpg", .60, .32, .46),
 "n08-white-bouquet":    ("CHSDM-8B07D8BB95A12-000001.jpg", .52, .58, .44),
 "n09-medallion":        ("CHSDM-B15A41F6A8722-000001.jpg", .83, .55, .32),
 "n09-flower-sprays":    ("CHSDM-B15A41F6A8722-000001.jpg", .22, .52, .40),
 "n10-golden-roses":     ("CHSDM-B82BE6B752A72-000001.jpg", .30, .47, .48),
 "n11-chintz-pink-a":    ("CHSDM-C38C74DF205E2-000001.jpg", .5, .30, .80),
 "n11-chintz-pink-b":    ("CHSDM-C38C74DF205E2-000001.jpg", .5, .72, .80),
 "n14-album-quilt":      ("NMAH-80-19790.jpg", .5, .52, .42),
 "n15-plume-drawing":    ("NMAH-RWS2018-00952.jpg", .32, .58, .40),
 "n18-plume-drawing-b":  ("NMAH-RWS2018-00966.jpg", .45, .58, .42),
}
def crop(f, cx, cy, wf, W=250, H=350):
    im = Image.open(os.path.join(SRC2, f)).convert("RGB"); iw, ih = im.size
    w = wf * iw; h = w * 1.4
    if h > ih * .96: h = ih * .96; w = h / 1.4
    x0 = min(max(cx * iw - w / 2, 0), iw - w); y0 = min(max(cy * ih - h / 2, 0), ih - h)
    return im.crop((round(x0), round(y0), round(x0 + w), round(y0 + h))).resize((W, H), Image.LANCZOS), (round(w), round(h))
def metrics(im):
    l = np.asarray(im.convert("L")).astype(float)
    tonal = np.percentile(l, 95) - np.percentile(l, 5)
    gy, gx = np.gradient(l); edge = np.hypot(gx, gy).mean()
    return round(tonal), round(edge, 1)
if __name__ == "__main__":
    out = "/home/claude/ref/cand"
    for name, (f, cx, cy, wf) in C.items():
        raw, (w, h) = crop(f, cx, cy, wf)
        for s in "HSDC":
            im = prints.cyanotype(name + s, raw) if False else None
            prints.INK[name + s] = prints.INK[s]
            prints.cyanotype(name + s, raw).save(f"{out}/{name}-{s}.png")
        print(name, f"src {w}x{h}", metrics(prints.cyanotype(name + "S", raw)))
