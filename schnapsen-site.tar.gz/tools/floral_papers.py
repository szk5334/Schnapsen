"""Royal House: the 2, 3 and 4 papers of each suit, from the Floral Deck repo (manifest.json 'deck' map).
Same treatment as the site's other faces: 250x350, wallpaper set tinted 12% toward the suit (app/prints),
sun-print set from the deck's own sun prints (app/cyano)."""
import json, os, sys, numpy as np
from PIL import Image
F, S = sys.argv[1], sys.argv[2]
m = json.load(open(F + "/manifest.json"))
TINT = {"H": (232, 86, 96), "S": (92, 128, 220), "D": (232, 176, 40), "C": (72, 160, 92)}
def load(p): return Image.open(p).convert("RGB").resize((250, 350), Image.LANCZOS)
def tint(su, im, amt=.12):
    a = np.asarray(im).astype(float); lum = (a @ [.299, .587, .114])[..., None] / 255; t = np.array(TINT[su], float)
    return Image.fromarray(np.clip(a * (1 - amt) + (lum * t + (1 - lum) * t * .25) * amt, 0, 255).astype(np.uint8))
for su in "SHDC":
    for r in "234":
        clip = m["deck"][su][r]
        tint(su, load(f"{F}/full-color-images/{clip}.jpg")).save(f"{S}/prints/{r}{su}.webp", quality=82, method=6)
        sp = [x for x in os.listdir(F + "/sun-print-images") if x.startswith(clip + "-")][0]
        load(f"{F}/sun-print-images/{sp}").save(f"{S}/cyano/{r}{su}.webp", quality=82, method=6)
        print(r + su, clip, sp)
