"""Court figures for classic tables, cut from the vector poker deck Seth supplied (Poker cards.jpg, 600 dpi).
Each figure panel is cropped at its frame, the two suit marks inside the frame are recoloured to the house
four-colour suits, and the panel is saved as WebP for app/courts/."""
import numpy as np
from PIL import Image
from scipy import ndimage
Image.MAX_IMAGE_PIXELS = None
im = np.asarray(Image.open("/home/claude/ref/poker/poker cards.jpg").convert("RGB")).astype(np.int16)
sc = 7016 / 1131
cols = [(80, 193), (203, 316), (326, 439), (449, 562)]
rows = {"K": ((172, 342), "CHDS"), "Q": ((352, 522), "CDHS"), "J": ((535, 705), "CDHS")}
HOUSE = {"S": (16, 42, 117), "H": (181, 28, 21), "D": (148, 101, 0), "C": (18, 95, 43)}
for rank, ((y0, y1), suits) in rows.items():
    for (x0, x1), su in zip(cols, suits):
        card = im[int(y0 * sc):int(y1 * sc), int(x0 * sc):int(x1 * sc)]
        H, W, _ = card.shape
        dark = card.sum(2) < 450
        # the frame: the longest dark runs, as rows and columns
        def longest(a):                       # longest unbroken run of True along axis 0, per column
            best = np.zeros(a.shape[1], int); cur = np.zeros(a.shape[1], int)
            for row in a:
                cur = np.where(row, cur + 1, 0); best = np.maximum(best, cur)
            return best
        vc = longest(dark)
        fx = np.where(vc > H * .33)[0]; fx = fx[(fx > W * .08) & (fx < W * .92)]
        fx0 = fx.min(); fx1 = fx.max() if fx.max() - fx0 > W * .6 else fx0 + int(W * .665)   # a sword can hide one side
        cover = dark[:, fx0 + 12:fx1 - 12].mean(1)
        fy = np.where(cover > .5)[0]; fy = fy[(fy > H * .06) & (fy < H * .95)]
        fy0, fy1 = fy.min(), fy.max()
        if fy1 - fy0 < H * .74: fy1 = fy0 + int(H * .776)                  # same for the bottom rule
        print(rank, su, "frame", fx0, fx1, fy0, fy1, end=" ")
        panel = card[fy0 - 2:fy1 + 3, fx0 - 2:fx1 + 3].copy()
        ph, pw, _ = panel.shape
        r, g, b = panel[..., 0], panel[..., 1], panel[..., 2]
        ink = (panel.sum(2) < 260) if su in "CS" else ((r > 140) & (g < 90) & (b < 90))
        lab, n = ndimage.label(ink)
        sizes = ndimage.sum(ink, lab, range(1, n + 1))
        boxes = ndimage.find_objects(lab)
        done = 0
        for corner in ("tl", "br"):
            best = None
            for k, sl in enumerate(boxes):
                ys, xs = sl
                cy, cx = (ys.start + ys.stop) / 2, (xs.start + xs.stop) / 2
                inside = (cx < pw * .45 and cy < ph * .3) if corner == "tl" else (cx > pw * .55 and cy > ph * .7)
                touches = ys.start <= 6 or xs.start <= 6 or ys.stop >= ph - 6 or xs.stop >= pw - 6
                h_, w_ = ys.stop - ys.start, xs.stop - xs.start
                if inside and not touches and .6 < h_ / max(w_, 1) < 1.6 and h_ > ph * .06 and (best is None or sizes[k] > sizes[best]):
                    best = k
            if best is None: continue
            m = ndimage.binary_dilation(lab == best + 1, iterations=3)
            # recolour by darkness: anti-aliased edges keep their blend with the white ground
            amt = np.clip((765 - panel.sum(2)) / 600, 0, 1) if su in "CS" else np.clip((panel[..., 0] - panel[..., 1]) / 160, 0, 1)
            for ch in range(3):
                panel[..., ch] = np.where(m, (255 - amt * (255 - HOUSE[su][ch])), panel[..., ch])
            done += 1
        panel = panel[8:-7, 8:-7]                                       # inside the black rule; the card draws its own gold one
        out = Image.fromarray(np.clip(panel, 0, 255).astype(np.uint8))
        out = out.resize((200, round(200 * out.size[1] / out.size[0])), Image.LANCZOS)   # ~46 css px on a phone, at 3x and some
        out.save(f"/home/claude/site/app/courts/{rank}{su}.webp", quality=76, method=6)
        print(rank, su, out.size, "recoloured", done)
