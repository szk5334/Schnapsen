/* Copy this file to config.js in the repo root (next to index.html) to change any setting.
 * Every setting is optional — the site works with no config.js at all. */
window.SX_CONFIG = {
  /* Namespace for finding peers. Only devices with the same value see each other. */
  p2pAppId: "szk5334-schnapsen",

  /* TURN relay, for the few networks where two devices can't connect directly (some mobile carriers,
   * strict office Wi-Fi). Free option: make an account at https://www.metered.ca/tools/openrelay/ ,
   * create an app, and paste its credentials URL here, API key included. It looks like:
   *   https://YOUR-APP.metered.live/api/v1/turn/credentials?apiKey=YOUR_KEY                        */
  turnCredentialsUrl: "",

  /* Or give ICE servers directly instead:  [{ urls: "turn:…", username: "…", credential: "…" }] */
  iceServers: [],

  /* Custom Nostr relays for introductions (wss://…). Leave empty for Trystero's defaults. */
  relays: [],
};
