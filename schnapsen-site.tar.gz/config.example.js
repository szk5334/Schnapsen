/* Copy this file to config.js in the repo root (next to index.html) to change any setting.
 * Every setting is optional — the site works with no config.js at all. */
window.SX_CONFIG = {
  /* Namespace: only copies of the site with the same value see each other. */
  p2pAppId: "szk5334-schnapsen",

  /* The Nostr relays that carry everything (sealed). Leave empty for the built-in eight. To choose your own,
   * open #/net on each phone, press "Check relays", and paste the list of relays that said Yes on both.
   * Both phones must share at least one relay. */
  relays: [],
};
