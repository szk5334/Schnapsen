/* Copy this file to config.js in the repo root (next to index.html) to change any setting.
 * Every setting is optional — the site works with no config.js at all. */
window.SX_CONFIG = {
  /* Namespace: only copies of the site with the same value see each other. */
  p2pAppId: "szk5334-schnapsen",

  /* The Nostr relays that carry everything (sealed). Leave empty for the built-in six:
   * relay.damus.io, nos.lol, relay.primal.net, nostr.mom, relay.nostr.net, offchain.pub.
   * Both phones must share at least one relay, so keep the lists the same on every copy. */
  relays: [],
};
