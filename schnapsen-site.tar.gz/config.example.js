/* Copy this file to config.js in the repo root (next to index.html) to change any setting.
 * Every setting is optional — the site works with no config.js at all. */
window.SX_CONFIG = {
  /* Namespace: only copies of the site with the same value see each other. */
  p2pAppId: "szk5334-schnapsen",

  /* Your own relay(s): "wss://…", or a list, best first. Built in: wss://schnapsen-relay.szk5334.workers.dev
   * (the Cloudflare Worker), so leave this out to use it. Setting it replaces the built-in list: add a second
   * relay with ["wss://schnapsen-relay.szk5334.workers.dev", "wss://…"], or "" for public relays only. All game
   * traffic goes to the first one that's up; the next takes over if it goes down; the public relays are only
   * listened to, as the last fallback. Both phones load the same config.js, so they agree on it. */
  // house: ["wss://schnapsen-relay.szk5334.workers.dev"],

  /* The public Nostr relays (sealed traffic, small budgets). Leave empty for the built-in nine. To choose your
   * own, open #/net on each phone, press "Check relays", and paste the list of relays that said Yes on both.
   * Both phones must share at least one relay. */
  relays: [],
};
